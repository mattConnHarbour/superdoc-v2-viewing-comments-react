/**
 * Shallow equality used by the controller to suppress redundant slice
 * notifications. v2-native, dependency-free.
 */
/**
 * Returns `true` when `a` and `b` are the same reference, or are objects with
 * the same own-enumerable keys and `Object.is`-equal values one level deep.
 * Arrays compare by index. Primitives compare with `Object.is`.
 */
export declare function shallowEqual(a: unknown, b: unknown): boolean;
