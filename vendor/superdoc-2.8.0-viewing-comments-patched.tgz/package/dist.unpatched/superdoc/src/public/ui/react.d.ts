import { ReactNode } from 'react';
import { BorrowedSuperDocUI, CommandState, CommentsSlice, ContentControlsSlice, DocumentSlice, FontFamilyOption, FontSizeOption, SelectionSlice, Subscribable, SuperDocLike, ToolbarSnapshotSlice, TrackChangesSlice, ZoomSlice } from './types.js';
/** The raw SuperDoc instance (or host stub) handed to the provider. */
export type SuperDocHost = SuperDocLike;
/** Props accepted by {@link SuperDocUIProvider}. */
export interface SuperDocUIProviderProps {
    /** Child tree that consumes the controller via hooks. */
    children?: ReactNode;
}
/**
 * Root provider. Call {@link useSetSuperDoc} from your editor-mount
 * component's ready callback to bind a running SuperDoc instance; the hooks
 * below then read that instance's own controller (`superdoc.ui`).
 *
 * The provider is a consumer, not an owner. SuperDoc creates the controller
 * and destroys it in `superdoc.destroy()`, so unmounting or rebinding the
 * provider leaves it running for the built-in toolbar and any other consumer
 * of the same instance. Every React hook therefore observes the same command
 * state the rest of the application sees.
 */
export declare function SuperDocUIProvider(props: SuperDocUIProviderProps): import('react').ReactElement;
/**
 * Read the controller, or `null` until a SuperDoc instance is bound.
 *
 * Borrowed: the bound instance owns teardown, so the returned type omits
 * `destroy()`. A provider-built fallback controller is disposed by the provider.
 */
export declare function useSuperDocUI(): BorrowedSuperDocUI | null;
/** Read the raw bound SuperDoc host, or `null` until one is bound. */
export declare function useSuperDocHost(): SuperDocHost | null;
/** Get the stable callback used to bind a running SuperDoc instance. */
export declare function useSetSuperDoc(): (superdoc: SuperDocHost) => void;
/**
 * Minimal value source the slice hooks consume: a synchronous snapshot read
 * plus a value-direct `observe` (immediate first emit, then on change). Every
 * domain handle satisfies this directly; command/font hooks adapt to it.
 */
interface SliceSource<T> {
    getSnapshot(): T;
    observe(listener: (value: T) => void): () => void;
}
/**
 * Normalize a `pick` result into a {@link SliceSource}. Domain handles and the
 * command/font hooks already expose the snapshot-shaped contract
 * (`getSnapshot` + `observe`) and pass through unchanged. A raw `ui.select(...)`
 * {@link Subscribable} (`get` + `subscribe`) is adapted: it `subscribe`s FIRST,
 * then emits the current value, so a synchronous recompute triggered by the
 * first listener is not missed (the substrate's `subscribe` does not emit on
 * attach). Exported for unit tests; not re-exported by the `superdoc/ui/react`
 * facade, so it stays off the public surface.
 */
export declare function toSliceSource<T>(source: SliceSource<T> | Subscribable<T>): SliceSource<T>;
/**
 * Subscribe to a derived slice of controller state. `pick` selects a value
 * source from the controller: a domain handle / snapshot source
 * ({@link SliceSource}) or a raw `ui.select(...)` {@link Subscribable}, both
 * normalized via {@link toSliceSource}. `initial` is returned until the
 * controller is bound.
 */
export declare function useSuperDocSlice<T>(pick: (ui: BorrowedSuperDocUI) => SliceSource<T> | Subscribable<T>, initial: T): T;
/** Subscribe to the selection slice. */
export declare function useSuperDocSelection(): SelectionSlice;
/** Subscribe to the comments slice. */
export declare function useSuperDocComments(): CommentsSlice;
/** Subscribe to the content-controls slice. */
export declare function useSuperDocContentControls(): ContentControlsSlice;
/** Subscribe to the track-changes slice. */
export declare function useSuperDocTrackChanges(): TrackChangesSlice;
/** Subscribe to the toolbar snapshot slice. */
export declare function useSuperDocToolbar(): ToolbarSnapshotSlice;
/** Subscribe to a single command's enable/active state. */
export declare function useSuperDocCommand(id: string): CommandState;
/** Subscribe to the document slice. */
export declare function useSuperDocDocument(): DocumentSlice;
/** Subscribe to available font-family options. */
export declare function useSuperDocFontOptions(): readonly FontFamilyOption[];
/** Subscribe to available font-size options. */
export declare function useSuperDocFontSizeOptions(): readonly FontSizeOption[];
/** Subscribe to the zoom slice. */
export declare function useSuperDocZoom(): ZoomSlice;
export {};
