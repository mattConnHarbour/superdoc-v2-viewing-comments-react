/**
 * Maps SDRunProps field names to InlineRunPatch field names.
 * SDRunProps (read-side) and InlineRunPatch (write-side) use different keys
 * for the same properties; direct assignment between them is forbidden.
 *
 * @param {Record<string, unknown>} props - SDRunProps object from doc.getNodeById
 * @returns {Record<string, unknown>} InlineRunPatch ready for doc.format.apply
 */
export function sdRunPropsToInlineRunPatch(props: Record<string, unknown>): Record<string, unknown>;
/**
 * Returns true when a selection segment spans the full visible text of its block.
 * A collapsed caret is NOT a full paragraph.
 *
 * @param {{ range: { start: number; end: number } }} segment
 * @param {number | null | undefined} blockVisibleLength
 */
export function isFullParagraph(segment: {
    range: {
        start: number;
        end: number;
    };
}, blockVisibleLength: number | null | undefined): boolean;
/**
 * Serializes a selection to a stable string key used to detect whether
 * the target selection is the same as the source (skip apply in that case).
 *
 * Falls back to the plain text target when the host has not populated an
 * explicit `selectionTarget` yet.
 *
 * @param {{ selectionTarget?: unknown; target?: unknown } | null | undefined} selection
 * @returns {string}
 */
export function selectionKey(selection: {
    selectionTarget?: unknown;
    target?: unknown;
} | null | undefined): string;
