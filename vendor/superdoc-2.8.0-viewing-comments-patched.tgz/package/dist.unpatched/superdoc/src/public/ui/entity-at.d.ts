import { ViewportEntityHit } from './types.js';
/**
 * A collected hit, optionally carrying the raw painter `data-story-key` string
 * read off the run/marker element. `storyKey` is an internal carrier the
 * controller PREFERS over the layout-story when mapping a tracked change to a
 * public {@link StoryLocator}; it is never surfaced on a returned public hit
 * (the controller resolves a locator from it, then builds the public hit
 * fresh). Kept off the public {@link ViewportEntityHit} so consumers still only
 * switch on the typed public shape.
 */
export interface CollectedEntityHit extends ViewportEntityHit {
    storyKey?: string;
}
/**
 * Read painted entities off `el` and every ancestor up to the document root, or
 * up to and INCLUDING `stopAt` when given. Innermost-first ordering: a tracked
 * change inside a comment highlight returns `[{ trackedChange }, { comment }]`,
 * matching what a switch on `hits[0]` expects when picking the most specific
 * entity.
 *
 * `stopAt` bounds the walk to the visible host: its own attributes are read, but
 * the walk never climbs into an app wrapper ABOVE it, so wrapper data-* cannot
 * leak into the hits. Omitting it keeps the original walk-to-document-root.
 *
 * Returns `[]` for null / non-Element starts. Uses duck-typed `getAttribute`
 * access so it works under any DOM implementation (happy-dom, jsdom, real
 * browser) without an `instanceof` check that could fail across realms.
 */
export declare function collectEntityHitsFromChain(start: Element | null, stopAt?: Element | null): CollectedEntityHit[];
