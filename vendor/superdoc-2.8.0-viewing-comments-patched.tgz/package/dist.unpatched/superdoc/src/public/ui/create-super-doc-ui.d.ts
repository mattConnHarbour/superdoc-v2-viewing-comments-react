import { SuperDocUI, SuperDocUIOptions } from './types.js';
/**
 * Heavy-read policy for the async read coordinator (source-loading deferral).
 * One shared table: the coordinator's gate and the table-driven policy tests
 * both consume THIS list, so the deferred set cannot silently drift from the
 * tested set. Keys are coordinator cache keys (exact) or key families
 * (prefix). See the gate in `readAsync` for the runtime semantics.
 */
export interface HeavyDocReadPolicyEntry {
    key: string;
    match: 'exact' | 'prefix';
    /** Audit rationale — why this key is catalog-scale (or reserved). */
    note: string;
}
export declare const HEAVY_DOC_READ_POLICY: readonly HeavyDocReadPolicyEntry[];
/** Whether a coordinator cache key falls under the heavy-read policy. */
export declare function isHeavyDocReadKey(key: string): boolean;
export declare function createSuperDocUI(options: SuperDocUIOptions): SuperDocUI;
