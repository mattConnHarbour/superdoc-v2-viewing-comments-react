import { SuperDoc } from './core/SuperDoc.js';
export default SuperDoc;
