/**
 * Classify the tracked-change identities carried by a v2 mutation event.
 *
 * Receipt entities are the durable invalidation contract between the document
 * kernel and derived review UI. Direct receipts carry entity refs; mutation
 * plans carry the same identities through `trackedChanges` and per-step ids.
 */
export function getV2TrackedChangeMutationImpact(event: any): {
    allResolved?: any;
    upsertIds: Set<any>;
    removedIds: Set<any>;
    remappedPairs: {
        from: string;
        to: string;
    }[];
    reconcileMode: string;
} | null;
