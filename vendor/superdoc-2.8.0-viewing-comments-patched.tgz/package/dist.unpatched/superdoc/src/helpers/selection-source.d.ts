export const DOCUMENT_EDITOR_SELECTION_SOURCE: "document-editor";
