/**
 * Collect tracked-change mark IDs from ranges touched by an editor transaction.
 *
 * @param {import('../core/types/index.js').EditorTransactionLike} transaction
 * @param {object} [options]
 * @param {object|null} [options.trackChangesPluginKey] - The TrackChangesBasePluginKey to read metadata from
 * @returns {Set<string>} Set of tracked-change mark IDs
 */
export function collectTouchedTrackedChangeIds(transaction: import('../core/types/index.js').EditorTransactionLike, { trackChangesPluginKey }?: {
    trackChangesPluginKey?: object | null | undefined;
}): Set<string>;
