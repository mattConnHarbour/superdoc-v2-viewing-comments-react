export function groupChanges(changes: any[]): any[];
