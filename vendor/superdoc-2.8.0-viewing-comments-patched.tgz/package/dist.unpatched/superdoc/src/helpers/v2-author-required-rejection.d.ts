/**
 * @param {any} event - a `v2-host-event` payload.
 * @returns {boolean} true when the rejection means the session needs an author.
 */
export function isV2AuthorRequiredRejection(event: any): boolean;
/**
 * Deduplicate the non-terminal notification per mounted document/session.
 * A successful mutation or a reopened session clears only its own scope, so a
 * rejection in one document cannot silence another document in the same
 * SuperDoc instance.
 */
export function createV2AuthorRequiredNotificationGate(): {
    shouldNotify(scope: any, event: any): boolean;
    clear(scope: any): void;
};
/** Stable, non-terminal exception code surfaced to consumers. */
export const V2_AUTHOR_REQUIRED_CODE: "author-required";
/**
 * Content-safe, actionable message. Contains no document text, imported author,
 * email, path, or source key — only how to fix the configuration.
 */
export const V2_AUTHOR_REQUIRED_MESSAGE: "This edit needs an author identity. Set `user.name` in your SuperDoc configuration and reopen the document to make tracked or revision-overlapping edits.";
