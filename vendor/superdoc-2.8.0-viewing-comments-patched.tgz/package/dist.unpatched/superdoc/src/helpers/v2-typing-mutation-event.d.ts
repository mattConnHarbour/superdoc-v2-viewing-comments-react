export function isV2EditableTextMutationEvent(event: {
    type?: string;
    origin?: string;
    editableCommandKind?: string;
} | null | undefined): boolean;
