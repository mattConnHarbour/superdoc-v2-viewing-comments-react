/**
 * Detect whether an editor transaction touches a structural row tracked
 * change (whole-table insert/delete encoded on `tableRow.attrs.trackChange`).
 *
 * Structural row revisions live on node attributes — NOT on inline marks — so
 * the inline `collectTouchedTrackedChangeIds` scan never reports them. When such
 * a node-attr change is part of a transaction, the right-rail structural bubble
 * sync must run a FULL resync (the targeted, id-based resync path only refreshes
 * inline mark bubbles). This helper flags those transactions so the caller can
 * force a full resync, mirroring how inline mark edits trigger sidebar refresh.
 *
 * Conservative by design: returns true if any node within a changed range is a
 * `tableRow` carrying a `rowInsert`/`rowDelete` `trackChange`. False positives
 * only cost an extra full resync; false negatives would silently drop the bubble.
 *
 * @param {import('../core/types/index.js').EditorTransactionLike} transaction
 * @returns {boolean}
 */
export function transactionTouchesStructuralChange(transaction: import('../core/types/index.js').EditorTransactionLike): boolean;
