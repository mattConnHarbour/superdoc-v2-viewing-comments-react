/**
 * Whether a context-menu event landed inside the tracked-change carrier that
 * is already visually active. The review visual owner maintains this marker,
 * so the right-click path can stay synchronous and avoid a catalog lookup or
 * document-wide DOM query.
 *
 * @param {EventTarget | null} target
 * @returns {boolean}
 */
export function isActiveTrackedChangeContextMenuTarget(target: EventTarget | null): boolean;
/**
 * Normalize adaptive comments UI policy fields.
 *
 * @param {false | Record<string, unknown> | undefined} commentsConfig
 * @returns {false | Record<string, unknown> | undefined}
 */
export function normalizeCommentsUiPolicy(commentsConfig: false | Record<string, unknown> | undefined): false | Record<string, unknown> | undefined;
export const COMPACT_ANCHOR_SELECTOR: "[data-track-change-id], .superdoc-comment-highlight, .sd-comment-anchor";
export const DEFAULT_COMMENTS_SIDEBAR_LANE_PX: 320;
export const DEFAULT_COMMENTS_MIN_GUTTER_PX: 24;
export const DEFAULT_DOCUMENT_VISIBLE_MIN_WIDTH_PX: 816;
export const RIGHT_CLICK_COMMENT_SUPPRESS_MS: 250;
export const DEFAULT_COMMENTS_DISPLAY_MODE: "sidebar";
export const VALID_COMMENTS_DISPLAY_MODES: Set<string>;
