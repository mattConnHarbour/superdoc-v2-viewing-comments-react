export function isV2RangeSnapshot(snapshot: {
    anchor?: {
        blockId?: unknown;
        blockOffset?: unknown;
    };
    focus?: {
        blockId?: unknown;
        blockOffset?: unknown;
    };
} | null | undefined): boolean;
export function hasOutsideV2DomRangeSelection(selection: Selection | null | undefined, root: Node | null | undefined): boolean;
export function shouldPreserveHostV2Selection(documentMode: string | null | undefined, hostSnapshot: unknown): boolean;
