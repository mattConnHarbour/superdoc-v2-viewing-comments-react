/**
 * Resolve the comments-store identity for a document-origin v2 review target.
 * Painted review carriers can become interactive before the asynchronous row
 * hydration finishes. In that window the host's canonical entity id remains
 * the correct pending active identity; once hydrated, the row aliases win.
 */
export function resolveV2ReviewTargetCommentId(target: any, getComment: any): any;
