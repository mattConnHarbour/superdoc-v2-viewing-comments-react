export function floor(val: number, precision?: number): number;
