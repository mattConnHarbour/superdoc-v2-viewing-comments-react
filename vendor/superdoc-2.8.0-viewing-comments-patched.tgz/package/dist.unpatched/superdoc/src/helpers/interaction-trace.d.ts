/**
 * @param {string} stage
 * @param {string} branch
 * @param {Record<string, unknown> | undefined} [meta]
 * @returns {{ traceId: string, spanId: string } | null}
 */
export function startInteractionSpan(stage: string, branch: string, meta?: Record<string, unknown> | undefined): {
    traceId: string;
    spanId: string;
} | null;
/**
 * @param {{ traceId: string, spanId: string } | null | undefined} span
 * @param {Record<string, unknown> | undefined} [meta]
 */
export function endInteractionSpan(span: {
    traceId: string;
    spanId: string;
} | null | undefined, meta?: Record<string, unknown> | undefined): void;
/**
 * @param {string} stage
 * @param {string} branch
 * @param {Record<string, unknown> | undefined} meta
 * @param {() => any} fn
 * @returns {any}
 */
export function withInteractionSpan(stage: string, branch: string, meta: Record<string, unknown> | undefined, fn: () => any): any;
