import { useSuperdocStore } from '../stores/superdoc-store.js';
import { useCommentsStore } from '../stores/comments-store.js';
import { useHighContrastMode } from '../composables/use-high-contrast-mode.js';
export function createSuperdocVueApp({ disablePiniaDevtools }?: {
    disablePiniaDevtools?: boolean | undefined;
}): SuperdocVueAppRefs;
/**
 * Result of `createSuperdocVueApp()`. Internal-only: the shape is consumed
 * by `SuperDoc.#initVueApp` and is not part of the public surface.
 */
export type SuperdocVueAppRefs = {
    /**
     * The Vue 3 app instance
     */
    app: import('vue').App;
    /**
     * The Pinia store instance attached to `app`
     */
    pinia: import('pinia').Pinia;
    /**
     * The SuperDoc Pinia store
     */
    superdocStore: ReturnType<typeof useSuperdocStore>;
    /**
     * The Comments Pinia store
     */
    commentsStore: ReturnType<typeof useCommentsStore>;
    /**
     * The high-contrast mode composable refs (`isHighContrastMode`, `setHighContrastMode`). Named `*Store` for historical reasons; this is a plain Vue composable, not a Pinia store.
     */
    highContrastModeStore: ReturnType<typeof useHighContrastMode>;
};
