/**
 * Replace the package loader before engine loading starts. The CDN entry uses
 * this seam to fetch the exact engine version from its public package URL.
 *
 * @param {() => Promise<unknown>} loader
 */
export function configureDefaultV2IntegrationLoader(loader: () => Promise<unknown>): void;
/** Load the engine before Vue evaluates the synchronous integration seam. */
export function loadDefaultV2Integration(): Promise<void>;
/** Load the engine for editor startup, preserving the fail-closed stub on failure. */
export function loadDefaultV2IntegrationOrFallback(): Promise<void>;
/**
 * @param {unknown} item
 * @returns {boolean}
 */
export function isSyntheticTrackedChangeCommentLaneItem(item: unknown): boolean;
/**
 * @param {{ trackedChange?: unknown, trackedChangeAnchorKey?: unknown } | null | undefined} row
 * @returns {boolean}
 */
export function isV2SyntheticTrackedChangeRow(row: {
    trackedChange?: unknown;
    trackedChangeAnchorKey?: unknown;
} | null | undefined): boolean;
/**
 * @returns {SuperDocV2Integration}
 */
export function createStubV2Integration(): SuperDocV2Integration;
/**
 * Build the default v2 integration the runtime always uses. The v2
 * browser shell is the only source of the editor runtime; no customer-provided
 * integration is consulted. Falls back to the local stub only if the engine
 * shell throws during construction (defensive, never selects v1).
 *
 * @returns {SuperDocV2Integration}
 */
export function createDefaultV2Integration(): SuperDocV2Integration;
/**
 * Backwards-compatible alias. The v2 branch no longer reads any customer
 * config; the parameter is ignored and retained only so existing call sites do
 * not need to change in lockstep with this internalization.
 *
 * @returns {SuperDocV2Integration}
 */
export function resolveV2Integration(): SuperDocV2Integration;
/**
 * @param {SuperDocV2Integration | null | undefined} integration
 * @returns {boolean}
 */
export function hasRealV2Integration(integration: SuperDocV2Integration | null | undefined): boolean;
/**
 * @typedef {Object} SuperDocV2Integration
 * @property {number} version Integration contract version.
 * @property {unknown} [capabilities] Optional capability snapshot/hints.
 * @property {unknown} EditorComponent Vue component that boots the V2 DOCX editor.
 * @property {unknown} [RulerComponent] Optional Vue component for the V2 ruler.
 * @property {(...args: unknown[]) => unknown} [createGeometryPublisher] Factory for the V2 geometry publisher.
 * @property {(...args: unknown[]) => unknown} [createReviewWindowController] Factory for the committed V2 review-window controller.
 * @property {(value: unknown) => boolean} [isSyntheticTrackedChangeCommentLaneItem] Predicate for synthetic tracked-change comment-lane items.
 * @property {(value: unknown) => boolean} [isV2SyntheticTrackedChangeRow] Predicate for synthesized V2 tracked-change rows.
 */
/** Default version for the local stub integration (V1-compatible). */
export const SUPERDOC_V2_INTEGRATION_VERSION: 1;
export type SuperDocV2Integration = {
    /**
     * Integration contract version.
     */
    version: number;
    /**
     * Optional capability snapshot/hints.
     */
    capabilities?: unknown;
    /**
     * Vue component that boots the V2 DOCX editor.
     */
    EditorComponent: unknown;
    /**
     * Optional Vue component for the V2 ruler.
     */
    RulerComponent?: unknown;
    /**
     * Factory for the V2 geometry publisher.
     */
    createGeometryPublisher?: ((...args: unknown[]) => unknown) | undefined;
    /**
     * Factory for the committed V2 review-window controller.
     */
    createReviewWindowController?: ((...args: unknown[]) => unknown) | undefined;
    /**
     * Predicate for synthetic tracked-change comment-lane items.
     */
    isSyntheticTrackedChangeCommentLaneItem?: ((value: unknown) => boolean) | undefined;
    /**
     * Predicate for synthesized V2 tracked-change rows.
     */
    isV2SyntheticTrackedChangeRow?: ((value: unknown) => boolean) | undefined;
};
