/**
 * @param {typeof globalThis} globalObject
 * @param {string} engineVersion
 * @param {string | null} buildOverride
 */
export function resolveDocxEngineCdnBaseUrl(globalObject: typeof globalThis, engineVersion: string, buildOverride?: string | null): any;
/** @param {{ engineVersion: string, buildBaseUrl: string | null }} options */
export function configureCdnEngineLoader({ engineVersion, buildBaseUrl }: {
    engineVersion: string;
    buildBaseUrl: string | null;
}): void;
/**
 * @param {string} url
 * @returns {Promise<void>}
 */
export function loadStylesheetOnce(url: string): Promise<void>;
