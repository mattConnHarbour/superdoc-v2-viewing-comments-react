export function readSuperDocV2BrowserRuntime(globalObject?: typeof globalThis): any;
export function installSuperDocV2BrowserRuntime(runtime?: {}, globalObject?: typeof globalThis): any;
export const SUPERDOC_V2_BROWSER_RUNTIME_GLOBAL_KEY: "__SUPERDOC_V2_BROWSER_RUNTIME__";
