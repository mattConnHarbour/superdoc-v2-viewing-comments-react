import { EditorRuntime, EditorRuntimeDocumentMode, EditorRuntimeId, EditorRuntimeState } from '../index.js';
export interface FakeV2RuntimeOptions {
    id?: EditorRuntimeId;
    documentId?: string;
    root?: HTMLElement;
    initialState?: EditorRuntimeState;
    initialDocumentMode?: EditorRuntimeDocumentMode;
}
export declare function createFakeV2Runtime(options?: FakeV2RuntimeOptions): EditorRuntime;
