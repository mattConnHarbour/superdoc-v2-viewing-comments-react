import { EditorRuntimeId } from './types.js';
/**
 * The data attribute the shell stamps on each runtime's host wrapper element.
 * `EditorRuntimeRegistry.resolveFromEventTarget` walks up from an event target
 * to the nearest element carrying this attribute.
 */
export declare const RUNTIME_ROOT_ATTRIBUTE = "data-superdoc-runtime-id";
/**
 * Mark a shell-owned host element as the root for a mounted runtime.
 *
 * Call this on the wrapper the shell owns around a runtime, not on painter DOM.
 *
 * @param root The shell-owned host wrapper element.
 * @param id The runtime id to associate with this root.
 */
export declare function markRuntimeRoot(root: HTMLElement, id: EditorRuntimeId): void;
/**
 * Remove the runtime-root marker from a host element.
 *
 * @param root The shell-owned host wrapper element.
 */
export declare function unmarkRuntimeRoot(root: HTMLElement): void;
/**
 * Read the runtime id marked directly on an element, or `null` when absent.
 *
 * This reads the attribute off the given element only; it does not walk
 * ancestors. Use `EditorRuntimeRegistry.resolveFromEventTarget` for the
 * ancestor walk from an arbitrary event target.
 *
 * @param root The element to inspect.
 * @returns The marked runtime id, or `null`.
 */
export declare function readRuntimeRootId(root: Element | null): EditorRuntimeId | null;
