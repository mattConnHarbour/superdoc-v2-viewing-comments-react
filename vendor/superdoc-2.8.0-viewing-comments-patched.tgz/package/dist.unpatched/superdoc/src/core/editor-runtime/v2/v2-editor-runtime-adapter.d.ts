import { EditorRuntime, EditorRuntimeDocumentMode, EditorRuntimeId, EditorRuntimeState } from '../index.js';
type HostLifecycleState = EditorRuntimeState | 'ready';
type HostCommandKind = 'text.insert' | 'text.replace' | 'text.deleteBackward' | 'text.deleteForward' | 'text.pastePlain' | 'history.undo' | 'history.redo' | 'structural.enter' | 'structural.listIndent' | 'structural.listOutdent' | string;
interface HostCommandSupportRecordLike {
    readonly command: HostCommandKind | string;
    readonly status: 'supported' | 'unsupported';
    readonly rejectionCode?: string | null;
    readonly reason?: string | null;
    readonly detail?: string | null;
    readonly enabled?: boolean;
}
interface HostSelectionStateLike {
    readonly anchor: unknown;
    readonly focus: unknown;
}
interface HostSelectionControllerLike {
    getSnapshot(): HostSelectionStateLike | null;
    subscribe(listener: (snapshot: HostSelectionStateLike | null) => void): () => void;
}
interface HostHandlesLike {
    readonly editing: {
        readonly selection: HostSelectionControllerLike;
    } | null;
}
interface HostEditableSubsetSnapshotLike {
    readonly editingMounted: boolean;
    readonly commands: readonly HostCommandSupportRecordLike[];
}
interface HostSnapshotLike {
    readonly state: HostLifecycleState;
    readonly documentMode: EditorRuntimeDocumentMode;
    readonly reason?: string;
    readonly detail?: string;
    readonly commentCommandsReason?: 'author-required' | null;
    readonly editableSubset: HostEditableSubsetSnapshotLike;
}
interface HostDispatchRejectionLike {
    readonly code: string;
    readonly detail?: string;
}
type HostDispatchResultLike = {
    readonly status: 'committed';
    readonly receipt?: unknown;
} | {
    readonly status: 'history-committed';
    readonly result?: unknown;
} | {
    readonly status: 'history-noop';
    readonly result?: {
        readonly reason?: string;
    };
} | {
    readonly status: 'receipt-failure';
    readonly failure?: unknown;
} | {
    readonly status: 'rejected';
    readonly rejection: HostDispatchRejectionLike;
};
type MaybePromise<T> = T | Promise<T>;
type HostCommandLike = {
    readonly kind: 'text.insert';
    readonly text: string;
} | {
    readonly kind: 'text.replace';
    readonly text: string;
} | {
    readonly kind: 'text.deleteBackward';
} | {
    readonly kind: 'text.deleteForward';
} | {
    readonly kind: 'text.pastePlain';
    readonly text: string;
} | {
    readonly kind: 'history.undo';
} | {
    readonly kind: 'history.redo';
} | {
    readonly kind: 'structural.enter';
} | {
    readonly kind: 'structural.listIndent';
} | {
    readonly kind: 'structural.listOutdent';
};
interface DocumentFacadeReceiptLike {
    readonly success?: boolean;
    readonly failure?: unknown;
}
interface DocumentFacadeHistoryResultLike {
    readonly noop?: boolean;
    readonly reason?: string;
}
interface DocumentFacadeSelectionInfoLike {
    readonly empty?: boolean;
    readonly target?: unknown;
}
interface DocumentFacadeLike {
    readonly comments?: {
        create?(input: {
            text: string;
            target?: unknown;
            parentCommentId?: string;
        }): MaybePromise<DocumentFacadeReceiptLike>;
        patch?(input: {
            commentId: string;
            text?: string;
            status?: 'resolved' | 'active';
        }): MaybePromise<DocumentFacadeReceiptLike>;
        delete?(input: {
            commentId: string;
        }): MaybePromise<DocumentFacadeReceiptLike>;
    };
    readonly trackChanges?: {
        decide?(input: {
            decision: 'accept' | 'reject';
            target: {
                kind: 'id';
                id: string;
            } | {
                kind: 'all';
            };
        }): MaybePromise<DocumentFacadeReceiptLike>;
    };
    readonly history?: {
        undo?(): MaybePromise<DocumentFacadeHistoryResultLike>;
        redo?(): MaybePromise<DocumentFacadeHistoryResultLike>;
    };
    readonly selection?: {
        current?(input?: {
            includeText?: boolean;
        }): MaybePromise<DocumentFacadeSelectionInfoLike>;
    };
}
type DocumentFacadeResultLike = {
    readonly available: true;
    readonly doc: DocumentFacadeLike;
} | {
    readonly available: false;
    readonly reason?: string;
};
interface HostPageMetricsSnapshotLike {
    readonly pages: readonly unknown[];
    readonly zoom: {
        readonly percent: number;
    };
}
interface HostSetZoomResultLike {
    readonly status: 'ok' | 'rejected';
    readonly reason?: string;
}
interface HostFocusHandleLike {
    focus?(options?: unknown): boolean | void | Promise<boolean | void>;
}
interface HostMountHandleLike {
    readonly focus: HostFocusHandleLike | null;
}
interface ModeAwareHostLike {
    getSnapshot(): HostSnapshotLike;
    subscribe(listener: (snapshot: HostSnapshotLike) => void): () => void;
    getDocumentMode(): EditorRuntimeDocumentMode;
    setDocumentMode(mode: EditorRuntimeDocumentMode): void;
    setTrackedChangesRenderOptions(options?: {
        mode?: 'review' | 'original' | 'final' | 'off';
        enabled?: boolean;
    }): void;
    dispatch(command: HostCommandLike): Promise<HostDispatchResultLike>;
    save(options?: {
        format?: 'docx';
        commentExportMode?: 'preserve' | 'strip';
    }): Promise<ArrayBuffer>;
    dispose(): Promise<void>;
    getHandles(): HostHandlesLike;
    getDocumentFacade?(): DocumentFacadeResultLike;
    getPageMetricsSnapshot(): HostPageMetricsSnapshotLike;
    subscribePageMetrics?(listener: (snapshot: HostPageMetricsSnapshotLike) => void): () => void;
    setZoom(percent: number): HostSetZoomResultLike;
}
export interface V2EditorRuntimeAdapterOptions {
    readonly id: EditorRuntimeId;
    readonly documentId: string;
    readonly root: HTMLElement;
    readonly host: ModeAwareHostLike;
    readonly getLegacyEditorProjection?: () => unknown;
    readonly onUnregister?: (id: EditorRuntimeId) => void;
}
export declare function createV2EditorRuntimeAdapter(options: V2EditorRuntimeAdapterOptions): {
    runtime: EditorRuntime;
    attachMountHandle(handle: HostMountHandleLike | null): void;
};
export {};
