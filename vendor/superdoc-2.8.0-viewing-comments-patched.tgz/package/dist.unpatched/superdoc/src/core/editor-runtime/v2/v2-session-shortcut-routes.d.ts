/**
 * The narrow slice of the public Document API facade (`activeEditor.doc`) the
 * reference shortcuts route through. Every method is optional so capability is
 * detected per facade rather than assumed.
 */
interface ReferenceDocumentApi {
    selection?: {
        current?: (input?: unknown) => unknown;
    };
    toc?: {
        list?: () => unknown;
        update?: (input: unknown) => unknown;
    };
    fields?: {
        list?: () => unknown;
        rebuild?: (input: unknown) => unknown;
        insert?: (input: unknown) => unknown;
    };
    index?: {
        list?: () => unknown;
        rebuild?: (input: unknown) => unknown;
    };
}
interface SessionShortcutRouteResult {
    handled: boolean;
    reason?: string;
}
type RouteReturn = SessionShortcutRouteResult | boolean;
interface SessionShortcutRoutes {
    focusToolbar?: () => RouteReturn;
    focusHeaderFooter?: (region: 'header' | 'footer') => RouteReturn;
    exitSession?: () => RouteReturn;
    updateFields?: () => RouteReturn;
    insertPageField?: (kind: 'page' | 'numpages') => RouteReturn;
}
export interface CreateV2SessionShortcutRoutesDeps {
    /** Resolve the live toolbar container element for this SuperDoc instance. */
    resolveToolbarElement: () => HTMLElement | null | undefined;
    /** Resolve the live public Document API facade, or null when unavailable. */
    getDocumentApi: () => ReferenceDocumentApi | null | undefined;
}
/**
 * Build the durable session/reference shortcut routes. Returned routes match the
 * `SessionShortcutRoutes` shape consumed by `bindV2SessionShortcuts`.
 */
export declare function createV2SessionShortcutRoutes(deps: CreateV2SessionShortcutRoutesDeps): SessionShortcutRoutes;
export {};
