import { EditorRuntime, EditorRuntimeId } from './types.js';
/**
 * Payload emitted whenever the active runtime changes (including when the active
 * runtime is unregistered and active state clears).
 */
export interface EditorRuntimeRegistryActiveChange {
    /** Runtime id that was active before this change, or `null`. */
    readonly previousRuntimeId: EditorRuntimeId | null;
    /** Runtime id that is active after this change, or `null` when cleared. */
    readonly nextRuntimeId: EditorRuntimeId | null;
    /** Stable reason string describing why the active runtime changed. */
    readonly reason: string;
    /**
     * The next active runtime's compatibility projection, if it exposes one. This
     * is the value SuperDoc routes through `setActiveEditor(...)` to keep the
     * `activeEditor` compatibility surface populated. `null` when the active
     * runtime was cleared or the runtime has no legacy projection.
     */
    readonly legacyEditorProjection: unknown | null;
}
export type EditorRuntimeRegistryListener = (change: EditorRuntimeRegistryActiveChange) => void;
export type EditorRuntimeRegistryUnsubscribe = () => void;
/**
 * Internal SuperDoc registry of mounted editor runtimes and the active-runtime
 * routing policy. Not a public SDK surface.
 */
export declare class EditorRuntimeRegistry {
    #private;
    /**
     * Register a mounted runtime.
     *
     * Does NOT auto-activate the runtime  -  activation is always an explicit
     * `setActive(...)` decision so cleanup never silently retargets commands.
     *
     * @param runtime The runtime to register.
     * @throws If a runtime with the same id is already registered, or a different
     *   runtime is already registered against the same root element.
     */
    register(runtime: EditorRuntime): void;
    /**
     * Unregister a runtime by id.
     *
     * If the unregistered runtime is the active one, active state is CLEARED and an
     * active-change event with `nextRuntimeId: null` is emitted. The registry must
     * NOT auto-promote another runtime to active  -  that would silently retarget
     * commands to a different document (the runtime contract, exit criteria §7).
     *
     * @param runtimeId The runtime id to remove.
     * @returns `true` when a runtime was removed, `false` when none matched.
     */
    unregister(runtimeId: EditorRuntimeId): boolean;
    /**
     * Get a registered runtime by id.
     *
     * @param runtimeId The runtime id.
     * @returns The runtime, or `null` when not registered.
     */
    get(runtimeId: EditorRuntimeId): EditorRuntime | null;
    /**
     * All registered runtimes, in registration order.
     */
    getAll(): EditorRuntime[];
    /**
     * All registered runtimes for a document id, in registration order.
     *
     * Returns every match rather than silently picking the first, because two
     * runtimes can legitimately back the same document.
     *
     * @param documentId The document id to match.
     * @returns The matching runtimes (possibly empty).
     */
    getAllByDocumentId(documentId: string): EditorRuntime[];
    /**
     * The currently active runtime, or `null` when none is active.
     */
    getActive(): EditorRuntime | null;
    /**
     * The currently active runtime id, or `null`.
     */
    getActiveId(): EditorRuntimeId | null;
    /**
     * Select the active runtime (or clear it with `null`).
     *
     * Idempotent: selecting the already-active runtime is a no-op and emits
     * nothing, so it does not trigger a redundant toolbar rebind.
     *
     * @param runtimeId The runtime id to activate, or `null` to clear active state.
     * @param reason Stable reason string for the active-change event.
     * @throws If `runtimeId` is non-null and not registered.
     */
    setActive(runtimeId: EditorRuntimeId | null, reason: string): void;
    /**
     * Resolve the runtime that owns a DOM event target by walking up to the
     * nearest element carrying the shell-owned root marker.
     *
     * This selects a runtime only; it performs no coordinate-to-position mapping
     * and no command dispatch.
     *
     * @param target An event target (typically `event.target`), node, or `null`.
     * @returns The owning runtime, or `null` when no marked root is found or the
     *   marked id is not registered.
     */
    resolveFromEventTarget(target: EventTarget | null): EditorRuntime | null;
    /**
     * Subscribe to active-runtime changes.
     *
     * @param listener Called with each {@link EditorRuntimeRegistryActiveChange}.
     * @returns An unsubscribe function.
     */
    subscribe(listener: EditorRuntimeRegistryListener): EditorRuntimeRegistryUnsubscribe;
    /**
     * Tear down the registry: drop all runtimes, root index, active state, and
     * subscriptions. Used during SuperDoc destroy / document teardown. Does not
     * emit  -  subscribers are being released alongside the registry.
     */
    clear(): void;
}
