/**
 * Resolves track-changes rendering from `config.viewing.trackedChanges` when
 * supplied, then falls back to the v2 compatibility paths. The normalized
 * result is mirrored to those paths while their internal consumers migrate.
 *
 * Precedence per field: canonical > legacy > derived default.
 *
 * Emits a one-time deprecation warning per legacy key path that was
 * populated by the caller. Suppresses warnings on a second pass over the
 * same config object so write-through values don't look like new legacy
 * usage.
 *
 * @param {Record<string, any>} config  The SuperDoc config object (mutated in place)
 * @returns {NormalizedTrackChangesConfig}
 */
export function normalizeTrackChangesConfig(config: Record<string, any>): NormalizedTrackChangesConfig;
/**
 * Test-only hook: clears the deduplicated deprecation-warning set so
 * tests can assert the warning fires on the first invocation.
 */
export function __resetDeprecationWarnings(): void;
export type TrackChangesMode = "review" | "original" | "final" | "off";
export type ViewingTrackedChangesMode = "original" | "markup" | "final";
export type TrackChangesReplacements = "paired" | "independent";
export type AuthorColorsConfig = {
    enabled?: boolean;
    overrides?: Record<string, string>;
    resolve?: (author: {
        name?: string;
        email?: string;
        image?: string;
    }) => (string | undefined);
};
export type TrackedChangeSemanticColorKey = import('../types/index.js').TrackedChangeSemanticColorKey;
export type SemanticColorResolverInput = {
    key: TrackedChangeSemanticColorKey;
    author?: {
        name?: string;
        email?: string;
        image?: string;
    };
    type?: string;
    subtype?: string;
    targetKind?: string;
    semanticAnchorScope?: string;
};
export type SemanticColorsConfig = {
    enabled?: boolean;
    overrides?: Partial<Record<TrackedChangeSemanticColorKey, string>>;
    resolve?: (input: SemanticColorResolverInput) => (string | undefined);
};
export type NormalizedTrackChangesConfig = {
    visible: boolean;
    mode: TrackChangesMode;
    enabled: boolean;
    replacements: TrackChangesReplacements;
    authorColors?: AuthorColorsConfig;
    semanticColors?: SemanticColorsConfig;
};
