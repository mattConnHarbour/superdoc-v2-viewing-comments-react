import { User } from '../types/index.js';
/** Public compatibility identity used when a consumer omits `config.user`. */
export declare const DEFAULT_SUPERDOC_USER: Readonly<{
    id: null;
    name: "Default SuperDoc user";
    email: null;
}>;
/**
 * Normalize missing and partial public user configuration without sharing the
 * frozen default object between instances. The mounted v2 shell receives this
 * value and derives the session author used by worker and inline opens.
 */
export declare function normalizeSuperDocUser(user: User | null | undefined): User;
