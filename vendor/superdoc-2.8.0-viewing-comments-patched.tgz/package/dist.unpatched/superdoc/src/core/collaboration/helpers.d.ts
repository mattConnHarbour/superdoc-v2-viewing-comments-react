export function loadCommentsFromYdoc(superdoc: Object): boolean;
export function initCollaborationComments(superdoc: Object): void;
export function initSuperdocYdoc(superdoc: Object): {
    ydoc: import('yjs').Doc;
    provider: import('../types/index.js').CollaborationProvider;
} | undefined;
export function makeDocumentsCollaborative(superdoc: Object): any;
export function syncCommentsToClients(superdoc: Object, event: Object): void;
