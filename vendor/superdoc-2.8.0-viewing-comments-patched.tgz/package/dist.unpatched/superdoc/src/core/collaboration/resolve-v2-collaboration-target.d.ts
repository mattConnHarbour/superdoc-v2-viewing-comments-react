/**
 * Centralized v2 collaboration target resolver.
 *
 * This is the single authority that decides whether a constructor-time
 * collaboration config or a late `upgradeToCollaboration(...)` call resolves to
 * a **supported** SuperDoc v2 collaboration room. SuperDoc v2 ships three
 * first-class single-doc provider families — y-websocket, Hocuspocus, and
 * Liveblocks — each bound to one `Y.Doc`, one provider session, and one
 * awareness channel (implemented inside the bundled v2 runtime) and surfaced
 * publicly through {@link V2CollaborationConfig} (`Document.v2Collaboration`).
 *
 * The resolver never returns a "maybe collaborative" result: it either returns
 * a normalized, supported target or a stable, redacted diagnostic. Tokens, auth
 * keys, auth endpoints, and query strings are never echoed back in diagnostics.
 */
/** Provider families the shipped v2 single-doc runtime can drive. */
export type SupportedV2ProviderFamily = 'y-websocket' | 'hocuspocus' | 'liveblocks';
/**
 * Stable, machine-readable reasons a target cannot be treated as a supported v2
 * collaboration room. These strings are part of the diagnostic contract and are
 * safe to assert against in tests; they never carry caller-provided values.
 */
export type V2CollaborationUnsupportedReason = 'missing-target' | 'invalid-document-id' | 'invalid-server-url' | 'invalid-room-mode' | 'invalid-auth-endpoint' | 'missing-auth' | 'mixed-auth' | 'unsupported-document-type' | 'unsupported-multi-document' | 'unsupported-legacy-provider' | 'unsupported-provider-family';
/**
 * Normalized, supported v2 collaboration room target.
 *
 * The shape is flat with provider-specific optional fields. y-websocket and
 * Hocuspocus carry `serverUrl` (and Hocuspocus optionally `token`); Liveblocks
 * carries exactly one of `publicApiKey` or `authEndpoint`. Only the fields that
 * apply to the resolved family are present.
 */
export interface NormalizedV2CollaborationTarget {
    providerFamily: SupportedV2ProviderFamily;
    /** Stable shared document/room identity. */
    documentId: string;
    /** WebSocket server URL (y-websocket / Hocuspocus single-doc providers). */
    serverUrl?: string;
    /** Optional connection query params (e.g. auth token) forwarded verbatim. */
    params?: Record<string, string>;
    /** Hocuspocus auth-message token. */
    token?: string;
    /** Liveblocks anonymous public key auth mode. */
    publicApiKey?: string;
    /** Liveblocks server-side auth endpoint mode. */
    authEndpoint?: string;
    /** Explicit room operation; join is the default at the untrusted input boundary. */
    roomMode: 'join' | 'create';
}
export type V2CollaborationTargetResolution = {
    ok: true;
    target: NormalizedV2CollaborationTarget;
} | {
    ok: false;
    reason: V2CollaborationUnsupportedReason;
    /** Human-readable, fully redacted diagnostic message. */
    message: string;
};
/**
 * Loose input shape for a legacy `modules.collaboration` / upgrade option block.
 * Typed permissively because the resolver inspects arbitrary consumer input and
 * must classify it without trusting its shape.
 */
export interface LegacyCollaborationLike {
    ydoc?: unknown;
    provider?: unknown;
    providerType?: unknown;
    url?: unknown;
    [key: string]: unknown;
}
export interface ResolveV2CollaborationTargetInput {
    /** Document-level v2 collaboration config (canonical supported entry point). */
    v2Collaboration?: unknown;
    /** Legacy provider-agnostic collaboration block (`modules.collaboration` / upgrade opts). */
    legacyCollaboration?: LegacyCollaborationLike | null;
    /** The single document's type. v2 collaboration supports DOCX only. */
    documentType?: string | null;
    /** Total number of mounted documents. v2 single-doc rooms support exactly one. */
    documentCount?: number;
    /**
     * Browser URL used only to resolve a relative Liveblocks auth endpoint.
     * Non-browser callers omit this so relative endpoints continue to fail
     * closed when there is no origin against which to resolve them.
     */
    authEndpointBaseUrl?: string;
}
/**
 * Redact a connection URL for safe inclusion in diagnostics and artifacts.
 *
 * Strips the query string, fragment, and any embedded credentials (userinfo)
 * because those commonly carry auth tokens. Falls back to a coarse string scrub
 * when the value is not a parseable absolute URL so a malformed value with an
 * inline `?token=...` still cannot leak.
 */
export declare function redactCollaborationUrl(url: unknown): string;
/**
 * Resolve a constructor-time or upgrade-time collaboration request into a
 * supported v2 room target, or a stable redacted diagnostic.
 */
export declare function resolveV2CollaborationTarget(input: ResolveV2CollaborationTargetInput): V2CollaborationTargetResolution;
