/**
 * Main function to create a provider for collaboration.
 * Currently only hocuspocus is actually supported.
 *
 * @deprecated Use external provider instead. Pass { ydoc, provider } to modules.collaboration config.
 * @param {Object} param The config object
 * @param {Object} param.config The configuration object
 * @param {Object} param.ydoc The Yjs document
 * @param {Object} param.user The user object
 * @param {string} param.documentId The document ID
 * @returns {Object} The provider and socket
 */
export function createProvider({ config, user, documentId, socket, superdocInstance }: {
    config: Object;
    ydoc: Object;
    user: Object;
    documentId: string;
}): Object;
/**
 * Setup awareness handler for external providers.
 * Wires up awareness 'change' events to emit superdoc 'awareness-update' events.
 *
 * @param {Object} provider The external provider (must have awareness property)
 * @param {Object} superdocInstance The SuperDoc instance
 * @param {Object} user The user object for local awareness state
 * @returns {() => void} Cleanup function that removes the awareness listener
 */
export function setupAwarenessHandler(provider: Object, superdocInstance: Object, user: Object): () => void;
