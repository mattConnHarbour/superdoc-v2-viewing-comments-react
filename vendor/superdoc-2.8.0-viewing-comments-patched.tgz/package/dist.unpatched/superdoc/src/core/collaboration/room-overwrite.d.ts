/**
 * Overwrite the room's comment array with the current local comments.
 *
 * Performs an authoritative replacement — all existing room comments
 * are removed and replaced with serialized local state.
 *
 * @param {import('yjs').Doc} ydoc The target Yjs document
 * @param {Array} commentsList The local comments list (items with `getValues()`)
 * @returns {void}
 */
export function overwriteRoomComments(ydoc: import('yjs').Doc, commentsList: any[]): void;
/**
 * Transfer the local lock state into the target room's meta map.
 *
 * @param {import('yjs').Doc} ydoc The target Yjs document
 * @param {{ isLocked: boolean, lockedBy: Object | null }} lockState
 * @returns {void}
 */
export function overwriteRoomLockState(ydoc: import('yjs').Doc, { isLocked, lockedBy }: {
    isLocked: boolean;
    lockedBy: Object | null;
}): void;
