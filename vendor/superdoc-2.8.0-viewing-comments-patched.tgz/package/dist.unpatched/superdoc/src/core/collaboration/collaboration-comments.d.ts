export function addYComment(yArray: any, ydoc: any, event: any, user: any): void;
export function updateYComment(yArray: any, ydoc: any, event: any, user: any): void;
export function deleteYComment(yArray: any, ydoc: any, event: any, user: any): void;
export function getCommentIndex(yArray: any, comment: any): any;
