export const PERMISSIONS: Readonly<{
    RESOLVE_OWN: "RESOLVE_OWN";
    RESOLVE_OTHER: "RESOLVE_OTHER";
    REJECT_OWN: "REJECT_OWN";
    REJECT_OTHER: "REJECT_OTHER";
    COMMENTS_OVERFLOW_OWN: "COMMENTS_OVERFLOW";
    COMMENTS_OVERFLOW_OTHER: "COMMENTS_OVERFLOW_OTHER";
    COMMENTS_DELETE_OWN: "COMMENTS_DELETE_OWN";
    COMMENTS_DELETE_OTHER: "COMMENTS_DELETE_OTHER";
    UPLOAD_VERSION: "UPLOAD_VERSION";
    VERSION_HISTORY: "VERSION_HISTORY";
}>;
export function isAllowed(permission: string, role: string, isInternal: boolean, context?: {
    comment?: object | null | undefined;
    superdoc?: object | null | undefined;
    currentUser?: object | null | undefined;
    permissionResolver?: Function | undefined;
    trackedChange?: object | null | undefined;
}): boolean;
