import { AwarenessState, User } from '../types/index.js';
/**
 * Compatibility bridge from the v2 presence runtime to the legacy
 * `awareness-update` public event.
 *
 * The shipped v2 presence facade reports normalized remote-actor snapshots
 * from the bundled browser presence bridge. The legacy
 * public `awareness-update` payload, by contrast, is a v1-shaped
 * `{ states: AwarenessState[], added: number[], removed: number[] }` where
 * `added` / `removed` are numeric client ids.
 *
 * v2 presence identifies actors with stable string ids, not numeric Yjs
 * client ids. To preserve the documented `number[]` public contract this
 * bridge maintains a deterministic string→number registry: each distinct
 * actor key is assigned a stable numeric id the first time it is seen, and
 * that id is reused for the lifetime of the bridge. The local actor always
 * maps to client id `0`.
 */
/** Minimal remote-actor shape consumed from the v2 presence facade snapshot. */
export interface V2AwarenessRemoteActor {
    /** Stable label resolved by the presence facade (userId → displayName → fallback). */
    actorLabel: string;
    displayName?: string | null;
    email?: string | null;
    color?: string | null;
}
/** Minimal presence-facade snapshot shape the bridge reads. */
export interface V2AwarenessSnapshotLike {
    remoteActors: ReadonlyArray<V2AwarenessRemoteActor>;
}
/** Core `awareness-update` payload (the `superdoc` backref is added by the caller). */
export interface V2AwarenessPayloadCore {
    states: AwarenessState[];
    added: number[];
    removed: number[];
}
/**
 * Stable string→number id registry. The local actor is reserved id `0`; remote
 * actors are assigned monotonically increasing ids starting at `1`.
 */
export declare class V2AwarenessIdRegistry {
    #private;
    idFor(key: string): number;
    /** True once a key has been assigned an id. */
    has(key: string): boolean;
}
/**
 * Create a stateful presence→awareness differ.
 *
 * Each call to `next(snapshot)` returns the legacy-shaped awareness payload
 * core for that snapshot, computing `added` / `removed` against the previously
 * observed remote-actor set. The local user is always included in `states`.
 */
export declare function createV2AwarenessDiffer(getLocalUser: () => User | null | undefined): {
    registry: V2AwarenessIdRegistry;
    next(snapshot: V2AwarenessSnapshotLike): V2AwarenessPayloadCore;
};
