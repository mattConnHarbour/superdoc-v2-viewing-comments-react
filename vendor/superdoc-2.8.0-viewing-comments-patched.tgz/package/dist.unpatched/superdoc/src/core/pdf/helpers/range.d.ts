export function range(start: any, end: any): any[];
