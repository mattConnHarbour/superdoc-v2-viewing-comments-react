export function readFileAsArrayBuffer(blob: any): Promise<any>;
