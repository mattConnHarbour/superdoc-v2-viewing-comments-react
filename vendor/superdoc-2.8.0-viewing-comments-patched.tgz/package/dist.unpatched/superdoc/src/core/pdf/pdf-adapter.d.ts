/**
 * @param {number} version
 * @returns {string}
 */
export function getWorkerSrcFromCDN(version: number): string;
export function createPDFConfig(config?: Partial<PDFConfig>): PDFConfig;
export class PDFJSAdapter extends PDFAdapter {
    /**
     * @param {PDFJSConfig} config
     */
    constructor(config: PDFJSConfig);
    pdfLib: any;
    workerSrc: string | undefined;
    /**
     * @param {string | ArrayBuffer | Uint8Array} file
     * @returns {Promise<PDFDocumentProxy>}
     */
    getDocument(file: string | ArrayBuffer | Uint8Array): Promise<PDFDocumentProxy>;
    /**
     * @param {PDFDocumentProxy} pdf
     * @param {number} firstPage
     * @param {number} lastPage
     * @returns {Promise<PDFPageProxy[]>}
     */
    getPages(pdf: PDFDocumentProxy, firstPage: number, lastPage: number): Promise<PDFPageProxy[]>;
}
export class PDFAdapterFactory {
    /**
     * @param {PDFJSConfig & {adapter: AdapterType}} config
     * @returns {PDFAdapter}
     * @throws {Error}
     */
    static create(config: PDFJSConfig & {
        adapter: AdapterType;
    }): PDFAdapter;
}
export type PDFDocumentProxy = import('pdfjs-dist').PDFDocumentProxy;
export type PDFPageProxy = import('pdfjs-dist').PDFPageProxy;
export type AdapterType = "pdfjs";
export type PDFConfig = {
    adapter: AdapterType;
    pdfLib?: any;
    workerSrc?: string | undefined;
    setWorker?: boolean | undefined;
};
export type PDFJSConfig = {
    pdfLib: any;
    workerSrc?: string | undefined;
    setWorker?: boolean | undefined;
};
export type RenderPagesOptions = {
    documentId: string;
    pdfDocument: PDFDocumentProxy;
    viewerContainer: HTMLElement;
    emit?: ((arg0: string, ...arg1: any[]) => void) | undefined;
};
export type PageSize = {
    width: number;
    height: number;
};
/**
 * @abstract
 */
declare class PDFAdapter {
}
export {};
