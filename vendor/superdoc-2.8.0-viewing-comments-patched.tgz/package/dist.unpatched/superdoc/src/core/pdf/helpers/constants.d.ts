export const OUTPUT_SCALE: 2;
export const PDF_TO_CSS_UNITS: number;
