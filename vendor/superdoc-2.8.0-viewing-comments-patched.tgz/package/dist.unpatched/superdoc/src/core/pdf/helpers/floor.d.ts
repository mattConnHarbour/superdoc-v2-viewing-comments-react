export function floor(val: any, precision: any): number;
