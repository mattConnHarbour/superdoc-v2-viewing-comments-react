/**
 * Default event map: string event names → tuple of payload args.
 *
 * The index-signature value is `unknown[]` (SD-3213 EventEmitter drain).
 * Specific event maps that extend this still type their known events
 * precisely; the index-signature fallback only governs untyped event
 * names. Currently this emitter is consumed by `Whiteboard` (no event
 * map yet — tracked as a follow-up); SuperDoc itself uses the
 * third-party `eventemitter3` and is unaffected by this change.
 */
export type DefaultEventMap = Record<string, unknown[]>;
/**
 * Event callback function type.
 *
 * Default `Args extends unknown[] = unknown[]` (was `any[]`, SD-3213).
 * Variance: when a specific event map provides a tighter tuple via
 * `EventMap[K]`, that flows through to `EventCallback<EventMap[K]>` at
 * the call site, so typed events keep their precise payloads.
 */
export type EventCallback<Args extends unknown[] = unknown[]> = (...args: Args) => void;
/**
 * EventEmitter class is used to emit and subscribe to events.
 */
export declare class EventEmitter<EventMap extends DefaultEventMap = DefaultEventMap> {
    #private;
    /**
     * Subscribe to the event.
     * @param name Event name.
     * @param fn Callback.
     */
    on<K extends keyof EventMap>(name: K, fn: EventCallback<EventMap[K]>): void;
    /**
     * Emit event.
     * @param name Event name.
     * @param args Arguments to pass to each listener.
     */
    emit<K extends keyof EventMap>(name: K, ...args: EventMap[K]): void;
    /**
     * Remove a specific callback from event
     * or all event subscriptions.
     * @param name Event name.
     * @param fn Callback.
     */
    off<K extends keyof EventMap>(name: K, fn?: EventCallback<EventMap[K]>): void;
    /**
     * Subscribe to an event that will be called only once.
     * @param name Event name.
     * @param fn Callback.
     */
    once<K extends keyof EventMap>(name: K, fn: EventCallback<EventMap[K]>): void;
    /**
     * Remove all registered events and subscriptions.
     */
    removeAllListeners(): void;
}
