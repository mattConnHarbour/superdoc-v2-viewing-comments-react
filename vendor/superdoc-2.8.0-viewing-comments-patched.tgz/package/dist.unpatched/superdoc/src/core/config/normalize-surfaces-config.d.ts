/**
 * Resolve the generic surface infrastructure config.
 *
 * Reads top-level `surfaces` first, then the legacy `modules.surfaces` block,
 * so both spellings work while the migration lands. Built-in surface intents
 * are deliberately not read here; they belong to the UI profile.
 *
 * The resolved shape mirrors the public `SurfacesConfig`, with every member
 * present: the presets are merged objects rather than optional, and `resolver`
 * is a function or `null` once a non-function value has been rejected.
 *
 * @param {Record<string, any>} [config] Raw consumer config.
 * @returns {{
 *   resolver: import('../types/index.js').SurfaceResolver | null,
 *   dialog: NonNullable<import('../types/index.js').SurfacesConfig['dialog']>,
 *   floating: NonNullable<import('../types/index.js').SurfacesConfig['floating']>,
 * }}
 */
export function normalizeSurfacesConfig(config?: Record<string, any>): {
    resolver: import('../types/index.js').SurfaceResolver | null;
    dialog: NonNullable<import('../types/index.js').SurfacesConfig["dialog"]>;
    floating: NonNullable<import('../types/index.js').SurfacesConfig["floating"]>;
};
