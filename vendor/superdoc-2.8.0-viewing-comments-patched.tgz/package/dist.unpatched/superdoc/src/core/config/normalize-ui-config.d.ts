/**
 * Collapse a consumer config into the effective built-in UI profile.
 *
 * @param {Record<string, any>} [config] Raw consumer config.
 * @returns {{
 *   enabled: boolean,
 *   toolbar: { enabled: boolean, container: string | HTMLElement | null, options: Record<string, unknown> },
 *   comments: { enabled: boolean, options: Record<string, unknown> },
 *   contextMenu: { enabled: boolean, suppressed: boolean, options: Record<string, unknown> },
 *   loading: { enabled: boolean },
 *   search: { enabled: boolean, options: Record<string, unknown> },
 *   linkPopover: { enabled: boolean, suppressed: boolean, options: Record<string, unknown> },
 *   ruler: { enabled: boolean, suppressed: boolean, container: string | HTMLElement | null },
 *   contentControls: { enabled: boolean, options: Record<string, unknown> },
 * }}
 */
export function normalizeUiConfig(config?: Record<string, any>): {
    enabled: boolean;
    toolbar: {
        enabled: boolean;
        container: string | HTMLElement | null;
        options: Record<string, unknown>;
    };
    comments: {
        enabled: boolean;
        options: Record<string, unknown>;
    };
    contextMenu: {
        enabled: boolean;
        suppressed: boolean;
        options: Record<string, unknown>;
    };
    loading: {
        enabled: boolean;
    };
    search: {
        enabled: boolean;
        options: Record<string, unknown>;
    };
    linkPopover: {
        enabled: boolean;
        suppressed: boolean;
        options: Record<string, unknown>;
    };
    ruler: {
        enabled: boolean;
        suppressed: boolean;
        container: string | HTMLElement | null;
    };
    contentControls: {
        enabled: boolean;
        options: Record<string, unknown>;
    };
};
/** Every built-in surface `ui: false` turns off. */
export const BUILT_IN_SURFACES: readonly string[];
/** Surfaces that render when the consumer says nothing at all. */
export const HISTORICAL_DEFAULTS: Readonly<{
    toolbar: true;
    comments: true;
    contextMenu: true;
    loading: true;
    search: false;
    linkPopover: false;
    ruler: false;
    contentControls: true;
}>;
