/**
 * Resolve the effective interaction policy.
 *
 * Reads `interaction.comments` first, then the legacy fields on
 * `modules.comments`, so both spellings work while the migration lands.
 *
 * @param {Record<string, any>} [config] Raw consumer config.
 * @returns {{ comments: { readOnly: boolean, allowResolve: boolean } }}
 */
export function normalizeInteractionConfig(config?: Record<string, any>): {
    comments: {
        readOnly: boolean;
        allowResolve: boolean;
    };
};
