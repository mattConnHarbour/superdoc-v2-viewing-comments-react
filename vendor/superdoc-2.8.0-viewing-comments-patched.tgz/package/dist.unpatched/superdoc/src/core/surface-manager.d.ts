/**
 * SurfaceManager — a plain JavaScript class that owns surface lifecycle state.
 *
 * NOT a Pinia store. Lives on the SuperDoc instance and survives runtime
 * restarts (collaboration upgrades). Vue components observe the reactive
 * refs (`activeDialog`, `activeFloating`) via provide/inject.
 */
export class SurfaceManager {
    /**
     * @param {{ getModuleConfig: () => SurfacesModuleConfig | undefined }} options
     */
    constructor({ getModuleConfig }: {
        getModuleConfig: () => SurfacesModuleConfig | undefined;
    });
    /** @type {import('vue').ShallowRef<ActiveSurface | null>} */
    activeDialog: import('vue').ShallowRef<ActiveSurface | null>;
    /** @type {import('vue').ShallowRef<ActiveSurface | null>} */
    activeFloating: import('vue').ShallowRef<ActiveSurface | null>;
    /**
     * Open a surface. Returns a handle with a result promise that always resolves.
     *
     * Throws synchronously on API misuse (bad request shape, unresolvable intent).
     * Normal lifecycle events (close, replace, destroy) resolve through the handle.
     *
     * @template [TResult=unknown]
     * @param {SurfaceRequest} rawRequest
     * @returns {SurfaceHandle<TResult>}
     */
    open<TResult = unknown>(rawRequest: SurfaceRequest): SurfaceHandle<TResult>;
    /**
     * Close a surface by id, or the topmost surface if no id is given.
     * @param {string} [id]
     * @param {unknown} [reason]
     */
    close(id?: string, reason?: unknown): void;
    /**
     * Settle all active surfaces with the given outcome.
     * Used by SuperDoc during runtime restart and destroy.
     * @param {SurfaceOutcome} outcome
     */
    settleAll(outcome: SurfaceOutcome): void;
    /**
     * Permanently shut down the manager. All active surfaces are settled with
     * { status: 'destroyed' }. Future open() calls return destroyed handles.
     */
    destroy(): void;
    #private;
}
export type SurfaceMode = import('./types/index.js').SurfaceMode;
export type SurfaceRequest = import('./types/index.js').SurfaceRequest;
export type SurfaceResolution = import('./types/index.js').SurfaceResolution;
export type SurfaceHandle = import('./types/index.js').SurfaceHandle;
export type SurfaceOutcome = import('./types/index.js').SurfaceOutcome;
export type SurfacesModuleConfig = import('./types/index.js').SurfacesModuleConfig;
export type ExternalSurfaceRenderContext = import('./types/index.js').ExternalSurfaceRenderContext;
export type ActiveSurface = {
    id: string;
    mode: SurfaceMode;
    request: SurfaceRequest;
    /**
     * Resolved Vue component
     */
    component?: unknown;
    /**
     * Extra props for the Vue component
     */
    props?: Record<string, unknown> | undefined;
    /**
     * External renderer
     */
    render?: ((ctx: ExternalSurfaceRenderContext) => ({
        destroy?: () => void;
    } | void)) | undefined;
    /**
     * Content-facing: settle with 'submitted'
     */
    resolve: (data?: unknown) => void;
    /**
     * Content-facing: settle with 'closed' and clear slot
     */
    close: (reason?: unknown) => void;
    /**
     * Settle the handle promise (internal)
     */
    settle: (outcome: SurfaceOutcome) => boolean;
    /**
     * Whether the handle has already been settled
     */
    settled: boolean;
};
