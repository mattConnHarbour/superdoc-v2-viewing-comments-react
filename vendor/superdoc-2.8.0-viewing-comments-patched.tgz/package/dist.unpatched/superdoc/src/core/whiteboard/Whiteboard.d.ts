import { EventEmitter } from '../EventEmitter.js';
import { WhiteboardPage } from './WhiteboardPage.js';
/**
 * @typedef {{ width: number, height: number, originalWidth?: number, originalHeight?: number }} WhiteboardPageSize
 *
 * The page-level serialized shape is the normalized one (matches what
 * `WhiteboardPage.toJSON()` actually returns). SD-3213 follow-up:
 * the previous `any[]` typing meant consumers reading
 * `whiteboard.getWhiteboardData().pages[0].strokes` had no
 * IntelliSense — and a wrong assumption that fields like `.points`
 * or `.x` would be present (runtime gives `pointsN` / `xN`).
 *
 * @typedef {import('./WhiteboardPage.js').WhiteboardStoredPageData} WhiteboardPageData
 *
 * Per-page size snapshot recorded in `WhiteboardDataMeta.pageSizes`.
 * `originalWidth` / `originalHeight` are `number | null` because
 * `getWhiteboardData()` writes `page.originalSize?.width ?? null` when
 * the original size is unknown.
 *
 * @typedef {{ width: number, height: number, originalWidth: number | null, originalHeight: number | null }} WhiteboardPageSizeSnapshot
 *
 * @typedef {{ pageSizes: Record<string, WhiteboardPageSizeSnapshot> }} WhiteboardDataMeta
 *
 * `WhiteboardData` is the **output** shape: what `getWhiteboardData()`
 * returns and what the `change` event payload carries. All three
 * fields are required because the runtime always populates them.
 * Consumers reading the change payload can write
 * `data.meta.pageSizes` without optional chaining.
 *
 * @typedef {{ pages: Record<string, WhiteboardPageData>, meta: WhiteboardDataMeta, version: 1 }} WhiteboardData
 *
 * `WhiteboardDataInput` is the **input** shape accepted by
 * `setWhiteboardData(json)`. All fields are optional because the
 * runtime only reads `json?.pages`; callers can pass
 * `{ pages: {...} }` without supplying `meta` or `version`. A round
 * trip works (`setWhiteboardData(getWhiteboardData())`) because
 * `WhiteboardData` is structurally assignable to `WhiteboardDataInput`.
 *
 * @typedef {{ pages?: Record<string, WhiteboardPageData>, meta?: WhiteboardDataMeta, version?: number }} WhiteboardDataInput
 *
 * Registry items the host can attach for UI palettes (stickers,
 * comments, etc.). The shape is intentionally extensible: `id` is the
 * one field the runtime actually relies on (filter, dedup); everything
 * else is consumer-typed via `unknown` so palettes for new domains
 * don't need a contract change.
 *
 * @typedef {{ id?: string | number, [key: string]: unknown }} WhiteboardRegistryItem
 *
 * Event map for `whiteboard.on(name, fn)` / `whiteboard.emit(name, ...)`.
 * Closed map (no DefaultEventMap fallback) because every event the
 * runtime emits is enumerated here; an unknown event name should be a
 * type error, not an `unknown[]` payload. SD-3213 follow-up to the
 * EventEmitter `unknown[]` drain: that change only fixed the
 * untyped-event fallback; without this map, listeners on Whiteboard
 * still received `unknown[]` because no event was named.
 *
 * @typedef {{
 *  tool: [string],
 *  enabled: [boolean],
 *  opacity: [number],
 *  setData: [WhiteboardPage[]],
 *  change: [WhiteboardData],
 * }} WhiteboardEventMap
 *
 * @typedef {{
 *  Renderer?: any,
 *  superdoc?: any,
 *  enabled?: boolean,
 *  onChange?: (data: WhiteboardData) => void,
 *  onSetData?: (pages: WhiteboardPage[]) => void,
 *  onEnabledChange?: (enabled: boolean) => void,
 * }} WhiteboardInit
 */
/**
 * Whiteboard manager for multi-page annotations.
 *
 * @extends {EventEmitter<WhiteboardEventMap>}
 */
export class Whiteboard extends EventEmitter<WhiteboardEventMap> {
    /**
     * Initialize the whiteboard instance.
     * @param {WhiteboardInit} [props]
     */
    constructor(props?: WhiteboardInit);
    /**
     * Register items for a UI palette type (e.g. stickers, comments).
     * @param {string} type
     * @param {WhiteboardRegistryItem[]} items
     */
    register(type: string, items: WhiteboardRegistryItem[]): void;
    /**
     * Get registered items by type.
     * @param {string} type
     * @returns {WhiteboardRegistryItem[] | undefined}
     */
    getType(type: string): WhiteboardRegistryItem[] | undefined;
    /**
     * Set current tool for all pages.
     * @param {string} tool
     */
    setTool(tool: string): void;
    /**
     * Get current tool.
     * @returns {string}
     */
    getTool(): string;
    /**
     * Enable/disable interactivity for all pages.
     * @param {boolean} enabled
     */
    setEnabled(enabled: boolean): void;
    /**
     * @returns {boolean}
     */
    isEnabled(): boolean;
    /**
     * Set overlay opacity.
     * @param {number} opacity
     */
    setOpacity(opacity: number): void;
    /**
     * @returns {number}
     */
    getOpacity(): number;
    /**
     * Return all page instances.
     * @returns {WhiteboardPage[]}
     */
    getPages(): WhiteboardPage[];
    /**
     * Re-render all pages.
     */
    rerender(): void;
    /**
     * Set size for a page (creates page if missing).
     * @param {number} pageIndex
     * @param {WhiteboardPageSize} size
     */
    setPageSize(pageIndex: number, size: WhiteboardPageSize): void;
    /**
     * Get a page by index.
     * @param {number} pageIndex
     * @returns {WhiteboardPage}
     */
    getPage(pageIndex: number): WhiteboardPage;
    /**
     * Serialize whiteboard data.
     * @returns {WhiteboardData}
     */
    getWhiteboardData(): WhiteboardData;
    /**
     * Load whiteboard data from JSON.
     * @param {WhiteboardDataInput} json
     */
    setWhiteboardData(json: WhiteboardDataInput): void;
    #private;
}
/**
 * The page-level serialized shape is the normalized one (matches what
 * `WhiteboardPage.toJSON()` actually returns). SD-3213 follow-up:
 * the previous `any[]` typing meant consumers reading
 * `whiteboard.getWhiteboardData().pages[0].strokes` had no
 * IntelliSense — and a wrong assumption that fields like `.points`
 * or `.x` would be present (runtime gives `pointsN` / `xN`).
 */
export type WhiteboardPageSize = {
    width: number;
    height: number;
    originalWidth?: number;
    originalHeight?: number;
};
/**
 * Per-page size snapshot recorded in `WhiteboardDataMeta.pageSizes`.
 * `originalWidth` / `originalHeight` are `number | null` because
 * `getWhiteboardData()` writes `page.originalSize?.width ?? null` when
 * the original size is unknown.
 */
export type WhiteboardPageData = import('./WhiteboardPage.js').WhiteboardStoredPageData;
export type WhiteboardPageSizeSnapshot = {
    width: number;
    height: number;
    originalWidth: number | null;
    originalHeight: number | null;
};
/**
 * `WhiteboardData` is the **output** shape: what `getWhiteboardData()`
 * returns and what the `change` event payload carries. All three
 * fields are required because the runtime always populates them.
 * Consumers reading the change payload can write
 * `data.meta.pageSizes` without optional chaining.
 */
export type WhiteboardDataMeta = {
    pageSizes: Record<string, WhiteboardPageSizeSnapshot>;
};
/**
 * `WhiteboardDataInput` is the **input** shape accepted by
 * `setWhiteboardData(json)`. All fields are optional because the
 * runtime only reads `json?.pages`; callers can pass
 * `{ pages: {...} }` without supplying `meta` or `version`. A round
 * trip works (`setWhiteboardData(getWhiteboardData())`) because
 * `WhiteboardData` is structurally assignable to `WhiteboardDataInput`.
 */
export type WhiteboardData = {
    pages: Record<string, WhiteboardPageData>;
    meta: WhiteboardDataMeta;
    version: 1;
};
/**
 * Registry items the host can attach for UI palettes (stickers,
 * comments, etc.). The shape is intentionally extensible: `id` is the
 * one field the runtime actually relies on (filter, dedup); everything
 * else is consumer-typed via `unknown` so palettes for new domains
 * don't need a contract change.
 */
export type WhiteboardDataInput = {
    pages?: Record<string, WhiteboardPageData>;
    meta?: WhiteboardDataMeta;
    version?: number;
};
/**
 * Event map for `whiteboard.on(name, fn)` / `whiteboard.emit(name, ...)`.
 * Closed map (no DefaultEventMap fallback) because every event the
 * runtime emits is enumerated here; an unknown event name should be a
 * type error, not an `unknown[]` payload. SD-3213 follow-up to the
 * EventEmitter `unknown[]` drain: that change only fixed the
 * untyped-event fallback; without this map, listeners on Whiteboard
 * still received `unknown[]` because no event was named.
 */
export type WhiteboardRegistryItem = {
    id?: string | number;
    [key: string]: unknown;
};
export type WhiteboardEventMap = {
    tool: [string];
    enabled: [boolean];
    opacity: [number];
    setData: [WhiteboardPage[]];
    change: [WhiteboardData];
};
export type WhiteboardInit = {
    Renderer?: any;
    superdoc?: any;
    enabled?: boolean;
    onChange?: (data: WhiteboardData) => void;
    onSetData?: (pages: WhiteboardPage[]) => void;
    onEnabledChange?: (enabled: boolean) => void;
};
