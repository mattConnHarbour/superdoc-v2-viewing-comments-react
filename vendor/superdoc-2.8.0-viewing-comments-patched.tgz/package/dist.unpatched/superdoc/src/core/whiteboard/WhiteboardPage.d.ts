/**
 * @typedef {{ width: number, height: number, originalWidth?: number, originalHeight?: number }} WhiteboardPageSize
 * @typedef {{ x: number, y: number }} Point
 *
 * Authored input shapes — what `addStroke`/`addText`/`addImage` accept
 * from a consumer (pixel-space coordinates, optional ids). The
 * add* methods normalize these into the stored shapes below.
 *
 * @typedef {{ points: number[][], color?: string, width?: number, type?: 'draw'|'erase' }} WhiteboardStroke
 * @typedef {{ id?: string|number, x: number, y: number, content: string, fontSize?: number, width?: number }} WhiteboardTextItem
 * @typedef {{ id?: string|number, stickerId?: string, x: number, y: number, src: string, width?: number, height?: number, type?: string }} WhiteboardImageItem
 *
 * Stored / normalized shapes — what the page actually holds in
 * `this.strokes` / `this.text` / `this.images` and what gets
 * serialized via `toJSON()` and re-applied via `applyData()`. Fields
 * suffixed with `N` (pointsN, xN, yN, widthN, heightN, fontSizeN) are
 * normalized to the page's 0..1 coordinate space; raw `width`/`height`
 * pairs are kept where consumers expect pixel sizes.
 *
 * SD-3213 follow-up: the public types were previously `any[]` for the
 * fields and the toJSON / applyData signatures; consumers reading
 * `page.strokes[0].points` would have hit pointsN at runtime with no
 * IntelliSense. The named shapes below restore typing without
 * over-committing the authored shapes (which the add* methods
 * normalize away).
 *
 * @typedef {{ pointsN: number[][], widthN?: number, color?: string, type?: 'draw'|'erase' }} WhiteboardStoredStroke
 * @typedef {{ id: string|number, xN: number, yN: number, content: string, fontSizeN?: number, widthN?: number | null }} WhiteboardStoredTextItem
 * @typedef {{ id: string|number, stickerId?: string | number | null, xN: number, yN: number, src: string, widthN?: number | null, heightN?: number | null, type?: string }} WhiteboardStoredImageItem
 *
 * @typedef {{
 *  strokes?: WhiteboardStoredStroke[],
 *  text?: WhiteboardStoredTextItem[],
 *  images?: WhiteboardStoredImageItem[],
 * }} WhiteboardStoredPageData
 *
 * @typedef {{
 *  pageIndex: number,
 *  enabled: boolean,
 *  Renderer: any,
 *  onChange?: () => void,
 *  onToolChange?: (tool: string) => void,
 * }} WhiteboardPageInit
 */
/**
 * Per-page whiteboard renderer/controller.
 */
export class WhiteboardPage {
    /**
     * Create a page controller.
     * @param {WhiteboardPageInit} props
     */
    constructor(props: WhiteboardPageInit);
    /** @type {number|null} */
    pageIndex: number | null;
    /** @type {WhiteboardStoredStroke[]} */
    strokes: WhiteboardStoredStroke[];
    /** @type {WhiteboardStoredTextItem[]} */
    text: WhiteboardStoredTextItem[];
    /** @type {WhiteboardStoredImageItem[]} */
    images: WhiteboardStoredImageItem[];
    /** @type {WhiteboardPageSize|null} */
    size: WhiteboardPageSize | null;
    /** @type {{ width: number|null, height: number|null }|null} */
    originalSize: {
        width: number | null;
        height: number | null;
    } | null;
    /**
     * Set tool for this page.
     * @param {string} tool
     */
    setTool(tool: string): void;
    /**
     * Get current tool for this page.
     * @returns {string}
     */
    getTool(): string;
    /**
     * Enable/disable interactivity for this page.
     * @param {boolean} enabled
     */
    setEnabled(enabled: boolean): void;
    /**
     * @returns {boolean}
     */
    isEnabled(): boolean;
    /**
     * Store page size (does not resize canvas).
     * @param {WhiteboardPageSize} size
     */
    setSize(size: WhiteboardPageSize): void;
    /**
     * Resize the Konva stage.
     * @param {number} width
     * @param {number} height
     */
    resize(width: number, height: number): void;
    /**
     * Mount Konva stage into a container.
     * @param {HTMLElement} container
     */
    mount(container: HTMLElement): void;
    /**
     * Re-render all content for this page.
     */
    render(): void;
    /**
     * Render stroke paths.
     */
    renderStrokes(): void;
    /**
     * Render text nodes.
     */
    renderText(): void;
    /**
     * Render image/sticker nodes.
     * NOTE: Images are reconciled by id to avoid re-creating nodes (prevents flicker).
     * If src changes for an existing id, this path does not reload the image.
     */
    renderImages(): void;
    /**
     * Destroy Konva stage and clean up listeners.
     */
    destroy(): void;
    /**
     * Serialize page data.
     * Returns the page's serializable shape. SD-3213 follow-up: fixed
     * stale JSDoc that said `stickers` (which never existed on the
     * runtime return) and typed the values as the stored normalized
     * shapes instead of `any[]`.
     *
     * @returns {{ strokes: WhiteboardStoredStroke[], text: WhiteboardStoredTextItem[], images: WhiteboardStoredImageItem[] }}
     */
    toJSON(): {
        strokes: WhiteboardStoredStroke[];
        text: WhiteboardStoredTextItem[];
        images: WhiteboardStoredImageItem[];
    };
    /**
     * Apply data to this page and re-render.
     * @param {WhiteboardStoredPageData} data
     */
    applyData(data?: WhiteboardStoredPageData): void;
    /**
     * Add a stroke to the model.
     * @param {WhiteboardStroke} stroke
     */
    addStroke(stroke: WhiteboardStroke): void;
    /**
     * Add a text item to the model.
     * @param {WhiteboardTextItem} item
     */
    addText(item: WhiteboardTextItem): void;
    /**
     * Add an image/sticker to the model.
     * @param {WhiteboardImageItem} item
     */
    addImage(item: WhiteboardImageItem): void;
    #private;
}
export type WhiteboardPageSize = {
    width: number;
    height: number;
    originalWidth?: number;
    originalHeight?: number;
};
/**
 * Authored input shapes — what `addStroke`/`addText`/`addImage` accept
 * from a consumer (pixel-space coordinates, optional ids). The
 * add* methods normalize these into the stored shapes below.
 */
export type Point = {
    x: number;
    y: number;
};
export type WhiteboardStroke = {
    points: number[][];
    color?: string;
    width?: number;
    type?: "draw" | "erase";
};
export type WhiteboardTextItem = {
    id?: string | number;
    x: number;
    y: number;
    content: string;
    fontSize?: number;
    width?: number;
};
/**
 * Stored / normalized shapes — what the page actually holds in
 * `this.strokes` / `this.text` / `this.images` and what gets
 * serialized via `toJSON()` and re-applied via `applyData()`. Fields
 * suffixed with `N` (pointsN, xN, yN, widthN, heightN, fontSizeN) are
 * normalized to the page's 0..1 coordinate space; raw `width`/`height`
 * pairs are kept where consumers expect pixel sizes.
 *
 * SD-3213 follow-up: the public types were previously `any[]` for the
 * fields and the toJSON / applyData signatures; consumers reading
 * `page.strokes[0].points` would have hit pointsN at runtime with no
 * IntelliSense. The named shapes below restore typing without
 * over-committing the authored shapes (which the add* methods
 * normalize away).
 */
export type WhiteboardImageItem = {
    id?: string | number;
    stickerId?: string;
    x: number;
    y: number;
    src: string;
    width?: number;
    height?: number;
    type?: string;
};
export type WhiteboardStoredStroke = {
    pointsN: number[][];
    widthN?: number;
    color?: string;
    type?: "draw" | "erase";
};
export type WhiteboardStoredTextItem = {
    id: string | number;
    xN: number;
    yN: number;
    content: string;
    fontSizeN?: number;
    widthN?: number | null;
};
export type WhiteboardStoredImageItem = {
    id: string | number;
    stickerId?: string | number | null;
    xN: number;
    yN: number;
    src: string;
    widthN?: number | null;
    heightN?: number | null;
    type?: string;
};
export type WhiteboardStoredPageData = {
    strokes?: WhiteboardStoredStroke[];
    text?: WhiteboardStoredTextItem[];
    images?: WhiteboardStoredImageItem[];
};
export type WhiteboardPageInit = {
    pageIndex: number;
    enabled: boolean;
    Renderer: any;
    onChange?: () => void;
    onToolChange?: (tool: string) => void;
};
