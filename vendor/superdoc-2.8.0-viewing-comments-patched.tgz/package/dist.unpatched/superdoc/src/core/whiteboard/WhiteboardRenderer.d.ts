import { default as Konva } from 'konva';
export { Konva as WhiteboardRenderer };
