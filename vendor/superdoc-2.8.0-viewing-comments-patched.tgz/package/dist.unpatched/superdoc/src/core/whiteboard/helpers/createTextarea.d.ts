export function createTextarea(options?: {}): HTMLTextAreaElement;
