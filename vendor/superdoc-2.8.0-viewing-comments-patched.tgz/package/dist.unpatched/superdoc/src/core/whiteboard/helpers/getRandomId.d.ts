export function getRandomId(prefix?: string): string;
