export function flattenPoints(points: any): any;
