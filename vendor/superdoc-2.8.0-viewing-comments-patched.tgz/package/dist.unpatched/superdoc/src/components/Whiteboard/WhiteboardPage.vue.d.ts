declare const _default: import('vue').DefineComponent<{}, {
    page: Record<string, any>;
    enabled: boolean;
    whiteboard: Record<string, any>;
    pageSize: Record<string, any>;
    pageOffset: Record<string, any>;
    $props: {
        readonly page?: Record<string, any> | undefined;
        readonly enabled?: boolean | undefined;
        readonly whiteboard?: Record<string, any> | undefined;
        readonly pageSize?: Record<string, any> | undefined;
        readonly pageOffset?: Record<string, any> | undefined;
    };
}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, string, import('vue').PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {
    containerRef: HTMLDivElement;
}, HTMLDivElement>;
export default _default;
