export function useWhiteboard({ proxy, layers, documents, modules }: {
    proxy: any;
    layers: any;
    documents: any;
    modules: any;
}): {
    whiteboard: any;
    whiteboardModuleConfig: import('vue').ComputedRef<any>;
    whiteboardPages: import('vue').ShallowRef<never[], never[]>;
    whiteboardPageSizes: {};
    whiteboardPageOffsets: {};
    whiteboardEnabled: import('vue').Ref<any, any>;
    whiteboardOpacity: import('vue').Ref<number, number>;
    whiteboardReady: import('vue').Ref<boolean, boolean>;
    handleWhiteboardPageReady: (payload: any) => void;
    updateWhiteboardPageSizes: () => void;
    updateWhiteboardPageOffsets: () => void;
};
