declare const _default: import('vue').DefineComponent<{}, {
    opacity: number;
    enabled: boolean;
    pages: unknown[];
    whiteboard: Record<string, any>;
    pageSizes: Record<string, any>;
    pageOffsets: Record<string, any>;
    interactive: boolean;
    $props: {
        readonly opacity?: number | undefined;
        readonly enabled?: boolean | undefined;
        readonly pages?: unknown[] | undefined;
        readonly whiteboard?: Record<string, any> | undefined;
        readonly pageSizes?: Record<string, any> | undefined;
        readonly pageOffsets?: Record<string, any> | undefined;
        readonly interactive?: boolean | undefined;
    };
}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, string, import('vue').PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {}, HTMLDivElement>;
export default _default;
