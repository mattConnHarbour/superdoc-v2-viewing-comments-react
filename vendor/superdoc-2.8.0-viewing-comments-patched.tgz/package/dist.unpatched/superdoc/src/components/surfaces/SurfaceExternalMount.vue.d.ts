declare const _default: import('vue').DefineComponent<{}, {
    close: Function;
    resolve: Function;
    request: Record<string, any>;
    mode: string;
    render: Function;
    surfaceId: string;
    $props: {
        readonly close?: Function | undefined;
        readonly resolve?: Function | undefined;
        readonly request?: Record<string, any> | undefined;
        readonly mode?: string | undefined;
        readonly render?: Function | undefined;
        readonly surfaceId?: string | undefined;
    };
}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, string, import('vue').PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {
    container: HTMLDivElement;
}, HTMLDivElement>;
export default _default;
