/**
 * CSS selector matching all focusable elements within a surface shell.
 * Used by SurfaceDialog (focus trap, initial focus) and SurfaceFloating (initial focus).
 */
export const FOCUSABLE_SELECTOR: string;
