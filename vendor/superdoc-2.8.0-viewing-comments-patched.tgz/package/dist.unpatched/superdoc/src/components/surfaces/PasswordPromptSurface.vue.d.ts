declare const _default: import('vue').DefineComponent<{}, {
    close: Function;
    resolve: Function;
    request: Record<string, any>;
    mode: string;
    surfaceId: string;
    passwordPrompt: Record<string, any>;
    $props: {
        readonly close?: Function | undefined;
        readonly resolve?: Function | undefined;
        readonly request?: Record<string, any> | undefined;
        readonly mode?: string | undefined;
        readonly surfaceId?: string | undefined;
        readonly passwordPrompt?: Record<string, any> | undefined;
    };
}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, string, import('vue').PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {}, HTMLDivElement>;
export default _default;
