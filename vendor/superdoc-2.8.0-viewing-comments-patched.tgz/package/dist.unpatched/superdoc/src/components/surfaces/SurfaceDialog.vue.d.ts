declare const _default: import('vue').DefineComponent<{}, {
    $emit: (event: "close", ...args: any[]) => void;
    surface: Record<string, any>;
    scrollLockTarget: Record<string, any>;
    $props: {
        readonly surface?: Record<string, any> | undefined;
        readonly scrollLockTarget?: Record<string, any> | undefined;
    };
}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, string, import('vue').PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {
    dialogRef: HTMLDivElement;
}, HTMLDivElement>;
export default _default;
