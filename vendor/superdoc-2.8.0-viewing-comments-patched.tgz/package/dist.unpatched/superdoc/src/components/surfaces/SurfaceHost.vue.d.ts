declare const _default: import('vue').DefineComponent<{}, {
    geometryTarget: Record<string, any>;
    $props: {
        readonly geometryTarget?: Record<string, any> | undefined;
    };
}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, string, import('vue').PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {
    hostRef: HTMLDivElement;
    floatingRef: import('vue').CreateComponentPublicInstanceWithMixins<Readonly<{}> & Readonly<{}>, {
        rootEl: import('vue').Ref<null, null>;
        surface: Record<string, any>;
        $props: {
            readonly surface?: Record<string, any> | undefined;
        };
    }, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, import('vue').PublicProps, {}, true, {}, {}, import('vue').GlobalComponents, import('vue').GlobalDirectives, string, {
        floatingRef: HTMLDivElement;
    }, HTMLDivElement, import('vue').ComponentProvideOptions, {
        P: {};
        B: {};
        D: {};
        C: {};
        M: {};
        Defaults: {};
    }, Readonly<{}> & Readonly<{}>, {
        rootEl: import('vue').Ref<null, null>;
        surface: Record<string, any>;
        $props: {
            readonly surface?: Record<string, any> | undefined;
        };
    }, {}, {}, {}, {}> | null;
}, any>;
export default _default;
