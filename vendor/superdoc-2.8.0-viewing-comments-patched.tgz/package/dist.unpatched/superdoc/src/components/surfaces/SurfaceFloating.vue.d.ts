declare const _default: import('vue').DefineComponent<{}, {
    rootEl: import('vue').Ref<null, null>;
    surface: Record<string, any>;
    $props: {
        readonly surface?: Record<string, any> | undefined;
    };
}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, string, import('vue').PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {
    floatingRef: HTMLDivElement;
}, HTMLDivElement>;
export default _default;
