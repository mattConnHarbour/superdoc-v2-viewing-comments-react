declare const _default: import('vue').DefineComponent<{}, {
    $emit: (event: "page-rendered" | "page-error" | "selection-raw" | "bypass-selection" | "page-focus", ...args: any[]) => void;
    config: Record<string, any>;
    pages: unknown[];
    hasTextLayer: boolean;
    pdf?: Record<string, any> | undefined;
    scale?: number | undefined;
    outputScale?: number | undefined;
    $props: {
        readonly config?: Record<string, any> | undefined;
        readonly pages?: unknown[] | undefined;
        readonly hasTextLayer?: boolean | undefined;
        readonly pdf?: Record<string, any> | undefined;
        readonly scale?: number | undefined;
        readonly outputScale?: number | undefined;
    };
}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, string, import('vue').PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {
    documentRef: HTMLDivElement;
    documentWrapper: HTMLDivElement;
}, HTMLDivElement>;
export default _default;
