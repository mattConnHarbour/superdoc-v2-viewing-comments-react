declare const _default: import('vue').DefineComponent<{}, {
    updateScale: typeof updateScale;
    $emit: (event: "page-rendered" | "selection-raw" | "bypass-selection" | "pages-loaded" | "document-loaded" | "document-ready" | "document-error", ...args: any[]) => void;
    config: Record<string, any>;
    file: Record<string, any>;
    initialScale: number;
    fileId?: string | undefined;
    $props: {
        readonly config?: Record<string, any> | undefined;
        readonly file?: Record<string, any> | undefined;
        readonly initialScale?: number | undefined;
        readonly fileId?: string | undefined;
    };
}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, string, import('vue').PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {
    rootRef: HTMLDivElement;
    documentRef: import('vue').CreateComponentPublicInstanceWithMixins<Readonly<{}> & Readonly<{}>, {
        $emit: (event: "page-rendered" | "page-error" | "selection-raw" | "bypass-selection" | "page-focus", ...args: any[]) => void;
        config: Record<string, any>;
        pages: unknown[];
        hasTextLayer: boolean;
        pdf?: Record<string, any> | undefined;
        scale?: number | undefined;
        outputScale?: number | undefined;
        $props: {
            readonly config?: Record<string, any> | undefined;
            readonly pages?: unknown[] | undefined;
            readonly hasTextLayer?: boolean | undefined;
            readonly pdf?: Record<string, any> | undefined;
            readonly scale?: number | undefined;
            readonly outputScale?: number | undefined;
        };
    }, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, import('vue').PublicProps, {}, true, {}, {}, import('vue').GlobalComponents, import('vue').GlobalDirectives, string, {
        documentRef: HTMLDivElement;
        documentWrapper: HTMLDivElement;
    }, HTMLDivElement, import('vue').ComponentProvideOptions, {
        P: {};
        B: {};
        D: {};
        C: {};
        M: {};
        Defaults: {};
    }, Readonly<{}> & Readonly<{}>, {
        $emit: (event: "page-rendered" | "page-error" | "selection-raw" | "bypass-selection" | "page-focus", ...args: any[]) => void;
        config: Record<string, any>;
        pages: unknown[];
        hasTextLayer: boolean;
        pdf?: Record<string, any> | undefined;
        scale?: number | undefined;
        outputScale?: number | undefined;
        $props: {
            readonly config?: Record<string, any> | undefined;
            readonly pages?: unknown[] | undefined;
            readonly hasTextLayer?: boolean | undefined;
            readonly pdf?: Record<string, any> | undefined;
            readonly scale?: number | undefined;
            readonly outputScale?: number | undefined;
        };
    }, {}, {}, {}, {}> | null;
}, HTMLDivElement>;
export default _default;
declare function updateScale(nextScale: any): void;
