declare const _default: import('vue').DefineComponent<{}, {
    $emit: (event: "page-rendered" | "page-error" | "text-layer-rendered" | "text-layer-error" | "selection-raw" | "bypass-selection", ...args: any[]) => void;
    config: Record<string, any>;
    page: Record<string, any>;
    pages: unknown[];
    scale: number;
    hasTextLayer: boolean;
    outputScale: number;
    documentEl: Record<string, any>;
    $props: {
        readonly config?: Record<string, any> | undefined;
        readonly page?: Record<string, any> | undefined;
        readonly pages?: unknown[] | undefined;
        readonly scale?: number | undefined;
        readonly hasTextLayer?: boolean | undefined;
        readonly outputScale?: number | undefined;
        readonly documentEl?: Record<string, any> | undefined;
    };
}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, string, import('vue').PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {
    pageRef: HTMLDivElement;
    canvasRef: HTMLCanvasElement;
    textLayerRef: HTMLDivElement;
}, HTMLDivElement>;
export default _default;
