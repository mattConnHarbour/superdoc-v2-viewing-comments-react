export function hasLegacyTrackedChangeThreadSignal(comment: Record<string, any> | null | undefined): boolean;
export function trackedChangeThreadParentIdForComment(comment: Record<string, any> | null | undefined): string | number | null;
