declare const _default: import('vue').DefineComponent<{}, {
    $emit: (event: "resolve" | "reject" | "reopen" | "overflow-select", ...args: any[]) => void;
    config: Record<string, any>;
    isPendingInput: boolean;
    isActive: boolean;
    resolveDisabledReason: string;
    rejectDisabledReason: string;
    reopenDisabledReason: string;
    reopenSupported: boolean;
    writeDisabledReason: string;
    timestamp?: number | undefined;
    comment?: Record<string, any> | undefined;
    $props: {
        readonly config?: Record<string, any> | undefined;
        readonly isPendingInput?: boolean | undefined;
        readonly isActive?: boolean | undefined;
        readonly resolveDisabledReason?: string | undefined;
        readonly rejectDisabledReason?: string | undefined;
        readonly reopenDisabledReason?: string | undefined;
        readonly reopenSupported?: boolean | undefined;
        readonly writeDisabledReason?: string | undefined;
        readonly timestamp?: number | undefined;
        readonly comment?: Record<string, any> | undefined;
    };
}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, string, import('vue').PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {}, HTMLDivElement>;
export default _default;
