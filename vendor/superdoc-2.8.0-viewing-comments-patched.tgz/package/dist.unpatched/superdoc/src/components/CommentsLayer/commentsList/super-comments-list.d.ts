import { EventEmitter } from 'eventemitter3';
/**
 * Comments list renderer (not floating comments)
 *
 * This renders a list of comments into an element, connected to main SuperDoc instance
 */
export class SuperComments extends EventEmitter<string | symbol, any> {
    constructor(options: any, superdoc: any);
    element: any;
    config: {
        comments: never[];
        element: null;
        commentsStore: null;
    };
    app: import('vue').App<Element> | null;
    superdoc: any;
    stopDirectoryObservers: any[];
    directorySnapshots: {
        comments: null;
        trackChanges: null;
    };
    directoryItemRefs: {
        comments: null;
        trackChanges: null;
    };
    directoryGeneration: number;
    syncDirectory(): void;
    startDirectoryObservers(): void;
    createVueApp(): void;
    container: import('vue').ComponentPublicInstance<{}, {}, {}, {}, {}, {}, {}, {}, false, import('vue').ComponentOptionsBase<any, any, any, any, any, any, any, any, any, {}, {}, string, {}, {}, {}, string, import('vue').ComponentProvideOptions>, {}, {}, "", {}, any> | null | undefined;
    close(): void;
    open(): void;
}
