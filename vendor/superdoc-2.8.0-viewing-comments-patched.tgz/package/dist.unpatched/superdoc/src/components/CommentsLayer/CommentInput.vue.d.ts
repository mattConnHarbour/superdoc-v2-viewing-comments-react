declare const _default: import('vue').DefineComponent<{}, {
    focus: (options: any) => void;
    $emit: (event: "focus", ...args: any[]) => void;
    config: Record<string, any>;
    users: unknown[];
    isFocused: boolean;
    includeHeader: boolean;
    comment?: Record<string, any> | undefined;
    $props: {
        readonly config?: Record<string, any> | undefined;
        readonly users?: unknown[] | undefined;
        readonly isFocused?: boolean | undefined;
        readonly includeHeader?: boolean | undefined;
        readonly comment?: Record<string, any> | undefined;
    };
}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, string, import('vue').PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {
    inputRef: HTMLTextAreaElement;
}, HTMLDivElement>;
export default _default;
