export function collectTrackedChangeThread<Comment extends {
    commentId: string;
    parentCommentId?: string | null;
    threadingParentCommentId?: string | null;
    trackedChangeThreadParentId?: string | null;
}>(parentComment: Comment, allComments: ReadonlyArray<Comment>): Array<Comment>;
