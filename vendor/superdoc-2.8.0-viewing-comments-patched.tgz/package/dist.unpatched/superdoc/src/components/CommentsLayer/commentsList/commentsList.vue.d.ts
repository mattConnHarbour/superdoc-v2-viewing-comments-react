declare const _default: import('vue').DefineComponent<{}, {
    showMainComments: boolean;
    showResolvedComments: boolean;
    $props: {
        readonly showMainComments?: boolean | undefined;
        readonly showResolvedComments?: boolean | undefined;
    };
}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, string, import('vue').PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {
    listRoot: HTMLDivElement;
}, HTMLDivElement>;
export default _default;
