export namespace conversation {
    let conversationId: null;
    let documentId: null;
    let creatorId: null;
    let creatorEmail: null;
    let creatorName: null;
    let comments: never[];
    let selection: null;
}
export namespace comment {
    let comment: null;
    namespace user {
        let id: null;
        let name: null;
        let email: null;
    }
    let timestamp: null;
}
