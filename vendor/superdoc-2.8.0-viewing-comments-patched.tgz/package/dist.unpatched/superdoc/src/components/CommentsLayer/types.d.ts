export type Comment = import('../../../../../shared/common').Comment;
export type CommentContent = import('../../../../../shared/common').CommentContent;
export type CommentJSON = import('../../../../../shared/common').CommentJSON;
