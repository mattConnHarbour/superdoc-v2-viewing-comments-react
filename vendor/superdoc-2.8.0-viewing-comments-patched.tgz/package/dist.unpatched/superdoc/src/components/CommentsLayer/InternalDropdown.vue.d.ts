declare const _default: import('vue').DefineComponent<{}, {
    $emit: (event: "select", ...args: any[]) => void;
    isDisabled: boolean;
    state?: string | undefined;
    $props: {
        readonly isDisabled?: boolean | undefined;
        readonly state?: string | undefined;
    };
}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, string, import('vue').PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {}, HTMLDivElement>;
export default _default;
