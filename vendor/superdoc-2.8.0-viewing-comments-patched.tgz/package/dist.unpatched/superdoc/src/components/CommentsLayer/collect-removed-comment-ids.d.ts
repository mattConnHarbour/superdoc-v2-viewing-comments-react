export function collectRemovedCommentIds(comments: ReadonlyArray<Record<string, any>>, targetIds: ReadonlyArray<string>, isInScope?: (comment: Record<string, any>) => boolean): Set<string>;
