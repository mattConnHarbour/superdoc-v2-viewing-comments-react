/**
 * Comment composable
 *
 * @param {Object} params The initial values of the comment
 * @returns {Object} The comment composable
 */
export default function useComment(params: Object): Object;
export const COMMENT_RECONCILIATION_TOKEN: unique symbol;
