declare const _default: import('vue').DefineComponent<{}, {
    $emit: (event: "resize" | "click-outside" | "ready" | "dialog-exit", ...args: any[]) => void;
    comment: Record<string, any>;
    autoFocus: boolean;
    floatingInstanceId: string;
    floatingPageIndex: number;
    floatingPositionEntry: Record<string, any>;
    threadComments: unknown[];
    parent?: Record<string, any> | undefined;
    isFloatingInstanceActive?: boolean | undefined;
    $props: {
        readonly comment?: Record<string, any> | undefined;
        readonly autoFocus?: boolean | undefined;
        readonly floatingInstanceId?: string | undefined;
        readonly floatingPageIndex?: number | undefined;
        readonly floatingPositionEntry?: Record<string, any> | undefined;
        readonly threadComments?: unknown[] | undefined;
        readonly parent?: Record<string, any> | undefined;
        readonly isFloatingInstanceActive?: boolean | undefined;
    };
}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, string, import('vue').PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {
    commentDialogElement: HTMLDivElement;
    commentInput: import('vue').CreateComponentPublicInstanceWithMixins<Readonly<{}> & Readonly<{}>, {
        focus: (options: any) => void;
        $emit: (event: "focus", ...args: any[]) => void;
        config: Record<string, any>;
        users: unknown[];
        isFocused: boolean;
        includeHeader: boolean;
        comment?: Record<string, any> | undefined;
        $props: {
            readonly config?: Record<string, any> | undefined;
            readonly users?: unknown[] | undefined;
            readonly isFocused?: boolean | undefined;
            readonly includeHeader?: boolean | undefined;
            readonly comment?: Record<string, any> | undefined;
        };
    }, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, import('vue').PublicProps, {}, true, {}, {}, import('vue').GlobalComponents, import('vue').GlobalDirectives, string, {
        inputRef: HTMLTextAreaElement;
    }, HTMLDivElement, import('vue').ComponentProvideOptions, {
        P: {};
        B: {};
        D: {};
        C: {};
        M: {};
        Defaults: {};
    }, Readonly<{}> & Readonly<{}>, {
        focus: (options: any) => void;
        $emit: (event: "focus", ...args: any[]) => void;
        config: Record<string, any>;
        users: unknown[];
        isFocused: boolean;
        includeHeader: boolean;
        comment?: Record<string, any> | undefined;
        $props: {
            readonly config?: Record<string, any> | undefined;
            readonly users?: unknown[] | undefined;
            readonly isFocused?: boolean | undefined;
            readonly includeHeader?: boolean | undefined;
            readonly comment?: Record<string, any> | undefined;
        };
    }, {}, {}, {}, {}> | null;
}, HTMLDivElement>;
export default _default;
