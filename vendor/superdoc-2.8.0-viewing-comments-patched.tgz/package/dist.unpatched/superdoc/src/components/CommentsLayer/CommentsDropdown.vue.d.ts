declare const _default: __VLS_WithTemplateSlots<typeof __VLS_component, __VLS_TemplateResult["slots"]>;
export default _default;
type __VLS_WithTemplateSlots<T, S> = T & (new () => {
    $slots: S;
});
declare const __VLS_component: import('vue').DefineComponent<{}, {
    $emit: (event: "select", ...args: any[]) => void;
    options: unknown[];
    disabled: boolean;
    contentStyle: Record<string, any>;
    $props: {
        readonly options?: unknown[] | undefined;
        readonly disabled?: boolean | undefined;
        readonly contentStyle?: Record<string, any> | undefined;
    };
}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, string, import('vue').PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {
    triggerRef: HTMLDivElement;
    menuRef: HTMLDivElement;
}, HTMLDivElement>;
type __VLS_TemplateResult = {
    attrs: Partial<{}>;
    slots: {
        default?(_: {}): any;
    };
    refs: {
        triggerRef: HTMLDivElement;
        menuRef: HTMLDivElement;
    };
    rootEl: HTMLDivElement;
};
