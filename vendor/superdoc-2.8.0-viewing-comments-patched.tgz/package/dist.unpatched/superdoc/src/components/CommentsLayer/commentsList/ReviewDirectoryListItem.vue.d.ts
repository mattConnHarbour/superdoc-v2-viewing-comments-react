declare const _default: import('vue').DefineComponent<{}, {
    $emit: (event: "focus-item" | "navigate", ...args: any[]) => void;
    item: Record<string, any>;
    index: number;
    total: number;
    tabIndex: number;
    $props: {
        readonly item?: Record<string, any> | undefined;
        readonly index?: number | undefined;
        readonly total?: number | undefined;
        readonly tabIndex?: number | undefined;
    };
}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, string, import('vue').PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {
    shell: HTMLDivElement;
}, HTMLDivElement>;
export default _default;
