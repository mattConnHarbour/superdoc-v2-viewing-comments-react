export function isPersistentReviewSidebarItem(comment: any): boolean;
export function normalizeFloatingAnchorTop(top: any): any;
export function isAnchorOutsideFloatingViewport(anchorTop: any, viewportTop: any, viewportBottom: any, anchorBottom?: any): boolean;
export function shouldKeepPersistentReviewCardAtAnchor({ comment, anchorTop, anchorBottom, viewportTop, viewportBottom, }: {
    comment: any;
    anchorTop: any;
    anchorBottom: any;
    viewportTop: any;
    viewportBottom: any;
}): boolean;
export function resolvePersistentReviewCardTop({ comment, anchorTop, anchorBottom, cardHeight, viewportTop, viewportBottom, }: {
    comment: any;
    anchorTop: any;
    anchorBottom: any;
    cardHeight: any;
    viewportTop: any;
    viewportBottom: any;
}): any;
export function shouldMountFloatingCommentDialog({ id, visibleIds, activeCommentInstanceId }: {
    id: any;
    visibleIds: any;
    activeCommentInstanceId: any;
}): boolean;
export function resolveRemovedReviewCardContinuityTarget({ previousIds, currentIds, removedId }: {
    previousIds: readonly string[];
    currentIds: ReadonlySet<string>;
    removedId: string;
}): string | null;
