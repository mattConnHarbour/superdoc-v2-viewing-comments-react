export function useFloatingComment(params: any): {
    id: any;
    comment: import('vue').Ref<any, any>;
    position: {
        top: number;
        left: number;
        right: number;
        bottom: number;
    };
    offset: import('vue').Ref<number, number>;
};
