declare const _default: import('vue').DefineComponent<{}, {
    $emit: (event: "ready" | "selection-change", ...args: any[]) => void;
    documentId: string;
    fileSource: File | Blob;
    $props: {
        readonly documentId?: string | undefined;
        readonly fileSource?: File | Blob | undefined;
    };
}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, string, import('vue').PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {}, HTMLDivElement>;
export default _default;
