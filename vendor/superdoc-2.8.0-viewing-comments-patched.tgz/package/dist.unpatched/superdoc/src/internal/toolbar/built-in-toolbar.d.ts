import { EventEmitter } from 'eventemitter3';
/**
 * Create the rendered built-in toolbar for a `SuperDoc` instance.
 * @param {object} config
 * @returns {BuiltInToolbar}
 */
export function createBuiltInToolbar(config: object): BuiltInToolbar;
/**
 * The rendered built-in toolbar. Shape-compatible with the historical
 * `superdoc.toolbar` (`SuperToolbar`) surface so existing docs, examples, the
 * proof lane, and behavior tests resolve against a real object.
 *
 * @class
 * @extends EventEmitter
 */
export class BuiltInToolbar extends EventEmitter<string | symbol, any> {
    /**
     * @param {object} config Toolbar config forwarded by `SuperDoc`. Requires
     *   `superdoc`; `selector` is the mount target.
     */
    constructor(config?: object);
    config: {
        selector: null;
        toolbarGroups: string[];
        role: string;
        icons: {
            undo: any;
            redo: any;
            bold: any;
            italic: any;
            underline: any;
            color: any;
            link: any;
            image: any;
            tableOfContents: any;
            alignLeft: any;
            alignRight: any;
            alignCenter: any;
            alignJustify: any;
            bulletList: any;
            bulletListDisc: any;
            bulletListCircle: any;
            bulletListSquare: any;
            numberedList: any;
            numberedListDecimal: any;
            numberedListDecimalParen: any;
            numberedListUpperRoman: any;
            numberedListLowerRoman: any;
            numberedListUpperAlpha: any;
            numberedListUpperAlphaParen: any;
            numberedListLowerAlpha: any;
            numberedListLowerAlphaParen: any;
            indentLeft: any;
            indentRight: any;
            directionLtr: any;
            directionRtl: any;
            pageBreak: any;
            copyFormat: any;
            clearFormatting: any;
            trackChanges: any;
            trackChangesFinal: any;
            trackChangesOriginal: any;
            trackChangesAccept: any;
            trackChangesReject: any;
            documentMode: any;
            documentEditingMode: any;
            documentSuggestingMode: any;
            documentViewingMode: any;
            colorOption: any;
            colorOptionCheck: any;
            linkInput: any;
            removeLink: any;
            openLink: any;
            overflow: any;
            dropdownCaretUp: any;
            dropdownCaretDown: any;
            ruler: any;
            paintbrush: any;
            highlight: any;
            ai: any;
            table: any;
            tableActions: any;
            splitCell: any;
            mergeCells: any;
            addRowBefore: any;
            addRowAfter: any;
            addColumnBefore: any;
            addColumnAfter: any;
            deleteRow: any;
            deleteColumn: any;
            deleteTable: any;
            deleteBorders: any;
            fixTables: any;
            lineHeight: any;
            search: any;
            cut: any;
            copy: any;
            paste: any;
            strikethrough: any;
            formattingMarks: any;
        };
        texts: {
            bold: string;
            fontFamily: string;
            ai: string;
            fontSize: string;
            italic: string;
            underline: string;
            highlight: string;
            strikethrough: string;
            color: string;
            search: string;
            link: string;
            image: string;
            tableOfContents: string;
            table: string;
            tableActions: string;
            addRowBefore: string;
            addRowAfter: string;
            addColumnBefore: string;
            addColumnAfter: string;
            deleteRow: string;
            deleteColumn: string;
            deleteTable: string;
            removeBorders: string;
            mergeCells: string;
            splitCell: string;
            fixTables: string;
            textAlign: string;
            bulletList: string;
            numberedList: string;
            indentLeft: string;
            indentRight: string;
            directionLtr: string;
            directionRtl: string;
            zoom: string;
            measurementUnit: string;
            undo: string;
            redo: string;
            trackChanges: string;
            trackChangesAccept: string;
            trackChangesReject: string;
            trackChangesOriginal: string;
            trackChangesFinal: string;
            clearFormatting: string;
            copyFormat: string;
            lineHeight: string;
            formatText: string;
            ruler: string;
            formattingMarks: string;
            pageBreak: string;
            documentEditingMode: string;
            documentSuggestingMode: string;
            documentViewingMode: string;
            documentEditingModeDescription: string;
            documentSuggestingModeDescription: string;
            documentViewingModeDescription: string;
            linkedStyles: string;
        };
        fonts: null;
        hideButtons: boolean;
        responsiveToContainer: boolean;
        mode: string;
        excludeItems: never[];
        groups: null;
        customButtons: never[];
        showFormattingMarksButton: boolean;
        showTableOfContentsButton: boolean;
    };
    toolbarItems: any[];
    overflowItems: any[];
    isDev: boolean;
    role: string;
    superdoc: any;
    toolbarContainer: null;
    toolbar: null;
    _detachFontsChanged: null;
    /** Active editor compatibility reference (set by `SuperDoc.setActiveEditor`). */
    activeEditor: any;
    /** SuperDoc-owned command controller (single command-state truth). */
    ui: any;
    /** Latest controller toolbar snapshot. */
    snapshot: any;
    /** Controller subscription unsubscribe handle. */
    _unsubscribeController: any;
    /** Format-painter mode subscription unsubscribe handle. */
    _detachFormatPainterModeChange: any;
    /** Registered custom-button command unregister handles. */
    _customCommandRegs: Map<any, any>;
    /**
     * Custom entries already reported as unbuildable.
     *
     * `#makeToolbarItems` runs on every throttled resize and on font or
     * active-editor changes, not only at construction, so a single static
     * configuration error would otherwise fire `exception` once per rebuild --
     * unbounded, into consumer telemetry, for a mistake that cannot change
     * without a reconfigure. Keyed by name plus message so a different fault
     * on the same entry still reports once.
     */
    _reportedInvalidCustomItems: Set<any>;
    /** Signature of the last-built font options, to skip redundant rebuilds. */
    _lastFontOptionsSignature: string;
    app: import('vue').App<Element> | undefined;
    getAvailableWidth(): any;
    getToolbarItemByGroup(groupName: any): any[];
    getToolbarItemByName(name: any): any;
    /**
     * The available linked-style options for the linked-styles dropdown. Projected
     * from the shared controller's public `superdoc/ui` style catalogue
     * (`ui.styles.getQuickGallery()`), which reads the Document API style catalogue
     * (`styles.getCatalog`) and honors `w:qFormat` with a v1-style alphabetical
     * fallback. Returns normalized `StyleCatalogItem`s (`id`, `name`, optional
     * `preview.css`, visibility), never raw style-model shapes. Empty when the
     * styles surface is unreachable (viewing mode, worker-backed editor, pre-ready
     * editor). Applying a style still routes through the shared `linked-style`
     * command, which targets `styles.paragraph.setStyle`.
     * @returns {Array}
     */
    getLinkedStyleOptions(): any[];
    /**
     * The stable style id active across the current selection's paragraph(s), or
     * `null` for a mixed selection / when the styles surface is unreachable. Used
     * to mark the active option in the linked-styles dropdown.
     * @returns {string|null}
     */
    getActiveLinkedStyleId(): string | null;
    /**
     * Compatibility hook: `SuperDoc` calls this when the active editor changes.
     * The shared controller already tracks selection/transaction state, so this
     * just refreshes font options (the new document may carry different fonts) and
     * re-projects item state.
     * @param {object|null} editor
     */
    setActiveEditor(editor: object | null): void;
    onToolbarResize: () => void;
    updateToolbarState(): void;
    /**
     * Main toolbar command entry point used by the rendered components.
     * @param {{ item: object, argument?: unknown, option?: unknown }} params
     */
    emitCommand({ item, argument, option }: {
        item: object;
        argument?: unknown;
        option?: unknown;
    }): void;
    destroy(): void;
    #private;
}
