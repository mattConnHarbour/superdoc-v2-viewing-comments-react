/** Layout regions a built-in toolbar item can be placed in. */
export type ToolbarGroup = 'left' | 'center' | 'right';
/** How a documented built-in toolbar item is (or is not) backed on V2. */
export type ToolbarItemDisposition = 'controller-routed' | 'host-routed' | 'shell-owned' | 'unsupported' | 'unresolved';
/** One documented built-in toolbar item and how it maps onto V2. */
export interface BuiltInToolbarItemEntry {
    /** Legacy built-in item name (the id v1 toolbars and the docs use). */
    readonly name: string;
    /**
     * Canonical V2 controller command id this item routes to. Present for
     * `controller-routed` items; `null` for host/shell/unresolved items.
     */
    readonly commandId: string | null;
    /**
     * Public `SuperDoc`-instance method the built-in shell calls to drive this
     * item. Present for `host-routed` items; `null` otherwise.
     */
    readonly instanceMethod: string | null;
    /** Disposition bucket. */
    readonly disposition: ToolbarItemDisposition;
    /** Default layout group for the rendered shell. */
    readonly group: ToolbarGroup;
    /**
     * Member controller command ids for an item that fans out into a family of
     * commands (e.g. `tableActions`). Documentation + later renderer use.
     */
    readonly memberCommandIds?: readonly string[];
    /**
     * Stable explanation. Required for `host-routed`, `shell-owned`, and
     * `unresolved` items so the non-controller disposition is never opaque.
     */
    readonly note?: string;
}
/**
 * The built-in toolbar compatibility catalog. Order groups items the way the
 * docs present them; it is documentation-only.
 *
 * Every documented `Available buttons` entry from
 * the built-in UI documentation appears here exactly once, plus the
 * `customButtons` shell concept.
 */
export declare const BUILT_IN_TOOLBAR_CATALOG: readonly BuiltInToolbarItemEntry[];
/** All documented built-in toolbar item names known to the catalog. */
export declare const ALL_BUILT_IN_TOOLBAR_ITEM_NAMES: readonly string[];
/** Resolve a built-in toolbar item entry by its legacy name, or `null`. */
export declare function getBuiltInToolbarItem(name: string): BuiltInToolbarItemEntry | null;
/** All built-in toolbar items declared for a layout group, in catalog order. */
export declare function listBuiltInToolbarItemsByGroup(group: ToolbarGroup): BuiltInToolbarItemEntry[];
/**
 * Resolve a legacy built-in item name to its canonical V2 controller command
 * id, or `null` when the item is not controller-routed.
 */
export declare function resolveToolbarCommandId(name: string): string | null;
/**
 * Cross-check the catalog against the V2 command controller catalog so the two
 * cannot drift. Throws on the first inconsistency. Exercised by the unit tests;
 * kept exported so a future renderer/build guard can reuse it.
 */
export declare function assertCatalogAlignedWithController(): void;
