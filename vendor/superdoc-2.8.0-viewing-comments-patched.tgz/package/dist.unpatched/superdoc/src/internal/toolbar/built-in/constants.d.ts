/**
 * The single seam that composes the font dropdown options: it turns the active document's
 * {@link import('../../../../../shared/font-system/src/index.js').DocumentFontOption}s into toolbar font options and unions them
 * with the bundled defaults. The toolbar only asks for the result; it does not know how a font previews.
 *
 * - A consumer-provided `configFonts` list is returned UNCHANGED (custom toolbars own their list).
 * - With no document options, returns `undefined` so the caller keeps its fallback to {@link TOOLBAR_FONTS}.
 * - Otherwise: bundled defaults and document fonts are deduped by normalized logical family, then sorted
 *   alphabetically by the visible font name. `label`/`key` stay the pure logical family (active-state
 *   matching + the stored value), and the preview renders in `previewFamily`.
 *
 * @param {ReadonlyArray<import('../../../../../shared/font-system/src/index.js').DocumentFontOption>} documentOptions
 * @param {Array} [configFonts] - the consumer's `fonts` config, if any
 * @returns {Array|undefined}
 */
export function composeToolbarFontOptions(documentOptions: ReadonlyArray<import('../../../../../shared/font-system/src/index.js').DocumentFontOption>, configFonts?: any[]): any[] | undefined;
/**
 * Map the host-computed, activation-aware font-family options onto the toolbar option shape. PURE: it
 * receives the already-resolved list from `superdoc.fonts.getFontFamilyOptions()` (the host owns the
 * `@superdoc/font-system` computation this module must not import). Returns `undefined` for an empty
 * list so the caller keeps its {@link TOOLBAR_FONTS} fallback. `label` is the Word-facing logical
 * family (stored on the selection + used for active-state matching), `key` is a stable option key, and
 * the row preview renders in `previewFamily` (falling back to the label).
 *
 * @param {ReadonlyArray<import('../../../../../shared/font-system/src/index.js').FontFamilyOption>} options
 * @returns {Array|undefined}
 */
export function mapFontFamilyOptionsToToolbar(options: ReadonlyArray<import('../../../../../shared/font-system/src/index.js').FontFamilyOption>): any[] | undefined;
export const TOOLBAR_FONTS: {
    label: string;
    key: string;
    props: {
        style: {
            fontFamily: string;
        };
        'data-item': string;
    };
}[];
export const TOOLBAR_FONT_SIZES: {
    label: string;
    key: string;
    props: {
        'data-item': string;
    };
}[];
export namespace RESPONSIVE_BREAKPOINTS {
    let sm: number;
    let md: number;
    let lg: number;
    let xl: number;
}
export namespace HEADLESS_ITEM_MAP {
    let undo: string;
    let redo: string;
    let bold: string;
    let italic: string;
    let underline: string;
    let strike: string;
    let acceptTrackedChangeBySelection: string;
    let rejectTrackedChangeOnSelection: string;
    let ruler: string;
    let formattingMarks: string;
    let zoom: string;
    let measurementUnit: string;
    let documentMode: string;
    let link: string;
    let fontFamily: string;
    let fontSize: string;
    let list: string;
    let numberedlist: string;
    let table: string;
    let image: string;
    let tableOfContents: string;
    let color: string;
    let highlight: string;
    let textAlign: string;
    let lineHeight: string;
    let linkedStyles: string;
    let indentleft: string;
    let indentright: string;
    let directionLtr: string;
    let directionRtl: string;
    let clearFormatting: string;
    let copyFormat: string;
}
export namespace TABLE_ACTION_COMMAND_MAP {
    let addRowBefore: string;
    let addRowAfter: string;
    let deleteRow: string;
    let addColumnBefore: string;
    let addColumnAfter: string;
    let deleteColumn: string;
    let deleteTable: string;
    let deleteCellAndTableBorders: string;
    let mergeCells: string;
    let splitCell: string;
    let fixTables: string;
}
export const TABLE_ACTION_COMMAND_IDS: string[];
export const HEADLESS_TOOLBAR_COMMANDS: string[];
export const HEADLESS_EXECUTE_ITEMS: Set<string>;
