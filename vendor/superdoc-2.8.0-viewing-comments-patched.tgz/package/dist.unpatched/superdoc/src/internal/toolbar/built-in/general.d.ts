export function findElementBySelector(selector: string | HTMLElement | null | undefined): HTMLElement | null;
