declare const _default: __VLS_WithTemplateSlots<typeof __VLS_component, __VLS_TemplateResult["slots"]>;
export default _default;
type __VLS_WithTemplateSlots<T, S> = T & (new () => {
    $slots: S;
});
declare const __VLS_component: import('vue').DefineComponent<{}, {
    disabled: boolean;
    contentStyle: Record<string, any>;
    trigger: string;
    delay: number;
    duration: number;
    $props: {
        readonly disabled?: boolean | undefined;
        readonly contentStyle?: Record<string, any> | undefined;
        readonly trigger?: string | undefined;
        readonly delay?: number | undefined;
        readonly duration?: number | undefined;
    };
}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, string, import('vue').PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {
    triggerRef: HTMLSpanElement;
    contentRef: HTMLDivElement;
}, any>;
type __VLS_TemplateResult = {
    attrs: Partial<{}>;
    slots: {
        trigger?(_: {}): any;
        default?(_: {}): any;
    };
    refs: {
        triggerRef: HTMLSpanElement;
        contentRef: HTMLDivElement;
    };
    rootEl: any;
};
