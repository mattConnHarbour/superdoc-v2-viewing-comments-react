declare const _default: import('vue').DefineComponent<{}, {
    $emit: (event: "select" | "clickoutside", ...args: any[]) => void;
    icons: unknown[];
    activeColor?: Record<string, any> | undefined;
    $props: {
        readonly icons?: unknown[] | undefined;
        readonly activeColor?: Record<string, any> | undefined;
    };
}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, string, import('vue').PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {
    rowRefs: HTMLDivElement[];
    iconRefs: HTMLDivElement[];
}, any>;
export default _default;
