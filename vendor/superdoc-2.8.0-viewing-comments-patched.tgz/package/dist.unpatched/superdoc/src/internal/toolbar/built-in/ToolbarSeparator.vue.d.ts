declare const _default: import('vue').DefineComponent<{}, {
    $emit: (event: "command", ...args: any[]) => void;
    active: boolean;
    $props: {
        readonly active?: boolean | undefined;
    };
}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, string, import('vue').PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {}, HTMLDivElement>;
export default _default;
