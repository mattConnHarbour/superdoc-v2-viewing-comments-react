declare const _default: import('vue').DefineComponent<{}, {
    $emit: (event: "select", ...args: any[]) => void;
    buttons: unknown[];
    selectedStyle: string;
    iconSize: number;
    $props: {
        readonly buttons?: unknown[] | undefined;
        readonly selectedStyle?: string | undefined;
        readonly iconSize?: number | undefined;
    };
}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, string, import('vue').PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {
    buttonRefs: HTMLDivElement[];
}, HTMLDivElement>;
export default _default;
