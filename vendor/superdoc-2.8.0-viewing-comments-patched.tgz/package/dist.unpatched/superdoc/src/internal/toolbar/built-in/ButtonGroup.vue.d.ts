declare const _default: import('vue').DefineComponent<{}, {
    $emit: (event: "command" | "item-clicked" | "dropdown-update-show", ...args: any[]) => void;
    $props: {
        readonly [x: string]: any;
    };
}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, string, import('vue').PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {
    buttonGroupRef: HTMLDivElement;
    toolbarItemRefs: HTMLDivElement[];
}, HTMLDivElement>;
export default _default;
