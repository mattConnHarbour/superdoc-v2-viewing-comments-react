declare const _default: import('vue').DefineComponent<{}, {
    name: string;
    color: string;
    icon: string;
    $props: {
        readonly name?: string | undefined;
        readonly color?: string | undefined;
        readonly icon?: string | undefined;
    };
}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, string, import('vue').PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {}, HTMLDivElement>;
export default _default;
