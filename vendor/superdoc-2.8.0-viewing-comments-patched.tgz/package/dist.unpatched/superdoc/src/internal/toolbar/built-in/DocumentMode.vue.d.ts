declare const _default: import('vue').DefineComponent<{}, {
    $emit: (event: "select", ...args: any[]) => void;
    options?: unknown[] | undefined;
    $props: {
        readonly options?: unknown[] | undefined;
    };
}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, string, import('vue').PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {
    documentModeRefs: HTMLDivElement[];
}, HTMLDivElement>;
export default _default;
