export const bulletStyleButtons: {
    key: string;
    icon: any;
    ariaLabel: string;
}[];
export const numberedStyleButtons: {
    key: string;
    icon: any;
    ariaLabel: string;
}[];
