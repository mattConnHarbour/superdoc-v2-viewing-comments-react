declare const _default: import('vue').DefineComponent<{}, {
    $emit: (event: "close" | "buttonClick", ...args: any[]) => void;
    toolbarItem: Record<string, any>;
    overflowItems: unknown[];
    $props: {
        readonly toolbarItem?: Record<string, any> | undefined;
        readonly overflowItems?: unknown[] | undefined;
    };
}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, string, import('vue').PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {}, HTMLDivElement>;
export default _default;
