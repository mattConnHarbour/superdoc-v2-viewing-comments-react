export function sanitizeNumber(value: any, defaultNumber: any): any;
export function throttle(func: any, wait: any, options: any): {
    (...callArgs: any[]): any;
    cancel(): void;
};
