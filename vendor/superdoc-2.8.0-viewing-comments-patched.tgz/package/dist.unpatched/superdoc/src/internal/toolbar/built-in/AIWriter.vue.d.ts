declare const _default: import('vue').DefineComponent<{}, {
    target: Record<string, any>;
    doc: Record<string, any>;
    restoreSelection: Function;
    selectedText: string;
    apiKey: string;
    endpoint: string;
    handleClose: Function;
    $props: {
        readonly target?: Record<string, any> | undefined;
        readonly doc?: Record<string, any> | undefined;
        readonly restoreSelection?: Function | undefined;
        readonly selectedText?: string | undefined;
        readonly apiKey?: string | undefined;
        readonly endpoint?: string | undefined;
        readonly handleClose?: Function | undefined;
    };
}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, string, import('vue').PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {
    textareaRef: HTMLTextAreaElement;
}, HTMLFormElement>;
export default _default;
