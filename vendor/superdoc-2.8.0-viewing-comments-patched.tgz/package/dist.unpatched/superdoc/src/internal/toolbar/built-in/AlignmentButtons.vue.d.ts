declare const _default: import('vue').DefineComponent<{}, {
    $emit: (event: "select", ...args: any[]) => void;
}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, string, import('vue').PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {
    alignmentButtonsRefs: HTMLDivElement[];
}, HTMLDivElement>;
export default _default;
