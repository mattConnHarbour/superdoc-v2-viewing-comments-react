declare const _default: __VLS_WithTemplateSlots<typeof __VLS_component, __VLS_TemplateResult["slots"]>;
export default _default;
type __VLS_WithTemplateSlots<T, S> = T & (new () => {
    $slots: S;
});
declare const __VLS_component: import('vue').DefineComponent<{}, {
    $emit: (event: "select" | "update:show", ...args: any[]) => void;
    options: unknown[];
    disabled: boolean;
    contentStyle: Record<string, any>;
    placement: string;
    show: boolean;
    menuProps: Function;
    nodeProps: Function;
    $props: {
        readonly options?: unknown[] | undefined;
        readonly disabled?: boolean | undefined;
        readonly contentStyle?: Record<string, any> | undefined;
        readonly placement?: string | undefined;
        readonly show?: boolean | undefined;
        readonly menuProps?: Function | undefined;
        readonly nodeProps?: Function | undefined;
    };
}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, string, import('vue').PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {
    triggerRef: HTMLDivElement;
    menuRef: HTMLDivElement;
}, HTMLDivElement>;
type __VLS_TemplateResult = {
    attrs: Partial<{}>;
    slots: {
        trigger?(_: {}): any;
    };
    refs: {
        triggerRef: HTMLDivElement;
        menuRef: HTMLDivElement;
    };
    rootEl: HTMLDivElement;
};
