/**
 * Set or clear the link item's `href` without disturbing the rest of its
 * attributes. The static configuration (`ariaLabel`, and anything added later)
 * lives in the same object as the transient href, so rebuilding that object
 * from the keys a caller knows about silently drops the others.
 *
 * Exported because the built-in toolbar's `updateToolbarState()` writes the
 * href on its own path, without going through this item's handlers. Both
 * callers share this one rule so the two cannot drift apart.
 */
export function withLinkHref(attributes: any, href: any): any;
export function makeDefaultItems({ superToolbar, toolbarIcons, toolbarTexts, toolbarFonts, hideButtons, availableWidth, role, isDev, }?: {
    isDev?: boolean | undefined;
}): {
    defaultItems: any[];
    overflowItems: any[];
};
