/**
 * Validate and normalize an href. Returns `{ href }` for safe values, or `null`.
 * @param {string} value
 * @returns {{ href: string }|null}
 */
export function sanitizeHref(value: string): {
    href: string;
} | null;
