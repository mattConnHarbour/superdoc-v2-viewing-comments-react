declare const _default: import('vue').DefineComponent<{}, {
    $emit: (event: "buttonClick" | "textSubmit" | "mainClick", ...args: any[]) => void;
    active: boolean;
    isNarrow: boolean;
    isWide: boolean;
    defaultLabel: string;
    iconColor: string;
    toolbarItem: Record<string, any>;
    isOverflowItem: boolean;
    allowEnterPropagation: boolean;
    $props: {
        readonly active?: boolean | undefined;
        readonly isNarrow?: boolean | undefined;
        readonly isWide?: boolean | undefined;
        readonly defaultLabel?: string | undefined;
        readonly iconColor?: string | undefined;
        readonly toolbarItem?: Record<string, any> | undefined;
        readonly isOverflowItem?: boolean | undefined;
        readonly allowEnterPropagation?: boolean | undefined;
    };
}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, string, import('vue').PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {
    inlineInput: HTMLInputElement;
}, HTMLDivElement>;
export default _default;
