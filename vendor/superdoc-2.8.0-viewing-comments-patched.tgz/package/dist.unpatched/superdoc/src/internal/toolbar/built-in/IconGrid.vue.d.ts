declare const _default: import('vue').DefineComponent<{}, {
    $emit: (event: "select" | "clickoutside", ...args: any[]) => void;
    icons: unknown[];
    hasNoneIcon: boolean;
    activeColor?: Record<string, any> | undefined;
    customIcons?: unknown[] | undefined;
    $props: {
        readonly icons?: unknown[] | undefined;
        readonly hasNoneIcon?: boolean | undefined;
        readonly activeColor?: Record<string, any> | undefined;
        readonly customIcons?: unknown[] | undefined;
    };
}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, string, import('vue').PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {}, HTMLDivElement>;
export default _default;
