/**
 * Whether a picked/dropped file is an insertable image (PNG/JPEG). Falls back
 * to the file extension when the browser reports no MIME type.
 * @param {File | null | undefined} file
 * @returns {boolean}
 */
export function isSupportedImageFile(file: File | null | undefined): boolean;
/**
 * Read a File/Blob into a base64 data URI.
 *
 * Some browsers/OSes deliver picked files with an empty `type`; the picker
 * accepts those by extension, but `readAsDataURL` would then produce an
 * `application/octet-stream` data URI that `create.image` rejects. Rewrite
 * the media type from the filename so extension-accepted files still insert.
 * @param {Blob & { name?: string }} file
 * @returns {Promise<string>}
 */
export function fileToDataUri(file: Blob & {
    name?: string;
}): Promise<string>;
/**
 * Resolve the `create.image` src for a picked file. Uses the consumer's
 * `handleImageUpload` callback when configured (V1 contract:
 * `(file: File) => Promise<string>`). A returned non-data URL is fetched and
 * embedded, because `create.image` requires an embedded base64 data URI.
 * @param {File} file
 * @param {((file: File) => Promise<string>) | null | undefined} handleImageUpload
 * @returns {Promise<string>}
 */
export function resolveImageSrc(file: File, handleImageUpload: ((file: File) => Promise<string>) | null | undefined): Promise<string>;
/**
 * Hidden `<input type=file>` picker bound to one toolbar instance. The input
 * stays attached (hidden) so automation and tests can drive it; `destroy()`
 * removes it. Picking a file calls `onPick(file)`; an unsupported type or a
 * failed pick routes through `onError(error)`.
 *
 * @param {{
 *   ownerDocument?: Document,
 *   onPick?: (file: File) => unknown,
 *   onError?: (error: Error) => void,
 * }} options
 * @returns {{ input: HTMLInputElement, open: () => void, destroy: () => void }}
 */
export function createImageFilePicker({ ownerDocument, onPick, onError }?: {
    ownerDocument?: Document;
    onPick?: (file: File) => unknown;
    onError?: (error: Error) => void;
}): {
    input: HTMLInputElement;
    open: () => void;
    destroy: () => void;
};
/**
 * Interactive image acquisition for the built-in toolbar (SD-3567).
 *
 * The toolbar image button routes through the shared controller command
 * `image` → `create.image`, which requires a base64 PNG/JPEG data-URI `src`.
 * This module owns the browser file picker and the File → data-URI
 * conversion; the toolbar dispatches the resulting payload through the
 * normal controller command path.
 */
/** Accept filter for the picker: PNG and JPEG only (V1 parity; OOXML-native formats). */
export const IMAGE_PICKER_ACCEPT: ".png,.jpg,.jpeg,image/png,image/jpeg";
