declare const _default: import('vue').DefineComponent<{}, {
    $emit: (event: "select" | "clickoutside", ...args: any[]) => void;
}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, string, import('vue').PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {
    tableGridItems: HTMLDivElement[];
}, HTMLDivElement>;
export default _default;
