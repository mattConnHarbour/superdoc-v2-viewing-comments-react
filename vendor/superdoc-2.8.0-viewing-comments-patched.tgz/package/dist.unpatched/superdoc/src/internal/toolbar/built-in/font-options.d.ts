export function normalizeFontOption(option: any): any;
