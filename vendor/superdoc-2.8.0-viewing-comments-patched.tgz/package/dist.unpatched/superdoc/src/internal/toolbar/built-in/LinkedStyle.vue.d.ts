declare const _default: import('vue').DefineComponent<{}, {
    $emit: (event: "select", ...args: any[]) => void;
    styles: unknown[];
    selectedOption: string;
    $props: {
        readonly styles?: unknown[] | undefined;
        readonly selectedOption?: string | undefined;
    };
}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, string, import('vue').PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {
    styleRefs: HTMLDivElement[];
}, HTMLDivElement>;
export default _default;
