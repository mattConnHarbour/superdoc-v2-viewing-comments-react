export function refocusEditorSurface(superToolbar: any, preferredEditor?: null): void;
