export function findPrefixMatchIndex(query: string, labels: ReadonlyArray<string>): number;
export function computeTypeahead(query: string, labels: ReadonlyArray<string>, { autocomplete }?: {
    autocomplete?: boolean;
}): {
    matchIndex: number;
    display: string;
    selectionStart: number;
    selectionEnd: number;
};
export function normalizeCustomFontFamily(value: any): string;
export function normalizeCustomFontSize(value: string): string;
