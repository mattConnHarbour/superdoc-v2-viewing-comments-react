declare const _default: import('vue').DefineComponent<{}, {
    $emit: (event: "command" | "item-clicked" | "tab-out" | "editor-handoff", ...args: any[]) => void;
    item: Record<string, any>;
    uiFontFamily: string;
    showPreview: boolean;
    normalizeValue: Function;
    $props: {
        readonly item?: Record<string, any> | undefined;
        readonly uiFontFamily?: string | undefined;
        readonly showPreview?: boolean | undefined;
        readonly normalizeValue?: Function | undefined;
    };
}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, string, import('vue').PublicProps, Readonly<{}> & Readonly<{}>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {
    rootRef: HTMLDivElement;
    inputRef: HTMLInputElement;
    popupRef: HTMLDivElement;
}, HTMLDivElement>;
export default _default;
