export function useCompactCommentPopover({ activeComment, pendingComment, activeCompactComment, showCommentsSidebar, selectionPosition, activeZoom, superdocRoot, layers, documents, resolveCommentPositionEntry, clearActiveComment, clearPendingComment, }: {
    activeComment: any;
    pendingComment: any;
    activeCompactComment: any;
    showCommentsSidebar: any;
    selectionPosition: any;
    activeZoom: any;
    superdocRoot: any;
    layers: any;
    documents: any;
    resolveCommentPositionEntry: any;
    clearActiveComment: any;
    clearPendingComment: any;
}): {
    compactCommentPopoverStyle: import('vue').ComputedRef<{
        top: string;
        right: string;
    }>;
    closeCompactCommentPopover: () => void;
    resetClickAnchor: () => void;
};
