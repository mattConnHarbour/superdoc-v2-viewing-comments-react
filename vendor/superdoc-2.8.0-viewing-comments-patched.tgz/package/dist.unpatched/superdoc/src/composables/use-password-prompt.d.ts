/**
 * Composable that coordinates password-prompt dialogs for encrypted DOCX files.
 *
 * Owns a FIFO queue of pending prompts (one active dialog at a time), and a
 * `pendingSignals` map that bridges the async gap between triggering a remount
 * and observing the result via `onEditorReady` / `onEditorException`.
 *
 * @param {Object} options
 * @param {() => import('../core/surface-manager.js').SurfaceManager | null} options.getSurfaceManager
 * @param {() => boolean | PasswordPromptConfig | undefined} options.getPasswordPromptConfig
 * @param {(doc: any, errorCode: string, originalException?: { error?: Error, editor?: any }) => void} [options.onUnhandled] Called when a queued prompt cannot be shown (resolver returned `none`, config error, or resolver threw). Receives the original exception payload so the host can re-emit it unchanged.
 */
export function usePasswordPrompt({ getSurfaceManager, getPasswordPromptConfig, onUnhandled }: {
    getSurfaceManager: () => import('../core/surface-manager.js').SurfaceManager | null;
    getPasswordPromptConfig: () => boolean | PasswordPromptConfig | undefined;
    onUnhandled?: ((doc: any, errorCode: string, originalException?: {
        error?: Error;
        editor?: any;
    }) => void) | undefined;
}): {
    handleEncryptionError: (doc: any, errorCode: string, originalException?: {
        error?: Error;
        editor?: any;
    }) => boolean;
    handleEditorReady: (doc: any) => void;
    destroy: () => void;
};
export type PasswordPromptConfig = import('../core/types/index.js').PasswordPromptConfig;
export type ResolvedPasswordPromptTexts = import('../core/types/index.js').ResolvedPasswordPromptTexts;
export type PasswordPromptHandle = import('../core/types/index.js').PasswordPromptHandle;
export type PasswordPromptContext = import('../core/types/index.js').PasswordPromptContext;
export type PasswordPromptResolution = import('../core/types/index.js').PasswordPromptResolution;
export type PasswordPromptAttemptResult = import('../core/types/index.js').PasswordPromptAttemptResult;
