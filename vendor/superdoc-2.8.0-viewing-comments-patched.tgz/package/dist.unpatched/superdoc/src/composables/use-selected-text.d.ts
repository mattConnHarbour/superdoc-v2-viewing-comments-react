/**
 * Composable to get the currently selected text from an editor.
 *
 * When a mounted editor runtime is active and can read selected text, route the
 * synchronous read through the runtime boundary. The legacy direct editor-state
 * read remains as a fallback for startup and bare-editor callers.
 *
 * @param {Object} editorRef - Ref to the editor instance
 * @param {Object} [options]
 * @param {() => (import('../core/editor-runtime/index.js').EditorRuntime | null | undefined)} [options.getActiveRuntime]
 *   Accessor for the active editor runtime.
 * @returns {Object} - Object containing the selected text as a computed property
 */
export function useSelectedText(editorRef: Object, options?: {
    getActiveRuntime?: (() => (import('../core/editor-runtime/index.js').EditorRuntime | null | undefined)) | undefined;
}): Object;
