/**
 * Viewport fit tracking. Maintains pure viewport metrics (available width,
 * document base width, fit zoom), stores them for `getViewportMetrics()`,
 * emits `viewport-change` when the fit they imply changes, and applies the
 * `fit-width` policy while `zoomMode` is `'fit-width'`.
 *
 * Metrics are policy-free measurements: `availableWidth` is the container
 * width minus the comments sidebar when visible; `fitZoom` is the raw
 * available/document ratio. The fit policy (and only the policy) accounts
 * for `config.zoom.fitWidth` padding and clamping.
 *
 * The base page width is re-resolved on every evaluation (never latched):
 * DOCX uses the widest laid-out page with page-styles fallback, PDF uses
 * rendered pages normalized by their actual scale factor, and HTML reflows
 * so it contributes no fixed width. A zoom-normalized DOM measurement is
 * the last-resort fallback for a DOCX editor without page geometry.
 *
 * The fit application writes the zoom state directly instead of calling
 * `setZoom()`, which by contract switches the mode to `manual`.
 *
 * Must be called inside a component `setup()` (registers watchers and an
 * unmount hook).
 */
export function useViewportFit({ getSuperdoc, superdocContainerWidth, isReady, activeZoom, zoomMode, viewportMetrics, showCommentsSidebar, rightSidebarRef, superdocRoot, documents, }: {
    getSuperdoc: any;
    superdocContainerWidth: any;
    isReady: any;
    activeZoom: any;
    zoomMode: any;
    viewportMetrics: any;
    showCommentsSidebar: any;
    rightSidebarRef: any;
    superdocRoot: any;
    documents: any;
}): {
    evaluateViewport: () => void;
};
export const FIT_WIDTH_DEFAULTS: Readonly<{
    min: 10;
    max: 100;
    padding: 0;
}>;
export function resolveFitWidthOptions(rawFitConfig: any): {
    min: number;
    max: number;
    padding: any;
};
export function computeFitZoom(availableWidth: any, documentWidth: any): number | null;
export function computeAppliedFitZoom(availableWidth: any, documentWidth: any, options: any): number | null;
export function normalizePdfPageMeasurement(measured: any, scaleFactor: any, zoomFactor: any): any;
