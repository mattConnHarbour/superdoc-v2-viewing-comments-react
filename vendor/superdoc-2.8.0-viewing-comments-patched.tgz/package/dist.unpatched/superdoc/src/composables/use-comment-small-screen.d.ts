export function useCommentSmallScreen({ commentsModuleConfig, superdocRoot, layers }: {
    commentsModuleConfig: any;
    superdocRoot: any;
    layers: any;
}): {
    superdocContainerWidth: import('vue').Ref<number, number>;
    isCompactCommentsMode: import('vue').Ref<boolean, boolean>;
    recalculateCompactCommentsMode: () => void;
    ensureCompactMeasurementObserver: () => void;
};
