/**
 * Make `owner` the ambient find-shortcut owner. Call on mount and on user
 * interaction (pointerdown / focusin inside the instance) so "the SuperDoc the
 * user last touched" wins the ambient shortcut.
 * @param {unknown} owner
 */
export function claimFindShortcut(owner: unknown): void;
/**
 * Clear ownership if `owner` currently holds it. Call on unmount.
 * @param {unknown} owner
 */
export function releaseFindShortcut(owner: unknown): void;
/**
 * Whether `owner` may handle the ambient (no-focus) find shortcut. With no
 * claimed owner any instance may handle it (single-instance pages), relying on
 * the `defaultPrevented` check in {@link shouldHandleFindShortcut} to keep the
 * shortcut single-fire.
 * @param {unknown} owner
 */
export function ownsAmbientFindShortcut(owner: unknown): boolean;
/**
 * Decide whether one SuperDoc instance's capture listener should handle a
 * find-shortcut keydown. `defaultPrevented` covers the cross-instance race
 * directly: the first instance to act marks the event, and sibling capture
 * listeners on the same node skip it.
 * @param {KeyboardEvent} event
 * @param {{ focusInside: boolean, owner: unknown }} context
 */
export function shouldHandleFindShortcut(event: KeyboardEvent, { focusInside, owner }: {
    focusInside: boolean;
    owner: unknown;
}): boolean;
