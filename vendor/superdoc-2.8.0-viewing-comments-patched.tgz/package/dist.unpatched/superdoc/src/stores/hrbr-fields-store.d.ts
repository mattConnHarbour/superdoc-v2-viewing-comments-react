export const useHrbrFieldsStore: import('pinia').StoreDefinition<"hrbr-fields", Pick<{
    hrbrFieldsConfig: {
        name: string;
    };
    fieldComponentsMap: Readonly<{
        TEXTINPUT: import('vue').Raw<object>;
        HTMLINPUT: import('vue').Raw<object>;
        SELECT: import('vue').Raw<object>;
        CHECKBOXINPUT: import('vue').Raw<object>;
        SIGNATUREINPUT: import('vue').Raw<object>;
        IMAGEINPUT: import('vue').Raw<object>;
    }>;
    getAnnotations: import('vue').ComputedRef<any[]>;
    getField: (documentId: any, fieldId: any) => any;
}, "hrbrFieldsConfig" | "fieldComponentsMap">, Pick<{
    hrbrFieldsConfig: {
        name: string;
    };
    fieldComponentsMap: Readonly<{
        TEXTINPUT: import('vue').Raw<object>;
        HTMLINPUT: import('vue').Raw<object>;
        SELECT: import('vue').Raw<object>;
        CHECKBOXINPUT: import('vue').Raw<object>;
        SIGNATUREINPUT: import('vue').Raw<object>;
        IMAGEINPUT: import('vue').Raw<object>;
    }>;
    getAnnotations: import('vue').ComputedRef<any[]>;
    getField: (documentId: any, fieldId: any) => any;
}, "getAnnotations">, Pick<{
    hrbrFieldsConfig: {
        name: string;
    };
    fieldComponentsMap: Readonly<{
        TEXTINPUT: import('vue').Raw<object>;
        HTMLINPUT: import('vue').Raw<object>;
        SELECT: import('vue').Raw<object>;
        CHECKBOXINPUT: import('vue').Raw<object>;
        SIGNATUREINPUT: import('vue').Raw<object>;
        IMAGEINPUT: import('vue').Raw<object>;
    }>;
    getAnnotations: import('vue').ComputedRef<any[]>;
    getField: (documentId: any, fieldId: any) => any;
}, "getField">>;
