export const useCommentsStore: import('pinia').StoreDefinition<"comments", Pick<{
    COMMENT_EVENTS: {
        readonly RESOLVED: "resolved";
        readonly NEW: "new";
        readonly ADD: "add";
        readonly UPDATE: "update";
        readonly DELETED: "deleted";
        readonly PENDING: "pending";
        readonly SELECTED: "selected";
        readonly COMMENTS_LIST: "comments-list";
        readonly CHANGE_ACCEPTED: "change-accepted";
        readonly CHANGE_REJECTED: "change-rejected";
    };
    isDebugging: boolean;
    hasInitializedComments: import('vue').Ref<boolean, boolean>;
    hasSyncedCollaborationComments: import('vue').Ref<boolean, boolean>;
    editingCommentId: import('vue').Ref<null, null>;
    activeComment: import('vue').Ref<null, null>;
    activeFloatingCommentInstanceId: import('vue').Ref<null, null>;
    commentDialogs: import('vue').Ref<never[], never[]>;
    overlappingComments: import('vue').Ref<never[], never[]>;
    overlappedIds: Set<never>;
    suppressInternalExternal: import('vue').Ref<boolean, boolean>;
    pendingComment: import('vue').Ref<null, null>;
    currentCommentText: import('vue').Ref<string, string>;
    currentCommentMentions: import('vue').Ref<never[], never[]>;
    commentsList: import('vue').Ref<never[], never[]>;
    reviewDirectoryList: import('vue').ShallowRef<never[], never[]>;
    isCommentsListVisible: import('vue').Ref<boolean, boolean>;
    isReviewDirectoryActive: import('vue').Ref<boolean, boolean>;
    isReviewDirectoryLoading: import('vue').Ref<boolean, boolean>;
    generalCommentIds: import('vue').Ref<never[], never[]>;
    editorCommentIds: import('vue').Ref<never[], never[]>;
    commentsParentElement: import('vue').Ref<null, null>;
    editorCommentPositions: import('vue').Ref<{}, {}>;
    hasInitializedLocations: import('vue').Ref<boolean, boolean>;
    isCommentHighlighted: import('vue').Ref<boolean, boolean>;
    floatingCommentsOffset: import('vue').Ref<number, number>;
    sortedConversations: import('vue').Ref<never[], never[]>;
    visibleConversations: import('vue').Ref<never[], never[]>;
    skipSelectionUpdate: import('vue').Ref<boolean, boolean>;
    isFloatingCommentsReady: import('vue').Ref<boolean, boolean>;
    instantSidebarAlignmentTargetY: import('vue').Ref<null, null>;
    instantSidebarAlignmentThreadId: import('vue').Ref<null, null>;
    instantSidebarAlignmentInstanceId: import('vue').Ref<null, null>;
    getConfig: import('vue').ComputedRef<{
        name: string;
        readOnly: boolean;
        allowResolve: boolean;
        showResolved: boolean;
    }>;
    documentsWithConverations: import('vue').ComputedRef<any>;
    getGroupedComments: import('vue').ComputedRef<{
        parentComments: any[];
        resolvedComments: any[];
    }>;
    getGroupedReviewDirectory: import('vue').ComputedRef<{
        parentComments: any[];
        resolvedComments: any[];
    }>;
    hasOpenTrackedChanges: import('vue').ComputedRef<boolean>;
    getCommentsByPosition: import('vue').ComputedRef<{
        parentComments: any[];
        resolvedComments: any[];
    }>;
    getFloatingComments: import('vue').ComputedRef<any[]>;
    getFloatingCommentInstances: import('vue').ComputedRef<{
        id: any;
        threadId: any;
        comment: any;
        positionKey: any;
        pageIndex: any;
        isPrimary: boolean;
        positionEntry: any;
    }[]>;
    getCommentAliasIds: (commentOrId: any) => (string | null)[];
    getTrackedChangeThread: (parentComment: any) => any[] | readonly never[];
    getCommentPositionKey: (commentOrId: Object | string | null | undefined) => string | null;
    getCommentPosition: (commentOrId: Object | string) => Object | null;
    getCommentAnchoredText: (commentOrId: Object | string, options?: {
        separator?: string | undefined;
        trim?: boolean | undefined;
    }) => string | null;
    getCommentAnchorData: (commentOrId: Object | string, options?: {
        separator?: string | undefined;
        trim?: boolean | undefined;
    }) => {
        position: Object;
        anchoredText: string | null;
    } | null;
    resolveCommentPositionEntry: (commentOrId: any, preferredId: any) => {
        key: string | null;
        entry: any;
    };
    getCommentDocumentId: (comment: any) => string | null;
    belongsToDocument: (comment: any, activeDocumentId: any, options?: {}) => any;
    viewingVisibility: {
        documentMode: string;
        commentsVisible: boolean;
        trackChangesVisible: boolean;
    };
    isViewingMode: import('vue').ComputedRef<boolean>;
    shouldRenderReviewInViewing: import('vue').ComputedRef<boolean>;
    init: (config?: Object) => void;
    setViewingVisibility: ({ documentMode, commentsVisible, trackChangesVisible }?: {}) => void;
    getComment: (id: string) => Record<string, unknown> | null | undefined;
    setActiveComment: (superdoc: Object | undefined | null, id: string | undefined | null) => void;
    getCommentLocation: (selection: any, parent: any) => {
        top: any;
        left: any;
    };
    hasOverlapId: (id: any) => any;
    getPendingComment: ({ selection, documentId, parentCommentId, ...options }: {
        selection: Object;
        documentId: string;
        parentCommentId: string;
    }) => Object;
    showAddComment: (superdoc: any, targetClientY?: null) => Promise<{
        ok: boolean;
        reason: any;
        detail: any;
    } | {
        ok: boolean;
        reason?: undefined;
        detail?: undefined;
    } | {
        ok: boolean;
        reason: string;
        detail: any;
    }> | {
        ok: boolean;
        reason: any;
    } | {
        ok: boolean;
        reason?: undefined;
    };
    addComment: ({ superdoc, comment, skipEditorUpdate, broadcastChanges }: {
        superdoc: any;
        comment: any;
        skipEditorUpdate?: boolean | undefined;
        broadcastChanges?: boolean | undefined;
    }) => void;
    addHydratedComment: ({ superdoc, comment, skipEditorUpdate, broadcastChanges }: {
        superdoc: any;
        comment: any;
        skipEditorUpdate?: boolean | undefined;
        broadcastChanges?: boolean | undefined;
    }) => void;
    cancelComment: (superdoc: any) => void;
    deleteComment: ({ commentId: commentIdToDelete, superdoc }: {
        commentId: any;
        superdoc: any;
    }) => Promise<any>;
    removePendingComment: (superdoc: any) => void;
    cancelImportedTrackedChangeBootstrap: (documentId: string | null | undefined) => number;
    removeCommentsForDocument: (documentId: string | null | undefined) => void;
    setReviewDirectoryFromV2: ({ superdoc, commentItems, trackedChangeItems }?: {
        commentItems?: never[] | undefined;
        trackedChangeItems?: never[] | undefined;
    }) => {
        ok: boolean;
        reason: string;
        count?: undefined;
    } | {
        ok: boolean;
        count: number;
        reason?: undefined;
    };
    clearReviewDirectory: () => void;
    processLoadedDocxComments: ({ superdoc, editor, comments, documentId, replacedFile }: {
        comments: any[];
        documentId: string;
        replacedFile?: boolean | undefined;
    }) => void;
    translateCommentsForExport: () => any[];
    handleEditorLocationsUpdate: (allCommentPositions: Object, options?: {
        retainMissingTrackedChangeGeometry?: boolean;
        retainedTrackedChangeIds?: Iterable<string>;
    }) => void;
    clearEditorCommentPositions: () => void;
    handleTrackedChangeUpdate: ({ superdoc, params, broadcastChanges, documentState, trackedChangeIdentityIndex, }: {
        superdoc: Object;
        params: Object;
    }) => void;
    refreshTrackedChangeCommentsByIds: ({ superdoc, editor, changeIds, broadcastChanges }: {
        superdoc: any;
        editor: any;
        changeIds: any;
        broadcastChanges?: boolean | undefined;
    }) => void;
    syncResolvedCommentsWithDocument: ({ editor }?: {}) => number;
    syncTrackedChangePositionsWithDocument: ({ documentId, editor }?: {}) => number;
    setActiveFloatingCommentInstance: (instanceId?: null) => void;
    requestInstantSidebarAlignment: (targetY?: null, threadId?: null, instanceId?: null) => void;
    peekInstantSidebarAlignment: () => null;
    clearInstantSidebarAlignment: () => void;
    syncTrackedChangeComments: ({ superdoc, editor, broadcastChanges }: {
        superdoc: any;
        editor: any;
        broadcastChanges?: boolean | undefined;
    }) => void;
    decideTrackedChangeFromSidebar: ({ superdoc, comment, decision }: {
        superdoc: Object;
        editor: Object;
    }) => void;
    v2CommentsAdapter: import('vue').ShallowRef<null, null>;
    setV2CommentsAdapter: (adapter: any) => void;
    getV2CommentsAdapter: (superdoc: any) => any;
    applyReviewWindowFromV2: ({ superdoc, commentsAdapter, trackedChangesAdapter, documentId, commentItems, trackedChangeItems, requestedCommentIds, requestedTrackedChangeIds, unresolvedCommentIds, trackedList, sourceCoverageRevision, evaluatedRevision, patch, }?: {}) => any;
    reconcileCommentsFromV2: ({ superdoc, adapter, documentId, items, preparedInputs, pruneStale, hydrationGeneration, }?: {
        preparedInputs?: null | undefined;
        pruneStale?: boolean | undefined;
    }) => any;
    announceV2CommentCreated: ({ superdoc, commentId }?: {}) => Promise<{
        ok: boolean;
        reason: string;
        detail?: undefined;
        comment?: undefined;
    } | {
        ok: boolean;
        reason: string;
        detail: any;
        comment?: undefined;
    } | {
        ok: boolean;
        comment: any;
        reason?: undefined;
        detail?: undefined;
    }>;
    isV2EditorActive: (superdoc: any) => boolean;
    replyCommentV2: ({ superdoc, parentCommentId, text, mentions, trackedChangeTarget }?: {
        mentions?: never[] | undefined;
    }) => Promise<any>;
    editCommentV2: ({ superdoc, commentId, text }?: {}) => Promise<any>;
    resolveCommentV2: ({ superdoc, commentId }?: {}) => Promise<any>;
    reopenCommentV2: ({ superdoc, commentId }?: {}) => Promise<any>;
    v2TrackedChangesAdapter: import('vue').ShallowRef<null, null>;
    setV2TrackedChangesAdapter: (adapter: any) => void;
    getV2TrackedChangesAdapter: (superdoc: any) => any;
    getV2TrackedChangeRowCount: (documentId?: null) => number;
    reconcileTrackedChangeMutationFromV2: ({ superdoc, adapter, documentId, upsertIds, removedIds, remappedPairs, allResolved, }?: {
        upsertIds?: never[] | undefined;
        removedIds?: never[] | undefined;
        remappedPairs?: never[] | undefined;
    }) => Promise<{
        ok: boolean;
        reason: string;
        items?: undefined;
        resolvedIds?: undefined;
        unresolvedIds?: undefined;
        allResolved?: undefined;
        removedRows?: undefined;
        removedIds?: undefined;
    } | {
        ok: boolean;
        items: never[];
        resolvedIds: never[];
        unresolvedIds: never[];
        allResolved: boolean;
        removedRows: any;
        reason?: undefined;
        removedIds?: undefined;
    } | {
        ok: boolean;
        items: never[];
        resolvedIds: never[];
        unresolvedIds: (string | null)[];
        removedIds: (string | null)[];
        reason?: undefined;
        allResolved?: undefined;
        removedRows?: undefined;
    }>;
    reconcileTrackedChangesFromV2: ({ superdoc, adapter, documentId, items, pruneStale, preparedParams, liveIds: suppliedLiveIds, liveAnchorKeys: suppliedLiveAnchorKeys, hydrationGeneration, }?: {
        pruneStale?: boolean | undefined;
        preparedParams?: null | undefined;
        liveIds?: null | undefined;
        liveAnchorKeys?: null | undefined;
    }) => any;
    remapTrackedChangeIdentities: (pairs?: any[], { documentId }?: {}) => void;
}, "suppressInternalExternal" | "activeComment" | "activeFloatingCommentInstanceId" | "floatingCommentsOffset" | "pendingComment" | "currentCommentText" | "currentCommentMentions" | "isDebugging" | "editingCommentId" | "editorCommentPositions" | "isCommentHighlighted" | "v2CommentsAdapter" | "COMMENT_EVENTS" | "hasInitializedComments" | "hasSyncedCollaborationComments" | "commentDialogs" | "overlappingComments" | "overlappedIds" | "commentsList" | "reviewDirectoryList" | "isCommentsListVisible" | "isReviewDirectoryActive" | "isReviewDirectoryLoading" | "generalCommentIds" | "editorCommentIds" | "commentsParentElement" | "hasInitializedLocations" | "sortedConversations" | "visibleConversations" | "skipSelectionUpdate" | "isFloatingCommentsReady" | "instantSidebarAlignmentTargetY" | "instantSidebarAlignmentThreadId" | "instantSidebarAlignmentInstanceId" | "viewingVisibility" | "v2TrackedChangesAdapter">, Pick<{
    COMMENT_EVENTS: {
        readonly RESOLVED: "resolved";
        readonly NEW: "new";
        readonly ADD: "add";
        readonly UPDATE: "update";
        readonly DELETED: "deleted";
        readonly PENDING: "pending";
        readonly SELECTED: "selected";
        readonly COMMENTS_LIST: "comments-list";
        readonly CHANGE_ACCEPTED: "change-accepted";
        readonly CHANGE_REJECTED: "change-rejected";
    };
    isDebugging: boolean;
    hasInitializedComments: import('vue').Ref<boolean, boolean>;
    hasSyncedCollaborationComments: import('vue').Ref<boolean, boolean>;
    editingCommentId: import('vue').Ref<null, null>;
    activeComment: import('vue').Ref<null, null>;
    activeFloatingCommentInstanceId: import('vue').Ref<null, null>;
    commentDialogs: import('vue').Ref<never[], never[]>;
    overlappingComments: import('vue').Ref<never[], never[]>;
    overlappedIds: Set<never>;
    suppressInternalExternal: import('vue').Ref<boolean, boolean>;
    pendingComment: import('vue').Ref<null, null>;
    currentCommentText: import('vue').Ref<string, string>;
    currentCommentMentions: import('vue').Ref<never[], never[]>;
    commentsList: import('vue').Ref<never[], never[]>;
    reviewDirectoryList: import('vue').ShallowRef<never[], never[]>;
    isCommentsListVisible: import('vue').Ref<boolean, boolean>;
    isReviewDirectoryActive: import('vue').Ref<boolean, boolean>;
    isReviewDirectoryLoading: import('vue').Ref<boolean, boolean>;
    generalCommentIds: import('vue').Ref<never[], never[]>;
    editorCommentIds: import('vue').Ref<never[], never[]>;
    commentsParentElement: import('vue').Ref<null, null>;
    editorCommentPositions: import('vue').Ref<{}, {}>;
    hasInitializedLocations: import('vue').Ref<boolean, boolean>;
    isCommentHighlighted: import('vue').Ref<boolean, boolean>;
    floatingCommentsOffset: import('vue').Ref<number, number>;
    sortedConversations: import('vue').Ref<never[], never[]>;
    visibleConversations: import('vue').Ref<never[], never[]>;
    skipSelectionUpdate: import('vue').Ref<boolean, boolean>;
    isFloatingCommentsReady: import('vue').Ref<boolean, boolean>;
    instantSidebarAlignmentTargetY: import('vue').Ref<null, null>;
    instantSidebarAlignmentThreadId: import('vue').Ref<null, null>;
    instantSidebarAlignmentInstanceId: import('vue').Ref<null, null>;
    getConfig: import('vue').ComputedRef<{
        name: string;
        readOnly: boolean;
        allowResolve: boolean;
        showResolved: boolean;
    }>;
    documentsWithConverations: import('vue').ComputedRef<any>;
    getGroupedComments: import('vue').ComputedRef<{
        parentComments: any[];
        resolvedComments: any[];
    }>;
    getGroupedReviewDirectory: import('vue').ComputedRef<{
        parentComments: any[];
        resolvedComments: any[];
    }>;
    hasOpenTrackedChanges: import('vue').ComputedRef<boolean>;
    getCommentsByPosition: import('vue').ComputedRef<{
        parentComments: any[];
        resolvedComments: any[];
    }>;
    getFloatingComments: import('vue').ComputedRef<any[]>;
    getFloatingCommentInstances: import('vue').ComputedRef<{
        id: any;
        threadId: any;
        comment: any;
        positionKey: any;
        pageIndex: any;
        isPrimary: boolean;
        positionEntry: any;
    }[]>;
    getCommentAliasIds: (commentOrId: any) => (string | null)[];
    getTrackedChangeThread: (parentComment: any) => any[] | readonly never[];
    getCommentPositionKey: (commentOrId: Object | string | null | undefined) => string | null;
    getCommentPosition: (commentOrId: Object | string) => Object | null;
    getCommentAnchoredText: (commentOrId: Object | string, options?: {
        separator?: string | undefined;
        trim?: boolean | undefined;
    }) => string | null;
    getCommentAnchorData: (commentOrId: Object | string, options?: {
        separator?: string | undefined;
        trim?: boolean | undefined;
    }) => {
        position: Object;
        anchoredText: string | null;
    } | null;
    resolveCommentPositionEntry: (commentOrId: any, preferredId: any) => {
        key: string | null;
        entry: any;
    };
    getCommentDocumentId: (comment: any) => string | null;
    belongsToDocument: (comment: any, activeDocumentId: any, options?: {}) => any;
    viewingVisibility: {
        documentMode: string;
        commentsVisible: boolean;
        trackChangesVisible: boolean;
    };
    isViewingMode: import('vue').ComputedRef<boolean>;
    shouldRenderReviewInViewing: import('vue').ComputedRef<boolean>;
    init: (config?: Object) => void;
    setViewingVisibility: ({ documentMode, commentsVisible, trackChangesVisible }?: {}) => void;
    getComment: (id: string) => Record<string, unknown> | null | undefined;
    setActiveComment: (superdoc: Object | undefined | null, id: string | undefined | null) => void;
    getCommentLocation: (selection: any, parent: any) => {
        top: any;
        left: any;
    };
    hasOverlapId: (id: any) => any;
    getPendingComment: ({ selection, documentId, parentCommentId, ...options }: {
        selection: Object;
        documentId: string;
        parentCommentId: string;
    }) => Object;
    showAddComment: (superdoc: any, targetClientY?: null) => Promise<{
        ok: boolean;
        reason: any;
        detail: any;
    } | {
        ok: boolean;
        reason?: undefined;
        detail?: undefined;
    } | {
        ok: boolean;
        reason: string;
        detail: any;
    }> | {
        ok: boolean;
        reason: any;
    } | {
        ok: boolean;
        reason?: undefined;
    };
    addComment: ({ superdoc, comment, skipEditorUpdate, broadcastChanges }: {
        superdoc: any;
        comment: any;
        skipEditorUpdate?: boolean | undefined;
        broadcastChanges?: boolean | undefined;
    }) => void;
    addHydratedComment: ({ superdoc, comment, skipEditorUpdate, broadcastChanges }: {
        superdoc: any;
        comment: any;
        skipEditorUpdate?: boolean | undefined;
        broadcastChanges?: boolean | undefined;
    }) => void;
    cancelComment: (superdoc: any) => void;
    deleteComment: ({ commentId: commentIdToDelete, superdoc }: {
        commentId: any;
        superdoc: any;
    }) => Promise<any>;
    removePendingComment: (superdoc: any) => void;
    cancelImportedTrackedChangeBootstrap: (documentId: string | null | undefined) => number;
    removeCommentsForDocument: (documentId: string | null | undefined) => void;
    setReviewDirectoryFromV2: ({ superdoc, commentItems, trackedChangeItems }?: {
        commentItems?: never[] | undefined;
        trackedChangeItems?: never[] | undefined;
    }) => {
        ok: boolean;
        reason: string;
        count?: undefined;
    } | {
        ok: boolean;
        count: number;
        reason?: undefined;
    };
    clearReviewDirectory: () => void;
    processLoadedDocxComments: ({ superdoc, editor, comments, documentId, replacedFile }: {
        comments: any[];
        documentId: string;
        replacedFile?: boolean | undefined;
    }) => void;
    translateCommentsForExport: () => any[];
    handleEditorLocationsUpdate: (allCommentPositions: Object, options?: {
        retainMissingTrackedChangeGeometry?: boolean;
        retainedTrackedChangeIds?: Iterable<string>;
    }) => void;
    clearEditorCommentPositions: () => void;
    handleTrackedChangeUpdate: ({ superdoc, params, broadcastChanges, documentState, trackedChangeIdentityIndex, }: {
        superdoc: Object;
        params: Object;
    }) => void;
    refreshTrackedChangeCommentsByIds: ({ superdoc, editor, changeIds, broadcastChanges }: {
        superdoc: any;
        editor: any;
        changeIds: any;
        broadcastChanges?: boolean | undefined;
    }) => void;
    syncResolvedCommentsWithDocument: ({ editor }?: {}) => number;
    syncTrackedChangePositionsWithDocument: ({ documentId, editor }?: {}) => number;
    setActiveFloatingCommentInstance: (instanceId?: null) => void;
    requestInstantSidebarAlignment: (targetY?: null, threadId?: null, instanceId?: null) => void;
    peekInstantSidebarAlignment: () => null;
    clearInstantSidebarAlignment: () => void;
    syncTrackedChangeComments: ({ superdoc, editor, broadcastChanges }: {
        superdoc: any;
        editor: any;
        broadcastChanges?: boolean | undefined;
    }) => void;
    decideTrackedChangeFromSidebar: ({ superdoc, comment, decision }: {
        superdoc: Object;
        editor: Object;
    }) => void;
    v2CommentsAdapter: import('vue').ShallowRef<null, null>;
    setV2CommentsAdapter: (adapter: any) => void;
    getV2CommentsAdapter: (superdoc: any) => any;
    applyReviewWindowFromV2: ({ superdoc, commentsAdapter, trackedChangesAdapter, documentId, commentItems, trackedChangeItems, requestedCommentIds, requestedTrackedChangeIds, unresolvedCommentIds, trackedList, sourceCoverageRevision, evaluatedRevision, patch, }?: {}) => any;
    reconcileCommentsFromV2: ({ superdoc, adapter, documentId, items, preparedInputs, pruneStale, hydrationGeneration, }?: {
        preparedInputs?: null | undefined;
        pruneStale?: boolean | undefined;
    }) => any;
    announceV2CommentCreated: ({ superdoc, commentId }?: {}) => Promise<{
        ok: boolean;
        reason: string;
        detail?: undefined;
        comment?: undefined;
    } | {
        ok: boolean;
        reason: string;
        detail: any;
        comment?: undefined;
    } | {
        ok: boolean;
        comment: any;
        reason?: undefined;
        detail?: undefined;
    }>;
    isV2EditorActive: (superdoc: any) => boolean;
    replyCommentV2: ({ superdoc, parentCommentId, text, mentions, trackedChangeTarget }?: {
        mentions?: never[] | undefined;
    }) => Promise<any>;
    editCommentV2: ({ superdoc, commentId, text }?: {}) => Promise<any>;
    resolveCommentV2: ({ superdoc, commentId }?: {}) => Promise<any>;
    reopenCommentV2: ({ superdoc, commentId }?: {}) => Promise<any>;
    v2TrackedChangesAdapter: import('vue').ShallowRef<null, null>;
    setV2TrackedChangesAdapter: (adapter: any) => void;
    getV2TrackedChangesAdapter: (superdoc: any) => any;
    getV2TrackedChangeRowCount: (documentId?: null) => number;
    reconcileTrackedChangeMutationFromV2: ({ superdoc, adapter, documentId, upsertIds, removedIds, remappedPairs, allResolved, }?: {
        upsertIds?: never[] | undefined;
        removedIds?: never[] | undefined;
        remappedPairs?: never[] | undefined;
    }) => Promise<{
        ok: boolean;
        reason: string;
        items?: undefined;
        resolvedIds?: undefined;
        unresolvedIds?: undefined;
        allResolved?: undefined;
        removedRows?: undefined;
        removedIds?: undefined;
    } | {
        ok: boolean;
        items: never[];
        resolvedIds: never[];
        unresolvedIds: never[];
        allResolved: boolean;
        removedRows: any;
        reason?: undefined;
        removedIds?: undefined;
    } | {
        ok: boolean;
        items: never[];
        resolvedIds: never[];
        unresolvedIds: (string | null)[];
        removedIds: (string | null)[];
        reason?: undefined;
        allResolved?: undefined;
        removedRows?: undefined;
    }>;
    reconcileTrackedChangesFromV2: ({ superdoc, adapter, documentId, items, pruneStale, preparedParams, liveIds: suppliedLiveIds, liveAnchorKeys: suppliedLiveAnchorKeys, hydrationGeneration, }?: {
        pruneStale?: boolean | undefined;
        preparedParams?: null | undefined;
        liveIds?: null | undefined;
        liveAnchorKeys?: null | undefined;
    }) => any;
    remapTrackedChangeIdentities: (pairs?: any[], { documentId }?: {}) => void;
}, "getConfig" | "documentsWithConverations" | "getGroupedComments" | "getGroupedReviewDirectory" | "hasOpenTrackedChanges" | "getCommentsByPosition" | "getFloatingComments" | "getFloatingCommentInstances" | "isViewingMode" | "shouldRenderReviewInViewing">, Pick<{
    COMMENT_EVENTS: {
        readonly RESOLVED: "resolved";
        readonly NEW: "new";
        readonly ADD: "add";
        readonly UPDATE: "update";
        readonly DELETED: "deleted";
        readonly PENDING: "pending";
        readonly SELECTED: "selected";
        readonly COMMENTS_LIST: "comments-list";
        readonly CHANGE_ACCEPTED: "change-accepted";
        readonly CHANGE_REJECTED: "change-rejected";
    };
    isDebugging: boolean;
    hasInitializedComments: import('vue').Ref<boolean, boolean>;
    hasSyncedCollaborationComments: import('vue').Ref<boolean, boolean>;
    editingCommentId: import('vue').Ref<null, null>;
    activeComment: import('vue').Ref<null, null>;
    activeFloatingCommentInstanceId: import('vue').Ref<null, null>;
    commentDialogs: import('vue').Ref<never[], never[]>;
    overlappingComments: import('vue').Ref<never[], never[]>;
    overlappedIds: Set<never>;
    suppressInternalExternal: import('vue').Ref<boolean, boolean>;
    pendingComment: import('vue').Ref<null, null>;
    currentCommentText: import('vue').Ref<string, string>;
    currentCommentMentions: import('vue').Ref<never[], never[]>;
    commentsList: import('vue').Ref<never[], never[]>;
    reviewDirectoryList: import('vue').ShallowRef<never[], never[]>;
    isCommentsListVisible: import('vue').Ref<boolean, boolean>;
    isReviewDirectoryActive: import('vue').Ref<boolean, boolean>;
    isReviewDirectoryLoading: import('vue').Ref<boolean, boolean>;
    generalCommentIds: import('vue').Ref<never[], never[]>;
    editorCommentIds: import('vue').Ref<never[], never[]>;
    commentsParentElement: import('vue').Ref<null, null>;
    editorCommentPositions: import('vue').Ref<{}, {}>;
    hasInitializedLocations: import('vue').Ref<boolean, boolean>;
    isCommentHighlighted: import('vue').Ref<boolean, boolean>;
    floatingCommentsOffset: import('vue').Ref<number, number>;
    sortedConversations: import('vue').Ref<never[], never[]>;
    visibleConversations: import('vue').Ref<never[], never[]>;
    skipSelectionUpdate: import('vue').Ref<boolean, boolean>;
    isFloatingCommentsReady: import('vue').Ref<boolean, boolean>;
    instantSidebarAlignmentTargetY: import('vue').Ref<null, null>;
    instantSidebarAlignmentThreadId: import('vue').Ref<null, null>;
    instantSidebarAlignmentInstanceId: import('vue').Ref<null, null>;
    getConfig: import('vue').ComputedRef<{
        name: string;
        readOnly: boolean;
        allowResolve: boolean;
        showResolved: boolean;
    }>;
    documentsWithConverations: import('vue').ComputedRef<any>;
    getGroupedComments: import('vue').ComputedRef<{
        parentComments: any[];
        resolvedComments: any[];
    }>;
    getGroupedReviewDirectory: import('vue').ComputedRef<{
        parentComments: any[];
        resolvedComments: any[];
    }>;
    hasOpenTrackedChanges: import('vue').ComputedRef<boolean>;
    getCommentsByPosition: import('vue').ComputedRef<{
        parentComments: any[];
        resolvedComments: any[];
    }>;
    getFloatingComments: import('vue').ComputedRef<any[]>;
    getFloatingCommentInstances: import('vue').ComputedRef<{
        id: any;
        threadId: any;
        comment: any;
        positionKey: any;
        pageIndex: any;
        isPrimary: boolean;
        positionEntry: any;
    }[]>;
    getCommentAliasIds: (commentOrId: any) => (string | null)[];
    getTrackedChangeThread: (parentComment: any) => any[] | readonly never[];
    getCommentPositionKey: (commentOrId: Object | string | null | undefined) => string | null;
    getCommentPosition: (commentOrId: Object | string) => Object | null;
    getCommentAnchoredText: (commentOrId: Object | string, options?: {
        separator?: string | undefined;
        trim?: boolean | undefined;
    }) => string | null;
    getCommentAnchorData: (commentOrId: Object | string, options?: {
        separator?: string | undefined;
        trim?: boolean | undefined;
    }) => {
        position: Object;
        anchoredText: string | null;
    } | null;
    resolveCommentPositionEntry: (commentOrId: any, preferredId: any) => {
        key: string | null;
        entry: any;
    };
    getCommentDocumentId: (comment: any) => string | null;
    belongsToDocument: (comment: any, activeDocumentId: any, options?: {}) => any;
    viewingVisibility: {
        documentMode: string;
        commentsVisible: boolean;
        trackChangesVisible: boolean;
    };
    isViewingMode: import('vue').ComputedRef<boolean>;
    shouldRenderReviewInViewing: import('vue').ComputedRef<boolean>;
    init: (config?: Object) => void;
    setViewingVisibility: ({ documentMode, commentsVisible, trackChangesVisible }?: {}) => void;
    getComment: (id: string) => Record<string, unknown> | null | undefined;
    setActiveComment: (superdoc: Object | undefined | null, id: string | undefined | null) => void;
    getCommentLocation: (selection: any, parent: any) => {
        top: any;
        left: any;
    };
    hasOverlapId: (id: any) => any;
    getPendingComment: ({ selection, documentId, parentCommentId, ...options }: {
        selection: Object;
        documentId: string;
        parentCommentId: string;
    }) => Object;
    showAddComment: (superdoc: any, targetClientY?: null) => Promise<{
        ok: boolean;
        reason: any;
        detail: any;
    } | {
        ok: boolean;
        reason?: undefined;
        detail?: undefined;
    } | {
        ok: boolean;
        reason: string;
        detail: any;
    }> | {
        ok: boolean;
        reason: any;
    } | {
        ok: boolean;
        reason?: undefined;
    };
    addComment: ({ superdoc, comment, skipEditorUpdate, broadcastChanges }: {
        superdoc: any;
        comment: any;
        skipEditorUpdate?: boolean | undefined;
        broadcastChanges?: boolean | undefined;
    }) => void;
    addHydratedComment: ({ superdoc, comment, skipEditorUpdate, broadcastChanges }: {
        superdoc: any;
        comment: any;
        skipEditorUpdate?: boolean | undefined;
        broadcastChanges?: boolean | undefined;
    }) => void;
    cancelComment: (superdoc: any) => void;
    deleteComment: ({ commentId: commentIdToDelete, superdoc }: {
        commentId: any;
        superdoc: any;
    }) => Promise<any>;
    removePendingComment: (superdoc: any) => void;
    cancelImportedTrackedChangeBootstrap: (documentId: string | null | undefined) => number;
    removeCommentsForDocument: (documentId: string | null | undefined) => void;
    setReviewDirectoryFromV2: ({ superdoc, commentItems, trackedChangeItems }?: {
        commentItems?: never[] | undefined;
        trackedChangeItems?: never[] | undefined;
    }) => {
        ok: boolean;
        reason: string;
        count?: undefined;
    } | {
        ok: boolean;
        count: number;
        reason?: undefined;
    };
    clearReviewDirectory: () => void;
    processLoadedDocxComments: ({ superdoc, editor, comments, documentId, replacedFile }: {
        comments: any[];
        documentId: string;
        replacedFile?: boolean | undefined;
    }) => void;
    translateCommentsForExport: () => any[];
    handleEditorLocationsUpdate: (allCommentPositions: Object, options?: {
        retainMissingTrackedChangeGeometry?: boolean;
        retainedTrackedChangeIds?: Iterable<string>;
    }) => void;
    clearEditorCommentPositions: () => void;
    handleTrackedChangeUpdate: ({ superdoc, params, broadcastChanges, documentState, trackedChangeIdentityIndex, }: {
        superdoc: Object;
        params: Object;
    }) => void;
    refreshTrackedChangeCommentsByIds: ({ superdoc, editor, changeIds, broadcastChanges }: {
        superdoc: any;
        editor: any;
        changeIds: any;
        broadcastChanges?: boolean | undefined;
    }) => void;
    syncResolvedCommentsWithDocument: ({ editor }?: {}) => number;
    syncTrackedChangePositionsWithDocument: ({ documentId, editor }?: {}) => number;
    setActiveFloatingCommentInstance: (instanceId?: null) => void;
    requestInstantSidebarAlignment: (targetY?: null, threadId?: null, instanceId?: null) => void;
    peekInstantSidebarAlignment: () => null;
    clearInstantSidebarAlignment: () => void;
    syncTrackedChangeComments: ({ superdoc, editor, broadcastChanges }: {
        superdoc: any;
        editor: any;
        broadcastChanges?: boolean | undefined;
    }) => void;
    decideTrackedChangeFromSidebar: ({ superdoc, comment, decision }: {
        superdoc: Object;
        editor: Object;
    }) => void;
    v2CommentsAdapter: import('vue').ShallowRef<null, null>;
    setV2CommentsAdapter: (adapter: any) => void;
    getV2CommentsAdapter: (superdoc: any) => any;
    applyReviewWindowFromV2: ({ superdoc, commentsAdapter, trackedChangesAdapter, documentId, commentItems, trackedChangeItems, requestedCommentIds, requestedTrackedChangeIds, unresolvedCommentIds, trackedList, sourceCoverageRevision, evaluatedRevision, patch, }?: {}) => any;
    reconcileCommentsFromV2: ({ superdoc, adapter, documentId, items, preparedInputs, pruneStale, hydrationGeneration, }?: {
        preparedInputs?: null | undefined;
        pruneStale?: boolean | undefined;
    }) => any;
    announceV2CommentCreated: ({ superdoc, commentId }?: {}) => Promise<{
        ok: boolean;
        reason: string;
        detail?: undefined;
        comment?: undefined;
    } | {
        ok: boolean;
        reason: string;
        detail: any;
        comment?: undefined;
    } | {
        ok: boolean;
        comment: any;
        reason?: undefined;
        detail?: undefined;
    }>;
    isV2EditorActive: (superdoc: any) => boolean;
    replyCommentV2: ({ superdoc, parentCommentId, text, mentions, trackedChangeTarget }?: {
        mentions?: never[] | undefined;
    }) => Promise<any>;
    editCommentV2: ({ superdoc, commentId, text }?: {}) => Promise<any>;
    resolveCommentV2: ({ superdoc, commentId }?: {}) => Promise<any>;
    reopenCommentV2: ({ superdoc, commentId }?: {}) => Promise<any>;
    v2TrackedChangesAdapter: import('vue').ShallowRef<null, null>;
    setV2TrackedChangesAdapter: (adapter: any) => void;
    getV2TrackedChangesAdapter: (superdoc: any) => any;
    getV2TrackedChangeRowCount: (documentId?: null) => number;
    reconcileTrackedChangeMutationFromV2: ({ superdoc, adapter, documentId, upsertIds, removedIds, remappedPairs, allResolved, }?: {
        upsertIds?: never[] | undefined;
        removedIds?: never[] | undefined;
        remappedPairs?: never[] | undefined;
    }) => Promise<{
        ok: boolean;
        reason: string;
        items?: undefined;
        resolvedIds?: undefined;
        unresolvedIds?: undefined;
        allResolved?: undefined;
        removedRows?: undefined;
        removedIds?: undefined;
    } | {
        ok: boolean;
        items: never[];
        resolvedIds: never[];
        unresolvedIds: never[];
        allResolved: boolean;
        removedRows: any;
        reason?: undefined;
        removedIds?: undefined;
    } | {
        ok: boolean;
        items: never[];
        resolvedIds: never[];
        unresolvedIds: (string | null)[];
        removedIds: (string | null)[];
        reason?: undefined;
        allResolved?: undefined;
        removedRows?: undefined;
    }>;
    reconcileTrackedChangesFromV2: ({ superdoc, adapter, documentId, items, pruneStale, preparedParams, liveIds: suppliedLiveIds, liveAnchorKeys: suppliedLiveAnchorKeys, hydrationGeneration, }?: {
        pruneStale?: boolean | undefined;
        preparedParams?: null | undefined;
        liveIds?: null | undefined;
        liveAnchorKeys?: null | undefined;
    }) => any;
    remapTrackedChangeIdentities: (pairs?: any[], { documentId }?: {}) => void;
}, "getCommentAliasIds" | "getTrackedChangeThread" | "getCommentPositionKey" | "getCommentPosition" | "getCommentAnchoredText" | "getCommentAnchorData" | "resolveCommentPositionEntry" | "getCommentDocumentId" | "belongsToDocument" | "init" | "setViewingVisibility" | "getComment" | "setActiveComment" | "getCommentLocation" | "hasOverlapId" | "getPendingComment" | "showAddComment" | "addComment" | "addHydratedComment" | "cancelComment" | "deleteComment" | "removePendingComment" | "cancelImportedTrackedChangeBootstrap" | "removeCommentsForDocument" | "setReviewDirectoryFromV2" | "clearReviewDirectory" | "processLoadedDocxComments" | "translateCommentsForExport" | "handleEditorLocationsUpdate" | "clearEditorCommentPositions" | "handleTrackedChangeUpdate" | "refreshTrackedChangeCommentsByIds" | "syncResolvedCommentsWithDocument" | "syncTrackedChangePositionsWithDocument" | "setActiveFloatingCommentInstance" | "requestInstantSidebarAlignment" | "peekInstantSidebarAlignment" | "clearInstantSidebarAlignment" | "syncTrackedChangeComments" | "decideTrackedChangeFromSidebar" | "setV2CommentsAdapter" | "getV2CommentsAdapter" | "applyReviewWindowFromV2" | "reconcileCommentsFromV2" | "announceV2CommentCreated" | "isV2EditorActive" | "replyCommentV2" | "editCommentV2" | "resolveCommentV2" | "reopenCommentV2" | "setV2TrackedChangesAdapter" | "getV2TrackedChangesAdapter" | "getV2TrackedChangeRowCount" | "reconcileTrackedChangeMutationFromV2" | "reconcileTrackedChangesFromV2" | "remapTrackedChangeIdentities">>;
