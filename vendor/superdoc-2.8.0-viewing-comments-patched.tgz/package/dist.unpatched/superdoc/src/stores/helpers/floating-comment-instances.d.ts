export function buildFloatingCommentInstances({ comment, positionKey, positionEntry, fallbackId }: {
    comment: any;
    positionKey: any;
    positionEntry: any;
    fallbackId: any;
}): {
    id: any;
    threadId: any;
    comment: any;
    positionKey: any;
    pageIndex: any;
    isPrimary: boolean;
    positionEntry: any;
}[];
