export function buildTrackedChangeThreadOwnerIndex<Comment extends {
    commentId: string | number;
    trackedChange?: boolean;
    trackedChangeCanonicalId?: string | number | null;
    trackedChangeSide?: string | null;
    semanticColorKey?: string | null;
    parentCommentId?: string | number | null;
    threadingParentCommentId?: string | number | null;
    trackedChangeParentId?: string | number | null;
    trackedChangeThreadParentId?: string | number | null;
}>(allComments: ReadonlyArray<Comment>): Map<Comment, Comment>;
export function buildTrackedChangeThreadIndex<Comment extends {
    commentId: string | number;
    trackedChange?: boolean;
    trackedChangeCanonicalId?: string | number | null;
    trackedChangeSide?: string | null;
    semanticColorKey?: string | null;
    createdTime?: number;
    parentCommentId?: string | number | null;
    threadingParentCommentId?: string | number | null;
    trackedChangeParentId?: string | number | null;
}>(allComments: ReadonlyArray<Comment>, previous?: ReadonlyMap<string | number, ReadonlyArray<Comment>>): Map<string | number, ReadonlyArray<Comment>>;
export function buildTrackedChangeDecisionLinkIndex<Comment extends {
    parentCommentId?: string | number | null;
    threadingParentCommentId?: string | number | null;
    trackedChangeParentId?: string | number | null;
    trackedChangeThreadParentId?: string | number | null;
}>(allComments: ReadonlyArray<Comment>, previous?: ReadonlyMap<string, ReadonlyArray<Comment>>): Map<string, ReadonlyArray<Comment>>;
