declare const DOCX: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document';
declare const PDF: 'application/pdf';
declare const HTML: 'text/html';
declare function getFileObject(fileUrl: string, name: string, type: string): Promise<File>;
declare function compareVersions(version1: string, version2: string): -1 | 0 | 1;
/** URL to the blank DOCX template */
declare const BlankDOCX: string;
export { SuperDoc } from './core/SuperDoc.js';
export { defineSuperDocExtension } from './core/extensions/index.js';
export { BlankDOCX, getFileObject, compareVersions, DOCX, PDF, HTML };
export { createTheme, buildTheme } from './core/theme/create-theme.js';
