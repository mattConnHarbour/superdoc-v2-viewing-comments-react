Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_create_super_doc_ui = require("../chunks/create-super-doc-ui-C7EfKMnu.cjs");
exports.BUILT_IN_COMMAND_IDS = require_create_super_doc_ui.BUILT_IN_COMMAND_IDS;
exports.createSuperDocUI = require_create_super_doc_ui.createSuperDocUI;
exports.shallowEqual = require_create_super_doc_ui.shallowEqual;
