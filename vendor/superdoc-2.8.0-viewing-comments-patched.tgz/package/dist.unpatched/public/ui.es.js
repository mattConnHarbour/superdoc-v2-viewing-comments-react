import { n as shallowEqual, r as BUILT_IN_COMMAND_IDS, t as createSuperDocUI } from "../chunks/create-super-doc-ui-CllOZdBy.es.js";
export { BUILT_IN_COMMAND_IDS, createSuperDocUI, shallowEqual };
