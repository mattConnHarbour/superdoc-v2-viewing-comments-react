import { t as createSuperDocUI } from "../chunks/create-super-doc-ui-CllOZdBy.es.js";
import { createContext, createElement, useCallback, useContext, useEffect, useRef, useState } from "react";
//#region src/public/ui/react.ts
/**
* v2-native React bindings for the `superdoc/ui` controller.
*
* Provider + hooks over the SuperDoc-owned controller (`superdoc.ui`). For a
* real `SuperDoc` this layer never creates or destroys a controller; it binds
* to the one the instance already owns. It falls back to building (and then
* owning) one only for a structural host that carries no `ui`, since
* `SuperDocHost` leaves that property optional. Authored with
* `React.createElement` (no JSX) so the
* library build needs no JSX transform, and `react` stays an external/optional
* peer. No v1 editor or private v2 runtime imports.
*/
var SuperDocUIContext = createContext(null);
/**
* Destroy a controller this provider built itself. Controllers read off
* `superdoc.ui` are never passed here: the instance owns those.
*/
function disposeOwnedUi(ref) {
	const ui = ref.current;
	if (!ui) return;
	ui.destroy();
	ref.current = null;
}
/**
* Root provider. Call {@link useSetSuperDoc} from your editor-mount
* component's ready callback to bind a running SuperDoc instance; the hooks
* below then read that instance's own controller (`superdoc.ui`).
*
* The provider is a consumer, not an owner. SuperDoc creates the controller
* and destroys it in `superdoc.destroy()`, so unmounting or rebinding the
* provider leaves it running for the built-in toolbar and any other consumer
* of the same instance. Every React hook therefore observes the same command
* state the rest of the application sees.
*/
function SuperDocUIProvider(props) {
	const [ui, setUi] = useState(null);
	const [host, setHost] = useState(null);
	/** Only ever holds a controller this provider created for a host lacking one. */
	const ownedUiRef = useRef(null);
	const setSuperDoc = useCallback((superdoc) => {
		const hostUi = superdoc.ui;
		disposeOwnedUi(ownedUiRef);
		if (hostUi) setUi(hostUi);
		else {
			const created = createSuperDocUI({ superdoc });
			ownedUiRef.current = created;
			setUi(created);
		}
		setHost(superdoc);
	}, []);
	useEffect(() => () => disposeOwnedUi(ownedUiRef), []);
	const value = {
		ui,
		host,
		setSuperDoc
	};
	return createElement(SuperDocUIContext.Provider, { value }, props.children);
}
function useContextValue() {
	const value = useContext(SuperDocUIContext);
	if (!value) throw new Error("[superdoc/ui/react] hooks must be used within <SuperDocUIProvider>.");
	return value;
}
/**
* Read the controller, or `null` until a SuperDoc instance is bound.
*
* Borrowed: the bound instance owns teardown, so the returned type omits
* `destroy()`. A provider-built fallback controller is disposed by the provider.
*/
function useSuperDocUI() {
	return useContextValue().ui;
}
/** Read the raw bound SuperDoc host, or `null` until one is bound. */
function useSuperDocHost() {
	return useContextValue().host;
}
/** Get the stable callback used to bind a running SuperDoc instance. */
function useSetSuperDoc() {
	return useContextValue().setSuperDoc;
}
/**
* Normalize a `pick` result into a {@link SliceSource}. Domain handles and the
* command/font hooks already expose the snapshot-shaped contract
* (`getSnapshot` + `observe`) and pass through unchanged. A raw `ui.select(...)`
* {@link Subscribable} (`get` + `subscribe`) is adapted: it `subscribe`s FIRST,
* then emits the current value, so a synchronous recompute triggered by the
* first listener is not missed (the substrate's `subscribe` does not emit on
* attach). Exported for unit tests; not re-exported by the `superdoc/ui/react`
* facade, so it stays off the public surface.
*/
function toSliceSource(source) {
	const candidate = source;
	if (typeof candidate.getSnapshot === "function" && typeof candidate.observe === "function") return source;
	const raw = source;
	return {
		getSnapshot: () => raw.get(),
		observe: (listener) => {
			const unsubscribe = raw.subscribe(listener);
			listener(raw.get());
			return unsubscribe;
		}
	};
}
/**
* Subscribe to a derived slice of controller state. `pick` selects a value
* source from the controller: a domain handle / snapshot source
* ({@link SliceSource}) or a raw `ui.select(...)` {@link Subscribable}, both
* normalized via {@link toSliceSource}. `initial` is returned until the
* controller is bound.
*/
function useSuperDocSlice(pick, initial) {
	const ui = useSuperDocUI();
	const [value, setValue] = useState(() => ui ? toSliceSource(pick(ui)).getSnapshot() : initial);
	useEffect(() => {
		if (!ui) {
			setValue(initial);
			return;
		}
		const source = toSliceSource(pick(ui));
		setValue(source.getSnapshot());
		return source.observe(setValue);
	}, [ui]);
	return value;
}
var EMPTY_SELECTION = {
	status: "pending",
	empty: true,
	target: null,
	selectionTarget: null,
	activeMarks: [],
	activeCommentIds: [],
	activeChangeIds: [],
	quotedText: ""
};
/** Subscribe to the selection slice. */
function useSuperDocSelection() {
	return useSuperDocSlice((ui) => ui.selection, EMPTY_SELECTION);
}
/** Subscribe to the comments slice. */
function useSuperDocComments() {
	return useSuperDocSlice((ui) => ui.comments, {
		status: "pending",
		listStatus: "pending",
		items: [],
		total: 0,
		activeIds: [],
		activeId: null
	});
}
/** Subscribe to the content-controls slice. */
function useSuperDocContentControls() {
	return useSuperDocSlice((ui) => ui.contentControls, {
		status: "pending",
		items: [],
		total: 0,
		activeId: null,
		activeIds: []
	});
}
/** Subscribe to the track-changes slice. */
function useSuperDocTrackChanges() {
	return useSuperDocSlice((ui) => ui.trackChanges, {
		status: "pending",
		items: [],
		total: 0,
		activeId: null,
		authors: []
	});
}
/** Subscribe to the toolbar snapshot slice. */
function useSuperDocToolbar() {
	return useSuperDocSlice((ui) => ui.toolbar, {
		context: null,
		commands: {},
		copyFormatActive: false
	});
}
/** Subscribe to a single command's enable/active state. */
function useSuperDocCommand(id) {
	return useSuperDocSlice((ui) => ({
		getSnapshot: () => ui.commands.get(id).getState(),
		observe: (cb) => ui.commands.get(id).observe(cb)
	}), {
		enabled: false,
		active: false,
		supported: false
	});
}
/** Subscribe to the document slice. */
function useSuperDocDocument() {
	return useSuperDocSlice((ui) => ui.document, {
		ready: false,
		mode: null,
		dirty: false
	});
}
/** Subscribe to available font-family options. */
function useSuperDocFontOptions() {
	return useSuperDocSlice((ui) => ({
		getSnapshot: () => ui.fonts.getFamilyOptions(),
		observe: (cb) => ui.fonts.observe((slice) => cb(slice.options))
	}), []);
}
/** Subscribe to available font-size options. */
function useSuperDocFontSizeOptions() {
	return useSuperDocSlice((ui) => ({
		getSnapshot: () => ui.fonts.getSizeOptions(),
		observe: (cb) => ui.fonts.observe((slice) => cb(slice.sizeOptions))
	}), []);
}
/** Subscribe to the zoom slice. */
function useSuperDocZoom() {
	return useSuperDocSlice((ui) => ui.zoom, {
		mode: null,
		value: 100,
		min: 10,
		max: 100
	});
}
//#endregion
export { SuperDocUIProvider, useSetSuperDoc, useSuperDocCommand, useSuperDocComments, useSuperDocContentControls, useSuperDocDocument, useSuperDocFontOptions, useSuperDocFontSizeOptions, useSuperDocHost, useSuperDocSelection, useSuperDocSlice, useSuperDocToolbar, useSuperDocTrackChanges, useSuperDocUI, useSuperDocZoom };
