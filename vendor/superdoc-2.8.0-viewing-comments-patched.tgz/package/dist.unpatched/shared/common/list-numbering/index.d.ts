type NumberingHandler = (path: number[], lvlText: string, customFormat?: string) => string | null;
export interface GenerateOrderedListIndexOptions {
    listLevel: number[];
    lvlText: string | null | undefined;
    listNumberingType?: string;
    customFormat?: string;
}
export declare const generateOrderedListIndex: ({ listLevel, lvlText, listNumberingType, customFormat, }: GenerateOrderedListIndexOptions) => string | null;
export declare const intToJapaneseCounting: (num: number) => string;
export declare const normalizeLvlTextChar: (lvlText?: string) => string | undefined;
export declare const listNumberingHelpers: {
    generateOrderedListIndex: ({ listLevel, lvlText, listNumberingType, customFormat, }: GenerateOrderedListIndexOptions) => string | null;
    intToJapaneseCounting: (num: number) => string;
    normalizeLvlTextChar: (lvlText?: string) => string | undefined;
};
export type { NumberingHandler };
