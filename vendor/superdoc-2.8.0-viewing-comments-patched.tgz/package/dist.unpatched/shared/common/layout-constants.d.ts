export declare const LIST_MARKER_GAP = 8;
export declare const MIN_MARKER_GUTTER = 24;
export declare const DEFAULT_LIST_INDENT_BASE_PX = 24;
export declare const DEFAULT_LIST_INDENT_STEP_PX = 24;
export declare const DEFAULT_LIST_HANGING_PX = 18;
export declare const SPACE_SUFFIX_GAP_PX = 4;
export declare const DEFAULT_TAB_INTERVAL_PX = 48;
