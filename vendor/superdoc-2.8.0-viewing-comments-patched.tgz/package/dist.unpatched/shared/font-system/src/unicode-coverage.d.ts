export interface UnicodeRange {
    start: number;
    end: number;
}
export interface UnicodeCoverage {
    ranges: readonly UnicodeRange[];
    cssUnicodeRange: string;
}
export declare function parseUnicodeCoverage(bytes: ArrayBuffer | ArrayBufferView): UnicodeCoverage | null;
export declare function unicodeCoverageIncludes(coverage: UnicodeCoverage | null | undefined, codePoint: number): boolean;
export declare function textForUnicodeCoverage(text: string, coverage: UnicodeCoverage): string;
