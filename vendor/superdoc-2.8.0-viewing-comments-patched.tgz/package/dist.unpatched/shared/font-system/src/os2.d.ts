import type { FaceKey } from './resolver.js';
/**
 * The embedding policy + face axis read from a font's OS/2 table.
 *
 * Used to decide whether a DOCX-embedded font may be REGISTERED for rendering (its license permits
 * embedding) and which weight/style FACE it represents - so embedded fonts become first-class
 * registry faces with the correct {@link FaceKey} instead of being inferred from filenames.
 */
export interface EmbeddingPolicy {
    /** Raw OS/2 `fsType` bit field (the licensing/embedding permissions). */
    fsType: number;
    /** The face this font provides, from OS/2 `usWeightClass` + the `fsSelection` italic bit. */
    face: FaceKey;
    /**
     * The minimal RENDER gate: false only when fsType marks the font Restricted-License / no-embedding
     * (bit 1). This is NOT a complete licensing model - Preview&Print vs Editable vs Installable, the
     * No-Subsetting (0x0100) and Bitmap-only (0x0200) bits, and re-embedding for EXPORT/EDIT (vs
     * display) all need their own policy decisions. The raw {@link fsType} is preserved so callers can
     * apply a stricter policy without re-parsing.
     */
    embeddable: boolean;
}
/**
 * Parse a font's OS/2 embedding policy + face from its raw bytes (a deobfuscated DOCX-embedded TTF/OTF).
 *
 * Returns `null` when the bytes are not a parseable SFNT or have no readable OS/2 table - callers MUST
 * treat a null result conservatively (do NOT register; fall through to the bundled substitute), since
 * we cannot prove the font is licensed for embedding.
 */
export declare function parseEmbeddingPolicy(bytes: ArrayBuffer | ArrayBufferView): EmbeddingPolicy | null;
