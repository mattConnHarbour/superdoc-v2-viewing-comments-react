/**
 * Document-scoped font options for the toolbar: one option per logical family a loaded document
 * actually uses. Distinct from the static {@link ./font-offerings} (the bundled choices): this is
 * runtime and document-scoped because it needs the document's registry and resolver.
 *
 * Fallback diagnostics are intentionally not part of this surface. The toolbar lists document fonts as
 * plain picker rows; internal fallback/reporting details stay in SuperDoc's runtime font report.
 */
import { type BundledActivation } from './activation.js';
import { type UsedFace } from './report.js';
import type { FontRegistry } from './registry.js';
import type { FontResolver } from './resolver.js';
/**
 * One document font for the toolbar: the logical name (the dropdown label and the value stored and
 * exported) and the family to render its preview in.
 */
export interface DocumentFontOption {
    /** The Word-facing logical family: the dropdown label and the value stored + exported (e.g. "Aptos"). */
    logicalFamily: string;
    /**
     * The physical family to render the dropdown PREVIEW in (Calibri previews as Carlito; a document-
     * provided font previews as itself). The regular face is used as the representative when present.
     */
    previewFamily: string;
}
/**
 * The document-specific font options for the toolbar: one per LOGICAL family the document renders,
 * deduped, each with the family that actually paints its preview. Resolved FACE-aware (via
 * {@link buildFaceReport}) so an embedded / customer font the document supplies is detected even when
 * no bundled clone exists.
 */
export declare function buildDocumentFontOptions(usedFaces: Iterable<UsedFace>, registry: FontRegistry, resolver?: FontResolver): DocumentFontOption[];
/**
 * Final, dropdown-ready font family option. `label` and `value` are the logical family; `previewFamily`
 * is only for rendering the row preview.
 */
export interface FontFamilyOption {
    /** Display text: the Word-facing logical family (e.g. "Calibri"). */
    label: string;
    /** Value to apply with the font-family command. */
    value: string;
    /** Physical family used to render the option preview. */
    previewFamily: string;
}
/**
 * Compose the final font-family picker list from the built-in toolbar choices plus the active
 * document's fonts. The built-in choices are gated on the document's bundled-font {@link
 * BundledActivation} (baseline when no pack is configured, the curated rich set when it is); pass it
 * from the editor so the picker advertises only what this document will render. Document fonts are
 * always listed - they come from the loaded document itself. Sorted alphabetically, deduped by
 * logical family.
 */
export declare function buildFontFamilyOptions(documentOptions: ReadonlyArray<DocumentFontOption>, activation?: BundledActivation): FontFamilyOption[];
