/** Selection of which bundled families are active, by logical Word family name. */
export interface BundledFontSelection {
    /** Active families. When set (non-empty), ONLY these logical families resolve/advertise. */
    include?: readonly string[];
    /** Inactive families. When set, every bundled family EXCEPT these is active. */
    exclude?: readonly string[];
}
/** Inputs that decide bundled activation for a document. */
export interface BundledActivationInput extends BundledFontSelection {
    /** Whether the consumer wired the bundled pack (config presence or the CDN build). */
    packConfigured: boolean;
}
/** A resolved activation: the packConfigured flag, a per-logical-family predicate, and a signature. */
export interface BundledActivation {
    /** True when the bundled pack is wired for this document (config presence or the CDN build). */
    readonly packConfigured: boolean;
    /** Whether bundled substitution / advertising is active for this LOGICAL family (any case). */
    isActive(logicalFamily: string): boolean;
    /**
     * Deterministic identity of this activation. `''` when FULLY active (packConfigured with no
     * include/exclude) so default / full-pack documents keep sharing the measure cache and match the
     * global resolver; any narrower activation (no pack, or curated) gets a distinct, non-empty
     * signature the resolver folds into its own {@link FontResolver.signature} (the measure-cache key)
     * - so a no-pack or curated document never reuses a full-pack document's cached measures.
     */
    readonly signature: string;
}
/**
 * Fully-active activation: every bundled family, signature `''`. The resolver's default, so the
 * module-level resolver and any `createFontResolver()` with no activation keep the prior global
 * substitution behavior (and share the measure cache).
 */
export declare const FULLY_ACTIVE_BUNDLED: BundledActivation;
/**
 * No-pack activation: no bundled family is active. The conservative baseline default for the STATIC
 * toolbar surfaces (the headless `DEFAULT_FONT_FAMILY_OPTIONS` / Vue `TOOLBAR_FONTS` consts, which
 * have no runtime config to read).
 */
export declare const BASELINE_BUNDLED: BundledActivation;
/**
 * Build a {@link BundledActivation} from config-presence plus optional include/exclude.
 *
 * `include` is the stronger intent and WINS if both are passed (they are not meant to be combined).
 * An include/exclude list with no usable entries is ignored rather than emptying the toolbar - "no
 * bundled fonts" is expressed by not configuring the pack, not by `include: []`.
 */
export declare function createBundledActivation(input: BundledActivationInput): BundledActivation;
/** Structural slice of a `fonts` config the activation needs - keeps this free of the editor type. */
export interface FontAssetConfigLike {
    resolveAssetUrl?: unknown;
    assetBaseUrl?: unknown;
    bundled?: BundledFontSelection;
}
/**
 * Derive a document's {@link BundledActivation} from its `fonts` config. The pack counts as
 * configured when the consumer set `resolveAssetUrl` (e.g. `superdocFonts`) or `assetBaseUrl`, or
 * when a host marked it present page-globally ({@link isBundledPackPresent}). Selection comes from
 * `fonts.bundled` (set via `createSuperDocFonts`).
 *
 * This is the lower-level primitive; runtime documents that may carry hand-written `fonts.bundled`
 * derive activation through `deriveBundledActivationForConfig` (in font-offerings), which sanitizes
 * unknown curation names against the known family set first.
 */
export declare function deriveBundledActivation(config: FontAssetConfigLike | null | undefined): BundledActivation;
