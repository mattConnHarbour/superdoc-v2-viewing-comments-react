/** The current epoch. Reuse signatures include this so they bust on a font change. */
export declare function getFontConfigVersion(): number;
/** Advance the epoch (call after a font loads or the configuration changes). */
export declare function bumpFontConfigVersion(): number;
/** Reset the epoch. Test-only; not part of the public surface. */
export declare function __resetFontConfigVersion(): void;
