import type { FontRegistry } from './registry.js';
import type { UnicodeCoverage } from './unicode-coverage.js';
export declare const CORE_SYMBOL_FALLBACK_FAMILY = "__superdoc_core_symbols__";
export declare const CORE_SYMBOL_FALLBACK_COVERAGE: UnicodeCoverage;
/** Register the core provider; the load gate activates it only for text in its exact coverage. */
export declare function installCoreSymbolFallback(registry: FontRegistry): void;
/** Return the unique characters in `text` that the core provider can render. */
export declare function textForCoreSymbolFallback(text: string): string;
