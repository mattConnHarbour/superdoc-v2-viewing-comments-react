/**
 * Manifest of the bundled reviewed fallback pack: pure data, no binary
 * imports. The provider ({@link ./bundled}) turns each entry into a `url(...)` face
 * against a runtime base URL, so font bytes are emitted/served as SEPARATE assets and
 * never inlined into the JS bundle. Adding reviewed fallback rows extends the pack without changing
 * the resolver -> registry -> gate -> report flow.
 *
 * The `family` is the physical substitute name (must match the resolver's targets); the
 * `file` is the asset filename under `../assets/`. Family display names with spaces map
 * to space-free file prefixes (e.g. "Liberation Sans" -> `LiberationSans-*.woff2`).
 */
/** License identifier or expression for provenance and diagnostics. */
export type BundledLicense = 'OFL-1.1' | 'Apache-2.0' | 'AGPL-3.0-only WITH PS-or-PDF-font-exception-20170817' | 'GPL-2.0-only WITH Font-exception-2.0' | 'LicenseRef-GUST-Font-License-1.0';
/** One shippable face of a bundled family: its style axis + the asset filename. */
export interface BundledFaceFile {
    weight: 'normal' | 'bold';
    style: 'normal' | 'italic';
    /** Asset filename under the pack's `assets/` dir, e.g. `Carlito-Regular.woff2`. */
    file: string;
}
/** A bundled substitute family modeled as its faces. */
export interface BundledFamilyManifest {
    /** Physical family name (the substitute), e.g. "Carlito", "Liberation Sans". */
    family: string;
    license: BundledLicense;
    faces: readonly BundledFaceFile[];
}
/**
 * The verified bundled substitutes. Adding a row extends the pack without
 * touching the provider, registry, gate, or report.
 */
export declare const BUNDLED_MANIFEST: readonly BundledFamilyManifest[];
