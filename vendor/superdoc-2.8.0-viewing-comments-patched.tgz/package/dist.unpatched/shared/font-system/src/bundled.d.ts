import type { FontRegistry } from './registry.js';
import type { FontAssetUrlResolver } from './types.js';
export type { BundledLicense, BundledFaceFile, BundledFamilyManifest } from './bundled-manifest.js';
export type { FontAssetUrlContext, FontAssetUrlResolver } from './types.js';
export { BUNDLED_MANIFEST } from './bundled-manifest.js';
/**
 * Last-resort base URL the bundled `.woff2` are served from. Used only when neither a
 * `resolveAssetUrl` nor an `assetBaseUrl` is configured and no build target set a default.
 * A dev / simple-self-host fallback, NOT the product deploy assumption.
 */
export declare const DEFAULT_BUNDLED_FONT_BASE = "/fonts/";
/** Override the default asset base (e.g. a host that serves the pack from a fixed path). */
export declare function setBundledFontAssetBase(base: string): void;
/** The current default asset base (script-relative on CDN, else {@link DEFAULT_BUNDLED_FONT_BASE}). */
export declare function getBundledFontAssetBase(): string;
/** Mark the bundled pack as served page-globally (for hosts that serve it without per-instance config). */
export declare function markBundledPackPresent(): void;
/** Whether the bundled pack is served page-globally (see {@link markBundledPackPresent}). */
export declare function isBundledPackPresent(): boolean;
/** Reset the page-global pack-present flag. Test-only; not part of the public surface. */
export declare function __resetBundledPackPresent(): void;
export interface InstallBundledOptions {
    /** Highest-precedence per-face URL resolver (consumer `fonts.resolveAssetUrl`). */
    resolveAssetUrl?: FontAssetUrlResolver;
    /** Base URL the `.woff2` are served from (consumer `fonts.assetBaseUrl`). */
    assetBaseUrl?: string;
}
/**
 * Register the bundled substitute pack into a registry, once, as URL-sourced faces.
 *
 * The pack is one font PROVIDER - it registers `url(...)` faces through the same
 * `registry.register` path as customer/embedded fonts, never importing font binaries
 * into shared runtime, so the bytes are emitted as separate assets and never inlined.
 *
 * URL resolution precedence (per face): `resolveAssetUrl` -> `assetBaseUrl` -> the module
 * default base (script-relative on CDN, else `/fonts/`). Loading stays lazy at the binary
 * level: a `.woff2` is fetched only when the load gate awaits the family a document
 * declares. Idempotent per registry. Physical family names MUST match the resolver's
 * substitute targets.
 */
export declare function installBundledSubstitutes(registry: FontRegistry, options?: InstallBundledOptions): void;
