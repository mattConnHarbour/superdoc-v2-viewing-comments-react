/** docfonts fidelity verdict, best to worst. */
export type SubstituteVerdict = 'metric_safe' | 'near_metric' | 'cell_width_only' | 'visual_only' | 'customer_supplied' | 'preserve_only' | 'no_substitute';
/** docfonts renderer-neutral resolution action. */
export type SubstitutePolicyAction = 'substitute' | 'category_fallback' | 'preserve_only' | 'customer_supplied';
/** Derived public gate status. Diagnostic only - NOT a runtime inclusion input. */
export type SubstituteGateStatus = 'pass' | 'not_run' | 'fail';
/** CSS generic family for the logical font. */
export type CssGeneric = 'serif' | 'sans-serif' | 'monospace';
/**
 * RIBBI face slot - the four canonical faces docfonts scores. Deliberately NOT named `StyleKey` (its
 * docfonts name) or `FaceKey` (the runtime weight/style face in `resolver.ts`): an evidence slot is a
 * coarse RIBBI bucket, not a runtime weight+style pair, and the two must not be confused.
 */
export type FaceSlot = 'regular' | 'bold' | 'italic' | 'boldItalic';
/** Advance-width divergence vs the proprietary oracle, as fractions (0 = identical advances). */
export interface AdvanceDelta {
    /** sample/model used for the advance comparison, e.g. Latin glyph advances vs monospace cell width. */
    basis: 'latin_full' | 'latin_text' | 'monospace_cell' | 'cjk_jp_text';
    meanDelta: number;
    /** the worst-case delta, not the mean, is what gates line-break fidelity. */
    maxDelta: number;
}
/** Which of the four RIBBI faces the physical candidate supplies. */
export interface FaceCoverage {
    regular: boolean;
    bold: boolean;
    italic: boolean;
    boldItalic: boolean;
}
/** How a reviewed fallback renders a requested RIBBI face. Only synthetic sources change loading. */
export type FallbackFaceSource = {
    kind: 'real';
} | {
    kind: 'synthetic';
    from: FaceSlot;
};
export type FallbackFaceSources = Partial<Record<FaceSlot, FallbackFaceSource>>;
/** The four derived gate statuses behind a verdict; the proof is the referenced measurements. */
export interface SubstituteGates {
    static: SubstituteGateStatus;
    metric: SubstituteGateStatus;
    layout: SubstituteGateStatus;
    ship: SubstituteGateStatus;
}
/**
 * A named glyph-level advance divergence that qualifies one face: the honest exception behind a face
 * whose advances match everywhere EXCEPT a specific codepoint (e.g. Caladea Bold Italic vs Cambria on
 * U+0060). The full numbers live in the referenced measurement; this names the divergence publicly.
 */
export interface GlyphException {
    slot: FaceSlot;
    /** the diverging codepoint, e.g. 0x60 (grave accent). */
    codepoint: number;
    /** fractional advance divergence at this glyph (0.231 = 23.1%). */
    advanceDelta: number;
    note: string;
}
/**
 * One logical font's substitution evidence. Mirrors the renderer-relevant fields of a docfonts
 * EvidenceRecord and omits its prose (`notes`, `confidence`, measured dates): SuperDoc decides from
 * structured data, not free text. The {@link SUBSTITUTION_EVIDENCE} assignment enforces that the
 * package's rows conform to this shape.
 */
export interface SubstitutionEvidence {
    /** docfonts EvidenceRecord id - the provenance pointer back to the source record, e.g. "cambria". */
    evidenceId: string;
    /** the proprietary family the document asks for (docfonts `originalFont`), e.g. "Cambria". */
    logicalFamily: string;
    /** the logical font's broad CSS category, for a last-resort generic `font-family` keyword. */
    generic: CssGeneric;
    /** the physical substitute rendered in its place; null when no candidate is recommended. */
    physicalFamily: string | null;
    /** worst-face fidelity verdict (the public summary; see `faceVerdicts` when faces disagree). */
    verdict: SubstituteVerdict;
    /**
     * Per-face verdicts, AUTHORITATIVE when present - set when the faces do not share one verdict (a
     * QUALIFIED substitute). When present, the top-level `verdict` is the WORST face; a consumer showing
     * fidelity must show this breakdown, not the rolled-up verdict alone.
     */
    faceVerdicts?: Partial<Record<FaceSlot, SubstituteVerdict>>;
    /** Synthetic face instructions for reviewed fallback faces. Real faces stay represented by `faces`. */
    faceSources?: FallbackFaceSources;
    /** named glyph-level divergences that qualify a face (e.g. one codepoint reflows). */
    glyphExceptions?: readonly GlyphException[];
    faces: FaceCoverage;
    advance?: AdvanceDelta;
    gates: SubstituteGates;
    /** renderer-neutral action; `substitute` is what makes the resolver map the family. */
    policyAction: SubstitutePolicyAction;
    /** proof pointers back into docfonts, by MeasurementId. */
    measurementRefs: readonly string[];
    /** Candidate license id or expression. SPDX when exact, stable docfonts label otherwise. */
    candidateLicense?: string | null;
    /** SuperDoc renders substitutes but always exports the original name. Always this for now. */
    exportRule: 'preserve_original_name';
}
/**
 * The reviewed substitution evidence, sourced from `@docfonts/fallbacks` and pinned to SuperDoc's
 * {@link SubstitutionEvidence} contract (the assignment is the drift guard - see the file header). The
 * resolver activates the rows it can render (asset-gated); the verdict / per-face / glyph-exception
 * fields ride along for the later verdict-aware reporting pass and are not read for inclusion.
 */
export declare const SUBSTITUTION_EVIDENCE: readonly SubstitutionEvidence[];
