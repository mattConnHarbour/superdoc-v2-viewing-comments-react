/**
 * `@superdoc/font-system` - runtime font registry, load-state, and logical->physical
 * resolution shared across the SuperDoc rendering pipeline.
 *
 * Consumed by measurement (`@superdoc/measuring-dom`), paint (`painters/dom`),
 * and editor runtimes so all layers agree on which
 * physical face is used and whether it is ready. Separate from
 * `@superdoc/font-utils` (CSS fallback-string composition only).
 *
 * Surfaces: the load-state contract + `FontRegistry` (a registry per `FontFaceSet`);
 * the resolver (`resolveFontFamily`/`resolvePhysicalFamily`, e.g. Calibri->Carlito);
 * and a `fontConfigVersion` epoch that reuse signatures fold in so a font change busts
 * stale measure/paint reuse. The bundled substitute pack ships from the `./bundled`
 * subpath; the public DX surface (T7) builds on `FontRegistry.register`.
 */
export type { FontLoadStatus, FontFaceSource, FontFaceDescriptor, RegisteredFace, RegisterFaceResult, FontLoadResult, FontLoadSummary, FontFaceRequest, FontFaceLoadResult, FontAssetUrlContext, FontAssetUrlResolver, RequiredFace, } from './types.js';
export { SETTLED_STATUSES, isSettled } from './types.js';
export type { FontResolution, FontResolutionReason, FaceKey, HasFace, FontMeasureContext, ResolvePhysicalFamily, } from './resolver.js';
export { FontResolver, createFontResolver, insertFontFamilyBeforeGeneric } from './resolver.js';
export { resolveFontFamily, resolvePhysicalFamily, resolvePrimaryPhysicalFamily, resolvePhysicalFamilies, resolveFace, DEFAULT_FONT_MEASURE_CONTEXT, } from './resolver.js';
export { getFontConfigVersion, bumpFontConfigVersion, __resetFontConfigVersion } from './epoch.js';
export type { BundledFontSelection, BundledActivation, BundledActivationInput, FontAssetConfigLike, } from './activation.js';
export { createBundledActivation, deriveBundledActivation, FULLY_ACTIVE_BUNDLED, BASELINE_BUNDLED } from './activation.js';
export { setBundledFontAssetBase, getBundledFontAssetBase, DEFAULT_BUNDLED_FONT_BASE, markBundledPackPresent, isBundledPackPresent, __resetBundledPackPresent, } from './bundled.js';
export type { FontResolutionRecord, ResolvedFontEvidence, UsedFace } from './report.js';
export { buildFontReport, buildFaceReport } from './report.js';
export type { EmbeddingPolicy } from './os2.js';
export { parseEmbeddingPolicy } from './os2.js';
export type { UnicodeCoverage, UnicodeRange } from './unicode-coverage.js';
export { parseUnicodeCoverage, textForUnicodeCoverage, unicodeCoverageIncludes } from './unicode-coverage.js';
export { CORE_SYMBOL_FALLBACK_COVERAGE, CORE_SYMBOL_FALLBACK_FAMILY, installCoreSymbolFallback, textForCoreSymbolFallback, } from './core-symbol-fallback.js';
export type { FontSetLike, FontFaceLike, FontFaceCtor, FontRegistryOptions, OwnedFaceDescriptor } from './registry.js';
export { FontRegistry, getFontRegistryFor, getDefaultFontRegistry, DEFAULT_FONT_LOAD_TIMEOUT_MS, __resetDefaultFontRegistry, } from './registry.js';
export type { FontOffering, OfferingClass, FontGeneric } from './font-offerings.js';
export { FONT_OFFERINGS, getBuiltInToolbarFontOfferings, getDefaultFontOfferings, getDefaultFontFamilyOptions, fontOfferingStack, fontOfferingRenderStack, warnUnknownBundledSelection, getBundledFamilyNames, sanitizeBundledSelection, deriveBundledActivationForConfig, } from './font-offerings.js';
export type { DocumentFontOption, FontFamilyOption } from './document-font-options.js';
export { buildDocumentFontOptions, buildFontFamilyOptions } from './document-font-options.js';
export type { FaceSlot as FontFaceSlot, GlyphException, SubstitutePolicyAction, SubstituteVerdict, } from './substitution-evidence.js';
