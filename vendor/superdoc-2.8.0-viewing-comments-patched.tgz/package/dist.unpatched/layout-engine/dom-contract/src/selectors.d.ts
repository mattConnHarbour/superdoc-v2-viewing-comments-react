/** Selector for any block SDT element that carries an sdtId attribute. */
export declare const SDT_BLOCK_WITH_ID_SELECTOR: string;
/** Selector for draggable elements. */
export declare const DRAGGABLE_SELECTOR: string;
/**
 * Builds a compound CSS selector matching any image element (block fragment,
 * inline clip-wrapper, or bare inline image) by its `data-pm-start` value.
 *
 * Useful when re-acquiring an image element after a layout re-render.
 *
 * Callers with untrusted or user-facing values should `CSS.escape()` before
 * passing them here; numeric PM positions and pre-escaped IDs are safe as-is.
 */
export declare function buildImagePmSelector(pmStart: string | number): string;
/**
 * Builds a compound CSS selector matching inline image elements (clip-wrapper
 * first, then bare inline image) by their `data-pm-start` value.
 *
 * Prefers the clip-wrapper because selection outlines and resize handles should
 * target the visible cropped portion, not the scaled inner image.
 */
export declare function buildInlineImagePmSelector(pmStart: string | number): string;
/**
 * Builds a selector for block-level SDT elements with a given sdtId.
 *
 * Callers MUST `CSS.escape()` the sdtId before passing it here;
 * numeric IDs and pre-escaped strings are safe as-is.
 */
export declare function buildSdtBlockSelector(escapedSdtId: string): string;
/**
 * Builds a selector for inline SDT wrapper elements with a given sdtId.
 *
 * Callers MUST `CSS.escape()` the sdtId before passing it here.
 */
export declare function buildSdtInlineSelector(escapedSdtId: string): string;
/**
 * Selector for annotation elements that carry a ProseMirror start position.
 */
export declare function buildAnnotationSelector(): string;
/**
 * Selector for annotation elements with a specific `data-type` value.
 */
export declare function buildAnnotationTypeSelector(type: string): string;
/**
 * Selector for an annotation element at a specific ProseMirror start position.
 */
export declare function buildAnnotationPmSelector(pmStart: string | number): string;
