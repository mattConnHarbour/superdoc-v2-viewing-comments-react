/**
 * DOM Contract: Data Attributes
 *
 * Named constants for `data-*` attributes stamped on rendered DOM elements.
 * These attributes are read by editor-side DOM observers, click-to-position
 * mapping, and bridge compatibility code.
 *
 * Each constant stores the full attribute name (e.g. `"data-pm-start"`) as it
 * appears in `getAttribute()` / `setAttribute()` calls and CSS selectors.
 *
 * The `DATASET_KEYS` mirror provides the camelCase equivalents used with
 * `element.dataset.*` access.
 *
 * Editor-neutral (prep-001) attributes live alongside the legacy `data-pm-*`
 * attributes; both surfaces are emitted so that v1 consumers continue to work
 * unmodified while future editor-neutral consumers (hit-test / range mapping)
 * can address rendered output without consulting ProseMirror positions.
 */
/**
 * Full attribute names for use with `getAttribute` / `setAttribute` / CSS selectors.
 */
export declare const DATA_ATTRS: {
    /** ProseMirror start position of the element's content range. */
    readonly PM_START: "data-pm-start";
    /** ProseMirror end position of the element's content range. */
    readonly PM_END: "data-pm-end";
    /** Layout epoch stamp — incremented on each layout pass. */
    readonly LAYOUT_EPOCH: "data-layout-epoch";
    /** JSON-encoded table boundary metadata for resize overlays. */
    readonly TABLE_BOUNDARIES: "data-table-boundaries";
    /** SDT unique identifier. */
    readonly SDT_ID: "data-sdt-id";
    /** SDT type (fieldAnnotation, structuredContent, documentSection, etc.). */
    readonly SDT_TYPE: "data-sdt-type";
    /** Field annotation field identifier. */
    readonly FIELD_ID: "data-field-id";
    /** Field annotation field type (signer, text, checkbox, etc.). */
    readonly FIELD_TYPE: "data-field-type";
    /** Marks an element as draggable by the editor. */
    readonly DRAGGABLE: "data-draggable";
    /** Display label text for drag toast / accessibility. */
    readonly DISPLAY_LABEL: "data-display-label";
    /** Field annotation variant (text, image, signature, checkbox, html, link). */
    readonly VARIANT: "data-variant";
    /** Element type discriminator (annotation variant, etc.). */
    readonly TYPE: "data-type";
    /** Schema version for the editor-neutral layout boundary attributes. */
    readonly LAYOUT_BOUNDARY_SCHEMA: "data-layout-boundary-schema";
    /** Stable opaque id of the rendered fragment (see `LayoutFragmentId`). */
    readonly LAYOUT_FRAGMENT_ID: "data-layout-fragment-id";
    /** Encoded story locator (e.g. `body`, `header:rId4`, `footer:rId7`). */
    readonly LAYOUT_STORY: "data-layout-story";
    /** Source block reference (today: producer's `blockId`). */
    readonly LAYOUT_BLOCK_REF: "data-layout-block-ref";
};
/**
 * CamelCase keys for use with `element.dataset.*` property access.
 *
 * `element.dataset.pmStart` is equivalent to `element.getAttribute('data-pm-start')`.
 */
export declare const DATASET_KEYS: {
    readonly PM_START: "pmStart";
    readonly PM_END: "pmEnd";
    readonly LAYOUT_EPOCH: "layoutEpoch";
    readonly TABLE_BOUNDARIES: "tableBoundaries";
    readonly SDT_ID: "sdtId";
    readonly SDT_TYPE: "sdtType";
    readonly FIELD_ID: "fieldId";
    readonly FIELD_TYPE: "fieldType";
    readonly DRAGGABLE: "draggable";
    readonly DISPLAY_LABEL: "displayLabel";
    readonly VARIANT: "variant";
    readonly TYPE: "type";
    readonly LAYOUT_BOUNDARY_SCHEMA: "layoutBoundarySchema";
    readonly LAYOUT_FRAGMENT_ID: "layoutFragmentId";
    readonly LAYOUT_STORY: "layoutStory";
    readonly LAYOUT_BLOCK_REF: "layoutBlockRef";
};
/**
 * Encode a `LayoutStoryLocator`-shaped object into its dataset string form.
 *
 * Format is `"body"` for body content and `"<kind>:<id>"` otherwise. The id
 * is passed through verbatim (no escaping is applied) because the producers
 * pass opaque part-relationship ids that do not contain the colon delimiter.
 *
 * Kept here so emitters and readers agree on the wire shape without taking a
 * dependency on the contracts package from dom-contract.
 */
export declare const encodeLayoutStoryDataset: (story: {
    kind: "body" | "header" | "footer" | "footnote" | "endnote" | "textbox" | "unknown";
    id?: string;
}) => string;
/**
 * Decode the dataset string back into a `LayoutStoryLocator`-shaped object.
 *
 * Used by editor-side DOM observers. Unknown kinds fall back to
 * `{ kind: 'unknown' }` so downstream code can treat the value as a
 * diagnostic, not as a default body.
 */
export declare const decodeLayoutStoryDataset: (raw: string | undefined | null) => {
    kind: "body" | "header" | "footer" | "footnote" | "endnote" | "textbox" | "unknown";
    id?: string;
};
