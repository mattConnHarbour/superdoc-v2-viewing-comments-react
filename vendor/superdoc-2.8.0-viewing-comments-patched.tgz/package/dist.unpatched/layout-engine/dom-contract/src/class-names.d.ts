/**
 * DOM Contract: Class Names
 *
 * CSS class names stamped on rendered document elements by the DOM painter.
 * These names form a public contract read by the painter (emitter) and by
 * editor-side DOM observation code (reader).
 *
 * Changing a value here is a breaking change for both systems.
 */
export declare const DOM_CLASS_NAMES: {
    /** Top-level page container element. */
    readonly PAGE: "superdoc-page";
    /** Fragment container (paragraph, table, image block, etc.). */
    readonly FRAGMENT: "superdoc-fragment";
    /** Non-flowing fragment whose visual position must not define body flow geometry. */
    readonly FLOATING_FRAGMENT: "superdoc-floating-fragment";
    /** Line container within a fragment. */
    readonly LINE: "superdoc-line";
    /**
     * Inline structured-content (SDT) wrapper.
     *
     * Carries `data-pm-start` / `data-pm-end` for selection highlighting.
     * Should be EXCLUDED from click-to-position mapping — child spans are
     * the character-level targets.
     */
    readonly INLINE_SDT_WRAPPER: "superdoc-structured-content-inline";
    /** Inline structured-content label chrome. */
    readonly INLINE_SDT_LABEL: "superdoc-structured-content-inline__label";
    /** Block-level structured-content container. */
    readonly BLOCK_SDT: "superdoc-structured-content-block";
    /** Block-level structured-content label chrome. */
    readonly BLOCK_SDT_LABEL: "superdoc-structured-content__label";
    /** Table fragment container (resize overlay and click-mapping target). */
    readonly TABLE_FRAGMENT: "superdoc-table-fragment";
    /** Document section container. */
    readonly DOCUMENT_SECTION: "superdoc-document-section";
    /**
     * Grouped hover highlight applied to all fragments of the same block SDT.
     * Set by document-runtime hover coordination via event delegation.
     */
    readonly SDT_GROUP_HOVER: "sdt-group-hover";
    /** Paragraph fragment rendered as a Table of Contents entry. */
    readonly TOC_ENTRY: "superdoc-toc-entry";
    /** TOC analogue of `SDT_GROUP_HOVER`, applied to every fragment sharing a `data-toc-id`. */
    readonly TOC_GROUP_HOVER: "toc-group-hover";
    /** Block-level image fragment (ImageBlock). */
    readonly IMAGE_FRAGMENT: "superdoc-image-fragment";
    /** Inline image element (ImageRun inside a paragraph). */
    readonly INLINE_IMAGE: "superdoc-inline-image";
    /** Wrapper around a paragraph's list marker (bullet glyph or ordered number). */
    readonly LIST_MARKER: "superdoc-list-marker";
    /** Clip wrapper around a cropped inline image. */
    readonly INLINE_IMAGE_CLIP_WRAPPER: "superdoc-inline-image-clip-wrapper";
    /** Field annotation outer wrapper. */
    readonly ANNOTATION: "annotation";
    /** Field annotation inner content wrapper. */
    readonly ANNOTATION_CONTENT: "annotation-content";
    /** Hidden caret anchor span appended after field annotation content. */
    readonly ANNOTATION_CARET_ANCHOR: "annotation-caret-anchor";
};
/** Union of all DOM contract class name values. */
export type DomClassName = (typeof DOM_CLASS_NAMES)[keyof typeof DOM_CLASS_NAMES];
/** Structured-content chrome labels that should not drive text-position mapping. */
export declare const STRUCTURED_CONTENT_CHROME_LABEL_CLASS_NAMES: readonly ["superdoc-structured-content-inline__label", "superdoc-structured-content__label"];
