import { combineIndentProperties, combineProperties, combineRunProperties, FONT_SLOT_THEME_PAIRS, PropertyObject } from '../cascade.js';
import { ParagraphConditionalFormatting, ParagraphProperties, RunProperties } from './types.js';
import { NumberingProperties } from './numbering-types.js';
import { StylesDocumentProperties, TableProperties, TableLookProperties, TableCellProperties } from './styles-types.js';
export { combineIndentProperties, combineProperties, combineRunProperties, FONT_SLOT_THEME_PAIRS };
export type { PropertyObject };
export type * from './types.js';
export type * from './numbering-types.js';
export type * from './styles-types.js';
export { TABLE_STYLE_ID_TABLE_GRID, TABLE_STYLE_ID_TABLE_NORMAL, TABLE_FALLBACK_BORDER, TABLE_FALLBACK_BORDERS, TABLE_FALLBACK_CELL_PADDING, isKnownTableStyleId, findTypeDefaultTableStyleId, resolveExistingTableEffectiveStyleId, resolvePreferredNewTableStyleId, } from './table-style-selection.js';
export type { ResolvedStyle, ResolvedStyleSource, TableSemanticStyleHints } from './table-style-selection.js';
export interface OoxmlResolverParams {
    translatedNumbering: NumberingProperties | null | undefined;
    translatedLinkedStyles: StylesDocumentProperties | null | undefined;
    /** Actual `w:type="paragraph" w:default="1"` style ID. */
    defaultParagraphStyleId?: string;
    /** Bounded read-only aliases for legacy dangling semantic references. */
    styleIdAliases?: Readonly<Record<string, string>>;
    /**
     * Opt-in memoization of `resolveStyleChain` results, keyed per params
     * object. Only set this when `translatedLinkedStyles` is immutable for the
     * lifetime of this params object (the compiled WordStyleModel guarantees
     * that; callers that rebuild styles in place must not opt in).
     */
    enableChainMemo?: boolean;
}
export interface TableInfo {
    tableProperties: TableProperties | null | undefined;
    directTableProperties?: TableProperties | null | undefined;
    rowIndex: number;
    cellIndex: number;
    numCells: number;
    numRows: number;
    rowCnfStyle?: ParagraphConditionalFormatting | null;
    cellCnfStyle?: ParagraphConditionalFormatting | null;
}
/**
 * OOXML default tblLook value (0x04A0) per ECMA-376 §17.4.56.
 * Word applies these flags when a table has no explicit w:tblLook element.
 */
export declare const DEFAULT_TBL_LOOK: TableLookProperties;
export declare function resolveRunProperties(params: OoxmlResolverParams, inlineRpr: RunProperties | null | undefined, resolvedPpr: ParagraphProperties | null | undefined, tableInfo?: TableInfo | null | undefined, isListNumber?: boolean, numberingDefinedInline?: boolean): RunProperties;
export declare function resolveParagraphProperties(params: OoxmlResolverParams, inlineProps: ParagraphProperties | null | undefined, tableInfo: TableInfo | null | undefined): ParagraphProperties;
export declare function resolveStyleChain<T extends PropertyObject>(propertyType: 'paragraphProperties' | 'runProperties' | 'tableProperties', params: OoxmlResolverParams, styleId: string | undefined, followBasedOnChain?: boolean): T;
export declare function getNumberingProperties<T extends ParagraphProperties | RunProperties>(propertyType: 'paragraphProperties' | 'runProperties', params: OoxmlResolverParams, ilvl: number, numId: number, tries?: number): T;
/**
 * Resolves table-level properties (borders, cellMargins, justification,
 * tableWidth, tableCellSpacing) by walking the full basedOn chain.
 *
 * Returns raw OOXML-translated shapes exactly as stored in
 * `translatedLinkedStyles`. Conversion to layout units (px, pt)
 * remains in the pm-adapter hydrator.
 */
export declare function resolveTableProperties(tableStyleId: string | null | undefined, translatedLinkedStyles: StylesDocumentProperties | null | undefined): TableProperties;
export declare function resolveDocxFontFamily(attributes: Record<string, unknown> | null | undefined, docx: Record<string, unknown> | null | undefined, toCssFontFamily?: (fontName: string, docx?: Record<string, unknown>) => string): string | null;
export declare function resolveCellStyles<T extends PropertyObject>(propertyType: 'paragraphProperties' | 'runProperties' | 'tableCellProperties', tableInfo: TableInfo | null | undefined, translatedLinkedStyles: StylesDocumentProperties): T[];
/**
 * Resolve table cell properties (shading, borders, margins) by cascading
 * conditional table style properties with inline cell properties.
 *
 * Cascade order (low → high priority):
 *   wholeTable → bands → firstRow/lastRow/firstCol/lastCol → corner cells → inline
 */
export declare function resolveTableCellProperties(inlineProps: TableCellProperties | null | undefined, tableInfo: TableInfo | null | undefined, translatedLinkedStyles: StylesDocumentProperties | null | undefined): TableCellProperties;
