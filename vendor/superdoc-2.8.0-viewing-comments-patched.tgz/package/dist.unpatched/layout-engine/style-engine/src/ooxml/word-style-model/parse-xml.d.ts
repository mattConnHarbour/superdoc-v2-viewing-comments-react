export interface OoxmlElement {
    name?: string;
    type?: string;
    attributes?: Record<string, string | undefined>;
    elements?: OoxmlElement[];
    text?: string;
}
export interface XmlParseResult {
    root: OoxmlElement | null;
    error?: string;
}
/**
 * Parse OOXML bytes/string to the `{ elements }` tree. Returns the first
 * element under the document node (typically `w:styles`, `w:numbering`, etc.).
 * Returns `{ root: null }` for empty/missing input; returns `{ error }` on
 * malformed XML so callers can record diagnostics.
 */
export declare function parseOoxml(input: Uint8Array | string | null | undefined): XmlParseResult;
/** Find the first child element with a given name. */
export declare function findChild(node: OoxmlElement | null | undefined, name: string): OoxmlElement | undefined;
/** Return all child elements with a given name. */
export declare function findChildren(node: OoxmlElement | null | undefined, name: string): OoxmlElement[];
/** Read a single attribute by name. */
export declare function attr(node: OoxmlElement | null | undefined, name: string): string | undefined;
export declare function parseOnOff(node: OoxmlElement | null | undefined): boolean | undefined;
/** Read `w:val` and coerce to a number, returning undefined on failure. */
export declare function parseNumberVal(node: OoxmlElement | null | undefined): number | undefined;
/** Read `w:val` as string. */
export declare function parseStringVal(node: OoxmlElement | null | undefined): string | undefined;
