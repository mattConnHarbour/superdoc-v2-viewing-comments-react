import { StylesDocumentProperties } from './styles-types.js';
export declare const TABLE_STYLE_ID_TABLE_GRID = "TableGrid";
export declare const TABLE_STYLE_ID_TABLE_NORMAL = "TableNormal";
/** Fallback border applied when no table style exists at all (source: 'none'). */
export declare const TABLE_FALLBACK_BORDER: {
    readonly val: "single";
    readonly size: 4;
    readonly color: "#000000";
};
export declare const TABLE_FALLBACK_BORDERS: {
    readonly top: {
        readonly val: "single";
        readonly size: 4;
        readonly color: "#000000";
    };
    readonly left: {
        readonly val: "single";
        readonly size: 4;
        readonly color: "#000000";
    };
    readonly bottom: {
        readonly val: "single";
        readonly size: 4;
        readonly color: "#000000";
    };
    readonly right: {
        readonly val: "single";
        readonly size: 4;
        readonly color: "#000000";
    };
    readonly insideH: {
        readonly val: "single";
        readonly size: 4;
        readonly color: "#000000";
    };
    readonly insideV: {
        readonly val: "single";
        readonly size: 4;
        readonly color: "#000000";
    };
};
/** Default cell padding in dxa (twips). left/right = 108 dxa ≈ 0.075in, matching Word defaults. */
export declare const TABLE_FALLBACK_CELL_PADDING: {
    readonly top: 0;
    readonly bottom: 0;
    readonly left: 108;
    readonly right: 108;
};
export type ResolvedStyleSource = 'explicit' | 'settings-default' | 'type-default' | 'builtin-fallback' | 'none';
export interface ResolvedStyle {
    styleId: string | null;
    source: ResolvedStyleSource;
}
export interface TableSemanticStyleHints {
    readonly normalTableStyleId?: string | null;
    readonly tableGridStyleId?: string | null;
}
/**
 * Checks whether a style ID exists in the catalog and is of type `table`.
 */
export declare function isKnownTableStyleId(styleId: string | null | undefined, translatedLinkedStyles: StylesDocumentProperties | null | undefined): boolean;
/**
 * Finds the type-default table style: `w:style w:type="table" w:default="1"`.
 * Typically `TableNormal`.
 */
export declare function findTypeDefaultTableStyleId(translatedLinkedStyles: StylesDocumentProperties | null | undefined): string | null;
/**
 * Determines the effective style ID for a table already in the document.
 *
 * Precedence:
 *  1. Explicit `tableStyleId` on the node, if valid (exists + type=table).
 *  2. Type-default table style from catalog (`w:default="1"`).
 *  3. No style (`source: 'none'`).
 */
export declare function resolveExistingTableEffectiveStyleId(explicitTableStyleId: string | null | undefined, translatedLinkedStyles: StylesDocumentProperties | null | undefined): ResolvedStyle;
/**
 * Determines the preferred style ID for a newly created table.
 *
 * Precedence:
 *  1. `w:defaultTableStyle` from settings, if present and resolvable.
 *  2. Type-default table style (`w:default="1"`).
 *  3. `TableGrid` if it exists in catalog (builtin-fallback).
 *  4. `TableNormal` if it exists in catalog (builtin-fallback).
 *  5. No style (`source: 'none'`).
 */
export declare function resolvePreferredNewTableStyleId(settingsDefaultTableStyleId: string | null | undefined, translatedLinkedStyles: StylesDocumentProperties | null | undefined, semanticHints?: TableSemanticStyleHints): ResolvedStyle;
