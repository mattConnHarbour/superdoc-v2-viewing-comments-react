import { findChildren, OoxmlElement } from './parse-xml.js';
export interface WordThemeColorPalette {
    readonly [colorName: string]: string;
}
export interface WordThemeFontScheme {
    readonly major?: WordThemeFontFamily;
    readonly minor?: WordThemeFontFamily;
}
export interface WordThemeFontFamily {
    readonly latin?: string;
    readonly ea?: string;
    readonly cs?: string;
}
/** Authored DrawingML format definitions, indexed by the matching style reference. */
export interface WordThemeFormatScheme {
    readonly fillStyles: readonly string[];
    readonly backgroundFillStyles: readonly string[];
    readonly lineStyles?: readonly string[];
}
export declare const DEFAULT_WORD_THEME_PALETTE: WordThemeColorPalette;
export declare const DEFAULT_WORD_THEME_FONT_SCHEME: WordThemeFontScheme;
export interface ThemeParseResult {
    palette?: WordThemeColorPalette;
    fontScheme?: WordThemeFontScheme;
    formatScheme?: WordThemeFormatScheme;
}
/**
 * Parse the theme root (`a:theme`) into colors + font scheme. Returns an
 * empty object when the part is absent or unreadable.
 */
export declare function compileThemeFromRoot(root: OoxmlElement | null | undefined): ThemeParseResult;
/**
 * Build the v1-shaped `docx[word/theme/theme1.xml]` object that
 * existing helpers like `resolveDocxFontFamily(...)` know how to walk.
 * Preserves the original xml-js element tree so callers needing legacy
 * compatibility do not have to reimplement font resolution.
 */
export declare function buildLegacyThemeShape(root: OoxmlElement | null | undefined): Record<string, unknown> | undefined;
export declare function buildFallbackThemeShape(theme?: ThemeParseResult): Record<string, unknown>;
export { findChildren };
