import { ParagraphProperties, RunFontFamilyProperties, RunProperties } from './ooxml/types.js';
import { TableCellProperties, TableProperties } from './ooxml/styles-types.js';
export type PropertyObject = ParagraphProperties | RunProperties | TableCellProperties | TableProperties;
/**
 * Performs a deep merge on an ordered list of property objects.
 *
 * This is the core cascade function used throughout style resolution.
 * Properties from later objects in the array override earlier ones.
 *
 * @param propertiesArray - Ordered list of property objects to combine (low -> high priority).
 * @param options - Configuration for full overrides and special handling.
 * @returns Combined property object.
 */
export declare function combineProperties<T extends PropertyObject>(propertiesArray: T[], options?: {
    /**
     * Keys that should completely overwrite instead of deep merge.
     * Use this for complex objects like fontFamily or color that should
     * be replaced entirely rather than merged property-by-property.
     */
    fullOverrideProps?: string[];
    /**
     * Custom merge handlers for specific keys.
     * The handler receives the accumulated target and current source,
     * and returns the new value for that key.
     */
    specialHandling?: Record<string, (target: Record<string, unknown>, source: Record<string, unknown>) => unknown>;
}): T;
/**
 * Combines run property objects while fully overriding certain keys.
 * This is a convenience wrapper for run properties (w:rPr).
 *
 * @param propertiesArray - Ordered list of run property objects.
 * @returns Combined run property object.
 */
export declare const FONT_SLOT_THEME_PAIRS: Array<[keyof RunFontFamilyProperties, keyof RunFontFamilyProperties]>;
export declare function combineRunProperties(propertiesArray: RunProperties[]): RunProperties;
/**
 * Combines indent properties with special handling for firstLine/hanging mutual exclusivity.
 *
 * @param indentChain - Ordered list of indent property objects (or objects with indent property).
 * @returns Combined indent object.
 */
export declare function combineIndentProperties(indentChain: ParagraphProperties[]): ParagraphProperties;
