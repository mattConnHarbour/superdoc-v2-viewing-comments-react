import { TabStop, FieldAnnotationMetadata, StructuredContentMetadata, DocumentSectionMetadata, DocPartMetadata, SdtMetadata } from '../../contracts/src/index.js';
/**
 * @superdoc/style-engine
 *
 * Resolves OOXML styles to normalized ComputedStyle objects that engines can consume.
 * This module owns the cascade rules (defaults -> styles -> numbering -> direct formatting).
 *
 * Tab Stops:
 * - Passes through OOXML TabStop values unchanged (positions in twips, val: start/end/etc.)
 * - No unit conversion happens here - preserves exact OOXML values for round-trip fidelity
 * - Conversion to pixels happens at measurement boundary only
 */
export { combineProperties, combineRunProperties, combineIndentProperties, type PropertyObject } from './cascade.js';
export type { FieldAnnotationMetadata, StructuredContentMetadata, DocumentSectionMetadata, DocPartMetadata, SdtMetadata, };
export type SdtNodeType = 'fieldAnnotation' | 'structuredContent' | 'structuredContentBlock' | 'documentSection' | 'docPartObject';
export interface ResolveSdtMetadataInput {
    nodeType?: SdtNodeType | string | null;
    attrs?: Record<string, unknown> | null;
    /**
     * Optional cache key for reusing normalized metadata between identical SDT nodes.
     * When omitted, the helper derives a key from attrs.hash/id when available.
     */
    cacheKey?: string | null;
}
export interface ResolveStyleOptions {
    sdt?: ResolveSdtMetadataInput | null;
}
export interface BorderStyle {
    style?: 'none' | 'solid' | 'dashed' | 'dotted' | 'double';
    width?: number;
    color?: string;
}
export interface ComputedParagraphStyle {
    alignment?: 'left' | 'center' | 'right' | 'justify';
    spacing?: {
        before?: number;
        after?: number;
        line?: number;
        lineRule?: 'auto' | 'exact' | 'atLeast';
    };
    indent?: {
        left?: number;
        right?: number;
        firstLine?: number;
        hanging?: number;
    };
    borders?: {
        top?: BorderStyle;
        right?: BorderStyle;
        bottom?: BorderStyle;
        left?: BorderStyle;
    };
    shading?: {
        fill?: string;
        pattern?: string;
    };
    tabs?: TabStop[];
}
export interface StyleContext {
    styles?: Record<string, unknown>;
    numbering?: Record<string, unknown>;
    theme?: Record<string, unknown>;
    defaults?: {
        paragraphFont?: string;
        fontSize?: number;
        paragraphFontFallback?: string;
        paragraphFontFamily?: string;
        decimalSeparator?: string;
        defaultTabIntervalTwips?: number;
    };
}
/**
 * Clears the internal SDT metadata cache.
 *
 * This is primarily useful for testing to ensure a clean state between test runs.
 * In production, the cache persists for the lifetime of the module to maximize performance.
 *
 * @example
 * ```typescript
 * import { clearSdtMetadataCache } from './index.js';
 *
 * // Before each test
 * beforeEach(() => {
 *   clearSdtMetadataCache();
 * });
 * ```
 */
export declare function clearSdtMetadataCache(): void;
/**
 * Normalizes Structured Document Tag (SDT) metadata into a stable contract shape.
 *
 * Supports the following SDT node types:
 * - `fieldAnnotation`: Inline field annotations with display labels, colors, and visibility
 * - `structuredContent` / `structuredContentBlock`: Inline or block-level structured content containers
 * - `documentSection`: Document section metadata with locks and descriptions
 * - `docPartObject`: Document part objects (e.g., TOC, bibliography)
 *
 * Results are cached by hash/id to avoid recomputing metadata for identical SDT instances.
 *
 * @param input - SDT node information including nodeType, attrs, and optional cacheKey
 * @returns Normalized SdtMetadata or undefined if nodeType is unsupported/missing
 *
 * @example
 * ```typescript
 * import { resolveSdtMetadata } from './index.js';
 *
 * const metadata = resolveSdtMetadata({
 *   nodeType: 'fieldAnnotation',
 *   attrs: {
 *     fieldId: 'CLIENT_NAME',
 *     displayLabel: 'Client Name',
 *     fieldColor: '#980043',
 *     visibility: 'visible'
 *   }
 * });
 *
 * console.log(metadata?.type); // 'fieldAnnotation'
 * console.log(metadata?.fieldColor); // '#980043'
 * ```
 */
export declare function resolveSdtMetadata(input?: ResolveSdtMetadataInput | null): SdtMetadata | undefined;
