import { RunProperties } from '../ooxml/types.js';
import { WordThemeColorPalette, WordThemeFontScheme } from '../ooxml/word-style-model/parse-theme.js';
import { TextRunStyleAttrs } from './types.js';
export interface NormalizeRunAttrsContext {
    /** Compiled theme color palette from the Word style model. */
    themeColors?: WordThemeColorPalette;
    /** Compiled theme font scheme. */
    themeFontScheme?: WordThemeFontScheme;
    /**
     * Resolved background color in which the run will render (e.g. shaded cell
     * background). When set and the run color resolves to `auto`, the
     * normalizer picks a contrasting color so dark-on-dark text does not
     * silently render unreadable inside shaded cells.
     */
    backgroundColor?: string;
}
export declare function normalizeRunAttrsFromOoxml(props: RunProperties | null | undefined, context?: NormalizeRunAttrsContext): TextRunStyleAttrs;
