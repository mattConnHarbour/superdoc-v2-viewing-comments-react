/**
 * Unit helpers used by the editor-neutral normalize layer.
 *
 * Kept tiny and pure so v2 rendering can map twips/half-points/eighth-points
 * into the layout-engine pixel domain without depending on pm-adapter or v1
 * editor runtime.
 */
export declare const PX_PER_TWIP: number;
export declare const PX_PER_POINT: number;
export declare const PX_PER_EIGHTH_POINT: number;
export declare function twipsToPx(value: number): number;
export declare function halfPointsToPx(value: number): number;
export declare function eighthPointsToPx(value: number): number;
