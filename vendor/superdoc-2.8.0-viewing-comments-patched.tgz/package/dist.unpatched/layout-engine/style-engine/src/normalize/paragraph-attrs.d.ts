import { ParagraphProperties } from '../ooxml/types.js';
import { ParagraphAttrs } from '../../../contracts/src/index.js';
export declare function normalizeParagraphAttrsFromOoxml(props: ParagraphProperties | null | undefined): Partial<ParagraphAttrs>;
