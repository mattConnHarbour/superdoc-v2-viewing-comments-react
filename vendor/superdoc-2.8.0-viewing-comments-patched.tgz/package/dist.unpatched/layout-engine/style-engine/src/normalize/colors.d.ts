import { WordThemeColorPalette } from '../ooxml/word-style-model/parse-theme.js';
export declare function normalizeHexColor(value: string | undefined | null): string | undefined;
export declare function resolveThemeColor(themeColor: string | undefined, palette: WordThemeColorPalette | undefined): string | undefined;
/**
 * Apply OOXML theme tint / shade to a base hex color.
 *
 * Both attributes are encoded as a hex byte (00..FF). tint blends the color
 * toward white; shade blends it toward black. This is an approximation of
 * the HSL-based Word behavior good enough for first-paint visual parity
 * and proven elsewhere in the v1 pipeline. The painter / pm-adapter parity
 * gate will harden corner cases if needed.
 */
export declare function applyThemeTintShade(hexInput: string, themeTint?: string, themeShade?: string): string;
