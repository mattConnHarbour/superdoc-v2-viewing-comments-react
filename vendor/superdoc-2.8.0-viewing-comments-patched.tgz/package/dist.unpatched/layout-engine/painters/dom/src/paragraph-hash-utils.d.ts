import { ParagraphBorders, ParagraphBorder, TableBorders, TableBorderValue, CellBorders, BorderSpec } from '../../../contracts/src/index.js';
/**
 * Hash helpers are duplicated from layout-bridge to avoid a circular dependency
 * (layout-bridge imports DOM_CLASS_NAMES from painter-dom). Keep these helpers
 * in sync with layout-bridge when formatting changes need cache invalidation.
 */
export declare const hashParagraphBorder: (border: ParagraphBorder) => string;
export declare const hashParagraphBorders: (borders: ParagraphBorders) => string;
export declare const hashBorderSpec: (border: BorderSpec) => string;
export declare const hashTableBorderValue: (borderValue: TableBorderValue | undefined) => string;
export declare const hashTableBorders: (borders: TableBorders | undefined) => string;
export declare const hashCellBorders: (borders: CellBorders | undefined) => string;
export { getRunBooleanProp, getRunNumberProp, getRunStringProp, getRunUnderlineColor, getRunUnderlineStyle, hasBooleanProp, hasNumberProp, hasStringProp, } from './runs/hash.js';
