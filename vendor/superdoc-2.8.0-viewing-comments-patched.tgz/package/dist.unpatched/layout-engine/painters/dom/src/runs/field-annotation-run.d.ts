import { FieldAnnotationRun } from '../../../../contracts/src/index.js';
import { RunRenderContext } from './types.js';
/**
 * Renders a FieldAnnotationRun as an inline "pill" element matching SuperDoc's
 * visual appearance.
 *
 * Field annotations are styled inline elements that display form fields with:
 * - Outer span with border, border-radius, padding, and background color
 * - Inner span containing the displayLabel or type-specific content (image, link, etc.)
 *
 * @param run - The FieldAnnotationRun to render containing field configuration and styling
 * @returns HTMLElement (span) or null if document is not available
 */
export declare const renderFieldAnnotationRun: (run: FieldAnnotationRun, context: RunRenderContext) => HTMLElement | null;
