import { MathRun } from '../../../../contracts/src/index.js';
import { RunRenderContext } from './types.js';
/**
 * Render a math run as a MathML element wrapped in a span.
 * Follows the same pattern as renderImageRun — sets explicit dimensions.
 */
export declare const renderMathRun: (run: MathRun, context: RunRenderContext) => HTMLElement | null;
