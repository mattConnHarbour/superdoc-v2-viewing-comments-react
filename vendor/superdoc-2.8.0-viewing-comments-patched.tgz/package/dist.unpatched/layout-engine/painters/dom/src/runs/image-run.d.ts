import { ImageBlock, ImageRun, ImageRunVerticalAlign } from '../../../../contracts/src/index.js';
import { RunRenderContext, TrackedChangesRenderConfig } from './types.js';
type ImageFilterSource = Pick<ImageBlock, 'grayscale' | 'gain' | 'blacklevel' | 'lum'>;
type ImageOpacitySource = Pick<ImageBlock, 'alphaModFix'>;
/**
 * Resolve the effective CSS `vertical-align` for an inline image run.
 *
 * Single source of truth for every vertical-align write site in this module
 * (raw image, clip wrapper, and legacy clip fallback) so they never drift. The
 * effective alignment is resolved upstream: render-line.ts copies the measured
 * per-line alignment onto the run before this module runs, and an authored
 * `run.verticalAlign` always wins. Absent any value, legacy `'top'` applies.
 */
export declare const resolveImageVerticalAlign: (run: Pick<ImageRun, "verticalAlign">) => ImageRunVerticalAlign;
export declare const buildImageFilters: (source: ImageFilterSource) => string[];
export declare const resolveImageOpacity: (source: ImageOpacitySource) => string | null;
/**
 * Renders an ImageRun as an inline <img> element.
 *
 * SECURITY NOTES:
 * - Data URLs are validated against an allowlist of image MIME types
 * - Size limit prevents DoS attacks from extremely large images
 * - Only allows safe image MIME types; non-base64 data URLs are limited to SVG
 * - Non-data URLs are sanitized through sanitizeUrl to prevent XSS
 *
 * METADATA ATTRIBUTE:
 * - Adds `data-image-metadata` attribute to enable interactive resizing via ImageResizeOverlay
 * - Metadata includes: originalWidth, originalHeight, aspectRatio, min/max dimensions
 * - Only added when run.width > 0 && run.height > 0 to prevent invalid metadata
 * - Max dimensions: 3x original size or 1000px (whichever is larger)
 * - Min dimensions: 20px to ensure visibility and interactivity
 *
 * @param run - The ImageRun to render containing image source, dimensions, and spacing
 * @returns HTMLElement (img) or null if src is missing or invalid
 */
export declare const renderImageRun: (run: ImageRun, context: RunRenderContext, trackedConfig?: TrackedChangesRenderConfig) => HTMLElement | null;
export {};
