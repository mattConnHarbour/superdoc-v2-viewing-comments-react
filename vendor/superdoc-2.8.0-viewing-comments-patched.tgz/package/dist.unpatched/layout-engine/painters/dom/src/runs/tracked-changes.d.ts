import { Run, TextRun, TrackedChangeKind, TrackedChangeMeta, TrackedChangesMode } from '../../../../contracts/src/index.js';
import { TrackedChangesRenderConfig } from './types.js';
export declare const TRACK_CHANGE_BASE_CLASS: Record<TrackedChangeKind, string>;
/**
 * Resolve the color used for the kind-level tracked-change CSS variable family.
 *
 * Plain insertion/deletion semantic colors are the default change-kind palette.
 * When an author color is present it remains the visible insert/delete/format
 * highlight color. Side/structural semantic categories (`move-from`,
 * `table-insertion`, `table-cell-insertion`, `cell-merge`, etc.) are explicit
 * semantic paint roles and keep semantic precedence.
 */
export declare const resolveTrackedChangeVisualColor: (layer: TrackedChangeMeta) => string | undefined;
/**
 * Stamps the element-scoped CSS variable family for a single tracked-change
 * layer from its resolved visual color. `meta.color` remains the per-author
 * color and is still surfaced separately as `data-track-change-author-color`.
 * The painter reads only paint-ready metadata; color resolution (overrides /
 * resolver / fallback) happened upstream in layout-adapter. Focused backgrounds
 * are derived from the visual color with alpha and only when it is a hex string
 * `colorWithAlpha` can safely extend (named/non-hex visual colors still set
 * border/text but never fabricate a derived background).
 */
export declare const applyTrackedChangeColorVariables: (elem: HTMLElement, layer: TrackedChangeMeta) => void;
export declare const TRACK_CHANGE_MODIFIER_CLASS: Record<TrackedChangeKind, Record<TrackedChangesMode, string | undefined>>;
/**
 * Stamps the semantic class + datasets for a tracked-change layer. Shared by
 * inline, row-level, and cell-level paint paths so the dataset/class vocabulary
 * stays identical. Only fields that are present are stamped; this never reads
 * or writes the author `color` dataset. The semantic datasets are namespaced
 * (`data-track-change-semantic-*`, `-type`, `-subtype`, `-target-kind`,
 * `-semantic-anchor-scope`) so they never collide with the existing author/
 * structural datasets even when row + cell metadata coexist.
 */
export declare const applySemanticTrackedChangeMetadata: (elem: HTMLElement, meta: TrackedChangeMeta) => void;
type TrackedChangeCarrier = Partial<Pick<TextRun, 'trackedChange' | 'trackedChanges'>>;
type TrackedChangeDecoratable = Run | TrackedChangeCarrier;
export declare const getTrackedChangeLayers: (carrier: TrackedChangeDecoratable) => TrackedChangeMeta[];
export declare const resolveTrackedChangesConfig: (block: {
    attrs?: unknown;
}) => TrackedChangesRenderConfig;
/**
 * Applies a structural row-level tracked change (inserted/deleted whole row) to
 * a single table cell element, reusing the exact same machinery as inline runs:
 * the shared {@link TrackedChangeMeta}, the `TRACK_CHANGE_BASE_CLASS`
 * (`track-insert-dec` / `track-delete-dec`), the `TRACK_CHANGE_MODIFIER_CLASS`
 * mode map (insert → review:highlighted / original:hidden / final:normal;
 * delete → review:highlighted / original:normal / final:hidden), and
 * `applyTrackedChangeColorVariables` for the tracked-change CSS variable family
 * (author colors own plain insert/delete highlights; semantic categories own
 * move/table/cell visuals).
 *
 * The painter renders a row as cells appended to a container (there is no
 * `<tr>` element), so the row's tracked-change visual is applied to each cell.
 * Boundary-safe: this lives in the painter and only reads paint-ready
 * `TrackedChangeMeta` from contracts.
 *
 * @param elem - The cell element to decorate.
 * @param meta - The row's resolved tracked-change metadata.
 * @param config - Tracked-changes mode/enabled (same source inline runs use).
 */
export declare const applyRowTrackedChangeToCell: (elem: HTMLElement, meta: TrackedChangeMeta, config: TrackedChangesRenderConfig) => void;
/**
 * Applies a cell-level structural tracked change (SD-3481
 * `TableCellAttrs.trackedChange`: cell insertion/deletion, merge, or split) to a
 * single table cell element. Mirrors {@link applyRowTrackedChangeToCell} but
 * carries its own marker class {@link TRACK_CHANGE_CELL_CLASS} so cell-level CSS
 * never affects inline spans or row-level decorations, and supports the
 * `format` kind (merge/split paint through the `--sd-tracked-changes-format-*`
 * family).
 *
 * Visual color uses {@link resolveTrackedChangeVisualColor} via
 * {@link applyTrackedChangeColorVariables}; semantic class/datasets come from
 * {@link applySemanticTrackedChangeMetadata}.
 *
 * Coexistence with a row-level tracked change: when this cell already carries a
 * row-level decoration (`track-row-cell-dec`), the row keeps ownership of the
 * shared single-value datasets and same-kind color variable family (row
 * precedence). Different-kind cell metadata still stamps its own independent
 * variable family (for example format vars for a cell merge inside an inserted
 * row), and the semantic datasets/classes are always added so neither
 * structural marker is dropped.
 *
 * @param elem - The cell element to decorate.
 * @param meta - The cell's resolved tracked-change metadata.
 * @param config - Tracked-changes mode/enabled (same source inline runs use).
 */
export declare const applyCellTrackedChangeToCell: (elem: HTMLElement, meta: TrackedChangeMeta, config: TrackedChangesRenderConfig) => void;
export declare const applyTrackedChangeDecorations: (elem: HTMLElement, run: TrackedChangeDecoratable, config: TrackedChangesRenderConfig) => void;
export {};
