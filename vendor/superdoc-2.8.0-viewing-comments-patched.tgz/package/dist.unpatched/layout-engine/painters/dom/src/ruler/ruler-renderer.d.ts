import { RulerDefinition } from './ruler-core.js';
/**
 * CSS class names for ruler elements
 */
export declare const RULER_CLASS_NAMES: {
    /** Main ruler container */
    readonly ruler: "superdoc-ruler";
    /** Tick mark element */
    readonly tick: "superdoc-ruler-tick";
    /** Main (inch) tick */
    readonly tickMain: "superdoc-ruler-tick--main";
    /** Half-inch tick */
    readonly tickHalf: "superdoc-ruler-tick--half";
    /** Eighth-inch tick */
    readonly tickEighth: "superdoc-ruler-tick--eighth";
    /** Inch label number */
    readonly label: "superdoc-ruler-label";
    /** Margin handle */
    readonly handle: "superdoc-ruler-handle";
    /** Left margin handle */
    readonly handleLeft: "superdoc-ruler-handle--left";
    /** Right margin handle */
    readonly handleRight: "superdoc-ruler-handle--right";
    /** Vertical indicator line during drag */
    readonly indicator: "superdoc-ruler-indicator";
};
/**
 * Options for creating a ruler element
 */
export type CreateRulerElementOptions = {
    /** The ruler definition from generateRulerDefinition() */
    definition: RulerDefinition;
    /** Document to create elements in */
    doc: Document;
    /** Whether to include interactive margin handles (default: false for per-page rulers) */
    interactive?: boolean;
    /** Callback when margin handle drag starts */
    onDragStart?: (side: 'left' | 'right', event: PointerEvent) => void;
    /** Callback when margin handle is dragged */
    onDrag?: (side: 'left' | 'right', x: number, event: PointerEvent) => void;
    /** Callback when margin handle drag ends */
    onDragEnd?: (side: 'left' | 'right', x: number, event: PointerEvent) => void;
};
/**
 * Create a ruler DOM element.
 *
 * Creates a complete ruler with tick marks and optionally interactive margin handles.
 * For per-page rulers in the painter, set `interactive: false` to render display-only rulers.
 * For the main interactive ruler overlay, set `interactive: true` and provide callbacks.
 *
 * @param options - Options for creating the ruler
 * @returns The ruler container element
 *
 * @example
 * ```typescript
 * // Display-only ruler for per-page rendering
 * const ruler = createRulerElement({
 *   definition: generateRulerDefinition({ pageSize, pageMargins }),
 *   doc: document,
 *   interactive: false,
 * });
 * pageElement.insertBefore(ruler, pageElement.firstChild);
 *
 * // Interactive ruler with margin handles
 * const interactiveRuler = createRulerElement({
 *   definition,
 *   doc: document,
 *   interactive: true,
 *   onDragEnd: (side, x) => editor.updatePageStyle({ pageMargins: { [side]: x / 96 } }),
 * });
 * ```
 */
export declare function createRulerElement(options: CreateRulerElementOptions): HTMLElement;
/**
 * Update a handle's position.
 *
 * @param ruler - Ruler container element
 * @param side - Which handle to update
 * @param x - New X position in pixels
 */
export declare function updateHandlePosition(ruler: HTMLElement, side: 'left' | 'right', x: number): void;
/**
 * Create a vertical indicator line element for drag feedback.
 *
 * @param doc - Document to create element in
 * @param height - Height of the indicator in pixels
 * @returns Indicator element
 */
export declare function createIndicatorElement(doc: Document, height: number): HTMLElement;
/**
 * Show/hide and position the vertical indicator.
 *
 * @param indicator - Indicator element
 * @param visible - Whether to show the indicator
 * @param x - X position in pixels (only used when visible)
 */
export declare function updateIndicator(indicator: HTMLElement, visible: boolean, x?: number): void;
