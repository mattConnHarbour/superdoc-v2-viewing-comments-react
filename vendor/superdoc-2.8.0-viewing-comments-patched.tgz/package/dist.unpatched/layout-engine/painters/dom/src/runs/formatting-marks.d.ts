import { Line, Run } from '../../../../contracts/src/index.js';
export declare const setTextContentWithFormattingSpaceMarks: (element: HTMLElement, text: string, doc: Document, showFormattingMarks: boolean) => void;
export declare const appendFormattingParagraphMark: (lineEl: HTMLElement, line: Line, runs: Run[], leftOffsetPx: number, availableWidth: number, hasExplicitPositioning: boolean, doc: Document, showFormattingMarks: boolean) => void;
