import { DomPainterHandle, DomPainterOptions, PaintSnapshot } from './index.js';
import { PageDecorationProvider } from './renderer.js';
import { FlowBlock, Layout, Measure, ResolvedLayout } from '../../../contracts/src/index.js';
export declare const emptyResolved: ResolvedLayout;
export declare function paintResolvedLayoutPersistent(painter: DomPainterHandle, resolvedLayout: ResolvedLayout, mount: HTMLElement): void;
/**
 * Test-only bridge: accepts old-style `{ blocks, measures, ...options }` and
 * returns a painter whose `paint()` automatically builds a `DomPainterInput`.
 */
export declare function createTestPainter(opts: {
    blocks?: FlowBlock[];
    measures?: Measure[];
} & DomPainterOptions): {
    paint(layout: Layout, mount: HTMLElement, mapping?: unknown): void;
    setData(blocks: FlowBlock[], measures: Measure[], hb?: FlowBlock[], hm?: Measure[], fb?: FlowBlock[], fm?: Measure[]): void;
    setResolvedLayout(rl: ResolvedLayout | null): void;
    setProviders(header?: PageDecorationProvider, footer?: PageDecorationProvider): void;
    getPersistentPageIndices(): number[];
    getPaintSnapshot(): PaintSnapshot | null;
    setShowFormattingMarks(showFormattingMarks: boolean): void;
    dispose(): void;
};
