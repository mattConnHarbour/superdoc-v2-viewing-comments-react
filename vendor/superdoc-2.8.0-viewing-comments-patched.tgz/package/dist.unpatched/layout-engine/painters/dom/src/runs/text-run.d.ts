import { Run, TextRun } from '../../../../contracts/src/index.js';
import { FragmentRenderContext } from '../renderer.js';
import { BROWSER_DEFAULT_FONT_SIZE } from '../styles.js';
import { RunRenderContext, TrackedChangesRenderConfig } from './types.js';
/**
 * Underline thickness in px, scaled to font size. Shared by text runs
 * (`text-decoration-thickness`) and tab underlines (border width) so a run's
 * underline renders as a single uniform weight across text and tab characters,
 * matching Word, on any display density (SD-3330). The divisor approximates the
 * font's natural underline weight (≈ what `text-decoration-thickness: auto`
 * produces) while staying deterministic across platforms.
 *
 * Rounded to an integer px because CSS borders snap to integer device pixels
 * while `text-decoration-thickness` keeps fractional values; using an integer
 * makes the tab border and the text underline rasterize to the same line weight.
 */
export declare const underlineThicknessPx: (fontSize: number) => number;
type ResolvePhysicalFont = (cssFontFamily: string, face: {
    weight: '400' | '700';
    style: 'normal' | 'italic';
}) => string;
export declare const applyRunTypographyStyles: (element: HTMLElement, run: TextRun, resolvePhysical?: ResolvePhysicalFont) => void;
/**
 * Applies run styling properties to a DOM element.
 *
 * @param element - The HTML element to style
 * @param run - The run object containing styling information
 * @param _isLink - Whether this run is part of a hyperlink. Note: This parameter
 *                  is kept for API compatibility but no longer affects behavior -
 *                  inline colors are now applied to all runs (including links) to
 *                  ensure OOXML hyperlink character styles appear correctly.
 */
export declare const applyRunStyles: (element: HTMLElement, run: Run, _isLink?: boolean, resolvePhysical?: ResolvePhysicalFont) => void;
export declare const resolveRunText: (run: Run, context: FragmentRenderContext) => string;
export declare const extractLinkData: (run: Run) => import('./types.js').LinkRenderData | null;
export declare const renderTextRun: (run: TextRun, context: FragmentRenderContext, renderContext: RunRenderContext, trackedConfig?: TrackedChangesRenderConfig) => HTMLElement | null;
export { BROWSER_DEFAULT_FONT_SIZE };
