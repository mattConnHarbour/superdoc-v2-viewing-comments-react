export declare function allowFontSynthesis(element: HTMLElement): void;
