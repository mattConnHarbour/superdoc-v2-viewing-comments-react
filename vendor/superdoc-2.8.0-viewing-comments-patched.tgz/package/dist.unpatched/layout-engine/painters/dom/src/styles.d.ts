/**
 * Fallback font-size applied to child elements inside a line container that
 * carry no explicit fontSize. Matches the browser default so rendering is
 * preserved after the strut-elimination fix (fontSize: '0' on lines).
 */
export declare const BROWSER_DEFAULT_FONT_SIZE = "16px";
export declare const CLASS_NAMES: {
    container: string;
    page: string;
    fragment: string;
    line: string;
    spread: string;
    pageHeader: string;
    pageFooter: string;
    textRun: string;
};
export type PageStyles = {
    background?: string;
    boxShadow?: string;
    border?: string;
    margin?: string;
    color?: string;
};
export declare const DEFAULT_PAGE_STYLES: Required<PageStyles>;
export declare const containerStyles: Partial<CSSStyleDeclaration>;
export declare const pageStyles: (width: number, height: number, overrides?: PageStyles) => Partial<CSSStyleDeclaration>;
export declare const fragmentStyles: Partial<CSSStyleDeclaration>;
/**
 * Line container styles. z-index is intentionally not set on the line so that
 * the resize overlay (and other UI) can stack above content. Only the image
 * element itself gets z-index for layering within the line (e.g. above tab leaders).
 */
export declare const lineStyles: (lineHeight: number) => Partial<CSSStyleDeclaration>;
/** One document-scoped stylesheet the paint surface requires: head marker attribute + CSS payload. */
export type SurfaceStylePreflightEntry = {
    markerAttribute: string;
    cssText: string;
};
export declare const ensurePrintStyles: (doc: Document | null | undefined) => void;
export declare const ensureDocumentSurfaceStyles: (doc: Document | null | undefined) => void;
export declare const ensureLinkStyles: (doc: Document | null | undefined) => void;
export declare const ensureTrackChangeStyles: (doc: Document | null | undefined) => void;
export declare const ensureFormattingMarksStyles: (doc: Document | null | undefined) => void;
export declare const ensureSdtContainerStyles: (doc: Document | null | undefined) => void;
export declare const ensureFieldAnnotationStyles: (doc: Document | null | undefined) => void;
/**
 * Injects image selection highlight styles into the document head.
 * Ensures styles are only injected once per document lifecycle.
 * @param {Document | null | undefined} doc - The document to inject styles into
 * @returns {void}
 */
export declare const ensureImageSelectionStyles: (doc: Document | null | undefined) => void;
/**
 * Injects the MathML <menclose> polyfill into the document head. Required
 * because no browser paints menclose natively (MathML Core dropped it). See
 * MATH_MENCLOSE_STYLES for the full rationale.
 */
export declare const ensureMathMencloseStyles: (doc: Document | null | undefined) => void;
/**
 * Injects footnote/endnote interaction styles (text cursor over note content)
 * into the document head. Injected once per document lifecycle. (SD-3400)
 */
export declare const ensureFootnoteStyles: (doc: Document | null | undefined) => void;
export declare const SURFACE_STYLE_PREFLIGHT: readonly SurfaceStylePreflightEntry[];
/**
 * Installs the full document-scoped style preflight (idempotent, one
 * `head.querySelector` per marker). The ONLY sanctioned way for a paint entry
 * to install document-level styles — per-path `ensure*Styles()` call lists
 * are the drift mechanism this helper exists to kill.
 */
export declare const ensureSurfaceStylePreflight: (doc: Document | null | undefined) => void;
