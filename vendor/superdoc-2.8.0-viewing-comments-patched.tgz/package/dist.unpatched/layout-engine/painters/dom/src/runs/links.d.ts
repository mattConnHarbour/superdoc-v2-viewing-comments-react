import { FlowRunLink } from '../../../../contracts/src/index.js';
import { LinkRenderData, RunRenderContext } from './types.js';
/**
 * Hyperlink rendering metrics for observability.
 * Tracks sanitization, blocking, and security-related events.
 */
export declare const linkMetrics: {
    sanitized: number;
    blocked: number;
    invalidProtocol: number;
    homographWarnings: number;
    reset(): void;
    getMetrics(): {
        'hyperlink.sanitized.count': number;
        'hyperlink.blocked.count': number;
        'hyperlink.invalid_protocol.count': number;
        'hyperlink.homograph_warnings.count': number;
    };
};
/**
 * Sanitize a URL to prevent XSS attacks.
 * Only allows http, https, mailto, tel, and internal anchors.
 *
 * @param href - The URL to sanitize
 * @returns Sanitized URL or null if blocked
 */
export declare function sanitizeUrl(href: string): string | null;
/**
 * Apply data-* attributes to an HTML element from a dataset object.
 * Safely assigns dataset properties while filtering out null/undefined values.
 *
 * @param element - Target HTML element to receive data attributes
 * @param dataset - Object mapping data attribute keys to string values
 */
export declare const applyLinkDataset: (element: HTMLElement, dataset?: Record<string, string>) => void;
export declare const buildLinkRenderData: (link: FlowRunLink) => LinkRenderData | null;
/**
 * Apply tooltip accessibility using aria-describedby for better screen reader support.
 * Creates a visually-hidden element containing the tooltip text and links it to the anchor.
 *
 * @param elem - The anchor element to enhance
 * @param tooltip - The tooltip text to make accessible
 * @returns The unique ID generated for this link
 */
export declare const applyTooltipAccessibility: (elem: HTMLAnchorElement, tooltip: string | null, context: RunRenderContext) => string;
/**
 * Enhance accessibility of a link element with ARIA labels and attributes.
 * Adds descriptive ARIA labels for ambiguous text and target=_blank links (WCAG 2.4.4).
 *
 * @param elem - The anchor element to enhance
 * @param linkData - Link metadata including href and target
 * @param textContent - The visible link text to analyze for ambiguity
 */
export declare const enhanceAccessibility: (elem: HTMLAnchorElement, linkData: LinkRenderData, textContent: string) => void;
/**
 * Apply link attributes to an anchor element.
 */
export declare const applyLinkAttributes: (elem: HTMLAnchorElement, linkData: LinkRenderData) => void;
