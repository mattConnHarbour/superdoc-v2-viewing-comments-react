import { Line, LineInlineBox, ParagraphBlock, Run, TextRun } from '../../../../contracts/src/index.js';
export declare const markInlineBoxRun: (run: TextRun, lineFrom: number, lineTo: number) => TextRun;
/** Splits text runs at the segment boundaries emitted for inline-box edges. */
export declare const splitInlineBoxRuns: (block: ParagraphBlock, line: Line) => Run[] | null;
/** Returns the resolved inline advance preceding an explicitly positioned text segment. */
export declare const inlineBoxAdvanceBeforeOffset: (boxes: readonly LineInlineBox[] | undefined, offset: number) => number;
/** Paints measured LTR inline-box slices on the canonical text leaves. */
export declare const paintInlineBoxes: (boxes: readonly LineInlineBox[] | undefined, lineElement: HTMLElement, isRtl: boolean) => void;
