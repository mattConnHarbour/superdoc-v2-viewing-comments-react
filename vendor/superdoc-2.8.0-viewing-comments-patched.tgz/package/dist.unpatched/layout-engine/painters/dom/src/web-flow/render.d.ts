import { FlowBlock } from '../../../../contracts/src/index.js';
import { WebFlowPaintItem, WebFlowPainterOptions } from './types.js';
export declare function doesWebFlowBlockProduceDom(block: FlowBlock): boolean;
export declare function renderWebFlowItem(item: WebFlowPaintItem, doc: Document, options: WebFlowPainterOptions): HTMLElement | null;
/** Identity-only signature for deciding whether a retained node needs dataset rebasing. */
export declare function webFlowItemIdentityFingerprint(item: WebFlowPaintItem): string;
/** Rebase canonical identity datasets without replacing an unchanged retained node. */
export declare function rebaseWebFlowItemNode(node: HTMLElement, previous: WebFlowPaintItem, next: WebFlowPaintItem): () => void;
