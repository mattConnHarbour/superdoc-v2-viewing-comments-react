import { WrapExclusion } from '../../../../contracts/src/index.js';
import { RenderedLineInfo } from '../renderer.js';
export declare const applySquareWrapExclusionsToLines: (renderedLines: RenderedLineInfo[], exclusions: WrapExclusion[], contentWidthPx: number, alignmentOffsetY: number) => void;
