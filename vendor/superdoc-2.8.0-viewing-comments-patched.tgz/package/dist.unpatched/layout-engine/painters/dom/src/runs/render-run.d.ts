import { FieldAnnotationRun, ImageRun, MathRun, Run } from '../../../../contracts/src/index.js';
import { FragmentRenderContext } from '../renderer.js';
import { RunRenderContext, TrackedChangesRenderConfig } from './types.js';
export declare const isImageRun: (run: Run) => run is ImageRun;
export declare const isLineBreakRun: (run: Run) => run is import('../../../../contracts/src/index.js').LineBreakRun;
export declare const isBreakRun: (run: Run) => run is import('../../../../contracts/src/index.js').BreakRun;
export declare const isFieldAnnotationRun: (run: Run) => run is FieldAnnotationRun;
export declare const isMathRun: (run: Run) => run is MathRun;
/**
 * Render a single run as an HTML element (span or anchor).
 */
export declare const renderRun: (run: Run, context: FragmentRenderContext, renderContext: RunRenderContext, trackedConfig?: TrackedChangesRenderConfig) => HTMLElement | null;
