import { SourceAnchor } from '../../../../contracts/src/index.js';
export declare function applySourceAnchorDataset(element: HTMLElement, sourceAnchor?: SourceAnchor): void;
