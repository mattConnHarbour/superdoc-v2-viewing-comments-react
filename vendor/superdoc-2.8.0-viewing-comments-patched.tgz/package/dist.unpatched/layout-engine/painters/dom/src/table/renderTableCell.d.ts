import { CellBorders, DrawingBlock, DrawingMeasure, ImageBlock, Line, ParagraphBlock, SdtMetadata, TableBlock, TableCell, TableMeasure } from '../../../../contracts/src/index.js';
import { ResolvePhysicalFamily } from '../../../../../shared/font-system/src/index.js';
import { FragmentRenderContext } from '../renderer.js';
import { SdtAncestorOptions } from '../sdt/container.js';
type TableRowMeasure = TableMeasure['rows'][number];
type TableCellMeasure = TableRowMeasure['cells'][number];
type TableCellBlock = NonNullable<TableCell['blocks']>[number];
type TableCellBlockMeasure = NonNullable<TableCellMeasure['blocks']>[number];
type ResolveCellAnchoredTopParams = {
    anchor: ImageBlock['anchor'] | DrawingBlock['anchor'];
    anchorParagraphId?: string;
    cellBlocks: TableCellBlock[];
    blockMeasures: TableCellBlockMeasure[];
    globalFromLine: number;
    globalToLine: number;
    paddingTop: number;
    objectHeight: number;
};
/**
 * Compute the total segment count for a cell's blocks, matching the layout engine's
 * recursive getCellLines() expansion. Paragraph blocks contribute their line count,
 * embedded tables contribute the sum of their rows' recursive segment counts,
 * and other blocks (images, drawings) contribute 1 segment.
 */
export declare function getCellSegmentCount(cell: TableCellMeasure): number;
type CellAnchoredTop = {
    top: number;
    /**
     * True only when the anchor paragraph was found and used as the base. Fallback results
     * (page/margin bases, missing/unresolvable anchorParagraphId) keep the legacy
     * top-of-cell invariant and must NOT be shifted by the vertical-alignment offset.
     */
    paragraphResolved: boolean;
};
export declare const resolveCellAnchoredTop: (params: ResolveCellAnchoredTopParams) => CellAnchoredTop | null;
/**
 * Dependencies required for rendering a table cell.
 *
 * Contains positioning, sizing, content, and rendering functions needed to
 * create a table cell DOM element with its content.
 */
type TableCellRenderDependencies = {
    /** Document object for creating DOM elements */
    doc: Document;
    /** Horizontal position (left edge) in pixels */
    x: number;
    /** Vertical position (top edge) in pixels */
    y: number;
    /** Height of the row containing this cell */
    rowHeight: number;
    /** Measurement data for this cell (width, paragraph layout) */
    cellMeasure: TableRowMeasure['cells'][number];
    /** Cell data (content, attributes), or undefined for empty cells */
    cell?: TableBlock['rows'][number]['cells'][number];
    /** Resolved borders for this cell */
    borders?: CellBorders;
    /** Whether to apply default border if no borders specified */
    useDefaultBorder?: boolean;
    /** Function to render a line of paragraph content */
    renderLine: (block: ParagraphBlock, line: Line, context: FragmentRenderContext, lineIndex: number, isLastLine: boolean, resolvedListTextStartPx?: number) => HTMLElement;
    /** Optional callback invoked after a table line's final styles/markers are applied. */
    captureLineSnapshot?: (lineEl: HTMLElement, context: FragmentRenderContext, options?: {
        inTableParagraph?: boolean;
        wrapperEl?: HTMLElement;
    }) => void;
    /**
     * Optional callback function to render drawing content (vectorShapes, shapeGroups).
     * If provided, this callback is used to render DrawingBlocks with drawingKind of 'vectorShape' or 'shapeGroup'.
     * The callback receives a DrawingBlock and must return an HTMLElement.
     * The returned element will have width: 100% and height: 100% styles applied automatically.
     * If undefined, a placeholder element with diagonal stripes pattern is rendered instead.
     */
    renderDrawingContent?: (block: DrawingBlock, interactionHost: HTMLElement, measure: DrawingMeasure) => HTMLElement;
    /** Rendering context */
    context: FragmentRenderContext;
    /** Function to apply SDT metadata as data attributes */
    applySdtDataset: (el: HTMLElement | null, metadata?: SdtMetadata | null) => void;
    /** Built-in SDT chrome rendering mode. */
    chrome?: 'default' | 'none';
    /** Ancestor SDT container key for suppressing duplicate container styling in cells */
    ancestorContainerKey?: string | null;
    /** Ancestor SDT metadata for suppressing duplicate id-less container styling in cells */
    ancestorContainerSdt?: SdtMetadata | null;
    /** Ancestor SDT keys for suppressing duplicate container styling in cells */
    ancestorContainerKeys?: SdtAncestorOptions['ancestorContainerKeys'];
    /** Ancestor SDT metadata chain for suppressing duplicate id-less container styling in cells */
    ancestorContainerSdts?: SdtAncestorOptions['ancestorContainerSdts'];
    /** Receives notification when this cell or descendants render SDT container chrome */
    onSdtContainerChrome?: () => void;
    /** Table indent in pixels (applied to table fragment positioning) */
    tableIndent?: number;
    /** Whether the table is visually right-to-left (w:bidiVisual, ECMA-376 §17.4.1) */
    isRtl?: boolean;
    /** Computed cell width from rescaled columnWidths (overrides cellMeasure.width when present) */
    cellWidth?: number;
    /** Starting line index for partial row rendering (inclusive) */
    fromLine?: number;
    /** Ending line index for partial row rendering (exclusive), -1 means render to end */
    toLine?: number;
    /**
     * Per-document logical->physical font resolver for in-cell list markers and drop caps. Threaded
     * from the renderer's per-document resolver so they paint the same physical family they were
     * measured in. Undefined falls back to the global resolver.
     */
    resolvePhysical?: ResolvePhysicalFamily;
};
/**
 * Result of rendering a table cell.
 */
export type TableCellRenderResult = {
    /** The cell container element (with borders, background, sizing, and content as child) */
    cellElement: HTMLElement;
};
/**
 * Renders a table cell as a DOM element.
 *
 * Creates a single cell element with content as a child:
 * - cellElement: Absolutely-positioned container with borders, background, sizing, padding,
 *   and content rendered inside. Cell uses overflow:hidden to clip any overflow.
 *
 * Handles:
 * - Cell borders (explicit or default)
 * - Background colors
 * - Vertical alignment (top, center, bottom)
 * - Cell padding (applied directly to cell element)
 * - Empty cells
 *
 * **Multi-Block Cell Rendering:**
 * - Iterates through all blocks in the cell (cell.blocks or cell.paragraph)
 * - Each block is rendered sequentially and stacked vertically
 * - Only paragraph blocks are currently rendered (other block types are ignored)
 *
 * **Backward Compatibility:**
 * - Supports legacy cell.paragraph field (single paragraph)
 * - Falls back to empty array if neither cell.blocks nor cell.paragraph is present
 * - Handles mismatches between blockMeasures and cellBlocks arrays using bounds checking
 *
 * **Empty Cell Handling:**
 * - Cells with no blocks render only the cell container (no content inside)
 * - Empty blocks arrays are safe (no content rendered)
 *
 * @param deps - All dependencies required for rendering
 * @returns Object containing cellElement (content is rendered inside as child)
 *
 * @example
 * ```typescript
 * const { cellElement } = renderTableCell({
 *   doc: document,
 *   x: 100,
 *   y: 50,
 *   rowHeight: 30,
 *   cellMeasure,
 *   cell,
 *   borders,
 *   useDefaultBorder: false,
 *   renderLine,
 *   renderDrawingContent: (block) => {
 *     // Custom drawing renderer for vectorShapes and shapeGroups
 *     const el = document.createElement('div');
 *     // Render drawing content...
 *     return el;
 *   },
 *   context,
 *   applySdtDataset
 * });
 * container.appendChild(cellElement);
 * ```
 */
export declare const renderTableCell: (deps: TableCellRenderDependencies) => TableCellRenderResult;
export {};
