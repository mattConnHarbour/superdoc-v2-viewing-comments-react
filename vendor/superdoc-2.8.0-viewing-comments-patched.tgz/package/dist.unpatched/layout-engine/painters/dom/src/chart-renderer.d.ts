import { ChartModel, DrawingGeometry, RenderPlaceholder } from '../../../contracts/src/index.js';
/**
 * Create a chart element from a ChartDrawing block.
 * Routes to the correct renderer based on chart type, with placeholder fallback.
 */
export declare function createChartElement(doc: Document, chartData: ChartModel | undefined, geometry: DrawingGeometry, placeholder?: RenderPlaceholder): HTMLElement;
/**
 * Create a placeholder for charts with missing data or unsupported types.
 * Preserves layout dimensions and is print-visible.
 */
export declare function createChartPlaceholder(doc: Document, container: HTMLElement, label: string, placeholder?: RenderPlaceholder): HTMLElement;
/** Format a numeric tick value for chart axis labels. */
export declare function formatTickValue(value: number): string;
