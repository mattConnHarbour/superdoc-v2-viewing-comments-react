/**
 * Ruler Styles - CSS injection for ruler elements
 *
 * This module provides CSS styles for ruler elements that are injected once
 * into the document head, similar to other painter styles.
 *
 * @module ruler-styles
 */
/**
 * Inject ruler styles into the document head.
 *
 * Styles are only injected once per document lifecycle.
 * Call this when initializing the painter or rendering the first ruler.
 *
 * @param doc - The document to inject styles into
 *
 * @example
 * ```typescript
 * // In DomPainter initialization
 * ensureRulerStyles(document);
 *
 * // Styles are now available for all ruler elements
 * const ruler = createRulerElement({ definition, doc: document });
 * ```
 */
export declare function ensureRulerStyles(doc: Document | null | undefined): void;
/**
 * Reset the injection state (useful for testing).
 * @internal
 */
export declare function _resetRulerStylesInjection(): void;
