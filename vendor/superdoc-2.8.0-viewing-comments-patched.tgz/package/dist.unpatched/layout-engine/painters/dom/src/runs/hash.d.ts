import { Run, TextRun } from '../../../../contracts/src/index.js';
/**
 * Type guard to check if a run has a string property.
 *
 * @param run - The run to check
 * @param prop - The property name to check
 * @returns True if the run has the property and it's a string
 */
export declare const hasStringProp: (run: Run, prop: string) => run is Run & Record<string, string>;
/**
 * Type guard to check if a run has a number property.
 *
 * @param run - The run to check
 * @param prop - The property name to check
 * @returns True if the run has the property and it's a number
 */
export declare const hasNumberProp: (run: Run, prop: string) => run is Run & Record<string, number>;
/**
 * Type guard to check if a run has a boolean property.
 *
 * @param run - The run to check
 * @param prop - The property name to check
 * @returns True if the run has the property and it's a boolean
 */
export declare const hasBooleanProp: (run: Run, prop: string) => run is Run & Record<string, boolean>;
/**
 * Safely gets a string property from a run, with type narrowing.
 *
 * @param run - The run to get the property from
 * @param prop - The property name
 * @returns The string value or empty string if not present
 */
export declare const getRunStringProp: (run: Run, prop: string) => string;
/**
 * Safely gets a number property from a run, with type narrowing.
 *
 * @param run - The run to get the property from
 * @param prop - The property name
 * @returns The number value or 0 if not present
 */
export declare const getRunNumberProp: (run: Run, prop: string) => number;
/**
 * Safely gets a boolean property from a run, with type narrowing.
 *
 * @param run - The run to get the property from
 * @param prop - The property name
 * @returns The boolean value or false if not present
 */
export declare const getRunBooleanProp: (run: Run, prop: string) => boolean;
/**
 * Safely gets the underline style from a run.
 * Handles the object-shaped underline property { style?, color? }.
 *
 * @param run - The run to get the underline style from
 * @returns The underline style or empty string if not present
 */
export declare const getRunUnderlineStyle: (run: Run) => string;
/**
 * Safely gets the underline color from a run.
 * Handles the object-shaped underline property { style?, color? }.
 *
 * @param run - The run to get the underline color from
 * @returns The underline color or empty string if not present
 */
export declare const getRunUnderlineColor: (run: Run) => string;
/**
 * Applies data-* attributes from a text run to a DOM element.
 * Validates attribute names and safely sets them on the element.
 * Invalid or unsafe attributes are skipped with development-mode logging.
 *
 * @param element - The HTML element to apply attributes to
 * @param dataAttrs - Record of data-* attribute key-value pairs from the text run
 *
 * @example
 * ```typescript
 * const span = document.createElement('span');
 * applyRunDataAttributes(span, { 'data-id': '123', 'data-name': 'test' });
 * // span now has: <span data-id="123" data-name="test"></span>
 * ```
 */
export declare const applyRunDataAttributes: (element: HTMLElement, dataAttrs?: Record<string, string>) => void;
export declare const textRunMergeSignature: (run: TextRun) => string;
