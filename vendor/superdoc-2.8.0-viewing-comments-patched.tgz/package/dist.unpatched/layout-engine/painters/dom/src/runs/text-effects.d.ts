import { TextEffects } from '../../../../contracts/src/index.js';
type TextInkBounds = {
    left: number;
    top: number;
    right: number;
    bottom: number;
};
export declare function reflectionDirection(direction: number): 'above' | 'below' | 'left' | 'right';
export declare function resolveTextReflectionTransform(reflection: NonNullable<TextEffects['reflection']>, ink: TextInkBounds): {
    transform: string;
    maskDirection: 'top' | 'bottom' | 'left' | 'right';
};
/**
 * Resolve reflection geometry without choosing a DOM or SVG transform syntax.
 * Both ordinary HTML runs and SVG WordArt use the same DrawingML direction,
 * distance, scale, and ink-edge anchoring contract.
 */
export declare function resolveTextReflectionPlacement(reflection: NonNullable<TextEffects['reflection']>, ink: TextInkBounds): {
    translateX: number;
    translateY: number;
    maskDirection: 'top' | 'bottom' | 'left' | 'right';
};
/** Resolve authored reflection opacity stops against visible glyph ink, not CSS leading. */
export declare function resolveTextReflectionMask(reflection: NonNullable<TextEffects['reflection']>, ink: TextInkBounds, box: {
    width: number;
    height: number;
}): string;
/** Apply paint-only Word text effects without changing glyph metrics. */
export declare function applyTextEffects(element: HTMLElement, effects: TextEffects | undefined): void;
export {};
