export declare const WEB_FLOW_CLASS_NAMES: {
    readonly root: "superdoc-web-flow";
    readonly block: "superdoc-web-flow-block";
    readonly paragraph: "superdoc-web-flow-paragraph";
    readonly run: "superdoc-web-flow-run";
    readonly listMarker: "superdoc-web-flow-list-marker";
    readonly table: "superdoc-web-flow-table";
    readonly diagnostic: "superdoc-web-flow-diagnostic";
};
export declare function ensureWebFlowStyles(doc: Document): void;
