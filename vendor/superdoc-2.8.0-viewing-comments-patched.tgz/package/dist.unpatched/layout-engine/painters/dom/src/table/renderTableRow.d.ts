import { DrawingBlock, DrawingMeasure, Line, ParagraphBlock, PartialRowInfo, SdtMetadata, TableBlock, TableBorders, TableMeasure } from '../../../../contracts/src/index.js';
import { ResolvePhysicalFamily } from '../../../../../shared/font-system/src/index.js';
import { FragmentRenderContext } from '../renderer.js';
import { SdtAncestorOptions } from '../sdt/container.js';
type TableRowMeasure = TableMeasure['rows'][number];
type TableRow = TableBlock['rows'][number];
/**
 * Dependencies required for rendering a table row.
 *
 * Contains all information needed to render cells in a table row, including
 * positioning, measurements, border resolution, and rendering functions.
 */
type TableRowRenderDependencies = {
    /** Document object for creating DOM elements */
    doc: Document;
    /** Container element to append cell elements to */
    container: HTMLElement;
    /** Zero-based index of this row */
    rowIndex: number;
    /** Vertical position (top edge) in pixels */
    y: number;
    /** Measurement data for this row (height, cell measurements) */
    rowMeasure: TableRowMeasure;
    /** Row data (cells, attributes), or undefined for empty rows */
    row?: TableRow;
    /** Previous (above) row data + measure, for collapsed-border conflict resolution (§17.4.66). */
    prevRow?: TableRow;
    prevRowMeasure?: TableRowMeasure;
    /** Next (below) row data, to detect a row-level border override that suppresses the shared
     * horizontal edge so the current row closes the grid itself (§17.4.61/§17.4.66). */
    nextRow?: TableRow;
    /** Next (below) row measure, to detect a gridAfter gap under a spanning cell (SD-3345). */
    nextRowMeasure?: TableRowMeasure;
    /**
     * Rightmost occupied grid column (exclusive) for THIS row, counting cells that span into it
     * via w:vMerge (rowspan) from an earlier row. Falls back to this row's own cells when absent.
     * Prevents a leftmost cell on a rowspan-continuation row from being treated as the rightmost
     * column. (SD-1797)
     */
    rowOccupiedRightCol?: number;
    /** Same as {@link rowOccupiedRightCol} for the NEXT row, so a rowspan continuation below is
     * not mistaken for a gridAfter gap (which would double the shared bottom edge). (SD-1797) */
    nextRowOccupiedRightCol?: number;
    /** Total number of rows in the table (for border resolution) */
    totalRows: number;
    /** Table-level borders (for resolving cell borders) */
    tableBorders?: TableBorders;
    /** Column widths array for calculating x positions from gridColumnStart */
    columnWidths: number[];
    /** All row heights for calculating rowspan cell heights */
    allRowHeights: number[];
    /** Table indent in pixels (applied to table fragment positioning) */
    tableIndent?: number;
    /** Whether the table is visually right-to-left (w:bidiVisual, ECMA-376 §17.4.1) */
    isRtl?: boolean;
    /** Rendering context */
    context: FragmentRenderContext;
    /** Function to render a line of paragraph content */
    renderLine: (block: ParagraphBlock, line: Line, context: FragmentRenderContext, lineIndex: number, isLastLine: boolean) => HTMLElement;
    /** Optional callback invoked after a table line's final styles/markers are applied. */
    captureLineSnapshot?: (lineEl: HTMLElement, context: FragmentRenderContext, options?: {
        inTableParagraph?: boolean;
        wrapperEl?: HTMLElement;
    }) => void;
    /** Function to render drawing content (images, shapes, shape groups) */
    renderDrawingContent?: (block: DrawingBlock, interactionHost: HTMLElement, measure: DrawingMeasure) => HTMLElement;
    /** Function to apply SDT metadata as data attributes */
    applySdtDataset: (el: HTMLElement | null, metadata?: SdtMetadata | null) => void;
    /** Ancestor SDT container key for suppressing duplicate container styling in cells */
    ancestorContainerKey?: string | null;
    /** Ancestor SDT metadata for suppressing duplicate id-less container styling in cells */
    ancestorContainerSdt?: SdtMetadata | null;
    /** Ancestor SDT keys for suppressing duplicate container styling in cells */
    ancestorContainerKeys?: SdtAncestorOptions['ancestorContainerKeys'];
    /** Ancestor SDT metadata chain for suppressing duplicate id-less container styling in cells */
    ancestorContainerSdts?: SdtAncestorOptions['ancestorContainerSdts'];
    /** Receives notification when cells render SDT container chrome */
    onSdtContainerChrome?: () => void;
    /**
     * If true, this row is the first body row of a continuation fragment.
     * MS Word draws borders at split points to visually close the table on each page,
     * so we do NOT suppress borders - both fragments draw their edge borders.
     */
    continuesFromPrev?: boolean;
    /**
     * If true, this row is the last body row before a page break continuation.
     * MS Word draws borders at split points to visually close the table on each page,
     * so we do NOT suppress borders - both fragments draw their edge borders.
     */
    continuesOnNext?: boolean;
    /**
     * Partial row information for mid-row splits.
     * Contains per-cell line ranges (fromLineByCell, toLineByCell) for rendering
     * only a portion of the row's content.
     */
    partialRow?: PartialRowInfo;
    /**
     * Cell spacing in pixels (border-spacing between cells).
     * Applied to cell x positions and row y advancement.
     */
    cellSpacingPx?: number;
    /** Built-in SDT chrome rendering mode. */
    chrome?: 'default' | 'none';
    /**
     * Per-document logical->physical font resolver for in-cell list markers and drop caps. Threaded
     * from the renderer's per-document resolver so they paint the same physical family they were
     * measured in. Undefined falls back to the global resolver.
     */
    resolvePhysical?: ResolvePhysicalFamily;
};
/**
 * Renders all cells in a table row.
 *
 * Iterates through cells in the row, resolving borders based on cell position,
 * and rendering each cell with its content. Cells are positioned horizontally
 * by accumulating their widths.
 *
 * Border resolution logic:
 * - Cells with explicit borders use those borders
 * - Otherwise, cells use position-based borders from table borders:
 *   - Edge cells use outer table borders
 *   - Interior cells use inside borders (insideH, insideV)
 * - If no table borders exist, default borders are applied
 *
 * @param deps - All dependencies required for rendering
 *
 * @example
 * ```typescript
 * renderTableRow({
 *   doc: document,
 *   container: tableContainer,
 *   rowIndex: 0,
 *   y: 0,
 *   rowMeasure,
 *   row,
 *   totalRows: 3,
 *   tableBorders,
 *   context,
 *   renderLine,
 *   applySdtDataset
 * });
 * // Appends all cell elements to container
 * ```
 */
export declare const renderTableRow: (deps: TableRowRenderDependencies) => void;
export {};
