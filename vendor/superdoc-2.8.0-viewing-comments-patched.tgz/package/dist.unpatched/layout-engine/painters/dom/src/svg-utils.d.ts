import { GradientFill, SolidFillWithAlpha, ShapeTextContent } from '../../../contracts/src/index.js';
/**
 * Validates and sanitizes a hex color string to prevent XSS attacks.
 *
 * Accepts hex colors in the following formats:
 * - 3-digit hex: #RGB (e.g., #F00)
 * - 6-digit hex: #RRGGBB (e.g., #FF0000)
 * - 3-digit hex without #: RGB (e.g., F00)
 * - 6-digit hex without #: RRGGBB (e.g., FF0000)
 *
 * @param color - The color string to validate
 * @returns The validated and normalized hex color with # prefix, or undefined if invalid
 *
 * @example
 * ```typescript
 * validateHexColor('#FF0000'); // '#FF0000'
 * validateHexColor('FF0000'); // '#FF0000'
 * validateHexColor('#F00'); // '#F00'
 * validateHexColor('F00'); // '#F00'
 * validateHexColor('javascript:alert(1)'); // undefined (XSS attempt)
 * validateHexColor('#GGGGGG'); // undefined (invalid hex)
 * validateHexColor('red'); // undefined (named colors not supported)
 * ```
 */
export declare function validateHexColor(color: string): string | undefined;
/**
 * Creates an SVG gradient element (linear or radial)
 */
export declare function createGradient(gradientData: GradientFill, gradientId: string): SVGLinearGradientElement | SVGRadialGradientElement | null;
/**
 * Creates an SVG foreignObject with formatted text content
 */
export declare function createTextElement(textContent: ShapeTextContent, textAlign: string, width: number, height: number): SVGForeignObjectElement;
/**
 * Applies a gradient to all filled elements in an SVG.
 *
 * Creates a gradient definition using the provided gradient data and applies it
 * to all filled elements in the SVG. Uses the shared createGradient utility to
 * ensure consistent gradient creation with validation.
 *
 * Gracefully handles DOM errors to prevent crashes.
 *
 * @param svg - The SVG element to apply the gradient to
 * @param gradientData - The gradient fill configuration
 *
 * @example
 * ```typescript
 * const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
 * applyGradientToSVG(svg, {
 *   type: 'gradient',
 *   gradientType: 'linear',
 *   angle: 90,
 *   stops: [
 *     { position: 0, color: '#FF0000', alpha: 1 },
 *     { position: 1, color: '#0000FF', alpha: 1 }
 *   ]
 * });
 * ```
 */
export declare function applyGradientToSVG(svg: SVGElement, gradientData: GradientFill): void;
/**
 * Applies alpha transparency to all filled elements in an SVG.
 *
 * Validates the color format before applying to prevent XSS attacks.
 * Clamps alpha value to the 0-1 range.
 * Gracefully handles DOM errors to prevent crashes.
 *
 * @param svg - The SVG element to apply the fill to
 * @param alphaData - The solid fill with alpha configuration
 *
 * @example
 * ```typescript
 * const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
 * applyAlphaToSVG(svg, { type: 'solidWithAlpha', color: '#FF0000', alpha: 0.5 });
 * ```
 */
export declare function applyAlphaToSVG(svg: SVGElement, alphaData: SolidFillWithAlpha): void;
/**
 * Generates CSS transform strings from shape attributes
 */
export declare function generateTransforms(attrs: {
    rotation?: number;
    flipH?: boolean;
    flipV?: boolean;
}): string[];
/**
 * Generates a unique gradient ID with optional prefix.
 *
 * Uses a combination of timestamp, counter, and random string to ensure uniqueness
 * even when multiple gradients are created in the same millisecond.
 *
 * @param prefix - Optional prefix for the gradient ID (defaults to 'gradient')
 * @returns A unique gradient ID string
 *
 * @example
 * ```typescript
 * generateGradientId(); // 'gradient-1700000000000-0-abc123def'
 * generateGradientId('linear'); // 'linear-1700000000000-1-xyz789ghi'
 * ```
 */
export declare function generateGradientId(prefix?: string): string;
