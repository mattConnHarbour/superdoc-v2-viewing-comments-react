import { WebFlowPainterHandle, WebFlowPainterOptions } from './types.js';
export declare function createWebFlowPainter(mount: HTMLElement, options?: WebFlowPainterOptions): WebFlowPainterHandle;
