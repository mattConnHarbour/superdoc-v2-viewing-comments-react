import { Run } from '../../contracts/src/index.js';
export declare const fieldAnnotationKey: (run: Run) => string;
