/**
 * Cursor Renderer
 *
 * Renders cursor and selection overlays as positioned div elements.
 * Provides smooth cursor blinking and instant updates without DOM measurements.
 *
 * @module cursor-renderer
 */
/**
 * Cursor position rectangle for rendering.
 */
export interface CursorRect {
    /** Page index where cursor is located */
    pageIndex: number;
    /** X position within the page */
    x: number;
    /** Y position within the page */
    y: number;
    /** Height of the cursor line */
    height: number;
    /**
     * Width of the selection rectangle.
     *
     * **Semantics:**
     * - When undefined: Represents a collapsed cursor (zero-width selection). Rendered as a thin
     *   vertical line at the cursor position. Typically uses the configured cursorWidth (default 2px).
     * - When defined: Represents a selection span (from !== to). Width indicates the horizontal
     *   extent of selected text or content.
     *
     * **Use Cases:**
     * - Cursor rendering: width should be undefined or omitted
     * - Selection highlighting: width should be the measured pixel width of the selected text/content
     * - Collapsed selections: Some renderers treat width=0 as equivalent to undefined
     *
     * **Rendering Behavior:**
     * The CursorRenderer uses this field to distinguish between cursor (thin line) and selection
     * (filled rectangle). When width is undefined, it falls back to cursorWidth for rendering.
     */
    width?: number;
}
/**
 * Configuration options for cursor rendering.
 */
export interface CursorRendererOptions {
    /** Container element to render cursor within */
    container: HTMLElement;
    /** Width of cursor line in pixels (default: 2) */
    cursorWidth?: number;
    /** Color of cursor (default: 'black') */
    cursorColor?: string;
    /** Cursor blink rate in milliseconds (default: 530) */
    blinkRate?: number;
    /** Selection background color (default: 'rgba(0, 123, 255, 0.3)') */
    selectionColor?: string;
}
/**
 * CursorRenderer renders cursor and selection overlays using positioned divs.
 *
 * This approach avoids browser's native cursor rendering and provides:
 * - Instant cursor updates without DOM measurements
 * - Precise positioning using calculated coordinates
 * - Smooth cursor blinking
 * - Multi-rect selection rendering
 *
 * Usage:
 * ```typescript
 * const renderer = new CursorRenderer({
 *   container: editorElement,
 *   cursorWidth: 2,
 *   cursorColor: 'black',
 *   blinkRate: 530
 * });
 *
 * // Render cursor at calculated position
 * renderer.render(cursorRect);
 *
 * // Render selection
 * renderer.renderSelection(selectionRects);
 *
 * // Clean up
 * renderer.destroy();
 * ```
 */
export declare class CursorRenderer {
    private container;
    private cursorWidth;
    private cursorColor;
    private blinkRate;
    private selectionColor;
    private cursorElement;
    private selectionElements;
    private blinkInterval;
    private isBlinkVisible;
    private isCursorVisible;
    /**
     * Creates a new CursorRenderer instance.
     *
     * @param options - Cursor rendering options
     */
    constructor(options: CursorRendererOptions);
    /**
     * Initialize the cursor DOM element.
     * @private
     */
    private initializeCursorElement;
    /**
     * Render cursor at calculated position.
     *
     * @param rect - Cursor rectangle or null to hide cursor
     */
    render(rect: CursorRect | null): void;
    /**
     * Render selection rectangles.
     *
     * Creates or updates div elements for each selection rectangle.
     *
     * @param rects - Array of selection rectangles
     */
    renderSelection(rects: CursorRect[]): void;
    /**
     * Show or hide the cursor.
     *
     * @param visible - Whether cursor should be visible
     */
    setVisible(visible: boolean): void;
    /**
     * Start cursor blink animation.
     */
    startBlink(): void;
    /**
     * Stop cursor blink animation.
     */
    stopBlink(): void;
    /**
     * Reset blink animation (show cursor and restart timer).
     * Call this when cursor moves to provide immediate visual feedback.
     * @private
     */
    private resetBlink;
    /**
     * Update cursor visibility based on blink state.
     * @private
     */
    private updateBlinkState;
    /**
     * Update cursor color.
     *
     * @param color - New cursor color
     */
    setCursorColor(color: string): void;
    /**
     * Update selection color.
     *
     * @param color - New selection color
     */
    setSelectionColor(color: string): void;
    /**
     * Update cursor width.
     *
     * @param width - New cursor width in pixels
     */
    setCursorWidth(width: number): void;
    /**
     * Update blink rate.
     *
     * @param rate - New blink rate in milliseconds
     */
    setBlinkRate(rate: number): void;
    /**
     * Clean up and remove all cursor and selection elements.
     */
    destroy(): void;
    /**
     * Check if cursor is currently visible (not hidden by user).
     *
     * @returns True if cursor is set to visible
     */
    isVisible(): boolean;
    /**
     * Check if cursor is currently blinking.
     *
     * @returns True if blink animation is running
     */
    isBlinking(): boolean;
    /**
     * Get current cursor position.
     *
     * @returns Current cursor rectangle or null if not rendered
     */
    getCurrentPosition(): {
        x: number;
        y: number;
        height: number;
    } | null;
    /**
     * Get count of currently rendered selection rectangles.
     *
     * @returns Number of selection rects
     */
    getSelectionCount(): number;
}
