import { FlowBlock } from '../../contracts/src/index.js';
/**
 * Generates a cache key hash from a block's content, incorporating text,
 * formatting, and embedded block data.
 *
 * Text content is preserved verbatim without whitespace normalization. Different
 * whitespace (multiple spaces, tabs, leading/trailing spaces) produces different
 * text measurements and must generate distinct cache keys to prevent incorrect
 * cache hits. See PR #1551 for context on the whitespace normalization bug.
 *
 * For image runs, includes the image source (first 50 chars) and dimensions to ensure
 * cache invalidation when image properties change. This is critical for converted
 * metafiles (WMF/EMF) where placeholder images may have different dimensions than
 * the original, preventing stale cached measurements from being served.
 *
 * @param block - The flow block to generate a hash for
 * @returns A string hash representing the block's run content and formatting
 */
/**
 * Content identity used by the measure cache's key (P8.4: also the adoption
 * key for previous-pass measures when block ids churn). Measures are a pure
 * function of (content, constraints, font signature); this hash IS the
 * content component of that key, so adopting a previous measure on hash
 * equality is exactly as sound as a cache hit.
 */
export declare const hashMeasureContent: (block: FlowBlock) => string;
/**
 * Cache statistics with LRU eviction tracking
 */
export type MeasureCacheStats = {
    hits: number;
    misses: number;
    sets: number;
    invalidations: number;
    clears: number;
    /**
     * Number of entries evicted due to LRU policy
     */
    evictions: number;
    /**
     * Current cache size (number of entries)
     */
    size: number;
    /**
     * Estimated memory usage (bytes)
     */
    memorySizeEstimate: number;
};
declare const preparedMeasureCacheKeyBrand: unique symbol;
export type PreparedMeasureCacheKey = string & {
    readonly [preparedMeasureCacheKeyBrand]: true;
};
/**
 * LRU-enhanced MeasureCache
 *
 * Key improvements:
 * 1. Bounded size: max 10,000 entries
 * 2. LRU eviction: Evicts least recently used when full
 * 3. O(1) access and eviction using Map insertion order
 * 4. Memory usage estimation
 * 5. Eviction statistics
 *
 * Performance characteristics:
 * - get(): O(1) - Map lookup + delete + re-insert for LRU tracking
 * - set(): O(1) - eviction (delete first key) + insert
 * - invalidate(): O(k) - where k = cached variants for the requested block IDs
 * - Memory: Bounded at 10K entries ~= 50-100MB
 */
export declare class MeasureCache<T> {
    private cache;
    private keysByBlockId;
    private blockIdByKey;
    private stats;
    /**
     * Retrieve a cached measure for the given block and dimensions.
     * Returns undefined if the block is null/undefined, lacks an ID, or if no cached value exists.
     *
     * @param block - The flow block to look up (may be null/undefined)
     * @param width - The width dimension for cache key
     * @param height - The height dimension for cache key
     * @returns The cached value or undefined
     */
    get(block: FlowBlock | null | undefined, width: number, height: number, fontSignature?: string): T | undefined;
    /**
     * Compose the complete content, constraint, and font key once for a cache
     * read followed by an insertion in the same measurement transaction.
     */
    prepareKey(block: FlowBlock | null | undefined, width: number, height: number, fontSignature?: string): PreparedMeasureCacheKey | undefined;
    getPrepared(key: PreparedMeasureCacheKey | undefined): T | undefined;
    /**
     * Store a measure in the cache for the given block and dimensions.
     * Silently returns if the block is null/undefined or lacks an ID.
     *
     * @param block - The flow block to cache (may be null/undefined)
     * @param width - The width dimension for cache key
     * @param height - The height dimension for cache key
     * @param value - The value to cache
     */
    set(block: FlowBlock | null | undefined, width: number, height: number, value: T, fontSignature?: string): void;
    setPrepared(key: PreparedMeasureCacheKey | undefined, blockId: string | undefined, value: T): void;
    /**
     * Invalidates cached measurements for specific block IDs.
     * Removes all cache entries whose keys start with any of the provided block IDs.
     *
     * @param blockIds - Array of block IDs to invalidate from the cache
     *
     * @example
     * ```typescript
     * cache.invalidate(['block-123', 'block-456']);
     * ```
     */
    invalidate(blockIds: string[]): void;
    /**
     * Clears all cached measurements and resets statistics.
     * Use when performing a full document re-layout.
     */
    clear(): void;
    /**
     * Resets cache statistics (hits, misses, sets) to zero.
     * Does not clear cached values.
     */
    resetStats(): void;
    /**
     * Returns current cache performance statistics.
     * Useful for monitoring cache effectiveness.
     *
     * @returns Object containing hits, misses, sets, and hit rate
     */
    getStats(): MeasureCacheStats;
    /**
     * Get current cache size (number of entries)
     */
    getSize(): number;
    /**
     * Get maximum cache size
     */
    getMaxSize(): number;
    /**
     * Check if cache is near capacity
     */
    isNearCapacity(threshold?: number): boolean;
    /**
     * Update size statistics
     */
    private updateSizeStats;
    private deleteKey;
    /**
     * Composes a cache key from block properties and dimensions.
     * Validates and clamps dimensions to prevent memory exhaustion.
     *
     * @param block - The flow block to create a key for
     * @param width - Width dimension (will be clamped to [0, MAX_DIMENSION])
     * @param height - Height dimension (will be clamped to [0, MAX_DIMENSION])
     * @returns Cache key string
     */
    private composeKey;
}
export {};
