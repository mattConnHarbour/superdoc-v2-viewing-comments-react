import { FlowBlock, SectionMetadata } from '../../contracts/src/index.js';
import { HeaderFooterConstraints } from '../../layout-engine/src/index.js';
import { MeasureCache } from './cache.js';
import { HeaderFooterLayoutCache } from './layoutHeaderFooter.js';
/**
 * Computes a hash for header/footer block content.
 * Used to detect when header/footer content has changed.
 *
 * @param blocks - Header/footer blocks
 * @returns Content hash string
 */
export declare function computeHeaderFooterContentHash(blocks: FlowBlock[]): string;
/**
 * Computes a hash for section metadata.
 * Used to detect when section numbering or properties have changed.
 *
 * @param sections - Section metadata array
 * @returns Metadata hash string
 */
export declare function computeSectionMetadataHash(sections: SectionMetadata[]): string;
/**
 * Computes a hash for header/footer constraints.
 * Used to detect when layout constraints have changed.
 *
 * @param constraints - Header/footer constraints
 * @returns Constraints hash string
 */
export declare function computeConstraintsHash(constraints: HeaderFooterConstraints): string;
/**
 * Cache state tracker for header/footer layouts.
 * Stores hashes of content, constraints, and metadata to detect changes.
 */
export declare class HeaderFooterCacheState {
    private contentHashes;
    private constraintsHash;
    private sectionMetadataHash;
    /**
     * Checks if header/footer content has changed for a variant.
     *
     * @param variantKey - Unique key for the variant (e.g., 'header-default')
     * @param blocks - Current blocks for the variant
     * @returns True if content has changed
     */
    hasContentChanged(variantKey: string, blocks: FlowBlock[]): boolean;
    /**
     * Checks if constraints have changed.
     *
     * @param constraints - Current constraints
     * @returns True if constraints have changed
     */
    hasConstraintsChanged(constraints: HeaderFooterConstraints): boolean;
    /**
     * Checks if section metadata has changed.
     *
     * @param sections - Current section metadata
     * @returns True if metadata has changed
     */
    hasSectionMetadataChanged(sections: SectionMetadata[]): boolean;
    /**
     * Resets all cached state.
     * Called when performing a full cache clear.
     */
    reset(): void;
}
/**
 * Invalidates header/footer cache based on change detection.
 *
 * This function checks what has changed (content, constraints, metadata) and
 * invalidates the appropriate cache entries. It uses the cache state tracker
 * to detect changes between layout runs.
 *
 * @param cache - Header/footer layout cache
 * @param cacheState - Cache state tracker
 * @param headerBlocks - Current header blocks (optional)
 * @param footerBlocks - Current footer blocks (optional)
 * @param constraints - Current constraints
 * @param sections - Current section metadata
 *
 * @example
 * ```typescript
 * invalidateHeaderFooterCache(
 *   cache,
 *   cacheState,
 *   headerBlocks,
 *   footerBlocks,
 *   constraints,
 *   sections
 * );
 * ```
 */
export declare function invalidateHeaderFooterCache(cache: HeaderFooterLayoutCache, cacheState: HeaderFooterCacheState, headerBlocks?: {
    default?: FlowBlock[];
    first?: FlowBlock[];
    even?: FlowBlock[];
    odd?: FlowBlock[];
}, footerBlocks?: {
    default?: FlowBlock[];
    first?: FlowBlock[];
    even?: FlowBlock[];
    odd?: FlowBlock[];
}, constraints?: HeaderFooterConstraints, sections?: SectionMetadata[]): void;
/**
 * Invalidates body measure cache for blocks affected by token resolution.
 *
 * This should be called after page token resolution to ensure re-measurement
 * of blocks with resolved tokens.
 *
 * @param cache - Body measure cache
 * @param affectedBlockIds - Set of block IDs affected by token resolution
 *
 * @example
 * ```typescript
 * const result = resolvePageNumberTokens(layout, blocks, measures, numberingCtx);
 * invalidateBodyMeasureCache(measureCache, result.affectedBlockIds);
 * ```
 */
export declare function invalidateBodyMeasureCache<T>(cache: MeasureCache<T>, affectedBlockIds: Set<string>): void;
