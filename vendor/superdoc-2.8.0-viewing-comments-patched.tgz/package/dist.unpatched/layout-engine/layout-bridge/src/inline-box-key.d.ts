import { InlineBoxSpan } from '../../contracts/src/index.js';
/** Shared inline-box identity for measure-cache and dirty-region decisions. */
export declare const inlineBoxKey: (box: InlineBoxSpan) => string;
