import { NeutralTextDirection } from '../../contracts/src/index.js';
/**
 * Whether a measured line's visible text mixes content that breaks the
 * single-level RTL reverse mapping.
 *
 * Returns `true` (→ caller fails closed with `unsupported-complex-bidi`) when
 * the text contains either:
 *   - any Unicode number (a weak-direction numeric run that the UBA can render
 *     as a contiguous number, not where a pure reverse would place it), or
 *   - a strong-LTR letter (any Unicode letter outside the strong-RTL ranges).
 *
 * Pure Hebrew/Arabic text with neutral punctuation, spaces, and RTL marks
 * returns `false` and is safe to mirror. Conservative by design: when in doubt
 * the caller fails closed rather than emit a mirrored-twice caret.
 */
export declare function lineHasComplexBidiContent(text: string): boolean;
/**
 * Container-space x for a logical advance (px measured from the logical line
 * start, as returned by `measureCharacterX(..., 'left')`).
 *
 * LTR: `contentLeft + advance`. RTL: mirrored about the content box so the
 * logical start sits at the visual right edge.
 */
export declare function logicalAdvanceToContainerX(direction: NeutralTextDirection, contentLeft: number, contentWidth: number, advance: number): number;
/**
 * Logical advance (px from the logical line start, clamped to
 * `[0, contentWidth]`) for a container-space x.
 *
 * The exact inverse of {@link logicalAdvanceToContainerX}: feed the result to
 * `findCharacterAtX(..., 'left')` to recover the logical character offset for
 * either direction. For RTL the visual-left edge maps to the logical end and the
 * visual-right edge maps to the logical start.
 */
export declare function containerXToLogicalAdvance(direction: NeutralTextDirection, contentLeft: number, contentWidth: number, containerX: number): number;
