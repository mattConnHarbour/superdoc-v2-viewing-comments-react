import { FontMetricsCache } from './font-metrics-cache.js';
import { LineInfo } from './paragraph-line-cache.js';
/**
 * Result of local paragraph layout calculation.
 */
export interface LocalLayoutResult {
    /** Array of lines with local offsets */
    lines: LineInfo[];
    /** Total height of all lines in pixels */
    totalHeight: number;
    /** Maximum line width in pixels */
    width: number;
}
/**
 * A text run with formatting information.
 */
export interface TextRun {
    /** Text content of the run */
    text: string;
    /** Font key for this run */
    fontKey: string;
}
/**
 * LocalParagraphLayout calculates line breaks for paragraphs using
 * cached font metrics in a synchronous, fast manner.
 *
 * This is the P0 layout path used when:
 * - Full layout is stale
 * - Need immediate cursor positioning
 * - Progressive enhancement before full layout completes
 *
 * Performance target: <5ms for typical paragraphs
 *
 * Usage:
 * ```typescript
 * const layoutEngine = new LocalParagraphLayout(fontMetricsCache);
 *
 * // Single-format paragraph
 * const result = layoutEngine.layout(text, fontKey, maxWidth);
 *
 * // Multi-format paragraph
 * const runs = [
 *   { text: 'Bold', fontKey: 'Arial|16|bold|normal' },
 *   { text: ' normal', fontKey: 'Arial|16|normal|normal' }
 * ];
 * const result = layoutEngine.layoutRuns(runs, maxWidth);
 * ```
 */
export declare class LocalParagraphLayout {
    private fontMetricsCache;
    /**
     * Creates a new LocalParagraphLayout instance.
     *
     * @param fontMetricsCache - Font metrics cache for character width lookup
     */
    constructor(fontMetricsCache: FontMetricsCache);
    /**
     * Calculate line breaks for a paragraph using cached font metrics.
     * This is the P0 (sync, <5ms) layout path.
     *
     * Uses greedy line breaking: add words until line width exceeds maxWidth,
     * then break to next line.
     *
     * @param text - Paragraph text content
     * @param fontKey - Font key for the entire paragraph
     * @param maxWidth - Maximum line width in pixels
     * @returns Layout result with line information
     */
    layout(text: string, fontKey: string, maxWidth: number): LocalLayoutResult;
    /**
     * Layout a paragraph with mixed formatting (multiple text runs).
     *
     * Each run can have different font properties. Line breaks are calculated
     * considering the varying character widths across runs.
     *
     * @param runs - Array of text runs with formatting
     * @param maxWidth - Maximum line width in pixels
     * @returns Layout result with line information
     */
    layoutRuns(runs: TextRun[], maxWidth: number): LocalLayoutResult;
    /**
     * Estimate paragraph height without full layout.
     *
     * Uses average character width and line height to quickly estimate
     * how tall a paragraph will be. Useful for scroll calculations.
     *
     * @param textLength - Number of characters in paragraph
     * @param fontKey - Font key for the paragraph
     * @param maxWidth - Maximum line width in pixels
     * @returns Estimated height in pixels
     */
    estimateHeight(textLength: number, fontKey: string, maxWidth: number): number;
}
