/**
 * Debounced Pass Manager
 *
 * Manages debouncing of expensive update passes during document editing to improve
 * typing performance. Allows deferring non-critical operations until typing pauses.
 *
 * Debouncing Strategy:
 * 1. Register expensive passes with delays and priorities
 * 2. Trigger passes during edits (starts/resets debounce timers)
 * 3. Execute passes only after debounce delay expires
 * 4. Cancel pending passes when needed
 *
 * Common Debounced Passes:
 * - Header/footer updates (500ms)
 * - List renumbering (100ms)
 * - Cross-reference updates (2000ms)
 * - Page number updates (500ms)
 * - Footnote layout (200ms)
 *
 * @module debounced-passes
 */
/**
 * Configuration for a debounced pass.
 */
export interface DebouncedPass {
    /** Unique identifier for this pass */
    id: string;
    /** Debounce delay in milliseconds */
    delay: number;
    /** Priority for execution ordering (higher = earlier) */
    priority: number;
    /** Function to execute when debounce expires */
    execute: () => void | Promise<void>;
}
/**
 * DebouncedPassManager coordinates the execution of expensive layout passes
 * by debouncing them during typing bursts.
 *
 * This ensures a responsive typing experience while still updating document
 * features like headers, footers, and cross-references once editing pauses.
 */
export declare class DebouncedPassManager {
    private passes;
    private timers;
    private pendingExecutions;
    /**
     * Register a debounced pass.
     *
     * @param pass - Pass configuration
     */
    register(pass: DebouncedPass): void;
    /**
     * Trigger a pass, starting or resetting its debounce timer.
     *
     * Example debounce delays:
     * - Header/footer updates: 500ms
     * - List renumbering: 100ms
     * - Cross-reference updates: 2000ms
     * - Page number updates: 500ms
     * - Footnote layout: 200ms
     *
     * @param passId - ID of the pass to trigger
     */
    trigger(passId: string): void;
    /**
     * Cancel a pending pass execution.
     *
     * @param passId - ID of the pass to cancel
     */
    cancel(passId: string): void;
    /**
     * Cancel all pending pass executions.
     */
    cancelAll(): void;
    /**
     * Check if a specific pass is currently pending.
     *
     * @param passId - ID of the pass to check
     * @returns True if the pass is pending execution
     */
    isPending(passId: string): boolean;
    /**
     * Get the number of pending pass executions.
     *
     * @returns Count of passes waiting to execute
     */
    getPendingCount(): number;
    /**
     * Execute a pass immediately.
     * Clears the timer and pending state.
     *
     * @param passId - ID of the pass to execute
     * @private
     */
    private executePass;
    /**
     * Unregister a pass.
     *
     * @param passId - ID of the pass to unregister
     */
    unregister(passId: string): void;
    /**
     * Get all registered pass IDs.
     *
     * @returns Array of registered pass IDs
     */
    getRegisteredPasses(): string[];
    /**
     * Clear all registrations and timers.
     */
    clear(): void;
    /**
     * Get pass configuration for a specific pass.
     *
     * @param passId - ID of the pass
     * @returns Pass configuration if registered, undefined otherwise
     */
    getPass(passId: string): DebouncedPass | undefined;
    /**
     * Trigger all pending passes immediately without waiting for debounce.
     * Useful when forcing a full update (e.g., before saving).
     */
    flushAll(): Promise<void>;
    /**
     * Trigger a specific pass immediately without waiting for debounce.
     *
     * @param passId - ID of the pass to flush
     */
    flush(passId: string): Promise<void>;
}
