/**
 * Paragraph Line Cache
 *
 * Caches line break information for paragraphs to avoid expensive recalculation.
 * Tracks dirty state to know when recalculation is needed after edits.
 *
 * @module paragraph-line-cache
 */
/**
 * Information about a single line within a paragraph.
 */
export interface LineInfo {
    /** Character offset within paragraph where line starts */
    localStart: number;
    /** Character offset within paragraph where line ends (exclusive) */
    localEnd: number;
    /** Width of the line in pixels */
    width: number;
    /** Height of the line in pixels */
    height: number;
}
/**
 * Cached line break information for a paragraph.
 */
export interface ParagraphLines {
    /** PM document version when these lines were calculated */
    version: number;
    /** Array of lines in this paragraph */
    lines: LineInfo[];
    /** Total height of all lines */
    totalHeight: number;
    /** Whether this cache entry needs recalculation */
    dirty: boolean;
}
/**
 * ParagraphLineCache stores line break information for paragraphs.
 *
 * This cache is essential for performance when calculating cursor positions
 * within multi-line paragraphs, as it avoids re-measuring line breaks.
 */
export declare class ParagraphLineCache {
    private cache;
    /**
     * Gets cached lines for a paragraph.
     *
     * @param paragraphIndex - Index of the paragraph
     * @returns Cached lines if available, undefined otherwise
     */
    getLines(paragraphIndex: number): ParagraphLines | undefined;
    /**
     * Sets lines for a paragraph.
     *
     * @param paragraphIndex - Index of the paragraph
     * @param lines - Line information to cache
     */
    setLines(paragraphIndex: number, lines: ParagraphLines): void;
    /**
     * Marks a paragraph as dirty (needs recalculation).
     *
     * @param paragraphIndex - Index of the paragraph to mark dirty
     */
    markDirty(paragraphIndex: number): void;
    /**
     * Marks all paragraphs starting from a specific index as dirty.
     *
     * This is useful when a change affects multiple paragraphs.
     *
     * @param startIndex - First paragraph index to mark dirty
     */
    markDirtyFrom(startIndex: number): void;
    /**
     * Marks all paragraphs in a range as dirty.
     *
     * @param startIndex - First paragraph index to mark dirty (inclusive)
     * @param endIndex - Last paragraph index to mark dirty (exclusive)
     */
    markDirtyRange(startIndex: number, endIndex: number): void;
    /**
     * Checks if a paragraph needs recalculation.
     *
     * @param paragraphIndex - Index of the paragraph to check
     * @returns True if the paragraph is dirty or not cached
     */
    isDirty(paragraphIndex: number): boolean;
    /**
     * Finds the line containing a local character offset within a paragraph.
     *
     * @param paragraphIndex - Index of the paragraph
     * @param localOffset - Character offset within the paragraph
     * @returns Line info if found, null otherwise
     */
    findLineContaining(paragraphIndex: number, localOffset: number): LineInfo | null;
    /**
     * Gets the line index containing a local character offset.
     *
     * @param paragraphIndex - Index of the paragraph
     * @param localOffset - Character offset within the paragraph
     * @returns Line index if found, -1 otherwise
     */
    findLineIndex(paragraphIndex: number, localOffset: number): number;
    /**
     * Removes a paragraph from the cache.
     *
     * @param paragraphIndex - Index of the paragraph to remove
     */
    remove(paragraphIndex: number): void;
    /**
     * Clears the entire cache.
     */
    clear(): void;
    /**
     * Gets the number of cached paragraphs.
     */
    get size(): number;
    /**
     * Checks if a paragraph is cached.
     *
     * @param paragraphIndex - Index of the paragraph to check
     * @returns True if the paragraph has cached lines
     */
    has(paragraphIndex: number): boolean;
    /**
     * Gets all cached paragraph indices.
     *
     * @returns Array of paragraph indices that are cached
     */
    getCachedIndices(): number[];
    /**
     * Gets cache statistics for debugging.
     *
     * @returns Statistics about the cache
     */
    getStats(): {
        total: number;
        dirty: number;
        clean: number;
    };
    /**
     * Validates cache entries for a specific version.
     * Marks entries with mismatched versions as dirty.
     *
     * @param currentVersion - Current PM document version
     * @returns Number of entries marked dirty
     */
    validateVersion(currentVersion: number): number;
    /**
     * Prunes dirty entries from the cache to free memory.
     *
     * @returns Number of entries removed
     */
    pruneDirty(): number;
}
