import { FlowBlock, HeaderFooterLayout, Measure, PageNumberChapterSeparator, PageNumberFormat, ParagraphBlock, ParagraphLineRegion, ParagraphMeasure } from '../../contracts/src/index.js';
import { HeaderFooterConstraints, LayoutExecutionCheckpoint, LayoutExecutionControl } from '../../layout-engine/src/index.js';
import { MeasureCache } from './cache.js';
import { ResolveHeaderFooterTokensOptions } from './resolveHeaderFooterTokens.js';
export type HeaderFooterBatch = Partial<Record<'default' | 'first' | 'even' | 'odd', FlowBlock[]>>;
export type MeasureResolver = (block: FlowBlock, constraints: {
    maxWidth: number;
    maxHeight: number;
}) => Promise<Measure>;
export type HeaderFooterBatchResult = Partial<Record<'default' | 'first' | 'even' | 'odd', {
    blocks: FlowBlock[];
    measures: Measure[];
    layout: HeaderFooterLayout;
}>>;
/**
 * Page resolver callback for header/footer token resolution.
 * Provides display page information for a specific physical page number.
 *
 * @param pageNumber - Physical page number (1-indexed)
 * @returns Display page information including formatted text and total pages
 */
export type PageResolver = (pageNumber: number) => {
    displayText: string;
    displayNumber?: number;
    totalPages: number;
    sectionPageCount?: number;
    pageFormat?: PageNumberFormat;
    chapterNumberText?: string;
    chapterSeparator?: PageNumberChapterSeparator;
};
/** Optional cooperative execution hooks for browser-owned furniture builds. */
export interface HeaderFooterLayoutExecution extends LayoutExecutionControl {
    /** Time-aware mounted probe. Null is the allocation-free under-budget path. */
    checkpointIfDue?: (checkpoint?: LayoutExecutionCheckpoint) => Promise<void> | null;
    /** Exact physical pages whose PAGE contexts are missing from a retained layout entry. */
    pageNumbers?: readonly number[];
}
/**
 * Digit bucket for page number caching strategy.
 * Different digit lengths require different measurements due to width changes.
 */
export type DigitBucket = 'd1' | 'd2' | 'd3' | 'd4';
/**
 * Determines the digit bucket for a given page number.
 *
 * Bucket strategy:
 * - d1: 1-9 (single digit)
 * - d2: 10-99 (two digits)
 * - d3: 100-999 (three digits)
 * - d4: 1000+ (four or more digits)
 *
 * This bucketing allows us to cache header/footer layouts by digit width,
 * reducing the number of unique layouts we need to measure and store.
 *
 * @param pageNumber - Page number to bucket (1-indexed)
 * @returns Digit bucket identifier
 *
 * @example
 * ```typescript
 * getBucketForPageNumber(5);    // 'd1'
 * getBucketForPageNumber(42);   // 'd2'
 * getBucketForPageNumber(123);  // 'd3'
 * getBucketForPageNumber(1000); // 'd4'
 * ```
 */
export declare function getBucketForPageNumber(pageNumber: number): DigitBucket;
/**
 * Gets a representative page number for a digit bucket.
 *
 * The representative page is used for measurement and layout.
 * We choose mid-range values to get realistic measurements:
 * - d1: 5 (middle of 1-9)
 * - d2: 50 (middle of 10-99)
 * - d3: 500 (middle of 100-999)
 * - d4: 5000 (representative of 1000+)
 *
 * @param bucket - Digit bucket identifier
 * @returns Representative page number for the bucket
 *
 * @example
 * ```typescript
 * getBucketRepresentative('d1'); // 5
 * getBucketRepresentative('d2'); // 50
 * getBucketRepresentative('d3'); // 500
 * ```
 */
export declare function getBucketRepresentative(bucket: DigitBucket): number;
export declare class HeaderFooterLayoutCache {
    private readonly cache;
    /** Drop every cached header/footer measure (equivalence-oracle cold start). */
    clear(): void;
    measureBlocks(blocks: FlowBlock[], constraints: {
        width: number;
        height: number;
    }, measureBlock: MeasureResolver, fontSignature?: string, execution?: LayoutExecutionControl): Promise<Measure[]>;
    invalidate(blockIds: string[]): void;
    /**
     * Gets cache statistics for monitoring and debugging.
     *
     * @returns Cache statistics object
     */
    getStats(): ReturnType<MeasureCache<Measure>['getStats']>;
}
/** Invalidate header/footer measure cache entries for the given block IDs. */
export declare function invalidateHeaderFooterMeasureCache(blockIds: string[]): void;
/**
 * Layouts header/footer variants with intelligent caching and page number resolution.
 *
 * Features:
 * - Resolves page tokens using section-aware display page numbers
 * - Uses digit bucketing to optimize caching for large documents
 * - Clones blocks per page/bucket to avoid mutating shared source data
 * - Produces HeaderFooterLayout with per-page fragments
 *
 * Key behaviors:
 * 1. If no pageResolver provided: falls back to simple single-page layout (backward compatibility)
 * 2. If variant has no tokens: creates one layout reused across all pages (fast path)
 * 3. For small docs (<100 pages): creates per-page layouts
 * 4. For large docs (>=100 pages): uses digit bucketing (d1, d2, d3, d4)
 *    unless PAGE tokens use non-decimal field formatting
 *
 * @param sections - Header/footer variants (default, first, even, odd)
 * @param constraints - Layout constraints (width, height, margins)
 * @param measureBlock - Function to measure individual blocks
 * @param cache - Measurement cache instance (optional, uses shared cache by default)
 * @param totalPages - Total page count for backward compatibility (deprecated, use pageResolver)
 * @param pageResolver - Callback to resolve display page info for a physical page number
 * @returns Batch result with layouts, blocks, and measures for each variant
 */
export declare function layoutHeaderFooterWithCache(sections: HeaderFooterBatch, constraints: HeaderFooterConstraints, measureBlock: MeasureResolver, cache?: HeaderFooterLayoutCache, totalPages?: number, pageResolver?: PageResolver, kind?: 'header' | 'footer', fontSignature?: string, remeasureParagraph?: (block: ParagraphBlock, maxWidth: number, firstLineIndent?: number, lineRegions?: readonly (readonly ParagraphLineRegion[])[]) => ParagraphMeasure, options?: ResolveHeaderFooterTokensOptions, execution?: HeaderFooterLayoutExecution): Promise<HeaderFooterBatchResult>;
