import { HeaderFooterType, Layout, SectionMetadata, Page, HeaderFooterResolutionSection } from '../../contracts/src/index.js';
export type HeaderFooterIdentifier = {
    headerIds: Record<'default' | 'first' | 'even' | 'odd', string | null>;
    footerIds: Record<'default' | 'first' | 'even' | 'odd', string | null>;
    titlePg: boolean;
    alternateHeaders: boolean;
};
export declare const defaultHeaderFooterIdentifier: () => HeaderFooterIdentifier;
export type ConverterLike = {
    headerIds?: {
        default?: string | null;
        first?: string | null;
        even?: string | null;
        odd?: string | null;
        titlePg?: boolean;
    };
    footerIds?: {
        default?: string | null;
        first?: string | null;
        even?: string | null;
        odd?: string | null;
        titlePg?: boolean;
    };
    pageStyles?: {
        alternateHeaders?: boolean;
    };
};
export declare const extractIdentifierFromConverter: (converter?: ConverterLike | null) => HeaderFooterIdentifier;
export declare const getHeaderFooterType: (pageNumber: number, identifier: HeaderFooterIdentifier, options?: {
    kind?: "header" | "footer";
    parityPageNumber?: number;
}) => HeaderFooterType | null;
export declare const resolveHeaderFooterForPage: (layout: Layout, pageIndex: number, identifier: HeaderFooterIdentifier, options?: {
    kind?: "header" | "footer";
    parityPageNumber?: number;
}) => {
    type: HeaderFooterType;
    layout: import('../../contracts/src/index.js').HeaderFooterLayout;
    page: import('../../contracts/src/index.js').HeaderFooterPage;
} | null;
/**
 * Type for per-section header/footer ID mappings.
 * Maps variant types (default, first, even, odd) to their content IDs.
 */
export type SectionHeaderFooterIds = Record<'default' | 'first' | 'even' | 'odd', string | null>;
/**
 * Extended identifier that supports per-section header/footer mappings.
 * Backward compatible with single-section documents via legacy fields.
 */
export type MultiSectionHeaderFooterIdentifier = {
    headerIds: SectionHeaderFooterIds;
    footerIds: SectionHeaderFooterIds;
    titlePg: boolean;
    alternateHeaders: boolean;
    sectionCount: number;
    sectionHeaderIds: Map<number, SectionHeaderFooterIds>;
    sectionFooterIds: Map<number, SectionHeaderFooterIds>;
    sectionTitlePg: Map<number, boolean>;
    sections: HeaderFooterResolutionSection[];
};
/**
 * Creates an empty multi-section identifier with default values.
 */
export declare const defaultMultiSectionIdentifier: () => MultiSectionHeaderFooterIdentifier;
/**
 * Builds a multi-section header/footer identifier from section metadata.
 *
 * This function creates mappings from section indices to their header/footer
 * content IDs. It also maintains backward-compatible legacy fields populated
 * from section 0 (or the first available section).
 *
 * @param sectionMetadata - Array of section metadata from layout options
 * @param pageStyles - Optional page styles containing alternateHeaders flag
 * @param converterIds - Optional converter-provided header/footer IDs to use as fallbacks
 *   for dynamically created headers/footers. These IDs are only used when the corresponding
 *   section metadata value is null. Existing section metadata always takes precedence.
 * @returns MultiSectionHeaderFooterIdentifier with per-section mappings
 *
 * @example
 * ```typescript
 * const sections = [
 *   { sectionIndex: 0, headerRefs: { default: 'rId1' }, footerRefs: { default: 'rId2' } },
 *   { sectionIndex: 1, headerRefs: { default: 'rId3' }, footerRefs: { default: 'rId4' } },
 * ];
 * const identifier = buildMultiSectionIdentifier(sections);
 * // identifier.sectionHeaderIds.get(0)?.default === 'rId1'
 * // identifier.sectionFooterIds.get(1)?.default === 'rId4'
 * ```
 *
 * @example
 * ```typescript
 * // With converter IDs as fallbacks
 * const sections = [
 *   { sectionIndex: 0, headerRefs: { default: null }, footerRefs: { default: null } },
 * ];
 * const converterIds = {
 *   headerIds: { default: 'conv-header-1' },
 *   footerIds: { default: 'conv-footer-1' },
 * };
 * const identifier = buildMultiSectionIdentifier(sections, undefined, converterIds);
 * // identifier.headerIds.default === 'conv-header-1' (from converter fallback)
 * ```
 */
export declare function buildMultiSectionIdentifier(sectionMetadata: SectionMetadata[], pageStyles?: {
    alternateHeaders?: boolean;
}, converterIds?: {
    headerIds?: {
        default?: string | null;
        first?: string | null;
        even?: string | null;
        odd?: string | null;
        titlePg?: boolean;
    };
    footerIds?: {
        default?: string | null;
        first?: string | null;
        even?: string | null;
        odd?: string | null;
        titlePg?: boolean;
    };
}): MultiSectionHeaderFooterIdentifier;
/**
 * Gets the header/footer variant type for a specific page within a section.
 *
 * This function determines which header/footer variant (default, first, even, odd)
 * should be used for a given page number within a specific section. It respects:
 * - Per-section titlePg (first page of section uses 'first' variant)
 * - Alternate headers (even/odd pages based on the effective Word page number)
 * - Fallback to default variant
 *
 * **Important**: When `titlePg` is enabled, this function returns 'first' even if the
 * section doesn't explicitly define a 'first' header/footer. This supports Word's
 * inheritance behavior where sections inherit header/footer definitions from previous
 * sections. The rendering layer is responsible for resolving the actual content ID
 * through inheritance fallback logic.
 *
 * @param pageNumber - Effective Word page number (1-indexed), after section page numbering settings
 * @param sectionIndex - Index of the section this page belongs to
 * @param identifier - Multi-section identifier with per-section mappings
 * @param options - Optional settings (kind, sectionPageNumber, parityPageNumber)
 * @returns HeaderFooterType ('default' | 'first' | 'even' | 'odd') or null if no header/footer content exists
 *
 * @example
 * ```typescript
 * // First page of section 1 with titlePg enabled and 'first' header defined
 * const type = getHeaderFooterTypeForSection(1, 1, identifier, { kind: 'header' });
 * // Returns 'first'
 *
 * // First page of section 2 with titlePg enabled but NO 'first' header defined
 * // (section 2 only has 'default' header)
 * const type = getHeaderFooterTypeForSection(2, 1, identifier, { kind: 'header' });
 * // Returns 'first' - rendering layer will inherit from section 1's 'first' header
 * ```
 */
export declare function getHeaderFooterTypeForSection(pageNumber: number, sectionIndex: number, identifier: MultiSectionHeaderFooterIdentifier, options?: {
    kind?: 'header' | 'footer';
    sectionPageNumber?: number;
    parityPageNumber?: number;
}): HeaderFooterType | null;
/**
 * Gets the header/footer content ID for a specific page using its section information.
 *
 * This function reads the page's sectionIndex and sectionRefs to determine
 * the correct content ID for rendering the header or footer. It supports
 * multi-section documents where each section can have different header/footer content.
 *
 * @param page - The Page object containing sectionIndex and sectionRefs
 * @param identifier - Multi-section identifier (can be used for variant resolution)
 * @param options - Optional settings (kind, sectionPageNumber, parityPageNumber)
 * @returns The content ID string, or null if not available
 *
 * @example
 * ```typescript
 * // Page in section 2 with footerRefs.default = 'rId8'
 * const footerId = getHeaderFooterIdForPage(page, identifier, { kind: 'footer' });
 * // Returns 'rId8'
 * ```
 */
export declare function getHeaderFooterIdForPage(page: Page, identifier: MultiSectionHeaderFooterIdentifier, options?: {
    kind?: 'header' | 'footer';
    sectionPageNumber?: number;
    parityPageNumber?: number;
}): string | null;
/**
 * Resolves header/footer layout information for a page using section-aware logic.
 *
 * This is the main entry point for section-aware header/footer resolution.
 * It combines the page's section information with the multi-section identifier
 * to select the correct header/footer content for rendering.
 *
 * @param layout - The complete Layout object with pages and headerFooter slots
 * @param pageIndex - Index of the page in layout.pages array (0-indexed)
 * @param identifier - Multi-section identifier with per-section mappings
 * @param options - Optional settings (kind, parityPageNumber)
 * @returns Resolution result with type, layout slot, page, and section info, or null
 *
 * @example
 * ```typescript
 * const result = resolveHeaderFooterForPageAndSection(layout, 5, identifier, { kind: 'footer' });
 * if (result) {
 *   // result.type: 'default' | 'first' | 'even' | 'odd'
 *   // result.layout: HeaderFooterLayout for this variant
 *   // result.page: HeaderFooterPage with fragments
 *   // result.sectionIndex: Which section this page belongs to
 *   // result.contentId: The rId for the header/footer XML content
 * }
 * ```
 */
export declare function resolveHeaderFooterForPageAndSection(layout: Layout, pageIndex: number, identifier: MultiSectionHeaderFooterIdentifier, options?: {
    kind?: 'header' | 'footer';
    parityPageNumber?: number;
}): {
    type: HeaderFooterType;
    layout: NonNullable<NonNullable<Layout['headerFooter']>[HeaderFooterType]>;
    page: NonNullable<NonNullable<Layout['headerFooter']>[HeaderFooterType]>['pages'][number];
    sectionIndex: number;
    contentId: string | null;
} | null;
