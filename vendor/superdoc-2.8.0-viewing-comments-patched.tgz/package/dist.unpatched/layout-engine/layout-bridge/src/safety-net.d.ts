/**
 * Runtime Safety Net
 *
 * Automatic fallback system that monitors for errors and performance degradation.
 * Triggers fallback to legacy behavior when issues are detected, then attempts
 * recovery after a cooldown period.
 *
 * Fallback Triggers:
 * - Consecutive errors exceeding threshold
 * - Latency exceeding configured budgets
 * - Manual fallback request
 *
 * Recovery Strategy:
 * - Cooldown period after fallback
 * - Automatic recovery attempt
 * - Error count reset on successful operations
 *
 * @module safety-net
 */
/**
 * Reason for triggering fallback to legacy behavior.
 */
export type FallbackReason = 'error' | 'latency' | 'budget_exceeded' | 'manual';
/**
 * Configuration for the safety net system.
 */
export interface SafetyConfig {
    /** Maximum consecutive errors before triggering fallback */
    maxConsecutiveErrors: number;
    /** Maximum layout duration in ms before triggering fallback */
    maxLayoutDuration: number;
    /** Maximum cursor update latency in ms before triggering fallback */
    maxCursorLatency: number;
    /** Cooldown period in ms before attempting recovery */
    cooldownPeriod: number;
}
/**
 * Safety net for automatic fallback and recovery.
 *
 * Monitors system health and triggers fallback when performance degrades
 * or errors accumulate. Attempts recovery after cooldown.
 *
 * @example
 * ```typescript
 * const safety = new SafetyNet({
 *   maxConsecutiveErrors: 3,
 *   maxLayoutDuration: 100,
 *   cooldownPeriod: 5000,
 * });
 *
 * // Set fallback handler
 * safety.setFallbackHandler((reason) => {
 *   console.warn(`Fallback triggered: ${reason}`);
 *   // Disable optimizations
 * });
 *
 * // Record errors
 * try {
 *   performOptimizedLayout();
 *   safety.reset(); // Success - clear error count
 * } catch (err) {
 *   safety.recordError(err);
 *   if (safety.isFallbackActive()) {
 *     // Use legacy code path
 *   }
 * }
 *
 * // Record latency
 * safety.recordLatency('layout', layoutDuration);
 * ```
 */
export declare class SafetyNet {
    private config;
    private errorCount;
    private fallbackActive;
    private fallbackReason;
    private cooldownTimer;
    private onFallback;
    private onRecovery;
    /**
     * Creates a new safety net instance.
     *
     * @param config - Safety configuration
     */
    constructor(config?: Partial<SafetyConfig>);
    /**
     * Records an error occurrence.
     *
     * Increments error count and triggers fallback if threshold exceeded.
     *
     * @param error - Error that occurred
     *
     * @example
     * ```typescript
     * try {
     *   dangerousOperation();
     * } catch (err) {
     *   safety.recordError(err);
     * }
     * ```
     */
    recordError(error: Error): void;
    /**
     * Records a latency measurement.
     *
     * Triggers fallback if latency exceeds configured budget.
     *
     * @param metric - Metric name ('layout' or 'cursor')
     * @param value - Measured latency in ms
     *
     * @example
     * ```typescript
     * const duration = measureLayoutDuration();
     * safety.recordLatency('layout', duration);
     * ```
     */
    recordLatency(metric: string, value: number): void;
    /**
     * Checks if fallback mode is currently active.
     *
     * @returns True if system is in fallback mode
     *
     * @example
     * ```typescript
     * if (safety.isFallbackActive()) {
     *   // Use legacy code path
     * } else {
     *   // Use optimized code path
     * }
     * ```
     */
    isFallbackActive(): boolean;
    /**
     * Gets the reason for current fallback state.
     *
     * @returns Fallback reason, or null if not in fallback
     *
     * @example
     * ```typescript
     * const reason = safety.getFallbackReason();
     * if (reason) {
     *   console.log(`System in fallback due to: ${reason}`);
     * }
     * ```
     */
    getFallbackReason(): FallbackReason | null;
    /**
     * Manually triggers fallback mode.
     *
     * Useful for testing or manual intervention.
     *
     * @param reason - Reason for manual fallback
     *
     * @example
     * ```typescript
     * // Force fallback for testing
     * safety.triggerFallback('manual');
     * ```
     */
    triggerFallback(reason: FallbackReason): void;
    /**
     * Attempts to recover from fallback state.
     *
     * Returns true if recovery successful, false if still in cooldown.
     *
     * @returns True if recovered, false if still in cooldown
     *
     * @example
     * ```typescript
     * if (safety.attemptRecovery()) {
     *   console.log('Recovery successful');
     * }
     * ```
     */
    attemptRecovery(): boolean;
    /**
     * Sets the fallback handler callback.
     *
     * Called when fallback is triggered.
     *
     * @param handler - Callback function to handle fallback
     *
     * @example
     * ```typescript
     * safety.setFallbackHandler((reason) => {
     *   // Disable optimizations and use legacy path
     *   console.warn('Fallback triggered:', reason);
     * });
     * ```
     */
    setFallbackHandler(handler: (reason: FallbackReason) => void): void;
    /**
     * Sets the recovery handler callback.
     *
     * Called when recovery from fallback is attempted.
     *
     * @param handler - Callback function to handle recovery
     *
     * @example
     * ```typescript
     * safety.setRecoveryHandler(() => {
     *   // Re-enable optimizations
     *   console.log('Recovered from fallback');
     * });
     * ```
     */
    setRecoveryHandler(handler: () => void): void;
    /**
     * Resets the error count.
     *
     * Call this after successful operations to prevent false positives.
     *
     * @example
     * ```typescript
     * try {
     *   performLayout();
     *   safety.reset(); // Success - clear errors
     * } catch (err) {
     *   safety.recordError(err);
     * }
     * ```
     */
    reset(): void;
    /**
     * Schedules automatic recovery after cooldown period.
     */
    private scheduleRecovery;
    /**
     * Cleans up timers and resources.
     *
     * Call this when destroying the safety net.
     */
    destroy(): void;
}
