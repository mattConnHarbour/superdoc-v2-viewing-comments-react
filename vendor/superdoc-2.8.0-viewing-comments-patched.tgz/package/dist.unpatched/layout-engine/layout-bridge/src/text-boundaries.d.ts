import { FlowBlock } from '../../contracts/src/index.js';
/**
 * Represents a boundary range with start and end positions
 */
export type BoundaryRange = {
    from: number;
    to: number;
};
/**
 * Find word boundaries around a given position in a block
 * Uses Unicode word boundary detection
 */
export declare function findWordBoundaries(blocks: FlowBlock[], pos: number): BoundaryRange | null;
/**
 * Find paragraph boundaries (entire block) around a given position
 */
export declare function findParagraphBoundaries(blocks: FlowBlock[], pos: number): BoundaryRange | null;
