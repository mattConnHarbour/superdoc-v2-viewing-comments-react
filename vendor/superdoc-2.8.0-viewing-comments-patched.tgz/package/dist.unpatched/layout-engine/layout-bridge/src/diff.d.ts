import { FlowBlock } from '../../contracts/src/index.js';
export type DirtyRegion = {
    firstDirtyIndex: number;
    lastStableIndex: number;
    insertedBlockIds: string[];
    deletedBlockIds: string[];
    /**
     * Existing blocks whose render-relevant content changed. This is distinct
     * from insertion/deletion churn and lets pagination establish the complete
     * affected frontier without guessing from only the first dirty ordinal.
     */
    changedBlockIds: string[];
    stableBlockIds: Set<string>;
};
/**
 * Computes dirty regions between two versions of a document's flow blocks.
 *
 * Identifies which blocks have changed, been added, or removed, and determines
 * the minimal region that needs to be re-laid out. Uses block IDs and tracked
 * change metadata to detect modifications.
 *
 * @param previous - Previous version of flow blocks
 * @param next - New version of flow blocks
 * @returns DirtyRegion describing the extent of changes
 *
 * @example
 * ```typescript
 * const region = computeDirtyRegions(oldBlocks, newBlocks);
 * if (region.isEntireDocument) {
 *   relayoutAll();
 * } else {
 *   relayoutRange(region.firstDirtyIndex, region.lastDirtyIndex);
 * }
 * ```
 */
export declare const computeDirtyRegions: (previous: FlowBlock[], next: FlowBlock[]) => DirtyRegion;
