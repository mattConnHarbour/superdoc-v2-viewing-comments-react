import { FlowBlock, Layout, LayoutStoryLocator, Measure, NeutralSegmentGeometryReadback } from '../../contracts/src/index.js';
import { PageGeometryHelper } from './page-geometry-helper.js';
export type CollectSegmentGeometryOptions = {
    /**
     * Story locator for the layout being read. Defaults to body. Pass the
     * header/footer/footnote/endnote locator when collecting geometry for a
     * non-body story layout so identity stays story-correct.
     */
    story?: LayoutStoryLocator;
    /**
     * Optional `PageGeometryHelper` for page-top lookups. Strongly recommended so
     * vertical geometry matches selection rendering exactly. Falls back to
     * `calculatePageTopFallback` when omitted.
     */
    geometryHelper?: PageGeometryHelper;
    /** Exact page interval/window to read; omitted means every page. */
    pageIndices?: readonly number[];
    /** Bounded page-top lookup used with `pageIndices` without building a whole-document helper cache. */
    pageTopAt?: (pageIndex: number) => number;
};
/**
 * Read editor-neutral measured segment geometry for every paintable fragment in
 * a layout.
 *
 * Body paragraph fragments (including word-layout list paragraphs) resolve to
 * full per-line / per-segment geometry. Fragment kinds whose text geometry this
 * version does not model (tables, inline/anchored images and drawings, and
 * standalone list-item fragments), and lines the substrate cannot place safely
 * (RTL/bidi), are emitted with identity + bounds and a diagnostic, never with a
 * guessed rect.
 */
export declare function collectSegmentGeometry(layout: Layout, blocks: FlowBlock[], measures: Measure[], options?: CollectSegmentGeometryOptions): NeutralSegmentGeometryReadback;
