import { FlowBlock, SectionMetadata, SectionRefType } from '../../contracts/src/index.js';
import { HeaderFooterConstraints } from '../../layout-engine/src/index.js';
export type HeaderFooterSectionKind = 'header' | 'footer';
export type HeaderFooterRefs = Partial<Record<SectionRefType, string>>;
export type SectionAwareHeaderFooterMeasurementGroup = {
    rId: string;
    sectionIndices: Set<number>;
    sectionConstraints: HeaderFooterConstraints;
    effectiveWidth: number;
};
export declare function buildSectionAwareHeaderFooterLayoutKey(rId: string, sectionIndex: number): string;
export declare function buildSectionContentWidth(section: SectionMetadata, fallback: HeaderFooterConstraints): number;
export declare function buildEffectiveHeaderFooterRefsBySection(sectionMetadata: SectionMetadata[], kind: HeaderFooterSectionKind): Map<number, HeaderFooterRefs>;
export declare function collectReferencedHeaderFooterRIds(effectiveRefsBySection: Map<number, HeaderFooterRefs>): Set<string>;
export declare function buildSectionAwareHeaderFooterMeasurementGroups(kind: HeaderFooterSectionKind, blocksByRId: Map<string, FlowBlock[]> | undefined, sectionMetadata: SectionMetadata[], fallbackConstraints: HeaderFooterConstraints): SectionAwareHeaderFooterMeasurementGroup[];
