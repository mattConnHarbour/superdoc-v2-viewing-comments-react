import { FlowBlock, ParagraphBlock, ParagraphMeasure } from '../../contracts/src/index.js';
type TextboxRemeasure = (block: ParagraphBlock, maxWidth: number) => ParagraphMeasure;
/**
 * Derives table-cell textbox measurements without mutating the projection
 * plane supplied by the caller. Only the textbox and its table ancestry are
 * copied; documents without table textboxes retain their original identities.
 */
export declare function hydrateTableTextboxMeasures(blocks: FlowBlock[], remeasure: TextboxRemeasure): FlowBlock[];
export {};
