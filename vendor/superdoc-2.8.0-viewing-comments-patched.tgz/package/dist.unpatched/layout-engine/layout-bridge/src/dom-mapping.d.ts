/**
 * ===================================================================
 * COMPATIBILITY ONLY — DO NOT USE FOR NEW CODE
 * ===================================================================
 *
 * The production implementation of DOM pointer mapping lives with the editor
 * runtime's DOM observer.
 *
 * This file is retained only for backward compatibility with existing
 * layout-bridge consumers. It will be removed in a later cleanup PR.
 *
 * Do NOT import from this file in editor runtime production code.
 * ===================================================================
 *
 * DOM-based click-to-position mapping utilities.
 *
 * This module provides pixel-perfect click-to-position mapping by reading actual
 * DOM elements with data attributes (`data-pm-start`, `data-pm-end`). This approach
 * is more accurate than pure geometry-based mapping because it uses the browser's
 * actual rendering and correctly handles ProseMirror position gaps that may occur
 * after document operations like paragraph joins.
 *
 * @module dom-mapping
 * @deprecated Use the editor runtime's DOM observer mapping instead.
 */
/**
 * Maps a click coordinate to a ProseMirror document position using DOM data attributes.
 *
 * This function provides pixel-perfect accuracy by:
 * 1. Finding the fragment element under the click point using `elementsFromPoint`
 * 2. Finding the line element at the Y coordinate
 * 3. Finding the span (text run) at the X coordinate
 * 4. Using binary search with `document.createRange()` to find the exact character boundary
 *
 * The DOM structure must follow this pattern (as produced by the DOM painter):
 * ```
 * <div class="superdoc-page" data-page-index="0">
 *   <div class="superdoc-fragment" data-block-id="...">
 *     <div class="superdoc-line" data-pm-start="2" data-pm-end="19">
 *       <span data-pm-start="2" data-pm-end="12">text content</span>
 *       <span data-pm-start="14" data-pm-end="19">more text</span>
 *     </div>
 *   </div>
 * </div>
 * ```
 *
 * **Important:** This function correctly handles PM position gaps (e.g., 12→14 in the example
 * above) that can occur after document edits. The geometry-based mapping in `clickToPosition`
 * may produce incorrect positions in these cases, which is why DOM mapping should be preferred
 * when available.
 *
 * **Inline SDT Filtering:** Inline structured content (SDT) wrapper elements are automatically
 * excluded from click-to-position mapping. These wrappers (identified by the class
 * `superdoc-structured-content-inline`) have PM position attributes for selection highlighting,
 * but their child spans provide more accurate character-level positioning for clicks. This
 * ensures the caret is placed at the exact clicked character rather than at wrapper boundaries.
 *
 * @param domContainer - The DOM container element (typically the viewport or page element)
 * @param clientX - X coordinate in viewport space (from MouseEvent.clientX)
 * @param clientY - Y coordinate in viewport space (from MouseEvent.clientY)
 * @returns ProseMirror document position, or null if mapping fails (no DOM data, invalid structure, etc.)
 *
 * @example
 * ```typescript
 * const pos = clickToPositionDom(viewportElement, event.clientX, event.clientY);
 * if (pos !== null) {
 *   editor.setSelection(pos, pos);
 * }
 * ```
 */
export declare function clickToPositionDom(domContainer: HTMLElement, clientX: number, clientY: number): number | null;
/**
 * Finds the page element containing the click coordinates.
 *
 * @param domContainer - The container element to search within
 * @param clientX - X coordinate in viewport space
 * @param clientY - Y coordinate in viewport space
 * @returns The page element, or null if not found
 */
export declare function findPageElement(domContainer: HTMLElement, clientX: number, clientY: number): HTMLElement | null;
