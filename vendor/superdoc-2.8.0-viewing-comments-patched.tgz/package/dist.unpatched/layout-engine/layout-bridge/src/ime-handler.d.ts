/**
 * IME Handler
 *
 * Handles Input Method Editor (IME) composition events for languages that require
 * multi-key input sequences (e.g., Chinese, Japanese, Korean).
 *
 * Strategy:
 * 1. Track composition state (start, update, end)
 * 2. Defer aggressive layout updates during composition
 * 3. Provide composition text for cursor positioning
 * 4. Signal when full layout should resume
 *
 * @module ime-handler
 */
/**
 * IME composition state.
 */
export interface ImeState {
    /** Whether IME composition is currently active */
    active: boolean;
    /** Current composition text */
    text: string;
    /** Selection start within composition */
    start: number;
    /** Selection end within composition */
    end: number;
}
/**
 * ImeHandler manages IME composition events and provides signals for
 * layout debouncing during multi-key input sequences.
 */
export declare class ImeHandler {
    private state;
    private layoutDebounceActive;
    /**
     * Called when composition starts (compositionstart event).
     *
     * @param event - CompositionEvent from browser
     */
    onCompositionStart(event: CompositionEvent): void;
    /**
     * Called when composition updates (compositionupdate event).
     *
     * @param event - CompositionEvent from browser
     */
    onCompositionUpdate(event: CompositionEvent): void;
    /**
     * Called when composition ends (compositionend event).
     *
     * @param event - CompositionEvent from browser
     */
    onCompositionEnd(event: CompositionEvent): void;
    /**
     * Check if IME composition is currently active.
     *
     * @returns True if composition is in progress
     */
    isActive(): boolean;
    /**
     * Get current composition text.
     *
     * @returns Composition text, or empty string if not composing
     */
    getCompositionText(): string;
    /**
     * Should layout be debounced more aggressively during composition?
     *
     * @returns True if layout should be deferred
     */
    shouldDeferLayout(): boolean;
    /**
     * Get full composition state for cursor positioning.
     *
     * @returns Current IME state
     */
    getState(): ImeState;
    /**
     * Manually reset IME state (useful for testing or error recovery).
     */
    reset(): void;
}
