import { FlowBlock, Line, Run } from '../../contracts/src/index.js';
import { FontMeasureContext } from '../../../shared/font-system/src/index.js';
/**
 * Generates a CSS font string from a run's formatting properties.
 *
 * @param run - The text or tab run to generate font string for
 * @returns CSS font string (e.g., "italic bold 16px Arial")
 */
export declare function getRunFontString(run: Run, fontContext?: FontMeasureContext): string;
export declare function measureCharacterX(block: FlowBlock, line: Line, charOffset: number, availableWidthOverride?: number, alignmentOverride?: string, fontContext?: FontMeasureContext): number;
/**
 * Convert a character offset within a line back to a ProseMirror position.
 *
 * This function is the inverse of finding a character offset from a PM position.
 * It accounts for PM position gaps that can occur between runs due to wrapper nodes
 * (e.g., inline formatting marks, link nodes) that don't correspond to visible characters.
 *
 * Algorithm:
 * 1. Iterate through runs in the line, tracking cumulative character offset
 * 2. For each run, determine its character length (accounting for tabs as 1 character)
 * 3. When the target charOffset falls within a run:
 *    - Calculate the offset within that run
 *    - Add to the run's pmStart to get the final PM position
 * 4. If charOffset exceeds all runs, return the last known PM position
 *
 * Edge Cases:
 * - **Character offset beyond line bounds**: Returns the last PM position in the line (clamped to end)
 * - **Negative character offset**: Clamped to 0, returns fallbackPmStart
 * - **Runs with missing PM data**: Falls back to fallbackPmStart + charOffset calculation
 * - **Non-paragraph blocks**: Returns fallbackPmStart + charOffset (simple arithmetic fallback)
 * - **Empty runs**: Skipped during iteration, don't contribute to character count
 * - **Tab runs**: Counted as 1 character regardless of visual width
 *
 * @param block - The paragraph block containing the line
 * @param line - The line to map within
 * @param charOffset - Character offset from start of line (0-based)
 * @param fallbackPmStart - PM position to use when run PM data is missing or invalid
 * @returns ProseMirror position corresponding to the character offset
 *
 * @example
 * ```typescript
 * // Line with runs: "Hello" (PM 0-5) + "World" (PM 7-12), gap at 5-7
 * const block = { kind: 'paragraph', runs: [...] };
 * const line = { fromRun: 0, toRun: 1, ... };
 *
 * // Character 3 maps to PM position 3 (within "Hello")
 * charOffsetToPm(block, line, 3, 0); // returns 3
 *
 * // Character 7 maps to PM position 9 (within "World", accounting for gap)
 * charOffsetToPm(block, line, 7, 0); // returns 9
 * ```
 */
export declare function charOffsetToPm(block: FlowBlock, line: Line, charOffset: number, fallbackPmStart: number): number;
export declare function findCharacterAtX(block: FlowBlock, line: Line, x: number, pmStart: number, availableWidthOverride?: number, alignmentOverride?: string, fontContext?: FontMeasureContext): {
    charOffset: number;
    pmPosition: number;
};
