/**
 * Font Metrics Cache
 *
 * Pre-measures character widths for common fonts using canvas measureText() API.
 * Enables fast character width lookups without repeated DOM operations.
 *
 * Population Strategy:
 * 1. On document load, scan all text runs for unique font combinations
 * 2. For each font, measure full printable ASCII + common Unicode via canvas
 * 3. Cache is persistent for session, keyed by font signature
 *
 * @module font-metrics-cache
 */
/**
 * Metrics for a specific font configuration.
 */
export interface FontMetrics {
    /** Map of character to width in pixels */
    charWidths: Map<string, number>;
    /** Width of space character in pixels */
    spaceWidth: number;
    /** Line height in pixels */
    lineHeight: number;
    /** Baseline offset from top in pixels */
    baseline: number;
    /** Average character width (fallback for unmeasured chars) */
    avgCharWidth: number;
    /** Timestamp when metrics were measured (for cache invalidation) */
    measuredAt: number;
}
/**
 * Configuration for font metrics caching.
 */
export interface FontMetricsCacheConfig {
    /** Font key in format "fontFamily|fontSize|fontWeight|fontStyle" */
    fontKey: string;
}
/**
 * FontMetricsCache provides fast character width lookups by pre-measuring
 * character widths for font configurations using canvas measureText().
 *
 * This cache is essential for performance when calculating cursor positions,
 * as it avoids repeated DOM measurements.
 */
export declare class FontMetricsCache {
    private cache;
    private canvas;
    private ctx;
    /**
     * Creates a new FontMetricsCache instance.
     * Initializes the canvas context for measurements.
     */
    constructor();
    /**
     * Initializes the canvas and context for font measurements.
     *
     * Creates an offscreen 1x1 canvas with 2D rendering context optimized for
     * text measurement. The canvas is never attached to the DOM and is purely
     * used for the canvas.measureText() API.
     *
     * Performance considerations:
     * - Canvas is created once and reused for all measurements
     * - Size is minimal (1x1) as we only need measureText(), not rendering
     * - willReadFrequently hint optimizes for frequent measureText() calls
     *
     * Failure modes:
     * - Not in browser environment (SSR): Sets ctx to null, cache will be disabled
     * - Canvas creation fails: Catches error, sets ctx to null, measurements fall back to defaults
     *
     * Side effects:
     * - Creates this.canvas and this.ctx properties
     * - On failure, cache becomes read-only (getMetrics returns undefined for unmeasured fonts)
     *
     * @private
     */
    private initializeCanvas;
    /**
     * Pre-warms the cache by measuring all characters for the specified fonts.
     *
     * @param fonts - Array of font configurations to pre-measure
     */
    warmCache(fonts: FontMetricsCacheConfig[]): void;
    /**
     * Gets cached metrics for a font key.
     *
     * @param fontKey - Font key in format "fontFamily|fontSize|fontWeight|fontStyle"
     * @returns Font metrics if cached, undefined otherwise
     */
    getMetrics(fontKey: string): FontMetrics | undefined;
    /**
     * Measures a specific character if not already in cache.
     * If the font is not cached, measures the entire font first.
     *
     * @param fontKey - Font key in format "fontFamily|fontSize|fontWeight|fontStyle"
     * @param char - Character to measure
     * @returns Width of the character in pixels
     */
    measureChar(fontKey: string, char: string): number;
    /**
     * Measures all common characters for a font and caches the results.
     *
     * @param fontKey - Font key in format "fontFamily|fontSize|fontWeight|fontStyle"
     * @returns Measured font metrics
     * @private
     */
    private measureFont;
    /**
     * Measures the width of a single character.
     *
     * @param fontKey - Font key in format "fontFamily|fontSize|fontWeight|fontStyle"
     * @param char - Character to measure
     * @returns Width in pixels
     * @private
     */
    private measureCharWidth;
    /**
     * Creates default metrics when canvas is not available.
     *
     * @returns Default font metrics
     * @private
     */
    private createDefaultMetrics;
    /**
     * Generates a font key from font properties.
     *
     * @param family - Font family name
     * @param size - Font size in pixels
     * @param weight - Font weight (e.g., 'normal', 'bold', '400', '700')
     * @param style - Font style (e.g., 'normal', 'italic')
     * @returns Font key string
     */
    static createFontKey(family: string, size: number, weight?: string, style?: string): string;
    /**
     * Parses a font key into its components.
     *
     * @param fontKey - Font key string
     * @returns Font properties
     * @private
     */
    private static parseFontKey;
    /**
     * Clears all cached metrics.
     */
    clear(): void;
    /**
     * Gets the number of cached font configurations.
     */
    get size(): number;
    /**
     * Checks if metrics exist for a font key.
     *
     * @param fontKey - Font key to check
     * @returns True if metrics are cached
     */
    has(fontKey: string): boolean;
    /**
     * Validates fontKey format.
     *
     * @param fontKey - Font key to validate
     * @returns True if fontKey has valid format "family|size|weight|style"
     * @private
     */
    private isValidFontKey;
}
