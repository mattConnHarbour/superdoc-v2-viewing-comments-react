import { Run } from '../../contracts/src/index.js';
/**
 * Builds a deterministic substring for measure-cache keys and dirty-run comparison.
 *
 * Include every run property that affects text measurement or painted output but is not
 * covered elsewhere (e.g. tracked-change / comment keys). When adding a new visual
 * property, update this function only — `cache.ts` and `diff.ts` both depend on it.
 * Paragraph-scoped inline boxes are deliberately keyed by `inline-box-key.ts`,
 * not by this run-scoped helper.
 *
 * @param run - Flow run (text, tab, image, etc.); unknown fields are ignored safely.
 * @returns Stable string encoding bold/italic/underline/strike/color/font/highlight/link.
 */
export declare const hashRunVisualMarks: (run: Run) => string;
