import { FlowBlock } from '../../contracts/src/index.js';
/**
 * Result of PM position validation.
 */
export interface ValidationResult {
    /** Whether validation passed */
    valid: boolean;
    /** Errors found during validation */
    errors: ValidationError[];
    /** Fraction of document covered by valid PM positions (0-1) */
    coverage: number;
}
/**
 * An error in PM position continuity.
 */
export interface ValidationError {
    /** Type of error */
    type: 'gap' | 'overlap' | 'out_of_order' | 'missing';
    /** Index of block where error occurred */
    blockIndex: number;
    /** Expected position range */
    expected: {
        start: number;
        end: number;
    };
    /** Actual position range */
    actual: {
        start: number;
        end: number;
    };
}
/**
 * PmPositionValidator ensures PM position continuity across document blocks.
 */
export declare class PmPositionValidator {
    /**
     * Validate pmStart/pmEnd continuity across all blocks.
     *
     * @param blocks - Array of flow blocks to validate
     * @returns Validation result with errors and coverage info
     */
    validate(blocks: FlowBlock[]): ValidationResult;
    /**
     * Validate a subset of blocks for incremental validation.
     *
     * @param blocks - Array of flow blocks
     * @param startIndex - Starting block index (inclusive)
     * @param endIndex - Ending block index (exclusive)
     * @returns Validation result
     */
    validateRange(blocks: FlowBlock[], startIndex: number, endIndex: number): ValidationResult;
    /**
     * Attempt to repair gaps in pmStart/pmEnd by interpolating missing positions.
     *
     * @param blocks - Array of flow blocks
     * @param errors - Validation errors to repair
     * @returns Repaired blocks (new array, original unmodified)
     */
    repair(blocks: FlowBlock[], errors: ValidationError[]): FlowBlock[];
    /**
     * Get coverage report for complex features.
     *
     * @param blocks - Array of flow blocks
     * @returns Coverage statistics for complex features
     */
    getFeatureCoverage(blocks: FlowBlock[]): {
        trackedChanges: {
            total: number;
            covered: number;
        };
        tables: {
            total: number;
            covered: number;
        };
        embeds: {
            total: number;
            covered: number;
        };
        tokens: {
            total: number;
            covered: number;
        };
    };
    /**
     * Extract pmStart from a block.
     *
     * @param block - Flow block
     * @returns PM start position or undefined
     * @private
     */
    private getBlockPmStart;
    /**
     * Extract pmEnd from a block.
     *
     * @param block - Flow block
     * @returns PM end position or undefined
     * @private
     */
    private getBlockPmEnd;
}
