/**
 * Focus Watchdog
 *
 * Monitors focus stability of the hidden ProseMirror view.
 * The typing performance system relies on the PM view maintaining focus
 * to receive input events. This watchdog detects focus drift and attempts
 * automatic recovery.
 *
 * Features:
 * - Periodic focus checking
 * - Drift detection with configurable threshold
 * - Automatic focus restoration
 * - Drift count tracking for debugging
 * - Event callbacks for drift and recovery
 *
 * @module focus-watchdog
 */
/**
 * Configuration for focus watchdog.
 */
export interface FocusWatchdogConfig {
    /** Interval between focus checks in ms (default: 1000) */
    checkInterval: number;
    /** Trigger recovery after this many drifts (default: 3) */
    maxDriftCount: number;
    /** Called when focus drift is detected */
    onDrift: (target: Element | null) => void;
    /** Called when focus is successfully restored */
    onRecovery: () => void;
}
/**
 * Focus watchdog for monitoring hidden PM view focus.
 *
 * Periodically checks that focus remains on the expected element (hidden PM view).
 * Detects drift and attempts automatic restoration.
 *
 * @example
 * ```typescript
 * const watchdog = new FocusWatchdog({
 *   checkInterval: 1000,
 *   maxDriftCount: 3,
 *   onDrift: (target) => {
 *     console.warn('Focus drifted to:', target);
 *   },
 *   onRecovery: () => {
 *     console.log('Focus restored');
 *   },
 * });
 *
 * // Set the expected focus element
 * watchdog.setExpectedFocus(hiddenPmView.dom);
 *
 * // Start monitoring
 * watchdog.start();
 *
 * // Later: stop monitoring
 * watchdog.stop();
 * ```
 */
export declare class FocusWatchdog {
    private config;
    private expectedFocusElement;
    private driftCount;
    private intervalId;
    private running;
    /**
     * Creates a new focus watchdog.
     *
     * @param config - Watchdog configuration
     */
    constructor(config: FocusWatchdogConfig);
    /**
     * Sets the expected focus element (hidden PM view).
     *
     * This is the element that should maintain focus during typing.
     *
     * @param element - The element that should have focus
     *
     * @example
     * ```typescript
     * watchdog.setExpectedFocus(pmView.dom);
     * ```
     */
    setExpectedFocus(element: HTMLElement): void;
    /**
     * Starts monitoring focus.
     *
     * Begins periodic checks at the configured interval.
     *
     * @example
     * ```typescript
     * watchdog.start();
     * ```
     */
    start(): void;
    /**
     * Stops monitoring focus.
     *
     * Clears the periodic check interval.
     *
     * @example
     * ```typescript
     * watchdog.stop();
     * ```
     */
    stop(): void;
    /**
     * Checks focus immediately.
     *
     * Returns true if focus is on the expected element, false otherwise.
     *
     * @returns True if focus is correct
     *
     * @example
     * ```typescript
     * if (!watchdog.check()) {
     *   console.warn('Focus is not on PM view');
     * }
     * ```
     */
    check(): boolean;
    /**
     * Gets the current drift count.
     *
     * @returns Number of times focus has drifted
     *
     * @example
     * ```typescript
     * const drifts = watchdog.getDriftCount();
     * console.log(`Focus has drifted ${drifts} times`);
     * ```
     */
    getDriftCount(): number;
    /**
     * Resets the drift count.
     *
     * Useful after manual intervention or system restart.
     *
     * @example
     * ```typescript
     * watchdog.resetDriftCount();
     * ```
     */
    resetDriftCount(): void;
    /**
     * Attempts to restore focus to the expected element.
     *
     * @returns True if restoration successful
     *
     * @example
     * ```typescript
     * if (watchdog.restoreFocus()) {
     *   console.log('Focus restored');
     * }
     * ```
     */
    restoreFocus(): boolean;
    /**
     * Handles focus drift detection.
     *
     * @param target - Element that currently has focus
     */
    private handleDrift;
    /**
     * Cleans up resources.
     *
     * Call when destroying the watchdog.
     */
    destroy(): void;
}
