import { ParagraphAttrs, ParagraphBorders, ParagraphBorder, Run, TableBorders, TableBorderValue, CellBorders, BorderSpec } from '../../contracts/src/index.js';
/**
 * Creates a deterministic hash string for a paragraph border.
 * Ensures consistent ordering regardless of JS engine property enumeration.
 *
 * @param border - The paragraph border to hash
 * @returns A deterministic hash string
 */
export declare const hashParagraphBorder: (border: ParagraphBorder) => string;
/**
 * Creates a deterministic hash string for paragraph borders.
 * Hashes all four sides (top, right, bottom, left) in a consistent order.
 *
 * @param borders - The paragraph borders to hash
 * @returns A deterministic hash string
 */
export declare const hashParagraphBorders: (borders: ParagraphBorders) => string;
/**
 * Creates a deterministic hash string for a border spec (used in table/cell borders).
 * Ensures consistent ordering regardless of JS engine property enumeration.
 *
 * @param border - The border spec to hash
 * @returns A deterministic hash string in format "s:style,w:width,c:color,sp:space"
 */
export declare const hashBorderSpec: (border: BorderSpec) => string;
/**
 * Creates a deterministic hash string for a table border value.
 * Handles the three-state value: null (inherit), { none: true } (explicit no border), or BorderSpec.
 *
 * @param borderValue - The table border value to hash
 * @returns A deterministic hash string:
 *   - Empty string for undefined
 *   - "null" for null (inherit from parent)
 *   - "none" for { none: true } (explicit no border)
 *   - Hash string for BorderSpec (e.g., "s:single,w:4,c:000000")
 * @example
 * hashTableBorderValue(undefined) // ""
 * hashTableBorderValue(null) // "null"
 * hashTableBorderValue({ none: true }) // "none"
 * hashTableBorderValue({ style: 'single', width: 4, color: '000000' }) // "s:single,w:4,c:000000"
 */
export declare const hashTableBorderValue: (borderValue: TableBorderValue | undefined) => string;
/**
 * Creates a deterministic hash string for table-level borders.
 * Hashes all six border positions (top, right, bottom, left, insideH, insideV) in a consistent order.
 *
 * @param borders - The table borders to hash
 * @returns A deterministic hash string with format "t:[top];r:[right];b:[bottom];l:[left];ih:[insideH];iv:[insideV]"
 *   where each border value is hashed using hashTableBorderValue. Empty string if borders is undefined.
 * @example
 * hashTableBorders(undefined) // ""
 * hashTableBorders({ top: { style: 'single', width: 4 } }) // "t:[s:single,w:4]"
 */
export declare const hashTableBorders: (borders: TableBorders | undefined) => string;
/**
 * Creates a deterministic hash string for cell-level borders.
 * Hashes all four sides (top, right, bottom, left) in a consistent order.
 *
 * @param borders - The cell borders to hash
 * @returns A deterministic hash string with format "t:[top];r:[right];b:[bottom];l:[left]"
 *   where each border is hashed using hashBorderSpec. Empty string if borders is undefined.
 * @example
 * hashCellBorders(undefined) // ""
 * hashCellBorders({ top: { style: 'single', width: 4, color: '000000' } }) // "t:[s:single,w:4,c:000000]"
 */
export declare const hashCellBorders: (borders: CellBorders | undefined) => string;
/**
 * Creates a deterministic hash string for paragraph-level attributes.
 * This is used for cache invalidation when paragraph formatting changes
 * (alignment, spacing, line height, indent, borders, shading, direction).
 *
 * The hash is deterministic to ensure consistent cache keys across different
 * JS engine property enumeration orders.
 *
 * @param attrs - The paragraph attributes to hash
 * @returns A deterministic hash string representing all paragraph attributes
 */
export declare const hashParagraphAttrs: (attrs: ParagraphAttrs | undefined) => string;
/**
 * Type guard to check if a run has a string property.
 *
 * @param run - The run to check
 * @param prop - The property name to check
 * @returns True if the run has the property and it's a string
 */
export declare const hasStringProp: (run: Run, prop: string) => run is Run & Record<string, string>;
/**
 * Type guard to check if a run has a number property.
 *
 * @param run - The run to check
 * @param prop - The property name to check
 * @returns True if the run has the property and it's a number
 */
export declare const hasNumberProp: (run: Run, prop: string) => run is Run & Record<string, number>;
/**
 * Type guard to check if a run has a boolean property.
 *
 * @param run - The run to check
 * @param prop - The property name to check
 * @returns True if the run has the property and it's a boolean
 */
export declare const hasBooleanProp: (run: Run, prop: string) => run is Run & Record<string, boolean>;
/**
 * Safely gets a string property from a run, with type narrowing.
 *
 * @param run - The run to get the property from
 * @param prop - The property name
 * @returns The string value or empty string if not present
 */
export declare const getRunStringProp: (run: Run, prop: string) => string;
/**
 * Safely gets a number property from a run, with type narrowing.
 *
 * @param run - The run to get the property from
 * @param prop - The property name
 * @returns The number value or 0 if not present
 */
export declare const getRunNumberProp: (run: Run, prop: string) => number;
/**
 * Safely gets a boolean property from a run, with type narrowing.
 *
 * @param run - The run to get the property from
 * @param prop - The property name
 * @returns The boolean value or false if not present
 */
export declare const getRunBooleanProp: (run: Run, prop: string) => boolean;
