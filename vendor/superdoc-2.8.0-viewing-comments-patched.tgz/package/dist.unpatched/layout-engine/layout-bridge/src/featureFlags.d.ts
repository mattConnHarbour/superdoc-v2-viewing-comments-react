/**
 * Feature Flags Module
 *
 * Centralized feature flag configuration for headers/footers page-number parity.
 * All flags are enabled by default but can be toggled via environment variables.
 *
 * Environment variables:
 * - SD_NUMBERING_SECTION_AWARE: Enable section-aware numbering (restarts, formats)
 * - SD_BODY_PAGE_TOKENS: Enable body page token resolution (PAGE/NUMPAGES)
 * - SD_HEADER_FOOTER_PAGE_TOKENS: Enable header/footer page token resolution
 * - SD_HF_DIGIT_BUCKETING: Enable digit bucketing for large documents
 * - SD_DEBUG_PAGE_TOKENS: Enable debug logging for page token resolution
 * - SD_DEBUG_HF_CACHE: Enable debug logging for header/footer cache operations
 * - SD_DEBUG_LAYOUT_VERSION: Enable debug logging for layout version tracking
 *
 * Each flag can be set to:
 * - "true" or "1": Explicitly enabled
 * - "false" or "0": Explicitly disabled
 * - undefined: Use default value (all default to true)
 */
/**
 * Feature flag configuration object.
 * All flags are checked once at module load time for performance.
 */
export declare const FeatureFlags: {
    /**
     * Enable section-aware numbering with restarts and format changes.
     * When disabled, falls back to simple 1-N sequential numbering.
     */
    readonly NUMBERING_SECTION_AWARE: boolean;
    /**
     * Enable body page token resolution (PAGE/NUMPAGES in document content).
     * When disabled, tokens remain as placeholders in body content.
     */
    readonly BODY_PAGE_TOKENS: boolean;
    /**
     * Enable header/footer page token resolution.
     * When disabled, headers/footers use painter-time token rendering fallback.
     */
    readonly HEADER_FOOTER_PAGE_TOKENS: boolean;
    /**
     * Enable digit bucketing for header/footer caching in large documents.
     * When disabled, creates per-page layouts for all documents (no bucketing).
     * Recommended to keep enabled for documents with 100+ pages.
     */
    readonly HF_DIGIT_BUCKETING: boolean;
    /**
     * Enable debug logging for page token resolution.
     * Logs token resolution details, affected blocks, and convergence iteration info.
     * Should be disabled in production (only enabled for debugging).
     */
    readonly DEBUG_PAGE_TOKENS: boolean;
    /**
     * Enable debug logging for header/footer cache operations.
     * Logs cache hits, misses, invalidations, and bucket selection.
     * Should be disabled in production (only enabled for debugging).
     */
    readonly DEBUG_HF_CACHE: boolean;
    /**
     * Enable debug logging for layout version tracking.
     * Logs stale layout reads, geometry fallbacks, PM transactions, and layout completions.
     * Should be disabled in production (only enabled for debugging).
     */
    readonly DEBUG_LAYOUT_VERSION: boolean;
};
/**
 * Type-safe feature flag keys for programmatic access.
 */
export type FeatureFlagKey = keyof typeof FeatureFlags;
/**
 * Checks if a specific feature flag is enabled.
 *
 * @param flag - Feature flag key
 * @returns True if the flag is enabled
 *
 * @example
 * ```typescript
 * if (isFeatureEnabled('BODY_PAGE_TOKENS')) {
 *   // Execute body token resolution
 * }
 * ```
 */
export declare function isFeatureEnabled(flag: FeatureFlagKey): boolean;
/**
 * Gets all feature flag values as an object.
 * Useful for logging and debugging.
 *
 * @returns Object with all feature flag values
 *
 * @example
 * ```typescript
 * console.log('Feature flags:', getAllFeatureFlags());
 * ```
 */
export declare function getAllFeatureFlags(): Record<FeatureFlagKey, boolean>;
