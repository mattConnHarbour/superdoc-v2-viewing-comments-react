import { FlowBlock, PageNumberChapterSeparator, PageNumberFormat } from '../../contracts/src/index.js';
/**
 * Placeholder for a total-page-count field whose source document carries no
 * cached result while pagination is still provisional. An em dash reads as
 * "value not yet known" without committing to a wrong number.
 */
export declare const PROVISIONAL_PAGE_COUNT_PLACEHOLDER = "\u2014";
/**
 * Options for {@link resolveHeaderFooterTokens}.
 */
export interface ResolveHeaderFooterTokensOptions {
    /**
     * When `false`, document-total fields (`NUMPAGES` / `SECTIONPAGES`) are NOT
     * substituted with the supplied totals: the run keeps its source-cached DOCX
     * result text, falling back to {@link PROVISIONAL_PAGE_COUNT_PLACEHOLDER}
     * when no cached result exists. `PAGE` always resolves — the physical page
     * a header/footer paints on is known even under partial pagination.
     * Defaults to `true` (exact totals), preserving existing caller behavior.
     */
    pageCountFieldsExact?: boolean;
}
/**
 * Resolves page number tokens in a batch of header or footer blocks.
 *
 * Headers and footers can contain the same token types as body content
 * (pageNumber, totalPageCount, sectionPageCount), but they need to be resolved to the specific
 * page where the header/footer will appear. This function mutates the blocks
 * in-place to replace token placeholders with actual values.
 *
 * The function processes all variants in the batch (default, first, even, odd),
 * applying the same page context to all. This is correct because a single batch
 * represents headers/footers for one specific page.
 *
 * IMPORTANT: This function modifies blocks in-place. The calling code should
 * ensure that blocks are not shared between multiple page contexts, or should
 * create copies before calling this function.
 *
 * @param blocks - Array of FlowBlocks for a single header/footer variant
 * @param pageNumber - Current page number (1-indexed) where this header/footer appears
 * @param totalPages - Total number of pages in the document
 * @param pageNumberText - Optional preformatted page number string (e.g., "-1-")
 *
 * @example
 * ```typescript
 * // Resolve tokens for the header that will appear on page 3
 * const headerBlocks = adapter.getBlocks('header', 'default');
 * resolveHeaderFooterTokens(headerBlocks, 3, 10);
 * // Now headerBlocks contain "3" instead of "0" for PAGE field
 * // and "10" for NUMPAGES field
 * ```
 */
export declare function resolveHeaderFooterTokens(blocks: FlowBlock[], pageNumber: number, totalPages: number, pageNumberText?: string, displayPageNumber?: number, sectionPageCount?: number, pageNumberFormat?: PageNumberFormat, chapterNumberText?: string, chapterSeparator?: PageNumberChapterSeparator, options?: ResolveHeaderFooterTokensOptions): void;
/**
 * Creates a deep copy of header/footer blocks to avoid mutating shared data.
 *
 * Since token resolution modifies blocks in-place, and the same header/footer
 * content may be used across multiple pages (with different page numbers),
 * we need to create independent copies for each page.
 *
 * This function performs a deep clone of the block structure, including runs
 * and all nested properties, to ensure complete isolation.
 *
 * @param blocks - Original blocks to copy
 * @returns Deep copy of the blocks
 *
 * @example
 * ```typescript
 * const originalBlocks = adapter.getBlocks('header', 'default');
 * const blocksForPage1 = cloneHeaderFooterBlocks(originalBlocks);
 * const blocksForPage2 = cloneHeaderFooterBlocks(originalBlocks);
 * // Now we can resolve tokens differently for each page
 * resolveHeaderFooterTokens(blocksForPage1, 1, 10);
 * resolveHeaderFooterTokens(blocksForPage2, 2, 10);
 * ```
 */
export declare function cloneHeaderFooterBlocks(blocks: FlowBlock[]): FlowBlock[];
