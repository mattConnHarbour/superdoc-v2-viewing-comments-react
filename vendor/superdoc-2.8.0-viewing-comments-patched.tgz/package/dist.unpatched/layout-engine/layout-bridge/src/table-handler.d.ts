/**
 * Table Handler
 *
 * Manages table-specific layout behavior during editing, including
 * column width recalculation debouncing and cell edit tracking.
 *
 * Strategy:
 * 1. Track table states (column widths, row heights)
 * 2. Mark tables dirty on cell edits
 * 3. Debounce column width recalculation
 * 4. Provide table state for incremental layout
 *
 * @module table-handler
 */
/**
 * Layout state for a single table.
 */
export interface TableLayoutState {
    /** Table block index */
    tableIndex: number;
    /** Column widths in pixels */
    columnWidths: number[];
    /** Row heights in pixels */
    rowHeights: number[];
    /** Whether table needs recalculation */
    dirty: boolean;
}
/**
 * TableHandler manages table-specific layout optimizations.
 */
export declare class TableHandler {
    private tableStates;
    private columnRecalcDebounce;
    private recalcTimers;
    /**
     * Handle edit within a table cell.
     *
     * @param tableIndex - Block index of the table
     * @param cellIndex - Index of the edited cell
     */
    onCellEdit(tableIndex: number, _cellIndex: number): void;
    /**
     * Get table state for layout.
     *
     * @param tableIndex - Table block index
     * @returns Table state if exists, undefined otherwise
     */
    getTableState(tableIndex: number): TableLayoutState | undefined;
    /**
     * Mark table columns for recalculation.
     *
     * @param tableIndex - Table block index
     */
    markColumnsDirty(tableIndex: number): void;
    /**
     * Should column width recalculation be deferred?
     *
     * @returns True if recalculation is pending
     */
    shouldDeferColumnRecalc(): boolean;
    /**
     * Update table layout state after recalculation.
     *
     * @param tableIndex - Table block index
     * @param columnWidths - New column widths
     * @param rowHeights - New row heights
     */
    updateTableState(tableIndex: number, columnWidths: number[], rowHeights: number[]): void;
    /**
     * Clear all table states.
     */
    clear(): void;
    /**
     * Get all dirty table indices.
     *
     * @returns Array of table indices needing recalculation
     */
    getDirtyTables(): number[];
    /**
     * Schedule column width recalculation with debouncing.
     *
     * @param tableIndex - Table block index
     * @private
     */
    private scheduleColumnRecalc;
}
