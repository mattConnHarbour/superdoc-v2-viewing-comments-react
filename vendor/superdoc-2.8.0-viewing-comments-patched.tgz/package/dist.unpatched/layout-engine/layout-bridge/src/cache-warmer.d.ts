import { FontMetricsCache } from './font-metrics-cache.js';
import { ParagraphLineCache } from './paragraph-line-cache.js';
/**
 * Configuration for cache warming.
 */
export interface WarmingConfig {
    /** Font keys to pre-warm */
    fonts: string[];
    /** Page indices currently in viewport */
    viewportPages: number[];
    /** Whether to prefetch adjacent pages */
    prefetchAdjacent: boolean;
}
/**
 * Information about a paragraph for cache warming.
 */
export interface ParagraphWarmInfo {
    /** Paragraph block index */
    index: number;
    /** Paragraph text content */
    text: string;
    /** Font key for this paragraph */
    fontKey: string;
    /** Maximum width for line breaking */
    maxWidth: number;
}
/**
 * CacheWarmer proactively populates caches to improve performance.
 */
export declare class CacheWarmer {
    private fontMetricsCache;
    private paragraphLineCache;
    private warmingProgress;
    constructor(fontMetricsCache: FontMetricsCache, paragraphLineCache: ParagraphLineCache);
    /**
     * Warm caches on document load.
     *
     * @param config - Warming configuration
     */
    warmOnLoad(config: WarmingConfig): Promise<void>;
    /**
     * Warm caches for adjacent pages as user scrolls.
     *
     * @param currentPage - Current page index
     */
    warmForScroll(_currentPage: number): void;
    /**
     * Pre-calculate line breaks for visible paragraphs.
     *
     * @param paragraphs - Array of paragraphs to warm
     */
    precalculateLines(paragraphs: ParagraphWarmInfo[]): void;
    /**
     * Get warming progress for UI feedback.
     *
     * @returns Progress statistics
     */
    getProgress(): {
        fontsCached: number;
        paragraphsCached: number;
        total: number;
    };
    /**
     * Reset warming progress counters.
     */
    resetProgress(): void;
    /**
     * Estimate completion percentage.
     *
     * @returns Completion percentage (0-100)
     */
    getCompletionPercentage(): number;
}
