/**
 * Union type representing all supported numbering format types.
 * These formats determine how list markers are displayed.
 */
export type NumberingFormat = 'bullet' | 'decimal' | 'lowerLetter' | 'upperLetter' | 'lowerRoman' | 'upperRoman';
/**
 * Default hanging indent for list items in pixels.
 * This value determines the horizontal offset between the marker and the text content.
 */
export declare const DEFAULT_LIST_HANGING_PX = 18;
/**
 * Gap between the list marker and the text content in pixels.
 * This spacing ensures visual separation between the marker and the paragraph text.
 */
export declare const LIST_MARKER_GAP = 8;
/**
 * Default bullet character used when no specific bullet glyph is provided.
 * The bullet point (•) is the standard Unicode character for unordered lists.
 */
export declare const DEFAULT_BULLET_GLYPH = "\u2022";
