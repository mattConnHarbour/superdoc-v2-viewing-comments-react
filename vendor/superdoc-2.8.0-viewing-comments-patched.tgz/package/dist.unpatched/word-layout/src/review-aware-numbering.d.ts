import { ComputeWordListMarkerResult, WordListMarkerDefinition } from './list-marker.js';
import { NumberingCursor, NumberingManager, NumberingManagerSnapshot } from './numbering-manager.js';
export type ReviewAwareNumberingMembership = 'ordinary' | 'inserted' | 'deleted' | 'malformed';
export type ReviewAwareNumberingStateMode = 'snapshot' | 'cursor';
export interface ReviewAwareWordNumberingDefinition extends WordListMarkerDefinition {
    restartNumberingAfterBreak?: boolean;
}
export type ReviewAwareWordMarkerFact = {
    status: 'resolved';
    result: ComputeWordListMarkerResult;
} | {
    status: 'unresolved';
    reason: 'missingLvlText' | 'malformedMembership';
};
export interface ReviewAwareWordNumberingResult {
    final: ReviewAwareWordMarkerFact | null;
    original: ReviewAwareWordMarkerFact | null;
    redline: ReviewAwareWordMarkerFact;
}
export interface ReviewAwareWordNumberingSnapshot {
    live?: NumberingManagerSnapshot | NumberingCursor;
    original?: NumberingManagerSnapshot | NumberingCursor;
    liveSectionEpoch: number;
    originalSectionEpoch: number;
}
export interface ReviewAwareWordNumberingSequence {
    advance(input: {
        definition: ReviewAwareWordNumberingDefinition;
        paragraphOrdinal: number;
        membership: ReviewAwareNumberingMembership;
    }): ReviewAwareWordNumberingResult;
    advanceSectionBreak(membership: ReviewAwareNumberingMembership): void;
    captureSnapshot(): ReviewAwareWordNumberingSnapshot;
    restoreSnapshot(snapshot: ReviewAwareWordNumberingSnapshot | null): void;
    counterScope(definition: ReviewAwareWordNumberingDefinition, plane: 'live' | 'original'): string;
    retainedState(): readonly [NumberingManager, NumberingManager];
}
export declare function createReviewAwareWordNumberingSequence(options?: {
    stateMode?: ReviewAwareNumberingStateMode;
}): ReviewAwareWordNumberingSequence;
export declare function reviewAwareWordNumberingCounterScope(definition: ReviewAwareWordNumberingDefinition, plane: 'live' | 'original', epochs: Pick<ReviewAwareWordNumberingSnapshot, 'liveSectionEpoch' | 'originalSectionEpoch'>): string;
