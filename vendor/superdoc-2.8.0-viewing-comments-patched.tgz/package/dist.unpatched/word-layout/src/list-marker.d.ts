import { NumberingManager } from './numbering-manager.js';
import { ListRenderingAttrs } from './types.js';
export interface WordListMarkerDefinition {
    /** Concrete numId. */
    numId: number | string;
    /** Abstract numbering id for shared counter scoping. */
    abstractId: number | string;
    /** Level index. */
    ilvl: number;
    /** Resolved level start value (override-aware). */
    start: number;
    /** True if the start value came from `w:lvlOverride/w:startOverride`. */
    startOverridden: boolean;
    /** `w:lvlRestart` value when defined. */
    restart?: number;
    /** Level text template. May be empty when none defined. */
    lvlText?: string;
    /** Effective `w:numFmt/@w:val`. */
    numFmt?: string;
    /** Custom format string when `numFmt === 'custom'`. */
    customFormat?: string;
    /** True when the level carries Word's legal-numbering semantics. */
    isLegal?: boolean;
    /** Effective numbering formats for placeholders that reference each level. */
    levelNumberingFormats?: Array<{
        ilvl: number;
        numFmt?: string;
        customFormat?: string;
    }>;
    /** `w:suff`. Defaults to `tab` when absent. */
    suffix?: string;
    /** `w:lvlJc`. Defaults to `left`. */
    justification?: string;
    /**
     * Effective start settings for ancestor levels `0..ilvl-1`. Registered with
     * `ensureStartSettings` (register-if-absent) before the marker path is
     * computed so first-emitted nested markers fall back to OOXML-defined
     * ancestor starts instead of `1`. Real ancestor counters still win.
     */
    ancestorStartSettings?: Array<{
        ilvl: number;
        start: number;
        restart?: number;
        startOverridden: boolean;
    }>;
}
export interface ComputeWordListMarkerInput {
    /** Resolved marker definition. */
    definition: WordListMarkerDefinition;
    /**
     * Numbering manager instance carrying counter state for this projection.
     * The caller must have already called `setStartSettings(...)` for the
     * paragraph's level (this is typically done up-front per (numId, level)
     * pair when paragraphs are first walked).
     */
    manager: NumberingManager;
    /**
     * Source-order key for this paragraph. Must be monotonically increasing
     * for paragraphs within a projection so the counter manager can detect
     * previous siblings.
     */
    paragraphOrdinal: number;
}
export interface ComputeWordListMarkerResult {
    listRenderingAttrs: ListRenderingAttrs;
    /** Computed numeric counter path. Useful for callers that want it directly. */
    path: number[];
    /** Effective counter value at the requested ilvl. */
    counter: number;
}
/**
 * Compute the marker text, list-rendering attributes, and counter path for
 * one numbered paragraph. Advances the manager state by recording the new
 * counter at the given paragraph ordinal.
 */
export declare function computeWordListMarker(input: ComputeWordListMarkerInput): ComputeWordListMarkerResult;
