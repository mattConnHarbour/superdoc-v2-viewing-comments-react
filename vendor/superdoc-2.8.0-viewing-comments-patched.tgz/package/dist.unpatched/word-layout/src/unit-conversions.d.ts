/**
 * Shared unit conversion helpers (twips, pixels, points).
 *
 * Word stores most layout values in twips (1/20th of a point). We convert
 * to/from CSS pixels to keep the pipeline consistent across DOM, canvas,
 * and PDF renderers.
 */
export declare const TWIPS_PER_INCH = 1440;
export declare const POINTS_PER_INCH = 72;
export declare const PIXELS_PER_INCH = 96;
export declare const TWIPS_PER_POINT = 20;
export declare const POINTS_PER_TWIP: number;
export declare const TWIPS_PER_PIXEL: number;
export declare const PIXELS_PER_TWIP: number;
/**
 * Converts CSS pixels to twips (twentieths of a point).
 *
 * Word documents store most measurements in twips, while web rendering uses pixels.
 * This function performs the conversion with proper rounding to maintain precision.
 * Invalid inputs (null, undefined, NaN, Infinity) return 0.
 *
 * @param px - The value in CSS pixels to convert. May be null or undefined.
 * @returns The equivalent value in twips, or 0 if input is invalid
 *
 * @example
 * ```typescript
 * pixelsToTwips(96);  // 1440 (1 inch = 96px = 1440 twips)
 * pixelsToTwips(24);  // 360
 * pixelsToTwips(null); // 0
 * pixelsToTwips(NaN);  // 0
 * ```
 */
export declare const pixelsToTwips: (px?: number | null) => number;
/**
 * Converts twips (twentieths of a point) to CSS pixels.
 *
 * This is the inverse of pixelsToTwips. Invalid inputs return 0.
 *
 * @param twips - The value in twips to convert. May be null or undefined.
 * @returns The equivalent value in CSS pixels, or 0 if input is invalid
 *
 * @example
 * ```typescript
 * twipsToPixels(1440); // 96 (1 inch)
 * twipsToPixels(720);  // 48 (half inch)
 * twipsToPixels(null); // 0
 * ```
 */
export declare const twipsToPixels: (twips?: number | null) => number;
/**
 * Converts points to twips (twentieths of a point).
 *
 * Points are a standard typographic unit (72 points = 1 inch).
 * This function converts them to twips for Word document storage.
 * Invalid inputs (null, undefined, NaN, Infinity) return 0.
 *
 * @param points - The value in points to convert. May be null or undefined.
 * @returns The equivalent value in twips, or 0 if input is invalid
 *
 * @example
 * ```typescript
 * pointsToTwips(72);   // 1440 (1 inch = 72 points = 1440 twips)
 * pointsToTwips(12);   // 240
 * pointsToTwips(null); // 0
 * ```
 */
export declare const pointsToTwips: (points?: number | null) => number;
/**
 * Converts twips (twentieths of a point) to points.
 *
 * This is the inverse of pointsToTwips. Points are a standard typographic
 * unit where 72 points equals 1 inch. Invalid inputs return 0.
 *
 * @param twips - The value in twips to convert. May be null or undefined.
 * @returns The equivalent value in points, or 0 if input is invalid
 *
 * @example
 * ```typescript
 * twipsToPoints(1440); // 72 (1 inch)
 * twipsToPoints(240);  // 12
 * twipsToPoints(null); // 0
 * ```
 */
export declare const twipsToPoints: (twips?: number | null) => number;
/**
 * Converts half-points to points.
 *
 * Word documents sometimes store measurements in half-points for finer
 * granularity. This function converts them to standard points by dividing by 2.
 * Invalid inputs (null, undefined, NaN, Infinity) return 0.
 *
 * @param halfPoints - The value in half-points to convert. May be null or undefined.
 * @returns The equivalent value in points, or 0 if input is invalid
 *
 * @example
 * ```typescript
 * halfPointsToPoints(24); // 12
 * halfPointsToPoints(5);  // 2.5
 * halfPointsToPoints(null); // 0
 * ```
 */
export declare const halfPointsToPoints: (halfPoints?: number | null) => number;
/**
 * Converts points to half-points.
 *
 * This is the inverse of halfPointsToPoints. Half-points provide finer
 * granularity for measurements in Word documents (2 half-points = 1 point).
 * Invalid inputs (null, undefined, NaN, Infinity) return 0.
 *
 * @param points - The value in points to convert. May be null or undefined.
 * @returns The equivalent value in half-points, or 0 if input is invalid
 *
 * @example
 * ```typescript
 * pointsToHalfPoints(12);   // 24
 * pointsToHalfPoints(2.5);  // 5
 * pointsToHalfPoints(null); // 0
 * ```
 */
export declare const pointsToHalfPoints: (points?: number | null) => number;
