import { SelectionCurrentInput, SelectionInfo } from './selection.types.js';
export type { SelectionCurrentInput, SelectionInfo } from './selection.types.js';
/**
 * Engine-specific adapter for the selection API.
 */
export interface SelectionAdapter {
    /** Read the editor's current selection. */
    current(input: SelectionCurrentInput): SelectionInfo;
}
/**
 * Public selection API exposed on `editor.doc.selection`.
 */
export interface SelectionApi {
    /**
     * Read the editor's current selection as a portable {@link SelectionInfo}.
     *
     * Use to drive custom UIs (toolbars, sidebars, popovers) without
     * reaching into ProseMirror internals. For comment-target construction,
     * pass the resulting `target` directly to `comments.create`.
     */
    current(input?: SelectionCurrentInput): SelectionInfo;
}
export declare function executeSelectionCurrent(adapter: SelectionAdapter, input?: SelectionCurrentInput): SelectionInfo;
