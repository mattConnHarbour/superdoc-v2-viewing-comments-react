import { TextMutationReceipt, TextMutationRange, ReceiptEffects, SDMutationReceipt, SelectionTarget, MutationResolutionTarget, ReceiptSuccess, SDMutationConversionReport } from './types/index.js';
export interface MutationReceiptBridgeContext {
    evaluatedRevision?: {
        before: string;
        after: string;
    };
    conversion?: SDMutationConversionReport;
}
interface CanonicalSuccessMetadata {
    id?: ReceiptSuccess['id'];
    inserted?: ReceiptSuccess['inserted'];
    updated?: ReceiptSuccess['updated'];
    removed?: ReceiptSuccess['removed'];
    invalidatedRefs?: ReceiptSuccess['invalidatedRefs'];
    remappedRefs?: ReceiptSuccess['remappedRefs'];
    affectedStories?: ReceiptSuccess['affectedStories'];
    textRangeShifts?: ReceiptSuccess['textRangeShifts'];
    txId?: ReceiptSuccess['txId'];
    warnings?: ReceiptSuccess['warnings'];
    effects?: ReceiptSuccess['effects'];
}
/**
 * Wraps a TextMutationReceipt into an SDMutationReceipt at the public API boundary.
 *
 * - Success/failure semantics are preserved.
 * - Resolution is passed through directly (both use TextAddress).
 * - Failure codes from the text pipeline are mapped to SDErrorCode.
 */
export declare function textReceiptToSDReceipt(receipt: TextMutationReceipt, context?: MutationReceiptBridgeContext): SDMutationReceipt;
/** Parameters for building a structural mutation receipt. */
export interface StructuralReceiptParams extends CanonicalSuccessMetadata, MutationReceiptBridgeContext {
    target: MutationResolutionTarget;
    range: TextMutationRange;
    selectionTarget?: SelectionTarget;
    /** Post-mutation created-content spans (inserted blocks / text). */
    effects?: ReceiptEffects;
}
/**
 * Builds an SDMutationReceipt for structural (block-level) mutations.
 *
 * Unlike {@link textReceiptToSDReceipt} which converts from the internal
 * text pipeline, this constructs a receipt directly: preserving the
 * original `BlockNodeAddress` target instead of normalizing it to a
 * synthetic `TextAddress`.
 */
export declare function buildStructuralReceipt(success: true, params: StructuralReceiptParams): SDMutationReceipt;
export declare function buildStructuralReceipt(success: false, params: StructuralReceiptParams, failure: {
    code: string;
    message: string;
}): SDMutationReceipt;
export {};
