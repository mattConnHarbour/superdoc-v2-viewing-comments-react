import { MutationOptions } from '../write/write.js';
import { SectionMutationResult } from '../sections/sections.types.js';
import { HeaderFooterKind, HeaderFooterVariant, HeaderFooterSlotAddress, HeaderFooterPartAddress, HeaderFooterSlotEntry, HeaderFooterResolveResult, HeaderFootersListQuery, HeaderFootersListResult, HeaderFootersGetInput, HeaderFootersResolveInput, HeaderFootersRefsSetInput, HeaderFootersRefsClearInput, HeaderFootersRefsSetLinkedToPreviousInput, HeaderFootersPartsListQuery, HeaderFootersPartsListResult, HeaderFootersPartsCreateInput, HeaderFootersPartsDeleteInput, HeaderFooterPartsMutationResult } from './header-footers.types.js';
export type { HeaderFooterKind, HeaderFooterVariant, HeaderFooterSlotAddress, HeaderFooterPartAddress, HeaderFooterSlotEntry, HeaderFooterResolveResult, HeaderFooterPartEntry, HeaderFootersListQuery, HeaderFootersListResult, HeaderFootersGetInput, HeaderFootersResolveInput, HeaderFootersRefsSetInput, HeaderFootersRefsClearInput, HeaderFootersRefsSetLinkedToPreviousInput, HeaderFootersPartsListQuery, HeaderFootersPartsListResult, HeaderFootersPartsCreateInput, HeaderFootersPartsDeleteInput, HeaderFooterPartsMutationResult, HeaderFooterRefsMutationResult, HeaderFooterRefsMutationSuccessResult, HeaderFooterRefsMutationFailureResult, HeaderFooterPartsMutationSuccessResult, HeaderFooterPartsMutationFailureResult, } from './header-footers.types.js';
export interface HeaderFootersAdapter {
    list(query?: HeaderFootersListQuery): HeaderFootersListResult;
    get(input: HeaderFootersGetInput): HeaderFooterSlotEntry;
    resolve(input: HeaderFootersResolveInput): HeaderFooterResolveResult;
    refs: {
        set(input: HeaderFootersRefsSetInput, options?: MutationOptions): SectionMutationResult;
        clear(input: HeaderFootersRefsClearInput, options?: MutationOptions): SectionMutationResult;
        setLinkedToPrevious(input: HeaderFootersRefsSetLinkedToPreviousInput, options?: MutationOptions): SectionMutationResult;
    };
    parts: {
        list(query?: HeaderFootersPartsListQuery): HeaderFootersPartsListResult;
        create(input: HeaderFootersPartsCreateInput, options?: MutationOptions): HeaderFooterPartsMutationResult;
        delete(input: HeaderFootersPartsDeleteInput, options?: MutationOptions): HeaderFooterPartsMutationResult;
    };
}
export type HeaderFootersApi = HeaderFootersAdapter;
export declare function validateHeaderFooterKind(operationName: string, kind: unknown): asserts kind is HeaderFooterKind;
export declare function validateHeaderFooterVariant(operationName: string, variant: unknown): asserts variant is HeaderFooterVariant;
export declare function assertHeaderFooterSlotTarget(input: unknown, operationName: string): asserts input is {
    target: HeaderFooterSlotAddress;
};
export declare function assertHeaderFooterPartTarget(input: unknown, operationName: string): asserts input is {
    target: HeaderFooterPartAddress;
};
export declare function executeHeaderFootersList(adapter: HeaderFootersAdapter, query?: HeaderFootersListQuery): HeaderFootersListResult;
export declare function executeHeaderFootersGet(adapter: HeaderFootersAdapter, input: HeaderFootersGetInput): HeaderFooterSlotEntry;
export declare function executeHeaderFootersResolve(adapter: HeaderFootersAdapter, input: HeaderFootersResolveInput): HeaderFooterResolveResult;
export declare function executeHeaderFootersRefsSet(adapter: HeaderFootersAdapter, input: HeaderFootersRefsSetInput, options?: MutationOptions): SectionMutationResult;
export declare function executeHeaderFootersRefsClear(adapter: HeaderFootersAdapter, input: HeaderFootersRefsClearInput, options?: MutationOptions): SectionMutationResult;
export declare function executeHeaderFootersRefsSetLinkedToPrevious(adapter: HeaderFootersAdapter, input: HeaderFootersRefsSetLinkedToPreviousInput, options?: MutationOptions): SectionMutationResult;
export declare function executeHeaderFootersPartsList(adapter: HeaderFootersAdapter, query?: HeaderFootersPartsListQuery): HeaderFootersPartsListResult;
export declare function executeHeaderFootersPartsCreate(adapter: HeaderFootersAdapter, input: HeaderFootersPartsCreateInput, options?: MutationOptions): HeaderFooterPartsMutationResult;
export declare function executeHeaderFootersPartsDelete(adapter: HeaderFootersAdapter, input: HeaderFootersPartsDeleteInput, options?: MutationOptions): HeaderFooterPartsMutationResult;
