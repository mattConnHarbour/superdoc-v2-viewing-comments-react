import { MutationOptions } from '../write/write.js';
import { CreateParagraphInput, CreateParagraphResult, CreateHeadingInput, CreateHeadingResult } from '../types/create.types.js';
import { CreateTableInput, CreateTableResult } from '../types/table-operations.types.js';
import { CreateSectionBreakInput, CreateSectionBreakResult } from '../sections/sections.types.js';
import { CreateTableOfContentsInput, CreateTableOfContentsResult } from '../toc/toc.types.js';
import { CreateImageInput, CreateImageResult } from '../images/images.types.js';
import { CreateContentControlInput, ContentControlMutationResult } from '../content-controls/content-controls.types.js';
export interface CreateApi {
    paragraph(input: CreateParagraphInput, options?: MutationOptions): CreateParagraphResult;
    heading(input: CreateHeadingInput, options?: MutationOptions): CreateHeadingResult;
    table(input: CreateTableInput, options?: MutationOptions): CreateTableResult;
    sectionBreak(input: CreateSectionBreakInput, options?: MutationOptions): CreateSectionBreakResult;
    tableOfContents(input: CreateTableOfContentsInput, options?: MutationOptions): CreateTableOfContentsResult;
    image(input: CreateImageInput, options?: MutationOptions): CreateImageResult;
    contentControl(input: CreateContentControlInput, options?: MutationOptions): ContentControlMutationResult;
}
export type CreateAdapter = CreateApi;
export declare function normalizeCreateParagraphInput(input: CreateParagraphInput): CreateParagraphInput;
export declare function executeCreateParagraph(adapter: CreateAdapter, input: CreateParagraphInput, options?: MutationOptions): CreateParagraphResult;
export declare function normalizeCreateHeadingInput(input: CreateHeadingInput): CreateHeadingInput;
export declare function executeCreateHeading(adapter: CreateAdapter, input: CreateHeadingInput, options?: MutationOptions): CreateHeadingResult;
export declare function normalizeCreateTableInput(input: CreateTableInput): CreateTableInput;
export declare function executeCreateTable(adapter: CreateAdapter, input: CreateTableInput, options?: MutationOptions): CreateTableResult;
export declare function normalizeCreateSectionBreakInput(input: CreateSectionBreakInput): CreateSectionBreakInput;
export declare function executeCreateSectionBreak(adapter: CreateAdapter, input: CreateSectionBreakInput, options?: MutationOptions): CreateSectionBreakResult;
export declare function normalizeCreateTableOfContentsInput(input: CreateTableOfContentsInput): CreateTableOfContentsInput;
export declare function executeCreateTableOfContents(adapter: CreateAdapter, input: CreateTableOfContentsInput, options?: MutationOptions): CreateTableOfContentsResult;
