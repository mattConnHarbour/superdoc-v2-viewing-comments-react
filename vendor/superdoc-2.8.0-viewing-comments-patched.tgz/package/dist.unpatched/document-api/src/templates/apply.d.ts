/**
 * `templates.apply`: source-authoritative template adoption (SD-3247).
 *
 * Adopts a source DOCX's template **style system and reusable template assets**
 * onto the currently open document while preserving the open document's
 * body/story content (`word/document.xml` is never replaced). This is template
 * adoption, not a blind substrate transplant. The adoption semantics are:
 *
 * - `styles`: source-authoritative overlap. For a `styleId` defined in both
 *   documents the source definition wins **in place** under the original id
 *   (no `*-tmpl` rename). The source `w:docDefaults` and `w:latentStyles`
 *   singletons replace the target's. Source-only styles are imported; target-only
 *   styles still required by preserved content are retained.
 * - `numbering`: reconciled as a dependency graph (not a flat append / blind
 *   replace). The `w:num`/`w:abstractNum` graph required by imported
 *   numbering-bearing styles is imported, colliding ids are remapped
 *   deterministically, and references are rewritten coherently in both
 *   `numbering.xml` and `styles.xml`.
 * - `settings`: bounded reconciliation — layout/style-affecting settings (e.g.
 *   default tab stop) are adopted; identity/workflow settings (`rsid*`, `docId`,
 *   protection/revision state, `attachedTemplate`) are preserved.
 * - `theme`, `fontTable`, `webSettings`: whole-part adoption.
 * - `headersFooters`: **all** source `header*.xml` / `footer*.xml` parts are
 *   imported as reusable template assets (even ones the page-1 governing
 *   section does not reference), together with their `.rels` and transitive
 *   media closure; colliding part names / relationship ids / media names are
 *   reallocated and references rewritten consistently.
 * - `sectionDefaults`: the source `w:sectPr` that governs page 1 is adopted as
 *   the current document's active/final section-default model. On multi-section
 *   targets, its header/footer visibility model (`headerReference`,
 *   `footerReference`, `w:titlePg`) is also propagated across the earlier
 *   sections without overwriting their own page geometry. Intermediate / later
 *   source sections are not imported.
 *
 * Selected non-body package sidecars (`customXml`, `docProps/custom.xml`,
 * comments, notes, people, keymap customizations, and `settings.xml.rels`) are
 * imported when present so reconstructed content can reuse the source package
 * substrate faithfully. Source body content, glossary, signatures, embeddings,
 * and body media remain out of scope and are reported, never applied.
 *
 * Engine-agnostic contract + execution entry point. No ProseMirror/converter imports.
 */
export type TemplatesApplySourcePath = {
    kind: 'path';
    path: string;
};
export type TemplatesApplySourceBase64 = {
    kind: 'base64';
    data: string;
    filename?: string;
};
export type TemplatesApplySource = TemplatesApplySourcePath | TemplatesApplySourceBase64;
export type TemplateBodyPolicy = 'preserve';
export type TemplateScope = 'styles' | 'numbering' | 'settings' | 'theme' | 'fontTable' | 'webSettings' | 'headersFooters' | 'sectionDefaults';
export interface TemplatesApplyInput {
    source: TemplatesApplySource;
    bodyPolicy?: TemplateBodyPolicy;
}
export interface TemplatesApplyOptions {
    dryRun?: boolean;
    expectedRevision?: string | number;
}
export interface NormalizedTemplatesApplyOptions {
    dryRun: boolean;
    expectedRevision: string | undefined;
}
export interface TemplateScopeReport {
    scope: TemplateScope;
    part: string;
    detail?: string;
}
export type TemplateSkipReason = 'NOT_PRESENT_IN_SOURCE' | 'OUT_OF_SCOPE' | 'NO_CHANGE' | 'CAPABILITY_UNAVAILABLE';
export interface TemplateScopeSkip {
    scope: string;
    part?: string;
    reason: TemplateSkipReason;
    message: string;
}
export interface TemplateUnsupportedItem {
    part: string;
    category: string;
    reason: string;
}
export type TemplateChangeKind = 'created' | 'replaced' | 'merged' | 'imported';
export interface TemplateChangedPart {
    part: string;
    scope: TemplateScope | 'package';
    change: TemplateChangeKind;
}
export interface TemplateIdMapping {
    kind: 'style' | 'numbering' | 'relationship';
    from: string;
    to: string;
}
export interface TemplateApplyWarning {
    code: string;
    message: string;
}
export interface TemplatesApplySourceInfo {
    kind: 'path' | 'base64';
    fingerprint: string;
    partCount: number;
}
export interface TemplatesApplyReceiptSuccess {
    success: true;
    changed: boolean;
    dryRun: boolean;
    bodyPolicy: 'preserve';
    source: TemplatesApplySourceInfo;
    detectedScopes: TemplateScopeReport[];
    appliedScopes: TemplateScopeReport[];
    skippedScopes: TemplateScopeSkip[];
    unsupportedItems: TemplateUnsupportedItem[];
    changedParts: TemplateChangedPart[];
    idMappings: {
        styles?: TemplateIdMapping[];
        numbering?: TemplateIdMapping[];
        relationships?: TemplateIdMapping[];
    };
    warnings: TemplateApplyWarning[];
}
export type TemplatesApplyFailureCode = 'UNSUPPORTED_SOURCE' | 'INVALID_PACKAGE' | 'CAPABILITY_UNAVAILABLE' | 'UNSUPPORTED_TEMPLATE_CONTENT';
export interface TemplatesApplyReceiptFailure {
    success: false;
    failure: {
        code: TemplatesApplyFailureCode;
        message: string;
    };
}
export type TemplatesApplyReceipt = TemplatesApplyReceiptSuccess | TemplatesApplyReceiptFailure;
export interface TemplatesAdapter {
    /**
     * Adopt a source package's template substrate. Returns a Promise: the source
     * package is loaded asynchronously (JSZip), so the receipt resolves after the
     * async OPC read + mutation work completes. Pre-apply guards (converter
     * availability, `expectedRevision`) still throw synchronously before any
     * Promise is returned — see `throws.preApply` in the contract metadata.
     */
    apply(input: TemplatesApplyInput, options: NormalizedTemplatesApplyOptions): Promise<TemplatesApplyReceipt>;
}
export interface TemplatesApi {
    /**
     * Apply detected template substrate from a source DOCX onto the open document.
     *
     * Must be awaited: source acquisition and OPC/ZIP package loading are async.
     * Synchronous input validation and pre-apply preconditions still throw before
     * the returned Promise is created.
     */
    apply(input: TemplatesApplyInput, options?: TemplatesApplyOptions): Promise<TemplatesApplyReceipt>;
}
/**
 * Execute `templates.apply`.
 *
 * Input validation and option normalization run synchronously, so invalid
 * input and other `throws.preApply` cases still throw synchronously (before any
 * Promise is created). The successful/receipt-returning path is async: the
 * adapter loads the source package via the async OPC reader and resolves a
 * {@link TemplatesApplyReceipt}.
 */
export declare function executeTemplatesApply(adapter: TemplatesAdapter, input: TemplatesApplyInput, options?: TemplatesApplyOptions): Promise<TemplatesApplyReceipt>;
