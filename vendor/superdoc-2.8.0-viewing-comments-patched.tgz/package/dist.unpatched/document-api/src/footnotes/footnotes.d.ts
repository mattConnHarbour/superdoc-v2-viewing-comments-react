import { MutationOptions } from '../write/write.js';
import { FootnoteGetInput, FootnoteInfo, FootnoteInsertInput, FootnoteUpdateInput, FootnoteRemoveInput, FootnoteConfigureInput, FootnoteMutationResult, FootnoteConfigResult, FootnoteListInput, FootnotesListResult } from './footnotes.types.js';
export interface FootnotesApi {
    list(query?: FootnoteListInput): FootnotesListResult;
    get(input: FootnoteGetInput): FootnoteInfo;
    insert(input: FootnoteInsertInput, options?: MutationOptions): FootnoteMutationResult;
    update(input: FootnoteUpdateInput, options?: MutationOptions): FootnoteMutationResult;
    remove(input: FootnoteRemoveInput, options?: MutationOptions): FootnoteMutationResult;
    configure(input: FootnoteConfigureInput, options?: MutationOptions): FootnoteConfigResult;
}
export type FootnotesAdapter = FootnotesApi;
export declare function executeFootnotesList(adapter: FootnotesAdapter, query?: FootnoteListInput): FootnotesListResult;
export declare function executeFootnotesGet(adapter: FootnotesAdapter, input: FootnoteGetInput): FootnoteInfo;
export declare function executeFootnotesInsert(adapter: FootnotesAdapter, input: FootnoteInsertInput, options?: MutationOptions): FootnoteMutationResult;
export declare function executeFootnotesUpdate(adapter: FootnotesAdapter, input: FootnoteUpdateInput, options?: MutationOptions): FootnoteMutationResult;
export declare function executeFootnotesRemove(adapter: FootnotesAdapter, input: FootnoteRemoveInput, options?: MutationOptions): FootnoteMutationResult;
export declare function executeFootnotesConfigure(adapter: FootnotesAdapter, input: FootnoteConfigureInput, options?: MutationOptions): FootnoteConfigResult;
