import { HeadingNodeInfo, ListItemNodeInfo, ParagraphNodeInfo } from './paragraph.types.js';
import { LineBreakNodeInfo, RunNodeInfo, TabNodeInfo } from './inline.types.js';
import { TableCellNodeInfo, TableNodeInfo, TableRowNodeInfo } from './tables.types.js';
import { ImageNodeInfo } from './media.types.js';
import { BookmarkNodeInfo, ContentControlInfo, HyperlinkNodeInfo } from './structured.types.js';
import { CommentNodeInfo } from './comments.types.js';
import { FootnoteRefNodeInfo } from './references.types.js';
import { TableOfContentsNodeInfo } from '../toc/toc.types.js';
export type NodeInfo = ParagraphNodeInfo | HeadingNodeInfo | ListItemNodeInfo | TableNodeInfo | TableRowNodeInfo | TableCellNodeInfo | TableOfContentsNodeInfo | ImageNodeInfo | ContentControlInfo | RunNodeInfo | BookmarkNodeInfo | CommentNodeInfo | HyperlinkNodeInfo | FootnoteRefNodeInfo | TabNodeInfo | LineBreakNodeInfo;
