import { BlockNodeAddress, NodeAddress } from './base.js';
import { TextSelector, NodeSelector } from './query.js';
import { SDContentNode, SDInlineNode } from './sd-nodes.js';
import { StoryLocator } from './story.types.js';
export interface SDPoint {
    blockId: string;
    /** UTF-16 code units. */
    offset: number;
}
export interface SDNodeContext {
    ancestors?: Array<{
        id: string;
        kind: string;
    }>;
    sectionId?: string;
    tablePosition?: {
        tableId: string;
        rowIndex: number;
        cellIndex: number;
    };
    listPosition?: {
        listId: string;
        itemPath: number[];
        level: number;
    };
}
export interface SDReadOptions {
    /** Include resolved (cascaded) property values. Default false. */
    includeResolved?: boolean;
    /** Include per-property provenance. Requires includeResolved=true. Default false. */
    includeProvenance?: boolean;
    /** Include SDNodeContext on SDNodeResult. Default false. */
    includeContext?: boolean;
}
export interface SDGetInput {
    /** Restrict the read to a specific story. Omit for body (backward compatible). */
    in?: StoryLocator;
    options?: SDReadOptions;
}
export interface SDFindInput {
    select: TextSelector | NodeSelector;
    within?: BlockNodeAddress;
    /** Restrict the search to a specific story. Omit for body (backward compatible). */
    in?: StoryLocator;
    limit?: number;
    offset?: number;
    options?: SDReadOptions;
}
export interface SDNodeResult {
    node: SDContentNode | SDInlineNode;
    address: NodeAddress;
    context?: SDNodeContext;
}
export interface SDFindResult {
    total: number;
    limit: number;
    offset: number;
    items: SDNodeResult[];
}
