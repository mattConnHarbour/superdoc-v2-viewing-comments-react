import { SectionAddress } from '../sections/sections.types.js';
/** All recognized story types. */
export declare const STORY_TYPES: readonly ["body", "headerFooterSlot", "headerFooterPart", "footnote", "endnote", "textbox"];
/** Valid header/footer story kinds. */
export declare const STORY_HEADER_FOOTER_KINDS: readonly ["header", "footer"];
/** Valid header/footer slot variants. */
export declare const STORY_HEADER_FOOTER_VARIANTS: readonly ["default", "first", "even"];
/** Valid header/footer slot resolution modes. */
export declare const STORY_HEADER_FOOTER_RESOLUTIONS: readonly ["effective", "explicit"];
/** Valid header/footer slot write modes. */
export declare const STORY_HEADER_FOOTER_ON_WRITE_VALUES: readonly ["materializeIfInherited", "editResolvedPart", "error"];
export type StoryType = (typeof STORY_TYPES)[number];
export type StoryHeaderFooterKind = (typeof STORY_HEADER_FOOTER_KINDS)[number];
export type StoryHeaderFooterVariant = (typeof STORY_HEADER_FOOTER_VARIANTS)[number];
export type StoryHeaderFooterResolution = (typeof STORY_HEADER_FOOTER_RESOLUTIONS)[number];
export type StoryHeaderFooterOnWrite = (typeof STORY_HEADER_FOOTER_ON_WRITE_VALUES)[number];
/** The main document body. */
export interface BodyStoryLocator {
    kind: 'story';
    storyType: 'body';
}
/**
 * A header/footer slot identified by section, kind, and variant.
 *
 * This is the high-level "logical" locator: it represents a slot that may
 * resolve to an explicit part in the targeted section or inherit from an
 * earlier section.
 *
 * - `resolution` controls whether the locator resolves to the effective part
 *   (following inheritance) or only matches an explicit local reference.
 *   Defaults to `'effective'` when omitted.
 * - `onWrite` controls mutation behavior when the slot is inherited:
 *   - `'materializeIfInherited'`: creates a local copy before editing (default).
 *   - `'editResolvedPart'`: edits the inherited part in place.
 *   - `'error'`: fails if the slot is not explicitly defined in this section.
 */
export interface HeaderFooterSlotStoryLocator {
    kind: 'story';
    storyType: 'headerFooterSlot';
    section: SectionAddress;
    headerFooterKind: StoryHeaderFooterKind;
    variant: StoryHeaderFooterVariant;
    /** Resolution strategy. Defaults to `'effective'` when omitted. */
    resolution?: StoryHeaderFooterResolution;
    /** Write behavior when the slot is inherited. Defaults to `'materializeIfInherited'`. */
    onWrite?: StoryHeaderFooterOnWrite;
}
/**
 * A header/footer part identified by its relationship ID.
 *
 * This is the low-level "physical" locator: it points directly at a specific
 * header or footer XML part, bypassing section-level resolution.
 */
export interface HeaderFooterPartStoryLocator {
    kind: 'story';
    storyType: 'headerFooterPart';
    refId: string;
}
/** A footnote story identified by its note ID. */
export interface FootnoteStoryLocator {
    kind: 'story';
    storyType: 'footnote';
    noteId: string;
}
/** An endnote story identified by its note ID. */
export interface EndnoteStoryLocator {
    kind: 'story';
    storyType: 'endnote';
    noteId: string;
}
/**
 * A textbox story identified by a stable textbox id.
 *
 * The supported subset is DrawingML textbox content (`w:txbxContent` inside
 * `w:drawing`) hosted in the main body story. VML textbox content
 * (`v:textbox` / `w:pict`), linked textbox chains (`w:linkedTxbxContent`),
 * nested textbox stories, and textbox stories inside headers/footers are
 * rejected at admission time with named diagnostics rather than silently
 * widened.
 */
export interface TextboxStoryLocator {
    kind: 'story';
    storyType: 'textbox';
    textboxId: string;
}
/**
 * Identifies a content story within a document.
 *
 * Discriminate on `storyType` to narrow to a specific variant.
 */
export type StoryLocator = BodyStoryLocator | HeaderFooterSlotStoryLocator | HeaderFooterPartStoryLocator | FootnoteStoryLocator | EndnoteStoryLocator | TextboxStoryLocator;
/**
 * Type guard: returns `true` if `value` is a valid {@link StoryLocator}.
 *
 * Checks the full discriminated-union shape so malformed partial locators do
 * not leak through validation and fail later with raw property-access errors.
 */
export declare function isStoryLocator(value: unknown): value is StoryLocator;
/**
 * Type guard: returns `true` if `locator` targets the document body.
 */
export declare function isBodyStory(locator: StoryLocator): locator is BodyStoryLocator;
/**
 * Returns the effective resolution mode for a header/footer slot locator.
 */
export declare function getStoryHeaderFooterResolution(locator: Pick<HeaderFooterSlotStoryLocator, 'resolution'>): StoryHeaderFooterResolution;
/**
 * Returns the effective write mode for a header/footer slot locator.
 */
export declare function getStoryHeaderFooterOnWrite(locator: Pick<HeaderFooterSlotStoryLocator, 'onWrite'>): StoryHeaderFooterOnWrite;
/**
 * Converts a {@link StoryLocator} to a canonical string key.
 *
 * The key is deterministic and suitable for use as a map key or cache key.
 * Round-tripping is NOT guaranteed: this is a one-way serialization.
 *
 * Examples:
 * - `{ kind: 'story', storyType: 'body' }` → `'story:body'`
 * - `{ kind: 'story', storyType: 'footnote', noteId: 'fn1' }` → `'story:footnote:fn1'`
 * - `{ kind: 'story', storyType: 'headerFooterSlot', section: { kind: 'section', sectionId: 's1' }, headerFooterKind: 'header', variant: 'default' }` → `'story:headerFooterSlot:s1:header:default:effective:materializeIfInherited'`
 * - `{ kind: 'story', storyType: 'headerFooterPart', refId: 'rId7' }` → `'story:headerFooterPart:rId7'`
 */
export declare function storyLocatorToKey(locator: StoryLocator): string;
