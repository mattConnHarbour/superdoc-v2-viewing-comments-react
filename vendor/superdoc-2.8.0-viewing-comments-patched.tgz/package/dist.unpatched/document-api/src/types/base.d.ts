import { StoryLocator } from './story.types.js';
export type NodeKind = 'block' | 'inline';
export declare const NODE_KINDS: readonly ["block", "inline"];
export type NodeType = 'paragraph' | 'heading' | 'listItem' | 'table' | 'tableRow' | 'tableCell' | 'tableOfContents' | 'run' | 'bookmark' | 'comment' | 'hyperlink' | 'footnoteRef' | 'endnoteRef' | 'crossRef' | 'indexEntry' | 'citation' | 'authorityEntry' | 'sequenceField' | 'tab' | 'lineBreak' | 'image' | 'sdt';
export declare const NODE_TYPES: readonly ["paragraph", "heading", "listItem", "table", "tableRow", "tableCell", "tableOfContents", "image", "sdt", "run", "bookmark", "comment", "hyperlink", "footnoteRef", "endnoteRef", "crossRef", "indexEntry", "citation", "authorityEntry", "sequenceField", "tab", "lineBreak"];
/**
 * Node types that can appear in block context.
 * Note: 'sdt' and 'image' can appear in both block and inline contexts.
 */
export type BlockNodeType = Extract<NodeType, 'paragraph' | 'heading' | 'listItem' | 'table' | 'tableRow' | 'tableCell' | 'tableOfContents' | 'image' | 'sdt'>;
export declare const BLOCK_NODE_TYPES: readonly ["paragraph", "heading", "listItem", "table", "tableRow", "tableCell", "tableOfContents", "image", "sdt"];
/**
 * Block node types that `blocks.delete` can target in this release.
 * Excludes `tableRow` and `tableCell` (row/column semantics are out of scope).
 */
export type DeletableBlockNodeType = Exclude<BlockNodeType, 'tableRow' | 'tableCell' | 'tableOfContents' | 'image'>;
export declare const DELETABLE_BLOCK_NODE_TYPES: readonly ["paragraph", "heading", "listItem", "table", "sdt"];
/**
 * Node types that can appear in inline context.
 * Note: 'sdt' and 'image' can appear in both block and inline contexts.
 */
export type InlineNodeType = Extract<NodeType, 'run' | 'bookmark' | 'comment' | 'hyperlink' | 'sdt' | 'image' | 'footnoteRef' | 'endnoteRef' | 'crossRef' | 'indexEntry' | 'citation' | 'authorityEntry' | 'sequenceField' | 'tab' | 'lineBreak'>;
export declare const INLINE_NODE_TYPES: readonly ["run", "bookmark", "comment", "hyperlink", "sdt", "image", "footnoteRef", "endnoteRef", "crossRef", "indexEntry", "citation", "authorityEntry", "sequenceField", "tab", "lineBreak"];
export type Position = {
    blockId: string;
    /**
     * 0-based offset into the block's flattened text representation.
     *
     * - Text runs contribute their character length.
     * - Leaf inline nodes (images, tabs, etc.) contribute a single placeholder character.
     * - Transparent inline wrappers (hyperlinks, bookmarks, etc.) contribute only their inner text.
     */
    offset: number;
};
export type InlineAnchor = {
    start: Position;
    end: Position;
};
export type BlockNodeAddress = {
    kind: 'block';
    nodeType: BlockNodeType;
    nodeId: string;
    /** Story containing this block. Omit for body (backward compatible). */
    story?: StoryLocator;
};
export type TableAddress = {
    kind: 'block';
    nodeType: 'table';
    nodeId: string;
};
export type TableRowAddress = {
    kind: 'block';
    nodeType: 'tableRow';
    nodeId: string;
};
export type TableCellAddress = {
    kind: 'block';
    nodeType: 'tableCell';
    nodeId: string;
};
export type TableOrRowAddress = TableAddress | TableRowAddress;
export type TableOrCellAddress = TableAddress | TableCellAddress;
export type DeletableBlockNodeAddress = {
    kind: 'block';
    nodeType: DeletableBlockNodeType;
    nodeId: string;
    /** Story containing this block. Omit for body (backward compatible). */
    story?: StoryLocator;
};
export type InlineNodeAddress = {
    kind: 'inline';
    nodeType: InlineNodeType;
    anchor: InlineAnchor;
    /** Story containing this inline node. Omit for body (backward compatible). */
    story?: StoryLocator;
};
export type NodeAddress = BlockNodeAddress | InlineNodeAddress;
export type NodeSummary = {
    label?: string;
    text?: string;
};
export interface BaseNodeInfo {
    nodeType: NodeType;
    kind: NodeKind;
    summary?: NodeSummary;
    text?: string;
    /** Child nodes. Typed as BaseNodeInfo[] to avoid circular imports; narrow via `nodeType`. */
    nodes?: BaseNodeInfo[];
}
