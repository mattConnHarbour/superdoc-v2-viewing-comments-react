import { BlockNodeAddress, BlockNodeType } from './base.js';
import { Range, SelectionTarget, TextTarget } from './address.js';
import { StoryLocator } from './story.types.js';
import { SDDiagnostic, SDHtmlMarkdownOutcome } from './sd-contract.js';
export declare const SD_PROJECTION_FORMATS: readonly ["html", "markdown"];
export type SDProjectionFormat = (typeof SD_PROJECTION_FORMATS)[number];
export declare const SD_PROJECTION_REVIEW_MODES: readonly ["final", "original", "redline"];
export type SDProjectionReviewMode = (typeof SD_PROJECTION_REVIEW_MODES)[number];
export declare const SD_PROJECTION_STATUSES: readonly ["success", "warning", "failed"];
export type SDProjectionStatus = (typeof SD_PROJECTION_STATUSES)[number];
export declare const SD_PROJECTION_DIAGNOSTIC_CODES: readonly ["projection-normalized-construct", "projection-downgraded-construct", "projection-unsupported-construct", "projection-placeholder-emitted", "projection-annotation-omitted", "projection-numbering-unresolved", "projection-source-coverage-incomplete", "projection-scope-unsupported", "projection-limit-exceeded", "projection-revision-changed", "projection-malformed-source"];
export type SDProjectionDiagnosticCode = (typeof SD_PROJECTION_DIAGNOSTIC_CODES)[number];
export declare const SD_PROJECTION_CONSTRUCTS: readonly ["document", "source", "text", "paragraph", "emptyParagraph", "softBreak", "lineBreak", "heading", "bold", "italic", "underline", "strike", "hyperlink", "list", "listLabel", "table", "tableHeader", "tableRow", "tableCell", "colSpan", "rowSpan", "horizontalRule", "inlineCode", "codeBlock", "image", "field", "contentControl", "math", "drawing", "embeddedObject", "sectionBreak", "pageBreak", "columnBreak", "trackedChange", "comment", "scope", "placeholder"];
export type SDProjectionConstruct = (typeof SD_PROJECTION_CONSTRUCTS)[number];
export declare const SD_PROJECTION_DISPOSITIONS: readonly ["preserved", "normalized", "downgraded", "placeholder", "omitted", "rejected"];
export type SDProjectionDisposition = (typeof SD_PROJECTION_DISPOSITIONS)[number];
export type SDProjectionScope = BlockNodeAddress | SelectionTarget;
export interface SDProjectionReadInput {
    in?: StoryLocator;
    reviewMode?: SDProjectionReviewMode;
    scope?: SDProjectionScope;
}
export interface ProjectHtmlInput extends SDProjectionReadInput {
    includeSourceMap?: boolean;
}
export interface ProjectMarkdownInput extends SDProjectionReadInput {
    includeSourceMap?: boolean;
}
export type SDResolvedProjectionScope = {
    kind: 'story';
} | {
    kind: 'block';
    target: BlockNodeAddress;
} | {
    kind: 'range';
    target: SelectionTarget & {
        coordinateSpace: 'tracked';
    };
};
export type SDProjectionBlockMapEntry = {
    nodeType: BlockNodeType;
    output: Range;
    parentBlockId?: string;
    changeIds?: string[];
    commentIds?: string[];
} & ({
    identity: 'public';
    blockId: string;
} | {
    identity: 'unavailable';
    identityUnavailableReason: 'positionDerivedFallback';
    blockId?: never;
});
export type SDProjectionDiagnostic = Omit<SDDiagnostic, 'code' | 'construct' | 'disposition' | 'lossy' | 'source'> & {
    code: SDProjectionDiagnosticCode;
    construct: SDProjectionConstruct;
    disposition: SDProjectionDisposition;
    lossy: boolean;
    source: {
        story: StoryLocator;
        blockId?: string;
        range?: Range;
        coordinateSpace?: 'tracked';
        changeIds?: string[];
        commentIds?: string[];
    };
    output?: {
        format: SDProjectionFormat;
        range?: Range;
    };
};
export interface SDProjectionSourceMap {
    version: 'sd-projection-source-map/1';
    outputCoordinateSpace: 'utf16';
    sourceCoordinateSpace: 'tracked';
    entries: SDProjectionSourceMapEntry[];
}
export type SDProjectionSourceMapEntry = {
    kind: 'text';
    output: Range;
    source: TextTarget & {
        coordinateSpace: 'tracked';
    };
    blockId: string;
    changeIds?: string[];
    commentIds?: string[];
} | ({
    kind: 'synthetic';
    output: Range;
    role: 'listLabel' | 'placeholder';
    changeIds?: string[];
    commentIds?: string[];
} & ({
    identity: 'public';
    blockId: string;
} | {
    identity: 'unavailable';
    identityUnavailableReason: 'positionDerivedFallback';
    blockId?: never;
}));
export interface SDProjectionAnnotation {
    kind: 'trackedChange' | 'comment';
    id: string;
    blockIds: string[];
    sourceTarget?: TextTarget;
    outputRanges: Range[];
    status: 'emitted' | 'partiallyEmitted' | 'omitted';
    omittedReason?: 'reviewMode' | 'unsupported';
    side?: 'inserted' | 'deleted' | 'source' | 'destination' | 'formatting';
}
export interface SDContentProjectionResult<TFormat extends SDProjectionFormat = SDProjectionFormat> {
    format: TFormat;
    content: string;
    status: SDProjectionStatus;
    /** Fidelity outcome derived from the complete projection diagnostics. */
    outcome: SDHtmlMarkdownOutcome;
    reviewMode: SDProjectionReviewMode;
    evaluatedRevision: string;
    story: StoryLocator;
    scope: SDResolvedProjectionScope;
    lossy: boolean;
    diagnostics: SDProjectionDiagnostic[];
    blocks: SDProjectionBlockMapEntry[];
    annotations: SDProjectionAnnotation[];
    sourceMap?: SDProjectionSourceMap;
}
export declare function deriveSDHtmlMarkdownOutcome(diagnostics: readonly Pick<SDDiagnostic, 'severity' | 'lossy'>[]): SDHtmlMarkdownOutcome;
export declare function deriveSDProjectionStatus(diagnostics: readonly Pick<SDProjectionDiagnostic, 'severity' | 'lossy'>[]): SDProjectionStatus;
export declare function validateSDProjectionSourceMap(sourceMap: SDProjectionSourceMap, contentLength: number): boolean;
