import { SDContentNode } from './sd-nodes.js';
import { SDStyles, SDDocDefaults, SDTheme } from './sd-styles.js';
import { SDNumberingCatalog, SDSection, SDReferenceCatalogs, SDAnnotations } from './sd-sections.js';
import { SDDocumentMeta } from './sd-props.js';
/** Structural content payload for insert and replace operations. */
export type SDFragment = SDContentNode | SDContentNode[];
export interface SDDocument {
    modelVersion: 'sdm/1';
    body: SDContentNode[];
    styles?: SDStyles;
    theme?: SDTheme;
    docDefaults?: SDDocDefaults;
    numbering?: SDNumberingCatalog;
    sections?: SDSection[];
    referenceCatalogs?: SDReferenceCatalogs;
    annotations?: SDAnnotations;
    metadata?: SDDocumentMeta;
}
export declare const SD_CONTENT_NODE_KINDS: readonly ["paragraph", "heading", "list", "table", "toc", "index", "bibliography", "tableOfAuthorities", "break", "horizontalRule", "sectionBreak", "sectPr", "image", "drawing", "sdt", "customXml", "altChunk", "math", "field"];
export type SDContentNodeKind = (typeof SD_CONTENT_NODE_KINDS)[number];
export declare const SD_INLINE_NODE_KINDS: readonly ["run", "hyperlink", "crossRef", "indexEntry", "sequenceField", "citation", "authorityEntry", "tocEntry", "image", "drawing", "sdt", "customXml", "math", "field", "tab", "lineBreak", "footnoteRef", "endnoteRef"];
export type SDInlineNodeKind = (typeof SD_INLINE_NODE_KINDS)[number];
export * from './sd-props.js';
export * from './sd-objects.js';
export * from './sd-nodes.js';
export * from './sd-styles.js';
export * from './sd-sections.js';
export * from './sd-envelope.js';
export * from './sd-contract.js';
