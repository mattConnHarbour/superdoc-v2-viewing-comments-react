/**
 * Placement and nesting policy types for structural insert/replace operations.
 */
/** Where to place structural content relative to the target. */
export type Placement = 'before' | 'after' | 'insideStart' | 'insideEnd';
/** Valid placement values for runtime validation. */
export declare const PLACEMENT_VALUES: ReadonlySet<string>;
/** Default placement for structural insert when not specified. */
export declare const DEFAULT_PLACEMENT: Placement;
/** Policy controlling whether nested tables are permitted. */
export type TableNestingPolicy = 'forbid' | 'allow';
/** Valid table nesting policy values for runtime validation. */
export declare const TABLE_NESTING_POLICY_VALUES: ReadonlySet<string>;
/** Policy object for controlling structural nesting behavior. */
export interface NestingPolicy {
    tables?: TableNestingPolicy;
}
/** Default nesting policy: nested tables are forbidden. */
export declare const DEFAULT_NESTING_POLICY: Readonly<Required<NestingPolicy>>;
/**
 * Failure codes specific to structural placement violations.
 * These extend the existing ReceiptFailureCode vocabulary.
 */
export type StructuralFailureCode = 'INVALID_NESTING' | 'INVALID_PLACEMENT' | 'EMPTY_FRAGMENT' | 'INVALID_FRAGMENT';
