import { SDRunProps, SDParagraphProps, SDTableProps, SDThemeColorName } from './sd-props.js';
export interface SDStyleBase<TProps> {
    name?: string;
    basedOn?: string;
    next?: string;
    linked?: string;
    props?: TProps;
}
export type SDParagraphStyleDef = SDStyleBase<SDParagraphProps>;
export type SDCharacterStyleDef = SDStyleBase<SDRunProps>;
export type SDTableStyleDef = SDStyleBase<SDTableProps>;
export interface SDStyles {
    paragraph?: Record<string, SDParagraphStyleDef>;
    character?: Record<string, SDCharacterStyleDef>;
    table?: Record<string, SDTableStyleDef>;
}
export interface SDTheme {
    colorScheme: Record<SDThemeColorName, string>;
    fontScheme?: {
        major?: {
            latin?: string;
            eastAsia?: string;
            complexScript?: string;
        };
        minor?: {
            latin?: string;
            eastAsia?: string;
            complexScript?: string;
        };
    };
}
export interface SDDocDefaults {
    run?: SDRunProps;
    paragraph?: SDParagraphProps;
    table?: SDTableProps;
}
