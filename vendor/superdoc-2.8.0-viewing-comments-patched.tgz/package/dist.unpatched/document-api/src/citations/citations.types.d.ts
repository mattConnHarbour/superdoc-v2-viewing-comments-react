import { InlineAnchor } from '../types/base.js';
import { TextTarget } from '../types/address.js';
import { StoryLocator } from '../types/story.types.js';
import { AdapterMutationFailure } from '../types/adapter-result.js';
import { DiscoveryOutput } from '../types/discovery.js';
import { TocCreateLocation } from '../toc/toc.types.js';
export interface CitationAddress {
    kind: 'inline';
    nodeType: 'citation';
    anchor: InlineAnchor;
    /** Story containing this citation. Omit for body (backward compatible). */
    story?: StoryLocator;
    /** Session-stable story identity used by the v2 runtime with `fieldId`. */
    storyId?: string;
    /** Session-stable identity of the citation's backing OOXML field. */
    fieldId?: string;
    /** Field occurrence fallback for collocated citations with identical anchors. */
    occurrenceIndex?: number;
}
export interface CitationSourceAddress {
    kind: 'entity';
    entityType: 'citationSource';
    sourceId: string;
}
export interface BibliographyAddress {
    kind: 'block';
    nodeType: 'bibliography';
    nodeId: string;
}
export type CitationSourceType = 'book' | 'journalArticle' | 'conferenceProceedings' | 'report' | 'website' | 'patent' | 'case' | 'statute' | 'thesis' | 'film' | 'interview' | 'misc';
export interface CitationPerson {
    first?: string;
    middle?: string;
    last: string;
}
/** Fields follow the OOXML bibliography schema (Sources.xsd). */
export interface CitationSourceFields {
    title?: string;
    authors?: CitationPerson[];
    year?: string;
    publisher?: string;
    city?: string;
    journalName?: string;
    volume?: string;
    issue?: string;
    pages?: string;
    url?: string;
    doi?: string;
    edition?: string;
    editor?: CitationPerson[];
    translator?: CitationPerson[];
    medium?: string;
    shortTitle?: string;
    standardNumber?: string;
}
export interface CitationListInput {
    limit?: number;
    offset?: number;
}
export interface CitationGetInput {
    target: CitationAddress;
}
export interface CitationRemoveInput {
    target: CitationAddress;
}
export interface CitationInsertInput {
    at: TextTarget;
    sourceIds: string[];
}
export interface CitationUpdateInput {
    target: CitationAddress;
    patch: {
        sourceIds?: string[];
    };
}
export interface CitationInfo {
    address: CitationAddress;
    sourceIds: string[];
    displayText: string;
    instruction: string;
}
export interface CitationDomain {
    address: CitationAddress;
    sourceIds: string[];
    displayText: string;
    instruction: string;
}
export interface CitationSourceListInput {
    type?: CitationSourceType;
    limit?: number;
    offset?: number;
}
export interface CitationSourceGetInput {
    target: CitationSourceAddress;
}
export interface CitationSourceRemoveInput {
    target: CitationSourceAddress;
}
export interface CitationSourceInsertInput {
    type: CitationSourceType;
    fields: CitationSourceFields;
}
export interface CitationSourceUpdateInput {
    target: CitationSourceAddress;
    patch: Partial<CitationSourceFields>;
}
export interface CitationSourceInfo {
    address: CitationSourceAddress;
    sourceId: string;
    tag: string;
    type: CitationSourceType;
    fields: CitationSourceFields;
}
export interface CitationSourceDomain {
    address: CitationSourceAddress;
    sourceId: string;
    tag: string;
    type: CitationSourceType;
    fields: CitationSourceFields;
}
export interface BibliographyInsertInput {
    at: TocCreateLocation;
    style?: string;
}
export interface BibliographyRebuildInput {
    target: BibliographyAddress;
}
export interface BibliographyConfigureInput {
    target: BibliographyAddress;
    style: string;
}
export interface BibliographyRemoveInput {
    target: BibliographyAddress;
}
export interface BibliographyGetInput {
    target: BibliographyAddress;
}
export interface BibliographyInfo {
    address: BibliographyAddress;
    style: string;
    sourceCount: number;
    instruction: string;
}
export interface CitationMutationSuccess {
    success: true;
    citation: CitationAddress;
}
export type CitationMutationResult = CitationMutationSuccess | AdapterMutationFailure;
export interface CitationSourceMutationSuccess {
    success: true;
    source: CitationSourceAddress;
}
export type CitationSourceMutationResult = CitationSourceMutationSuccess | AdapterMutationFailure;
export interface BibliographyMutationSuccess {
    success: true;
    bibliography: BibliographyAddress;
}
export type BibliographyMutationResult = BibliographyMutationSuccess | AdapterMutationFailure;
export type CitationsListResult = DiscoveryOutput<CitationDomain>;
export type CitationSourcesListResult = DiscoveryOutput<CitationSourceDomain>;
