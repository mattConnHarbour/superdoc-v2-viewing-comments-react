import { MutationOptions } from '../write/write.js';
import { CitationListInput, CitationGetInput, CitationInsertInput, CitationUpdateInput, CitationRemoveInput, CitationInfo, CitationMutationResult, CitationsListResult, CitationSourceListInput, CitationSourceGetInput, CitationSourceInsertInput, CitationSourceUpdateInput, CitationSourceRemoveInput, CitationSourceInfo, CitationSourceMutationResult, CitationSourcesListResult, BibliographyInsertInput, BibliographyRebuildInput, BibliographyConfigureInput, BibliographyRemoveInput, BibliographyGetInput, BibliographyInfo, BibliographyMutationResult } from './citations.types.js';
export interface CitationsApi {
    list(query?: CitationListInput): CitationsListResult;
    get(input: CitationGetInput): CitationInfo;
    insert(input: CitationInsertInput, options?: MutationOptions): CitationMutationResult;
    update(input: CitationUpdateInput, options?: MutationOptions): CitationMutationResult;
    remove(input: CitationRemoveInput, options?: MutationOptions): CitationMutationResult;
    sources: {
        list(query?: CitationSourceListInput): CitationSourcesListResult;
        get(input: CitationSourceGetInput): CitationSourceInfo;
        insert(input: CitationSourceInsertInput, options?: MutationOptions): CitationSourceMutationResult;
        update(input: CitationSourceUpdateInput, options?: MutationOptions): CitationSourceMutationResult;
        remove(input: CitationSourceRemoveInput, options?: MutationOptions): CitationSourceMutationResult;
    };
    bibliography: {
        get(input: BibliographyGetInput): BibliographyInfo;
        insert(input: BibliographyInsertInput, options?: MutationOptions): BibliographyMutationResult;
        rebuild(input: BibliographyRebuildInput, options?: MutationOptions): BibliographyMutationResult;
        configure(input: BibliographyConfigureInput, options?: MutationOptions): BibliographyMutationResult;
        remove(input: BibliographyRemoveInput, options?: MutationOptions): BibliographyMutationResult;
    };
}
export type CitationsAdapter = CitationsApi;
export declare function executeCitationsList(adapter: CitationsAdapter, query?: CitationListInput): CitationsListResult;
export declare function executeCitationsGet(adapter: CitationsAdapter, input: CitationGetInput): CitationInfo;
export declare function executeCitationsInsert(adapter: CitationsAdapter, input: CitationInsertInput, options?: MutationOptions): CitationMutationResult;
export declare function executeCitationsUpdate(adapter: CitationsAdapter, input: CitationUpdateInput, options?: MutationOptions): CitationMutationResult;
export declare function executeCitationsRemove(adapter: CitationsAdapter, input: CitationRemoveInput, options?: MutationOptions): CitationMutationResult;
export declare function executeCitationSourcesList(adapter: CitationsAdapter, query?: CitationSourceListInput): CitationSourcesListResult;
export declare function executeCitationSourcesGet(adapter: CitationsAdapter, input: CitationSourceGetInput): CitationSourceInfo;
export declare function executeCitationSourcesInsert(adapter: CitationsAdapter, input: CitationSourceInsertInput, options?: MutationOptions): CitationSourceMutationResult;
export declare function executeCitationSourcesUpdate(adapter: CitationsAdapter, input: CitationSourceUpdateInput, options?: MutationOptions): CitationSourceMutationResult;
export declare function executeCitationSourcesRemove(adapter: CitationsAdapter, input: CitationSourceRemoveInput, options?: MutationOptions): CitationSourceMutationResult;
export declare function executeBibliographyGet(adapter: CitationsAdapter, input: BibliographyGetInput): BibliographyInfo;
export declare function executeBibliographyInsert(adapter: CitationsAdapter, input: BibliographyInsertInput, options?: MutationOptions): BibliographyMutationResult;
export declare function executeBibliographyRebuild(adapter: CitationsAdapter, input: BibliographyRebuildInput, options?: MutationOptions): BibliographyMutationResult;
export declare function executeBibliographyConfigure(adapter: CitationsAdapter, input: BibliographyConfigureInput, options?: MutationOptions): BibliographyMutationResult;
export declare function executeBibliographyRemove(adapter: CitationsAdapter, input: BibliographyRemoveInput, options?: MutationOptions): BibliographyMutationResult;
