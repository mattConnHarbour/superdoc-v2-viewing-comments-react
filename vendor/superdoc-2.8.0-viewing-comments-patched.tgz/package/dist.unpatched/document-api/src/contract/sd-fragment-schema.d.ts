type JsonSchema = Record<string, unknown>;
export declare const SD_CONVERSION_FRAGMENT_SCHEMA_DEFS: Record<string, JsonSchema>;
export declare const SD_CONVERSION_FRAGMENT_SCHEMA: JsonSchema;
export {};
