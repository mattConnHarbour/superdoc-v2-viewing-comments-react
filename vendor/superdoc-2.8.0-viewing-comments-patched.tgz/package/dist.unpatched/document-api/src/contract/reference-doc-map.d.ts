import { ReferenceGroupKey } from './operation-definitions.js';
import { OperationId } from './types.js';
export type { ReferenceGroupKey } from './operation-definitions.js';
export interface ReferenceOperationGroupDefinition {
    key: ReferenceGroupKey;
    title: string;
    description: string;
    pagePath: string;
    operations: readonly OperationId[];
}
export declare const OPERATION_REFERENCE_DOC_PATH_MAP: Record<OperationId, string>;
export declare const REFERENCE_OPERATION_GROUPS: readonly ReferenceOperationGroupDefinition[];
