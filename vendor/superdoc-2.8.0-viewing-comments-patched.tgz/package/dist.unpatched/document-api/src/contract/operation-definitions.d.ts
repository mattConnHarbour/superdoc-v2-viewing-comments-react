import { CommandStaticMetadata } from './metadata-types.js';
export type ReferenceGroupKey = 'core' | 'blocks' | 'capabilities' | 'create' | 'sections' | 'format' | 'format.paragraph' | 'styles' | 'styles.paragraph' | 'templates' | 'lists' | 'comments' | 'trackChanges' | 'query' | 'mutations' | 'tables' | 'history' | 'toc' | 'images' | 'hyperlinks' | 'headerFooters' | 'contentControls' | 'bookmarks' | 'footnotes' | 'clipboard' | 'crossRefs' | 'index' | 'captions' | 'fields' | 'citations' | 'authorities' | 'ranges' | 'selection' | 'diff' | 'export' | 'protection' | 'permissionRanges' | 'customXml' | 'metadata';
export interface OperationDefinitionEntry {
    memberPath: string;
    description: string;
    expectedResult: string;
    requiresDocumentContext: boolean;
    metadata: CommandStaticMetadata;
    referenceDocPath: string;
    referenceGroup: ReferenceGroupKey;
    skipAsATool?: boolean;
    /** Which intent tool this operation belongs to (e.g. 'edit' → superdoc_edit). */
    intentGroup?: string;
    /** Action enum value within the intent group (e.g. 'insert', 'replace'). */
    intentAction?: string;
}
export interface IntentGroupMeta {
    toolName: string;
    description: string;
    /**
     * Concrete input examples for LLM tool calling (e.g. Anthropic's input_examples).
     * Each example must be a valid input object for this tool.
     * Kept here (source of truth) and propagated to provider formats during codegen.
     */
    inputExamples?: Record<string, unknown>[];
}
export declare const V1_RUNTIME_UNAVAILABLE_OPERATION_IDS: readonly ["blocks.split", "blocks.merge", "blocks.move", "lists.getState", "lists.apply", "lists.continue", "lists.restart", "lists.remove", "format.paragraph.setMarkRunProps", "tables.moveRow"];
export declare const INTENT_GROUP_META: Record<string, IntentGroupMeta>;
export declare const OPERATION_DEFINITIONS: {
    readonly 'styles.apply': {
        readonly memberPath: "styles.apply";
        readonly description: "Apply document-level default style changes to the stylesheet (word/styles.xml). Targets docDefaults run and paragraph channels with set-style patch semantics.";
        readonly expectedResult: "Returns a StylesApplyReceipt with per-channel success/failure details for each property change.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "styles/apply.mdx";
        readonly referenceGroup: "styles";
    };
    readonly 'styles.getCatalog': {
        readonly memberPath: "styles.getCatalog";
        readonly description: "List the available styles as a normalized catalogue with stable IDs, display names, type, visibility, priority, provenance, and source diagnostics. Supports view (quickGallery/recommended/currentDocument/all/inUse), type filtering, hidden/latent inclusion, usage rollups, and UI-safe preview tokens. Distinct from DocumentInfo.styles, which is a usage summary.";
        readonly expectedResult: "Returns a StylesGetCatalogResult with the requested view, the full filtered style set, document defaults, per-source status, and diagnostics (including labeled fallbacks and unsupported-option notices).";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "styles/get-catalog.mdx";
        readonly referenceGroup: "styles";
    };
    readonly 'templates.apply': {
        readonly memberPath: "templates.apply";
        readonly description: "Apply detected DOCX template/substrate (styles, numbering, settings, theme, font table, web settings, headers/footers, section defaults) from a source package onto the current document, preserving body content. Scopes are auto-detected from source package evidence.";
        readonly expectedResult: "Returns a TemplatesApplyReceipt with detected/applied/skipped scopes, unsupported items, changed parts, id mappings, and warnings.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "templates/apply.mdx";
        readonly referenceGroup: "templates";
    };
    readonly 'create.paragraph': {
        readonly memberPath: "create.paragraph";
        readonly description: "Create a standalone paragraph at the target position. To add a list item, use lists.insert instead.";
        readonly expectedResult: "Returns a CreateParagraphResult with the new paragraph block ID and address.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "create/paragraph.mdx";
        readonly referenceGroup: "create";
        readonly intentGroup: "create";
        readonly intentAction: "paragraph";
    };
    readonly 'create.heading': {
        readonly memberPath: "create.heading";
        readonly description: "Create a new heading at the target position.";
        readonly expectedResult: "Returns a CreateHeadingResult with the new heading block ID and address.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "create/heading.mdx";
        readonly referenceGroup: "create";
        readonly intentGroup: "create";
        readonly intentAction: "heading";
    };
    readonly 'create.sectionBreak': {
        readonly memberPath: "create.sectionBreak";
        readonly description: "Create a section break at the target location with optional initial section properties.";
        readonly expectedResult: "Returns a CreateSectionBreakResult with the new section break position and section address.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "create/section-break.mdx";
        readonly referenceGroup: "create";
    };
    readonly 'sections.list': {
        readonly memberPath: "sections.list";
        readonly description: "List sections in deterministic order with section-target handles.";
        readonly expectedResult: "Returns a SectionsListResult with an ordered array of section summaries and their target handles.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "sections/list.mdx";
        readonly referenceGroup: "sections";
    };
    readonly 'sections.get': {
        readonly memberPath: "sections.get";
        readonly description: "Retrieve full section information by section address.";
        readonly expectedResult: "Returns a SectionInfo object with full section properties including margins, columns, and header/footer refs.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "sections/get.mdx";
        readonly referenceGroup: "sections";
    };
    readonly 'sections.setBreakType': {
        readonly memberPath: "sections.setBreakType";
        readonly description: "Set the section break type.";
        readonly expectedResult: "Returns a SectionMutationResult receipt; reports NO_OP if the section already has the requested break type.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "sections/set-break-type.mdx";
        readonly referenceGroup: "sections";
    };
    readonly 'sections.setPageMargins': {
        readonly memberPath: "sections.setPageMargins";
        readonly description: "Set page-edge margins for a section.";
        readonly expectedResult: "Returns a SectionMutationResult receipt; reports NO_OP if margins already match the requested values.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "sections/set-page-margins.mdx";
        readonly referenceGroup: "sections";
    };
    readonly 'sections.setHeaderFooterMargins': {
        readonly memberPath: "sections.setHeaderFooterMargins";
        readonly description: "Set header/footer margin distances for a section.";
        readonly expectedResult: "Returns a SectionMutationResult receipt; reports NO_OP if header/footer margins already match the requested values.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "sections/set-header-footer-margins.mdx";
        readonly referenceGroup: "sections";
    };
    readonly 'sections.setPageSetup': {
        readonly memberPath: "sections.setPageSetup";
        readonly description: "Set page size/orientation properties for a section.";
        readonly expectedResult: "Returns a SectionMutationResult receipt; reports NO_OP if page size and orientation already match the requested values.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "sections/set-page-setup.mdx";
        readonly referenceGroup: "sections";
    };
    readonly 'sections.setColumns': {
        readonly memberPath: "sections.setColumns";
        readonly description: "Set column configuration for a section.";
        readonly expectedResult: "Returns a SectionMutationResult receipt; reports NO_OP if column configuration already matches.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "sections/set-columns.mdx";
        readonly referenceGroup: "sections";
    };
    readonly 'sections.setLineNumbering': {
        readonly memberPath: "sections.setLineNumbering";
        readonly description: "Enable or configure line numbering for a section.";
        readonly expectedResult: "Returns a SectionMutationResult receipt; reports NO_OP if line numbering settings already match.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "sections/set-line-numbering.mdx";
        readonly referenceGroup: "sections";
    };
    readonly 'sections.setPageNumbering': {
        readonly memberPath: "sections.setPageNumbering";
        readonly description: "Set page numbering format/start and chapter numbering settings for a section.";
        readonly expectedResult: "Returns a SectionMutationResult receipt; reports NO_OP if page numbering settings already match.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "sections/set-page-numbering.mdx";
        readonly referenceGroup: "sections";
    };
    readonly 'sections.setTitlePage': {
        readonly memberPath: "sections.setTitlePage";
        readonly description: "Enable or disable title-page behavior for a section.";
        readonly expectedResult: "Returns a SectionMutationResult receipt; reports NO_OP if the title-page setting already matches.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "sections/set-title-page.mdx";
        readonly referenceGroup: "sections";
    };
    readonly 'sections.setOddEvenHeadersFooters': {
        readonly memberPath: "sections.setOddEvenHeadersFooters";
        readonly description: "Enable or disable odd/even header-footer mode in document settings.";
        readonly expectedResult: "Returns a DocumentMutationResult (not SectionMutationResult) because odd/even headers-footers is a document-level setting, not per-section. Reports NO_OP if the setting already matches.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "sections/set-odd-even-headers-footers.mdx";
        readonly referenceGroup: "sections";
    };
    readonly 'sections.setVerticalAlign': {
        readonly memberPath: "sections.setVerticalAlign";
        readonly description: "Set vertical page alignment for a section.";
        readonly expectedResult: "Returns a SectionMutationResult receipt; reports NO_OP if vertical alignment already matches.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "sections/set-vertical-align.mdx";
        readonly referenceGroup: "sections";
    };
    readonly 'sections.setSectionDirection': {
        readonly memberPath: "sections.setSectionDirection";
        readonly description: "Set section text flow direction (LTR/RTL).";
        readonly expectedResult: "Returns a SectionMutationResult receipt; reports NO_OP if text direction already matches.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "sections/set-section-direction.mdx";
        readonly referenceGroup: "sections";
    };
    readonly 'sections.setHeaderFooterRef': {
        readonly memberPath: "sections.setHeaderFooterRef";
        readonly description: "Set or replace a section header/footer reference for a variant.";
        readonly expectedResult: "Returns a SectionMutationResult receipt; reports NO_OP if the header/footer reference already matches.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "sections/set-header-footer-ref.mdx";
        readonly referenceGroup: "sections";
    };
    readonly 'sections.clearHeaderFooterRef': {
        readonly memberPath: "sections.clearHeaderFooterRef";
        readonly description: "Clear a section header/footer reference for a specific variant.";
        readonly expectedResult: "Returns a SectionMutationResult receipt; reports NO_OP if no reference exists for the specified variant.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "sections/clear-header-footer-ref.mdx";
        readonly referenceGroup: "sections";
    };
    readonly 'sections.setLinkToPrevious': {
        readonly memberPath: "sections.setLinkToPrevious";
        readonly description: "Set or clear link-to-previous behavior for a header/footer variant.";
        readonly expectedResult: "Returns a SectionMutationResult receipt; reports NO_OP if link-to-previous already matches the requested value.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "sections/set-link-to-previous.mdx";
        readonly referenceGroup: "sections";
    };
    readonly 'sections.setPageBorders': {
        readonly memberPath: "sections.setPageBorders";
        readonly description: "Set page border configuration for a section.";
        readonly expectedResult: "Returns a SectionMutationResult receipt; reports NO_OP if page border configuration already matches.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "sections/set-page-borders.mdx";
        readonly referenceGroup: "sections";
    };
    readonly 'sections.clearPageBorders': {
        readonly memberPath: "sections.clearPageBorders";
        readonly description: "Clear page border configuration for a section.";
        readonly expectedResult: "Returns a SectionMutationResult receipt; reports NO_OP if no page borders are configured on the section.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "sections/clear-page-borders.mdx";
        readonly referenceGroup: "sections";
    };
    readonly 'styles.paragraph.setStyle': {
        readonly memberPath: "styles.paragraph.setStyle";
        readonly description: "Apply a paragraph style (w:pStyle) to a paragraph-like block, clearing direct run formatting while preserving character-style references.";
        readonly expectedResult: "Returns a ParagraphMutationResult; reports NO_OP if the style already matches. When the style changes, direct run formatting is cleared while character-style references are preserved.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "styles/paragraph/set-style.mdx";
        readonly referenceGroup: "styles.paragraph";
        readonly intentGroup: "format";
        readonly intentAction: "set_style";
    };
    readonly 'styles.paragraph.setStyleRef': {
        readonly memberPath: "styles.paragraph.setStyleRef";
        readonly description: "Apply a paragraph style (w:pStyle) to a paragraph-like block without clearing direct run formatting.";
        readonly expectedResult: "Returns a ParagraphMutationResult; reports NO_OP if the style reference already matches. Unlike setStyle, existing run formatting is preserved.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "styles/paragraph/set-style-ref.mdx";
        readonly referenceGroup: "styles.paragraph";
        readonly intentGroup: "format";
        readonly intentAction: "set_style_ref";
    };
    readonly 'styles.paragraph.clearStyle': {
        readonly memberPath: "styles.paragraph.clearStyle";
        readonly description: "Remove the paragraph style reference from a paragraph-like block.";
        readonly expectedResult: "Returns a ParagraphMutationResult; reports NO_OP if no style is set.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "styles/paragraph/clear-style.mdx";
        readonly referenceGroup: "styles.paragraph";
    };
    readonly 'format.paragraph.resetDirectFormatting': {
        readonly memberPath: "format.paragraph.resetDirectFormatting";
        readonly description: "Strip all direct paragraph formatting while preserving style reference, numbering, and section metadata.";
        readonly expectedResult: "Returns a ParagraphMutationResult; reports NO_OP if no direct formatting is present.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "format/paragraph/reset-direct-formatting.mdx";
        readonly referenceGroup: "format.paragraph";
    };
    readonly 'format.paragraph.setAlignment': {
        readonly memberPath: "format.paragraph.setAlignment";
        readonly description: "Set visual paragraph alignment on a paragraph-like block. For RTL paragraphs, left/right are translated to Word-compatible stored justification values.";
        readonly expectedResult: "Returns a ParagraphMutationResult; reports NO_OP if the alignment already matches.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "format/paragraph/set-alignment.mdx";
        readonly referenceGroup: "format.paragraph";
        readonly intentGroup: "format";
        readonly intentAction: "set_alignment";
    };
    readonly 'format.paragraph.clearAlignment': {
        readonly memberPath: "format.paragraph.clearAlignment";
        readonly description: "Remove direct paragraph alignment, reverting to style-defined or default alignment.";
        readonly expectedResult: "Returns a ParagraphMutationResult; reports NO_OP if no direct alignment is set.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "format/paragraph/clear-alignment.mdx";
        readonly referenceGroup: "format.paragraph";
    };
    readonly 'format.paragraph.setIndentation': {
        readonly memberPath: "format.paragraph.setIndentation";
        readonly description: "Set paragraph indentation properties (signed left/right, firstLine, hanging) in twips.";
        readonly expectedResult: "Returns a ParagraphMutationResult; reports NO_OP if indentation already matches.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "format/paragraph/set-indentation.mdx";
        readonly referenceGroup: "format.paragraph";
        readonly intentGroup: "format";
        readonly intentAction: "set_indentation";
    };
    readonly 'format.paragraph.clearIndentation': {
        readonly memberPath: "format.paragraph.clearIndentation";
        readonly description: "Remove all direct paragraph indentation.";
        readonly expectedResult: "Returns a ParagraphMutationResult; reports NO_OP if no direct indentation is set.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "format/paragraph/clear-indentation.mdx";
        readonly referenceGroup: "format.paragraph";
    };
    readonly 'format.paragraph.setSpacing': {
        readonly memberPath: "format.paragraph.setSpacing";
        readonly description: "Set paragraph spacing properties (before, after, line, lineRule) in twips.";
        readonly expectedResult: "Returns a ParagraphMutationResult; reports NO_OP if spacing already matches.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "format/paragraph/set-spacing.mdx";
        readonly referenceGroup: "format.paragraph";
        readonly intentGroup: "format";
        readonly intentAction: "set_spacing";
    };
    readonly 'format.paragraph.clearSpacing': {
        readonly memberPath: "format.paragraph.clearSpacing";
        readonly description: "Remove all direct paragraph spacing.";
        readonly expectedResult: "Returns a ParagraphMutationResult; reports NO_OP if no direct spacing is set.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "format/paragraph/clear-spacing.mdx";
        readonly referenceGroup: "format.paragraph";
    };
    readonly 'format.paragraph.setKeepOptions': {
        readonly memberPath: "format.paragraph.setKeepOptions";
        readonly description: "Set keep-with-next, keep-lines-together, and widow/orphan control flags.";
        readonly expectedResult: "Returns a ParagraphMutationResult; reports NO_OP if all flags already match.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "format/paragraph/set-keep-options.mdx";
        readonly referenceGroup: "format.paragraph";
    };
    readonly 'format.paragraph.setOutlineLevel': {
        readonly memberPath: "format.paragraph.setOutlineLevel";
        readonly description: "Set the paragraph outline level (0–9) or null to clear.";
        readonly expectedResult: "Returns a ParagraphMutationResult; reports NO_OP if outline level already matches.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "format/paragraph/set-outline-level.mdx";
        readonly referenceGroup: "format.paragraph";
    };
    readonly 'format.paragraph.setFlowOptions': {
        readonly memberPath: "format.paragraph.setFlowOptions";
        readonly description: "Set paragraph flow flags: contextual spacing, page-break-before, suppress-auto-hyphens, and the advanced layout toggles auto-space-DE, auto-space-DN, adjust-right-indent, and snap-to-grid.";
        readonly expectedResult: "Returns a ParagraphMutationResult; reports NO_OP if all flags already match.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "format/paragraph/set-flow-options.mdx";
        readonly referenceGroup: "format.paragraph";
        readonly intentGroup: "format";
        readonly intentAction: "set_flow_options";
    };
    readonly 'format.paragraph.setTabStop': {
        readonly memberPath: "format.paragraph.setTabStop";
        readonly description: "Add or replace a tab stop at a given position.";
        readonly expectedResult: "Returns a ParagraphMutationResult; reports NO_OP if an identical tab stop already exists.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "format/paragraph/set-tab-stop.mdx";
        readonly referenceGroup: "format.paragraph";
    };
    readonly 'format.paragraph.clearTabStop': {
        readonly memberPath: "format.paragraph.clearTabStop";
        readonly description: "Remove a tab stop at a given position.";
        readonly expectedResult: "Returns a ParagraphMutationResult; reports NO_OP if no tab stop exists at that position.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "format/paragraph/clear-tab-stop.mdx";
        readonly referenceGroup: "format.paragraph";
    };
    readonly 'format.paragraph.clearAllTabStops': {
        readonly memberPath: "format.paragraph.clearAllTabStops";
        readonly description: "Remove all tab stops from a paragraph.";
        readonly expectedResult: "Returns a ParagraphMutationResult; reports NO_OP if no tab stops exist.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "format/paragraph/clear-all-tab-stops.mdx";
        readonly referenceGroup: "format.paragraph";
    };
    readonly 'format.paragraph.setBorder': {
        readonly memberPath: "format.paragraph.setBorder";
        readonly description: "Set border properties for a specific side of a paragraph.";
        readonly expectedResult: "Returns a ParagraphMutationResult; reports NO_OP if the border already matches.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "format/paragraph/set-border.mdx";
        readonly referenceGroup: "format.paragraph";
    };
    readonly 'format.paragraph.clearBorder': {
        readonly memberPath: "format.paragraph.clearBorder";
        readonly description: "Remove border for a specific side or all sides of a paragraph.";
        readonly expectedResult: "Returns a ParagraphMutationResult; reports NO_OP if the border is already absent.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "format/paragraph/clear-border.mdx";
        readonly referenceGroup: "format.paragraph";
    };
    readonly 'format.paragraph.setShading': {
        readonly memberPath: "format.paragraph.setShading";
        readonly description: "Set paragraph shading (background fill, pattern color, pattern type).";
        readonly expectedResult: "Returns a ParagraphMutationResult; reports NO_OP if the shading already matches.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "format/paragraph/set-shading.mdx";
        readonly referenceGroup: "format.paragraph";
    };
    readonly 'format.paragraph.clearShading': {
        readonly memberPath: "format.paragraph.clearShading";
        readonly description: "Remove all paragraph shading.";
        readonly expectedResult: "Returns a ParagraphMutationResult; reports NO_OP if no shading is set.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "format/paragraph/clear-shading.mdx";
        readonly referenceGroup: "format.paragraph";
    };
    readonly 'format.paragraph.setMarkRunProps': {
        readonly memberPath: "format.paragraph.setMarkRunProps";
        readonly description: string;
        readonly expectedResult: "Returns a ParagraphMutationResult; reports NO_OP if the encoded mark run properties already match.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "format/paragraph/set-mark-run-props.mdx";
        readonly referenceGroup: "format.paragraph";
    };
    readonly 'format.paragraph.setDirection': {
        readonly memberPath: "format.paragraph.setDirection";
        readonly description: "Set paragraph base direction (LTR or RTL via w:bidi). Optionally align text to match.";
        readonly expectedResult: "Returns a ParagraphMutationResult; reports NO_OP if the direction already matches.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "format/paragraph/set-direction.mdx";
        readonly referenceGroup: "format.paragraph";
        readonly intentGroup: "format";
        readonly intentAction: "set_direction";
    };
    readonly 'format.paragraph.clearDirection': {
        readonly memberPath: "format.paragraph.clearDirection";
        readonly description: "Remove explicit paragraph direction, reverting to inherited or default (LTR).";
        readonly expectedResult: "Returns a ParagraphMutationResult; reports NO_OP if no direction is set.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "format/paragraph/clear-direction.mdx";
        readonly referenceGroup: "format.paragraph";
    };
    readonly 'format.paragraph.setNumbering': {
        readonly memberPath: "format.paragraph.setNumbering";
        readonly description: "Attach numbering (numId + level) to an existing paragraph or heading so it joins a numbered sequence. Numbering is a paragraph property; the node and its style are otherwise unchanged, though any direct paragraph indent is cleared so the numbering level controls indentation. Direct edits only; tracked mode is unsupported.";
        readonly expectedResult: "Returns a ParagraphMutationResult; reports NO_OP if the block already carries this numbering. On a successful apply, resolution.target reflects the post-mutation address (a numbered plain paragraph re-resolves to listItem; a heading stays a heading); a dryRun returns the input target.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "format/paragraph/set-numbering.mdx";
        readonly referenceGroup: "format.paragraph";
    };
    readonly 'lists.list': {
        readonly memberPath: "lists.list";
        readonly description: "List all list nodes in the document, optionally filtered by scope.";
        readonly expectedResult: "Returns a ListsListResult with an array of list item summaries and total count.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "lists/list.mdx";
        readonly referenceGroup: "lists";
    };
    readonly 'lists.get': {
        readonly memberPath: "lists.get";
        readonly description: "Retrieve a specific list node by target.";
        readonly expectedResult: "Returns a ListItemInfo object with the item kind, level, marker, and address.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "lists/get.mdx";
        readonly referenceGroup: "lists";
    };
    readonly 'lists.insert': {
        readonly memberPath: "lists.insert";
        readonly description: "Insert a new list item before or after an existing list item. The new item inherits the target list context.";
        readonly expectedResult: "Returns a ListsInsertResult with the new list item address and block ID.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "lists/insert.mdx";
        readonly referenceGroup: "lists";
        readonly intentGroup: "list";
        readonly intentAction: "insert";
    };
    readonly 'lists.create': {
        readonly memberPath: "lists.create";
        readonly description: "Create a new list from one or more paragraphs. Supports optional preset or style for new sequences. When sequence.mode is \"continuePrevious\", preset and style are not allowed: the new items inherit formatting from the previous sequence.";
        readonly expectedResult: "Returns a ListsCreateResult with the new listId and the first item address.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "lists/create.mdx";
        readonly referenceGroup: "lists";
        readonly intentGroup: "list";
        readonly intentAction: "create";
    };
    readonly 'lists.attach': {
        readonly memberPath: "lists.attach";
        readonly description: "Convert non-list paragraphs to list items under an existing list sequence.";
        readonly expectedResult: "Returns a ListsMutateItemResult confirming attachment. Tracked-mode results include `trackedChangeRefs` pointing at the pPrChange-backed numPr revision.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "lists/attach.mdx";
        readonly referenceGroup: "lists";
        readonly intentGroup: "list";
        readonly intentAction: "attach";
    };
    readonly 'lists.detach': {
        readonly memberPath: "lists.detach";
        readonly description: "Remove numbering properties from list items, converting them to plain paragraphs.";
        readonly expectedResult: "Returns a ListsDetachResult confirming the item was converted to a plain paragraph.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "lists/detach.mdx";
        readonly referenceGroup: "lists";
        readonly intentGroup: "list";
        readonly intentAction: "detach";
    };
    readonly 'lists.delete': {
        readonly memberPath: "lists.delete";
        readonly description: string;
        readonly expectedResult: "Returns a ListsDeleteResult with `deletedCount` (number of items removed). Reports failure (INVALID_TARGET) if the target is not a list item.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "lists/delete.mdx";
        readonly referenceGroup: "lists";
        readonly intentGroup: "list";
        readonly intentAction: "delete";
    };
    readonly 'lists.indent': {
        readonly memberPath: "lists.indent";
        readonly description: "Increase the indentation level of a list item.";
        readonly expectedResult: "Returns a ListsMutateItemResult receipt; reports NO_OP if the item is already at maximum indent level.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "lists/indent.mdx";
        readonly referenceGroup: "lists";
        readonly intentGroup: "list";
        readonly intentAction: "indent";
    };
    readonly 'lists.outdent': {
        readonly memberPath: "lists.outdent";
        readonly description: "Decrease the indentation level of a list item.";
        readonly expectedResult: "Returns a ListsMutateItemResult receipt; reports NO_OP if the item is already at the root level.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "lists/outdent.mdx";
        readonly referenceGroup: "lists";
        readonly intentGroup: "list";
        readonly intentAction: "outdent";
    };
    readonly 'lists.join': {
        readonly memberPath: "lists.join";
        readonly description: "Merge two adjacent list sequences into one.";
        readonly expectedResult: "Returns a ListsJoinResult with the resulting listId of the merged sequence.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "lists/join.mdx";
        readonly referenceGroup: "lists";
    };
    readonly 'lists.canJoin': {
        readonly memberPath: "lists.canJoin";
        readonly description: "Check whether two adjacent list sequences can be joined.";
        readonly expectedResult: "Returns a ListsCanJoinResult indicating feasibility and reason if not possible.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "lists/can-join.mdx";
        readonly referenceGroup: "lists";
    };
    readonly 'lists.separate': {
        readonly memberPath: "lists.separate";
        readonly description: "Split a list sequence at the target item, creating a new sequence from that point forward.";
        readonly expectedResult: "Returns a ListsSeparateResult with the new listId and numId.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "lists/separate.mdx";
        readonly referenceGroup: "lists";
    };
    readonly 'lists.merge': {
        readonly memberPath: "lists.merge";
        readonly description: "Compound: merge two adjacent list sequences into one. Reassigns numId on the absorbed sequence (no strict abstractNumId check: absorbed items adopt the absorbing definition) and deletes empty paragraphs between the two sequences. Use this instead of lists.join for the user-facing \"merge these lists\" intent.";
        readonly expectedResult: "Returns a ListsMergeResult with the merged listId, absorbedCount, and removedEmptyBlocks count.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "lists/merge.mdx";
        readonly referenceGroup: "lists";
        readonly intentGroup: "list";
        readonly intentAction: "merge";
    };
    readonly 'lists.split': {
        readonly memberPath: "lists.split";
        readonly description: "Compound: split a list sequence at the target item into two independent sequences. Runs lists.separate then (by default) lists.setValue(1) so the new half starts numbering fresh at 1. Pass restartNumbering:false for raw separate semantics (new half continues the previous count).";
        readonly expectedResult: "Returns a ListsSplitResult with the new listId, numId, and the restart value applied (or null).";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "lists/split.mdx";
        readonly referenceGroup: "lists";
        readonly intentGroup: "list";
        readonly intentAction: "split";
    };
    readonly 'lists.setLevel': {
        readonly memberPath: "lists.setLevel";
        readonly description: "Set the absolute nesting level (0..8) of a list item.";
        readonly expectedResult: "Returns a ListsMutateItemResult receipt; reports NO_OP if already at the target level.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "lists/set-level.mdx";
        readonly referenceGroup: "lists";
        readonly intentGroup: "list";
        readonly intentAction: "set_level";
    };
    readonly 'lists.setValue': {
        readonly memberPath: "lists.setValue";
        readonly description: "Set an explicit numbering value at the target item. Mid-sequence targets are atomically separated first.";
        readonly expectedResult: "Returns a ListsMutateItemResult receipt.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "lists/set-value.mdx";
        readonly referenceGroup: "lists";
        readonly intentGroup: "list";
        readonly intentAction: "set_value";
    };
    readonly 'lists.continuePrevious': {
        readonly memberPath: "lists.continuePrevious";
        readonly description: "Continue numbering from the nearest compatible previous list sequence.";
        readonly expectedResult: "Returns a ListsMutateItemResult receipt.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "lists/continue-previous.mdx";
        readonly referenceGroup: "lists";
        readonly intentGroup: "list";
        readonly intentAction: "continue_previous";
    };
    readonly 'lists.canContinuePrevious': {
        readonly memberPath: "lists.canContinuePrevious";
        readonly description: "Check whether the target sequence can continue numbering from a previous compatible sequence.";
        readonly expectedResult: "Returns a ListsCanContinuePreviousResult indicating feasibility.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "lists/can-continue-previous.mdx";
        readonly referenceGroup: "lists";
    };
    readonly 'lists.setLevelRestart': {
        readonly memberPath: "lists.setLevelRestart";
        readonly description: "Set the restart behavior for a specific list level.";
        readonly expectedResult: "Returns a ListsMutateItemResult receipt.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "lists/set-level-restart.mdx";
        readonly referenceGroup: "lists";
    };
    readonly 'lists.convertToText': {
        readonly memberPath: "lists.convertToText";
        readonly description: "Convert list items to plain paragraphs, optionally prepending the rendered marker text.";
        readonly expectedResult: "Returns a ListsConvertToTextResult confirming the conversion.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "lists/convert-to-text.mdx";
        readonly referenceGroup: "lists";
    };
    readonly 'lists.applyTemplate': {
        readonly memberPath: "lists.applyTemplate";
        readonly description: "Advanced alias for lists.applyStyle. Apply a captured ListTemplate to the target list (abstract-scoped, no clone-on-write).";
        readonly expectedResult: "Returns a ListsMutateItemResult receipt; reports NO_OP if all levels already match.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "lists/apply-template.mdx";
        readonly referenceGroup: "lists";
    };
    readonly 'lists.applyPreset': {
        readonly memberPath: "lists.applyPreset";
        readonly description: "Apply a built-in list formatting preset to the target list.";
        readonly expectedResult: "Returns a ListsMutateItemResult receipt; reports NO_OP if all levels already match the preset.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "lists/apply-preset.mdx";
        readonly referenceGroup: "lists";
    };
    readonly 'lists.setType': {
        readonly memberPath: "lists.setType";
        readonly description: "Convert a list to ordered or bullet and merge adjacent compatible sequences to preserve continuous numbering.";
        readonly expectedResult: "Returns a ListsMutateItemResult receipt; reports NO_OP if the list is already the requested kind and no sequences were merged.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "lists/set-type.mdx";
        readonly referenceGroup: "lists";
        readonly intentGroup: "list";
        readonly intentAction: "set_type";
    };
    readonly 'lists.captureTemplate': {
        readonly memberPath: "lists.captureTemplate";
        readonly description: "Advanced alias for lists.getStyle. Capture list formatting from the abstract definition only (does not merge lvlOverride formatting).";
        readonly expectedResult: "Returns a ListsCaptureTemplateResult containing the captured template.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "lists/capture-template.mdx";
        readonly referenceGroup: "lists";
    };
    readonly 'lists.setLevelNumbering': {
        readonly memberPath: "lists.setLevelNumbering";
        readonly description: "Advanced alias for lists.setLevelNumberStyle/setLevelText/setLevelStart. Set format, pattern, and start in one call (abstract-scoped, no clone-on-write).";
        readonly expectedResult: "Returns a ListsMutateItemResult receipt; reports NO_OP if the level already matches.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "lists/set-level-numbering.mdx";
        readonly referenceGroup: "lists";
    };
    readonly 'lists.setLevelBullet': {
        readonly memberPath: "lists.setLevelBullet";
        readonly description: "Set the bullet marker text for a specific list level.";
        readonly expectedResult: "Returns a ListsMutateItemResult receipt; reports NO_OP if the marker already matches.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "lists/set-level-bullet.mdx";
        readonly referenceGroup: "lists";
    };
    readonly 'lists.setLevelPictureBullet': {
        readonly memberPath: "lists.setLevelPictureBullet";
        readonly description: "Set a picture bullet for a specific list level by its OOXML lvlPicBulletId.";
        readonly expectedResult: "Returns a ListsMutateItemResult receipt; reports NO_OP if the picture bullet already matches.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "lists/set-level-picture-bullet.mdx";
        readonly referenceGroup: "lists";
    };
    readonly 'lists.setLevelAlignment': {
        readonly memberPath: "lists.setLevelAlignment";
        readonly description: "Set the marker alignment (left, center, right) for a specific list level.";
        readonly expectedResult: "Returns a ListsMutateItemResult receipt; reports NO_OP if the alignment already matches.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "lists/set-level-alignment.mdx";
        readonly referenceGroup: "lists";
    };
    readonly 'lists.setLevelIndents': {
        readonly memberPath: "lists.setLevelIndents";
        readonly description: "Set the paragraph indentation values (left, hanging, firstLine) for a specific list level.";
        readonly expectedResult: "Returns a ListsMutateItemResult receipt; reports NO_OP if all indent values already match.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "lists/set-level-indents.mdx";
        readonly referenceGroup: "lists";
    };
    readonly 'lists.setLevelTrailingCharacter': {
        readonly memberPath: "lists.setLevelTrailingCharacter";
        readonly description: "Set the trailing character (tab, space, nothing) after the marker for a specific list level.";
        readonly expectedResult: "Returns a ListsMutateItemResult receipt; reports NO_OP if the trailing character already matches.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "lists/set-level-trailing-character.mdx";
        readonly referenceGroup: "lists";
    };
    readonly 'lists.setLevelMarkerFont': {
        readonly memberPath: "lists.setLevelMarkerFont";
        readonly description: "Set the font family used for the marker character at a specific list level.";
        readonly expectedResult: "Returns a ListsMutateItemResult receipt; reports NO_OP if the font already matches.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "lists/set-level-marker-font.mdx";
        readonly referenceGroup: "lists";
    };
    readonly 'lists.clearLevelOverrides': {
        readonly memberPath: "lists.clearLevelOverrides";
        readonly description: "Remove instance-level overrides for a specific list level, restoring abstract definition values.";
        readonly expectedResult: "Returns a ListsMutateItemResult receipt; reports NO_OP if no override exists.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "lists/clear-level-overrides.mdx";
        readonly referenceGroup: "lists";
    };
    readonly 'lists.getStyle': {
        readonly memberPath: "lists.getStyle";
        readonly description: "Read the effective reusable style of a list, including instance-level overrides. Returns a ListStyle that can be applied to other lists via lists.applyStyle.";
        readonly expectedResult: "Returns a ListsGetStyleResult containing the captured style.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "lists/get-style.mdx";
        readonly referenceGroup: "lists";
    };
    readonly 'lists.applyStyle': {
        readonly memberPath: "lists.applyStyle";
        readonly description: "Apply a reusable list style to the target list. Sequence-local: if the abstract definition is shared with other lists, it is cloned first to avoid affecting them.";
        readonly expectedResult: "Returns a ListsMutateItemResult receipt; reports NO_OP if all levels already match.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "lists/apply-style.mdx";
        readonly referenceGroup: "lists";
    };
    readonly 'lists.restartAt': {
        readonly memberPath: "lists.restartAt";
        readonly description: "Restart numbering at the target list item with a specific value. If the item is mid-sequence, it is separated first.";
        readonly expectedResult: "Returns a ListsMutateItemResult receipt.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "lists/restart-at.mdx";
        readonly referenceGroup: "lists";
    };
    readonly 'lists.setLevelNumberStyle': {
        readonly memberPath: "lists.setLevelNumberStyle";
        readonly description: "Set the numbering style (e.g. decimal, lowerLetter, upperRoman) for a specific list level. Rejects \"bullet\": use setLevelBullet instead. Sequence-local: clones shared definitions.";
        readonly expectedResult: "Returns a ListsMutateItemResult receipt; reports NO_OP if the value already matches.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "lists/set-level-number-style.mdx";
        readonly referenceGroup: "lists";
    };
    readonly 'lists.setLevelText': {
        readonly memberPath: "lists.setLevelText";
        readonly description: "Set the level text pattern (e.g. \"%1.\", \"(%1)\") for a specific list level. Uses OOXML level-placeholder syntax. Sequence-local: clones shared definitions.";
        readonly expectedResult: "Returns a ListsMutateItemResult receipt; reports NO_OP if the value already matches.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "lists/set-level-text.mdx";
        readonly referenceGroup: "lists";
    };
    readonly 'lists.setLevelStart': {
        readonly memberPath: "lists.setLevelStart";
        readonly description: "Set the start value for a specific list level. Rejects bullet levels and non-positive values. Sequence-local: clones shared definitions.";
        readonly expectedResult: "Returns a ListsMutateItemResult receipt; reports NO_OP if the value already matches.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "lists/set-level-start.mdx";
        readonly referenceGroup: "lists";
    };
    readonly 'lists.setLevelLayout': {
        readonly memberPath: "lists.setLevelLayout";
        readonly description: "Set the layout properties (alignment, indentation, trailing character, tab stop) for a specific list level. Accepts partial updates: omitted fields are left unchanged. Sequence-local: clones shared definitions.";
        readonly expectedResult: "Returns a ListsMutateItemResult receipt; reports NO_OP if all values already match.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "lists/set-level-layout.mdx";
        readonly referenceGroup: "lists";
    };
    readonly 'lists.getState': {
        readonly memberPath: "lists.getState";
        readonly description: string;
        readonly expectedResult: "Returns a ListsGetStateResult with `isListItem` plus numId/ilvl/abstract/numFmt metadata when present.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "lists/get-state.mdx";
        readonly referenceGroup: "lists";
    };
    readonly 'lists.apply': {
        readonly memberPath: "lists.apply";
        readonly description: string;
        readonly expectedResult: "Returns a ListsMutateItemResult receipt with txId; partsChanged includes numbering / content-types / rels when first-list materialization fires.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "lists/apply.mdx";
        readonly referenceGroup: "lists";
    };
    readonly 'lists.continue': {
        readonly memberPath: "lists.continue";
        readonly description: string;
        readonly expectedResult: "Returns a ListsMutateItemResult receipt with txId.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "lists/continue.mdx";
        readonly referenceGroup: "lists";
    };
    readonly 'lists.restart': {
        readonly memberPath: "lists.restart";
        readonly description: string;
        readonly expectedResult: "Returns a ListsMutateItemResult receipt with txId; partsChanged includes /word/numbering.xml.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "lists/restart.mdx";
        readonly referenceGroup: "lists";
    };
    readonly 'lists.remove': {
        readonly memberPath: "lists.remove";
        readonly description: string;
        readonly expectedResult: "Returns a ListsMutateItemResult receipt with txId.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "lists/remove.mdx";
        readonly referenceGroup: "lists";
    };
    readonly 'comments.create': {
        readonly memberPath: "comments.create";
        readonly description: "Create a new comment thread (or reply when parentCommentId is given). Accepts TextAddress / TextTarget anchors, or a TrackedChangeCommentTarget that names a logical tracked-change id. The tracked-change target accepts both the explicit kind form and the Labs-compatible trackedChangeId-only form; the adapter normalizes it to a Word-compatible content anchor on the requested revision side. Callers may supply a durable externalId, or use the v1-compatible caller-supplied commentId alias, plus author fields and arbitrary JSON metadata for integration correlation. The caller-owned id remains distinct from the generated Word-compatible commentId.";
        readonly expectedResult: "Returns a Receipt with the new commentId in `id` and `inserted` on success; rejects whitespace-only bodies, unsupported anchor contexts, and cross-story targets. Tracked-change comment targets support insertion, deletion, replacement, and paired-move revisions; they fail with `TARGET_NOT_FOUND` for stale ids, `CAPABILITY_UNAVAILABLE` for formatting / structural revisions and unpaired move sides, and `INVALID_TARGET` for incompatible side requests or ambiguous replacement targets that omit a required `side`.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "comments/create.mdx";
        readonly referenceGroup: "comments";
        readonly intentGroup: "comment";
        readonly intentAction: "create";
    };
    readonly 'comments.patch': {
        readonly memberPath: "comments.patch";
        readonly description: "Patch exactly one field on an existing comment (`text`, `target`, `status`, or `isInternal`). The `target` branch accepts a plain TextAddress or a TrackedChangeCommentTarget, with or without `kind: \"trackedChange\"`, that names a logical tracked-change id. The legacy `isInternal` input sets or clears the `sdcom:internal` attribute for v1 backward compatibility. Multi-field patches and no-op edits are rejected with `INVALID_INPUT`; reply target / status patches are rejected with `INVALID_CONTEXT`.";
        readonly expectedResult: "Returns a Receipt with `updated` populated on success. Reports `NO_OP` for byte-identical edits, rejects empty-body / trim-equivalent edits with `INVALID_INPUT`, no-op resolve/reopen/setInternal with `INVALID_INPUT`, reply target/status with `INVALID_CONTEXT`, cross-story moves with `INVALID_CONTEXT`, materializing inherited slot moves with `CAPABILITY_UNAVAILABLE`, stale tracked-change targets with `TARGET_NOT_FOUND`, and formatting / structural / unpaired-move tracked-change targets with `CAPABILITY_UNAVAILABLE`.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "comments/patch.mdx";
        readonly referenceGroup: "comments";
        readonly intentGroup: "comment";
        readonly intentAction: "update";
    };
    readonly 'comments.delete': {
        readonly memberPath: "comments.delete";
        readonly description: "Remove the targeted comment or reply by ID. Deleting a root does not delete descendant replies.";
        readonly expectedResult: "Returns a Receipt with the targeted removed commentId in `removed` and every story touched in `affectedStories`. Rejects with `TARGET_NOT_FOUND` when the comment id does not exist and reports `NO_OP` when the command layer accepts the target but removes nothing.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "comments/delete.mdx";
        readonly referenceGroup: "comments";
        readonly intentGroup: "comment";
        readonly intentAction: "delete";
    };
    readonly 'comments.get': {
        readonly memberPath: "comments.get";
        readonly description: "Retrieve a single comment thread by ID.";
        readonly expectedResult: "Returns a CommentInfo object with the comment text, author, date, and thread metadata.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "comments/get.mdx";
        readonly referenceGroup: "comments";
        readonly intentGroup: "comment";
        readonly intentAction: "get";
    };
    readonly 'comments.list': {
        readonly memberPath: "comments.list";
        readonly description: "List all comment threads in the document.";
        readonly expectedResult: "Returns a CommentsListResult with an array of comment threads and total count.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "comments/list.mdx";
        readonly referenceGroup: "comments";
        readonly intentGroup: "comment";
        readonly intentAction: "list";
    };
    readonly 'trackChanges.list': {
        readonly memberPath: "trackChanges.list";
        readonly description: "List tracked changes in the document. Body-only by default; pass `in: <StoryLocator>` or `in: \"all\"` to widen scope.";
        readonly expectedResult: "Returns a TrackChangesListResult of logical tracked-change entries with SuperDoc ids, semantic type/subtype, author/date/excerpt, revisionGroupId, flat projection fields (`grouping`, `insertedText`, `deletedText`, `formattingDeltaSummary`, `origin`, `imported`, `canonicalizationKind`, `addressKind`, `resolvableById`), optional overlap metadata, and source provenance via `sourceIds` / `wordRevisionIds`. Structural whole-table changes surface subtypes such as `table-insert` and `table-delete`.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "track-changes/list.mdx";
        readonly referenceGroup: "trackChanges";
        readonly intentGroup: "track_changes";
        readonly intentAction: "list";
    };
    readonly 'trackChanges.get': {
        readonly memberPath: "trackChanges.get";
        readonly description: "Retrieve a single tracked change by SuperDoc logical id.";
        readonly expectedResult: "Returns a TrackChangeInfo object with the logical id, semantic type/subtype, state, target, before/after snapshots, author/initials/email, date, revisionGroupId, splitFromId, replacement or move side metadata when applicable, story locator, excerpt, optional overlap metadata, and source provenance via `sourceIds` / `wordRevisionIds`. Structural whole-table changes surface subtypes such as `table-insert` and `table-delete`.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "track-changes/get.mdx";
        readonly referenceGroup: "trackChanges";
    };
    readonly 'trackChanges.decide': {
        readonly memberPath: "trackChanges.decide";
        readonly description: "Accept or reject tracked changes by logical id, by several logical ids atomically, by selected text range, by logical anchor range ({ anchor, relativeStart, relativeEnd }), or every active change in the document. Range targets may include overlap / side selectors and may partially resolve a change, splitting surviving content into new fragments with stable ids. Legacy `{ id, range: { kind: \"partial\", ... } }` targets are promoted only when the active adapter supports `decide()`; legacy fallback adapters fail closed with `INVALID_INPUT`. `input.expectedRevision` is accepted as a compatibility alias for mutation options.";
        readonly expectedResult: "Returns a Receipt. `removed` lists retired tracked-change ids; `inserted` lists successor fragment ids produced by partial range splits; `invalidatedRefs` lists every retired tracked-change ref plus cascade-deleted comment ids; `remappedRefs` carries surviving comment anchors moved by the decision; `affectedStories` lists touched stories; `textRangeShifts` reports per-story visible-text deltas; `txId` correlates with history. Failures: SPAN_FRAGMENTED when a range crosses an indivisible boundary, CAPABILITY_UNAVAILABLE for formatting / structural / move targets (not yet supported), TARGET_NOT_FOUND for retired ids or zero overlap, STALE_REVISION for stale expectedRevision, REVISION_MISMATCH for stale range coverage, NO_OP when { kind: 'all' } resolves an empty target set.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "track-changes/decide.mdx";
        readonly referenceGroup: "trackChanges";
        readonly intentGroup: "track_changes";
        readonly intentAction: "decide";
    };
    readonly 'query.match': {
        readonly memberPath: "query.match";
        readonly description: "Deterministic selector-based search returning mutation-grade addresses and text ranges. Use this to discover targets before any mutation.";
        readonly expectedResult: "Returns a QueryMatchOutput with the resolved target address and cardinality metadata.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "query/match.mdx";
        readonly referenceGroup: "query";
        readonly intentGroup: "search";
        readonly intentAction: "match";
    };
    readonly 'ranges.resolve': {
        readonly memberPath: "ranges.resolve";
        readonly description: "Resolve two explicit anchors into a contiguous document range. Returns a transparent SelectionTarget, handle metadata, and preview metadata. handle.ref is nullable and present only when the resolved range is mutation-ready; callers must check handle.ref !== null and/or coversFullTarget before using it for mutations. Stateless and deterministic.";
        readonly expectedResult: "Returns a ResolveRangeOutput with evaluatedRevision, handle.ref may be null, handle.coversFullTarget, target (SelectionTarget), and preview metadata.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "ranges/resolve.mdx";
        readonly referenceGroup: "ranges";
    };
    readonly 'selection.current': {
        readonly memberPath: "selection.current";
        readonly description: "Read the editor's current selection as a portable SelectionInfo with a text-anchored TextTarget. Primitive for building custom comments UIs, floating toolbars, and other selection-driven components without reaching into ProseMirror internals.";
        readonly expectedResult: "Returns a SelectionInfo with `empty`, `target` (TextTarget or null), optional `selectionTarget`, `activeMarks`, and optionally `text` when `includeText: true`.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "selection/current.mdx";
        readonly referenceGroup: "selection";
    };
    readonly 'mutations.preview': {
        readonly memberPath: "mutations.preview";
        readonly description: "Dry-run a mutation plan, returning resolved targets without applying changes.";
        readonly expectedResult: "Returns a MutationsPreviewOutput with resolved targets and step details without applying changes.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "mutations/preview.mdx";
        readonly referenceGroup: "mutations";
        readonly intentGroup: "mutations";
        readonly intentAction: "preview";
    };
    readonly 'mutations.apply': {
        readonly memberPath: "mutations.apply";
        readonly description: "Execute a mutation plan atomically against the document.";
        readonly expectedResult: "Returns a PlanReceipt with per-step results for the atomically applied mutation plan.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "mutations/apply.mdx";
        readonly referenceGroup: "mutations";
        readonly intentGroup: "mutations";
        readonly intentAction: "apply";
    };
    readonly 'plan.execute': {
        readonly memberPath: "plan.execute";
        readonly description: string;
        readonly expectedResult: "Returns a PlanExecuteResult with per-entry receipts, projected captures, and the first hard failure if any.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "mutations/plan-execute.mdx";
        readonly referenceGroup: "mutations";
        readonly skipAsATool: true;
    };
    readonly 'capabilities.get': {
        readonly memberPath: "capabilities";
        readonly description: "Query runtime capabilities supported by the current document engine.";
        readonly expectedResult: "Returns a DocumentApiCapabilities object describing supported features of the current engine.";
        readonly requiresDocumentContext: false;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "capabilities/get.mdx";
        readonly referenceGroup: "capabilities";
    };
    readonly 'capabilities.check': {
        readonly memberPath: "capabilities.check";
        readonly description: "Check an exact HTML or Markdown insert, replace, or detailed projection against the current document without mutating it.";
        readonly expectedResult: "Returns a Promise resolving to structured support, fidelity outcome, diagnostics, and a revision-bound guard for supported writes.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "capabilities/check.mdx";
        readonly referenceGroup: "capabilities";
        readonly intentGroup: "edit";
        readonly intentAction: "check_support";
    };
    readonly 'create.table': {
        readonly memberPath: "create.table";
        readonly description: "Create a new table at the target position.";
        readonly expectedResult: "Returns a CreateTableResult with the new table block ID and address.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "create/table.mdx";
        readonly referenceGroup: "create";
        readonly intentGroup: "create";
        readonly intentAction: "table";
    };
    readonly 'tables.convertFromText': {
        readonly memberPath: "tables.convertFromText";
        readonly description: "Convert a text range into a table.";
        readonly expectedResult: "Returns a TableMutationResult receipt confirming text was converted into a table.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "tables/convert-from-text.mdx";
        readonly referenceGroup: "tables";
    };
    readonly 'tables.delete': {
        readonly memberPath: "tables.delete";
        readonly description: "Delete the target table from the document.";
        readonly expectedResult: "Returns a TableMutationResult receipt; reports NO_OP if the table was already removed.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "tables/delete.mdx";
        readonly referenceGroup: "tables";
        readonly intentGroup: "table";
        readonly intentAction: "delete";
    };
    readonly 'tables.clearContents': {
        readonly memberPath: "tables.clearContents";
        readonly description: "Clear the contents of the target table or cell range.";
        readonly expectedResult: "Returns a TableMutationResult receipt; reports NO_OP if the target cells are already empty.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "tables/clear-contents.mdx";
        readonly referenceGroup: "tables";
    };
    readonly 'tables.move': {
        readonly memberPath: "tables.move";
        readonly description: "Move a table to a new position in the document.";
        readonly expectedResult: "Returns a TableMutationResult receipt; reports NO_OP if the table is already at the target position.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "tables/move.mdx";
        readonly referenceGroup: "tables";
    };
    readonly 'tables.split': {
        readonly memberPath: "tables.split";
        readonly description: "Split a table into two tables at the target row.";
        readonly expectedResult: "Returns a TableMutationResult receipt confirming the table was split at the target row.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "tables/split.mdx";
        readonly referenceGroup: "tables";
    };
    readonly 'tables.convertToText': {
        readonly memberPath: "tables.convertToText";
        readonly description: "Convert a table back to plain text.";
        readonly expectedResult: "Returns a TableMutationResult receipt; reports NO_OP if the table has no content to convert.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "tables/convert-to-text.mdx";
        readonly referenceGroup: "tables";
    };
    readonly 'tables.setLayout': {
        readonly memberPath: "tables.setLayout";
        readonly description: "Set the layout mode of the target table.";
        readonly expectedResult: "Returns a TableMutationResult receipt; reports NO_OP if the table already uses the requested layout mode.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "tables/set-layout.mdx";
        readonly referenceGroup: "tables";
        readonly intentGroup: "table";
        readonly intentAction: "set_layout";
    };
    readonly 'tables.insertRow': {
        readonly memberPath: "tables.insertRow";
        readonly description: "Insert a new row into the target table. The new row is cloned from an adjacent row, so it inherits the existing cell shading, borders, alignment, and padding. No follow-up styling call is needed unless the new row should look different from the rest of the table.";
        readonly expectedResult: "Returns a TableMutationResult receipt confirming a row was inserted.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "tables/insert-row.mdx";
        readonly referenceGroup: "tables";
        readonly intentGroup: "table";
        readonly intentAction: "insert_row";
    };
    readonly 'tables.deleteRow': {
        readonly memberPath: "tables.deleteRow";
        readonly description: "Delete a row from the target table.";
        readonly expectedResult: "Returns a TableMutationResult receipt; reports NO_OP if the target row does not exist.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "tables/delete-row.mdx";
        readonly referenceGroup: "tables";
        readonly intentGroup: "table";
        readonly intentAction: "delete_row";
    };
    readonly 'tables.moveRow': {
        readonly memberPath: "tables.moveRow";
        readonly description: string;
        readonly expectedResult: "Returns a TableMutationResult receipt; reports NO_OP if the row is already at the requested position.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "tables/move-row.mdx";
        readonly referenceGroup: "tables";
        readonly intentGroup: "table";
        readonly intentAction: "move_row";
    };
    readonly 'tables.setRowHeight': {
        readonly memberPath: "tables.setRowHeight";
        readonly description: "Set the height of a table row.";
        readonly expectedResult: "Returns a TableMutationResult receipt; reports NO_OP if the row height already matches.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "tables/set-row-height.mdx";
        readonly referenceGroup: "tables";
        readonly intentGroup: "table";
        readonly intentAction: "set_row";
    };
    readonly 'tables.distributeRows': {
        readonly memberPath: "tables.distributeRows";
        readonly description: "Distribute row heights evenly across the target table.";
        readonly expectedResult: "Returns a TableMutationResult receipt; reports NO_OP if row heights are already equal.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "tables/distribute-rows.mdx";
        readonly referenceGroup: "tables";
    };
    readonly 'tables.setRowOptions': {
        readonly memberPath: "tables.setRowOptions";
        readonly description: "Set options on a table row such as header repeat or page break.";
        readonly expectedResult: "Returns a TableMutationResult receipt; reports NO_OP if row options already match.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "tables/set-row-options.mdx";
        readonly referenceGroup: "tables";
        readonly intentGroup: "table";
        readonly intentAction: "set_row_options";
    };
    readonly 'tables.insertColumn': {
        readonly memberPath: "tables.insertColumn";
        readonly description: "Insert a new column into the target table. The new column is cloned from an adjacent column, so it inherits the existing cell shading, borders, alignment, and width. No follow-up styling call is needed unless the new column should look different from the rest of the table.";
        readonly expectedResult: "Returns a TableMutationResult receipt confirming a column was inserted.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "tables/insert-column.mdx";
        readonly referenceGroup: "tables";
        readonly intentGroup: "table";
        readonly intentAction: "insert_column";
    };
    readonly 'tables.deleteColumn': {
        readonly memberPath: "tables.deleteColumn";
        readonly description: "Delete a column from the target table.";
        readonly expectedResult: "Returns a TableMutationResult receipt; reports NO_OP if the target column does not exist.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "tables/delete-column.mdx";
        readonly referenceGroup: "tables";
        readonly intentGroup: "table";
        readonly intentAction: "delete_column";
    };
    readonly 'tables.setColumnWidth': {
        readonly memberPath: "tables.setColumnWidth";
        readonly description: "Set the width of a table column.";
        readonly expectedResult: "Returns a TableMutationResult receipt; reports NO_OP if the column width already matches.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "tables/set-column-width.mdx";
        readonly referenceGroup: "tables";
        readonly intentGroup: "table";
        readonly intentAction: "set_column";
    };
    readonly 'tables.distributeColumns': {
        readonly memberPath: "tables.distributeColumns";
        readonly description: "Distribute column widths evenly across the target table.";
        readonly expectedResult: "Returns a TableMutationResult receipt; reports NO_OP if column widths are already equal.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "tables/distribute-columns.mdx";
        readonly referenceGroup: "tables";
    };
    readonly 'tables.insertCell': {
        readonly memberPath: "tables.insertCell";
        readonly description: "Insert a new cell into a table row.";
        readonly expectedResult: "Returns a TableMutationResult receipt confirming a cell was inserted.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "tables/insert-cell.mdx";
        readonly referenceGroup: "tables";
    };
    readonly 'tables.deleteCell': {
        readonly memberPath: "tables.deleteCell";
        readonly description: "Delete a cell from a table row.";
        readonly expectedResult: "Returns a TableMutationResult receipt; reports NO_OP if the target cell does not exist.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "tables/delete-cell.mdx";
        readonly referenceGroup: "tables";
    };
    readonly 'tables.mergeCells': {
        readonly memberPath: "tables.mergeCells";
        readonly description: "Merge a range of table cells into one.";
        readonly expectedResult: "Returns a TableMutationResult receipt; reports NO_OP if the cells are already merged.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "tables/merge-cells.mdx";
        readonly referenceGroup: "tables";
        readonly intentGroup: "table";
        readonly intentAction: "merge_cells";
    };
    readonly 'tables.unmergeCells': {
        readonly memberPath: "tables.unmergeCells";
        readonly description: "Unmerge a previously merged table cell.";
        readonly expectedResult: "Returns a TableMutationResult receipt; reports NO_OP if the cell is not merged.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "tables/unmerge-cells.mdx";
        readonly referenceGroup: "tables";
        readonly intentGroup: "table";
        readonly intentAction: "unmerge_cells";
    };
    readonly 'tables.splitCell': {
        readonly memberPath: "tables.splitCell";
        readonly description: "Split a table cell into multiple cells.";
        readonly expectedResult: "Returns a TableMutationResult receipt confirming the cell was split.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "tables/split-cell.mdx";
        readonly referenceGroup: "tables";
    };
    readonly 'tables.setCellProperties': {
        readonly memberPath: "tables.setCellProperties";
        readonly description: string;
        readonly expectedResult: "Returns a TableMutationResult receipt; reports NO_OP if cell properties already match.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "tables/set-cell-properties.mdx";
        readonly referenceGroup: "tables";
        readonly intentGroup: "table";
        readonly intentAction: "set_cell";
    };
    readonly 'tables.setCellText': {
        readonly memberPath: "tables.setCellText";
        readonly description: string;
        readonly expectedResult: "Returns a TableMutationResult receipt; reports NO_OP if the cell already contains exactly this text.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "tables/set-cell-text.mdx";
        readonly referenceGroup: "tables";
        readonly intentGroup: "table";
        readonly intentAction: "set_cell_text";
    };
    readonly 'tables.sort': {
        readonly memberPath: "tables.sort";
        readonly description: "Sort table rows by a column value.";
        readonly expectedResult: "Returns a TableMutationResult receipt confirming rows were reordered.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "tables/sort.mdx";
        readonly referenceGroup: "tables";
    };
    readonly 'tables.setAltText': {
        readonly memberPath: "tables.setAltText";
        readonly description: "Set the alternative text description for a table.";
        readonly expectedResult: "Returns a TableMutationResult receipt; reports NO_OP if alt text already matches.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "tables/set-alt-text.mdx";
        readonly referenceGroup: "tables";
    };
    readonly 'tables.setStyle': {
        readonly memberPath: "tables.setStyle";
        readonly description: "Apply a named table style to the target table, or clear the style when styleId is omitted.";
        readonly expectedResult: "Returns a TableMutationResult receipt; reports NO_OP if the table already uses the requested style or has no style to clear.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "tables/set-style.mdx";
        readonly referenceGroup: "tables";
    };
    readonly 'tables.clearStyle': {
        readonly memberPath: "tables.clearStyle";
        readonly description: "Remove the applied table style, reverting to defaults.";
        readonly expectedResult: "Returns a TableMutationResult receipt; reports NO_OP if no table style is applied.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "tables/clear-style.mdx";
        readonly referenceGroup: "tables";
    };
    readonly 'tables.setStyleOption': {
        readonly memberPath: "tables.setStyleOption";
        readonly description: "Toggle a conditional style option such as banded rows or first column.";
        readonly expectedResult: "Returns a TableMutationResult receipt; reports NO_OP if the style option already matches.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "tables/set-style-option.mdx";
        readonly referenceGroup: "tables";
    };
    readonly 'tables.setBorder': {
        readonly memberPath: "tables.setBorder";
        readonly description: "Set border properties on a table or cell range.";
        readonly expectedResult: "Returns a TableMutationResult receipt; reports NO_OP if border properties already match.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "tables/set-border.mdx";
        readonly referenceGroup: "tables";
    };
    readonly 'tables.clearBorder': {
        readonly memberPath: "tables.clearBorder";
        readonly description: "Remove border formatting from a table or cell range.";
        readonly expectedResult: "Returns a TableMutationResult receipt; reports NO_OP if no borders are set.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "tables/clear-border.mdx";
        readonly referenceGroup: "tables";
    };
    readonly 'tables.applyBorderPreset': {
        readonly memberPath: "tables.applyBorderPreset";
        readonly description: "Apply a border preset (e.g. all borders, outside only) to a table.";
        readonly expectedResult: "Returns a TableMutationResult receipt; reports NO_OP if the preset is already applied.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "tables/apply-border-preset.mdx";
        readonly referenceGroup: "tables";
    };
    readonly 'tables.setShading': {
        readonly memberPath: "tables.setShading";
        readonly description: "Set the background shading color on a table or cell range.";
        readonly expectedResult: "Returns a TableMutationResult receipt; reports NO_OP if shading already matches.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "tables/set-shading.mdx";
        readonly referenceGroup: "tables";
        readonly intentGroup: "table";
        readonly intentAction: "set_shading";
    };
    readonly 'tables.clearShading': {
        readonly memberPath: "tables.clearShading";
        readonly description: "Remove shading from a table or cell range.";
        readonly expectedResult: "Returns a TableMutationResult receipt; reports NO_OP if no shading is set.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "tables/clear-shading.mdx";
        readonly referenceGroup: "tables";
    };
    readonly 'tables.setTablePadding': {
        readonly memberPath: "tables.setTablePadding";
        readonly description: "Set default cell padding for the entire table.";
        readonly expectedResult: "Returns a TableMutationResult receipt; reports NO_OP if table padding already matches.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "tables/set-table-padding.mdx";
        readonly referenceGroup: "tables";
    };
    readonly 'tables.setCellPadding': {
        readonly memberPath: "tables.setCellPadding";
        readonly description: "Set padding on a specific table cell or cell range.";
        readonly expectedResult: "Returns a TableMutationResult receipt; reports NO_OP if cell padding already matches.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "tables/set-cell-padding.mdx";
        readonly referenceGroup: "tables";
    };
    readonly 'tables.setCellSpacing': {
        readonly memberPath: "tables.setCellSpacing";
        readonly description: "Set the cell spacing for the target table.";
        readonly expectedResult: "Returns a TableMutationResult receipt; reports NO_OP if cell spacing already matches.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "tables/set-cell-spacing.mdx";
        readonly referenceGroup: "tables";
    };
    readonly 'tables.clearCellSpacing': {
        readonly memberPath: "tables.clearCellSpacing";
        readonly description: "Remove custom cell spacing from the target table.";
        readonly expectedResult: "Returns a TableMutationResult receipt; reports NO_OP if no custom cell spacing is set.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "tables/clear-cell-spacing.mdx";
        readonly referenceGroup: "tables";
    };
    readonly 'tables.applyStyle': {
        readonly memberPath: "tables.applyStyle";
        readonly description: string;
        readonly expectedResult: "Returns a TableMutationResult receipt; reports NO_OP if the style and all provided options already match.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "tables/apply-style.mdx";
        readonly referenceGroup: "tables";
        readonly intentGroup: "table";
        readonly intentAction: "set_style_options";
    };
    readonly 'tables.setBorders': {
        readonly memberPath: "tables.setBorders";
        readonly description: "Set borders on a table using a target set or per-edge patch.";
        readonly expectedResult: "Returns a TableMutationResult receipt. Does not perform NO_OP detection.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "tables/set-borders.mdx";
        readonly referenceGroup: "tables";
        readonly intentGroup: "table";
        readonly intentAction: "set_borders";
    };
    readonly 'tables.setTableOptions': {
        readonly memberPath: "tables.setTableOptions";
        readonly description: "Set table-level default cell margins and/or cell spacing.";
        readonly expectedResult: "Returns a TableMutationResult receipt; reports NO_OP if the provided values already match current direct formatting.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "tables/set-table-options.mdx";
        readonly referenceGroup: "tables";
        readonly intentGroup: "table";
        readonly intentAction: "set_options";
    };
    readonly 'tables.applyPreset': {
        readonly memberPath: "tables.applyPreset";
        readonly description: string;
        readonly expectedResult: "Returns a TableMutationResult receipt.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "tables/apply-preset.mdx";
        readonly referenceGroup: "tables";
    };
    readonly 'tables.get': {
        readonly memberPath: "tables.get";
        readonly description: "Retrieve table structure and dimensions by locator.";
        readonly expectedResult: "Returns a TablesGetOutput with the table row count, column count, and structural metadata.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "tables/get.mdx";
        readonly referenceGroup: "tables";
    };
    readonly 'tables.getCells': {
        readonly memberPath: "tables.getCells";
        readonly description: "Retrieve cell information for a table, optionally filtered by row or column.";
        readonly expectedResult: "Returns a TablesGetCellsOutput with cell information for the requested rows and columns.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "tables/get-cells.mdx";
        readonly referenceGroup: "tables";
    };
    readonly 'tables.getProperties': {
        readonly memberPath: "tables.getProperties";
        readonly description: "Retrieve layout and style properties of a table.";
        readonly expectedResult: "Returns a TablesGetPropertiesOutput with direct table layout and style state, including style options, borders, default cell margins, and cell spacing when explicitly set.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "tables/get-properties.mdx";
        readonly referenceGroup: "tables";
    };
    readonly 'tables.getStyles': {
        readonly memberPath: "tables.getStyles";
        readonly description: "List all table styles and the document-level default table style setting.";
        readonly expectedResult: "Returns a TablesGetStylesOutput with the style catalog, explicit default, and effective default.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "tables/get-styles.mdx";
        readonly referenceGroup: "tables";
    };
    readonly 'tables.setDefaultStyle': {
        readonly memberPath: "tables.setDefaultStyle";
        readonly description: "Set the document-level default table style (w:defaultTableStyle in settings.xml).";
        readonly expectedResult: "Returns a DocumentMutationResult; reports NO_OP if the default already matches.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "tables/set-default-style.mdx";
        readonly referenceGroup: "tables";
    };
    readonly 'tables.clearDefaultStyle': {
        readonly memberPath: "tables.clearDefaultStyle";
        readonly description: "Remove the document-level default table style setting.";
        readonly expectedResult: "Returns a DocumentMutationResult; reports NO_OP if no default is set.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "tables/clear-default-style.mdx";
        readonly referenceGroup: "tables";
    };
    readonly 'create.tableOfContents': {
        readonly memberPath: "create.tableOfContents";
        readonly description: "Insert a new table of contents at the target position.";
        readonly expectedResult: "Returns a CreateTableOfContentsResult with the new TOC block address.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "create/table-of-contents.mdx";
        readonly referenceGroup: "create";
    };
    readonly 'toc.list': {
        readonly memberPath: "toc.list";
        readonly description: "List all tables of contents in the document.";
        readonly expectedResult: "Returns a TocListResult with an array of TOC discovery items and pagination metadata.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "toc/list.mdx";
        readonly referenceGroup: "toc";
    };
    readonly 'toc.get': {
        readonly memberPath: "toc.get";
        readonly description: "Retrieve details of a specific table of contents.";
        readonly expectedResult: "Returns a TocInfo object with the instruction, source/display configuration, and entry count.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "toc/get.mdx";
        readonly referenceGroup: "toc";
    };
    readonly 'toc.configure': {
        readonly memberPath: "toc.configure";
        readonly description: "Update the configuration switches of a table of contents.";
        readonly expectedResult: "Returns a TocMutationResult with the updated TOC address on success, or a failure code on no-op.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "toc/configure.mdx";
        readonly referenceGroup: "toc";
    };
    readonly 'toc.update': {
        readonly memberPath: "toc.update";
        readonly description: "Rebuild or refresh the materialized content of a table of contents.";
        readonly expectedResult: "Returns a TocMutationResult with the TOC address on success, or a failure code if content is unchanged or page numbers cannot be resolved.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "toc/update.mdx";
        readonly referenceGroup: "toc";
    };
    readonly 'toc.remove': {
        readonly memberPath: "toc.remove";
        readonly description: "Remove a table of contents from the document.";
        readonly expectedResult: "Returns a TocMutationResult with the removed TOC address on success, or a failure code on no-op.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "toc/remove.mdx";
        readonly referenceGroup: "toc";
    };
    readonly 'toc.markEntry': {
        readonly memberPath: "toc.markEntry";
        readonly description: "Insert a TC (table of contents entry) field at the target paragraph.";
        readonly expectedResult: "Returns a TocEntryMutationResult with the created entry address on success.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "toc/mark-entry.mdx";
        readonly referenceGroup: "toc";
    };
    readonly 'toc.unmarkEntry': {
        readonly memberPath: "toc.unmarkEntry";
        readonly description: "Remove a TC (table of contents entry) field from the document.";
        readonly expectedResult: "Returns a TocEntryMutationResult with the removed entry address on success.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "toc/unmark-entry.mdx";
        readonly referenceGroup: "toc";
    };
    readonly 'toc.listEntries': {
        readonly memberPath: "toc.listEntries";
        readonly description: "List all TC (table of contents entry) fields in the document body.";
        readonly expectedResult: "Returns a TocListEntriesResult with an array of TC entry discovery items and pagination metadata.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "toc/list-entries.mdx";
        readonly referenceGroup: "toc";
    };
    readonly 'toc.getEntry': {
        readonly memberPath: "toc.getEntry";
        readonly description: "Retrieve details of a specific TC (table of contents entry) field.";
        readonly expectedResult: "Returns a TocEntryInfo object with the instruction, text, level, and switch configuration.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "toc/get-entry.mdx";
        readonly referenceGroup: "toc";
    };
    readonly 'toc.editEntry': {
        readonly memberPath: "toc.editEntry";
        readonly description: "Update the properties of a TC (table of contents entry) field.";
        readonly expectedResult: "Returns a TocEntryMutationResult with the updated entry address on success, or NO_OP if no change.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "toc/edit-entry.mdx";
        readonly referenceGroup: "toc";
    };
    readonly 'history.get': {
        readonly memberPath: "history.get";
        readonly description: "Query the current undo/redo history state of the document.";
        readonly expectedResult: "Returns a HistoryState object with undoDepth, redoDepth, canUndo, canRedo, and a list of history-unsafe operations.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "history/get.mdx";
        readonly referenceGroup: "history";
    };
    readonly 'history.undo': {
        readonly memberPath: "history.undo";
        readonly description: "Undo the most recent history-safe mutation in the document.";
        readonly expectedResult: "Returns a HistoryActionResult with noop flag, revision before/after, optional noop reason, and optional ref-effect fields such as inserted, removed, invalidatedRefs, remappedRefs, and affectedStories.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "history/undo.mdx";
        readonly referenceGroup: "history";
        readonly intentGroup: "edit";
        readonly intentAction: "undo";
    };
    readonly 'history.redo': {
        readonly memberPath: "history.redo";
        readonly description: "Redo the most recently undone action in the document.";
        readonly expectedResult: "Returns a HistoryActionResult with noop flag, revision before/after, optional noop reason, and optional ref-effect fields such as inserted, removed, invalidatedRefs, remappedRefs, and affectedStories.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "history/redo.mdx";
        readonly referenceGroup: "history";
        readonly intentGroup: "edit";
        readonly intentAction: "redo";
    };
    readonly 'create.image': {
        readonly memberPath: "create.image";
        readonly description: "Insert a new image at the target position.";
        readonly expectedResult: "Returns a CreateImageResult with the new image address. Tracked-mode results include `trackedChangeRefs` pointing at the tracked insertion review entity.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "create/image.mdx";
        readonly referenceGroup: "create";
    };
    readonly 'images.list': {
        readonly memberPath: "images.list";
        readonly description: "List all images in the document.";
        readonly expectedResult: "Returns an ImagesListResult with total count and image summaries.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "images/list.mdx";
        readonly referenceGroup: "images";
    };
    readonly 'images.get': {
        readonly memberPath: "images.get";
        readonly description: "Get details for a specific image by its stable ID.";
        readonly expectedResult: "Returns an ImageSummary with full image properties.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "images/get.mdx";
        readonly referenceGroup: "images";
    };
    readonly 'images.delete': {
        readonly memberPath: "images.delete";
        readonly description: "Delete an image from the document.";
        readonly expectedResult: "Returns an ImagesMutationResult indicating success or failure.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "images/delete.mdx";
        readonly referenceGroup: "images";
    };
    readonly 'images.move': {
        readonly memberPath: "images.move";
        readonly description: "Move an image to a new location in the document. Tracked-mode authoring supports safe sole inline-image body paragraphs and emits paired `<w:moveFrom>` / `<w:moveTo>` wrappers with explicit move range marker identity.";
        readonly expectedResult: "Returns an ImagesMutationResult indicating success or failure. Tracked-mode results include `trackedChangeRefs` pointing at the paired move review entity.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "images/move.mdx";
        readonly referenceGroup: "images";
    };
    readonly 'images.convertToInline': {
        readonly memberPath: "images.convertToInline";
        readonly description: "Convert a floating image to inline placement.";
        readonly expectedResult: "Returns an ImagesMutationResult; reports NO_OP if already inline.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "images/convert-to-inline.mdx";
        readonly referenceGroup: "images";
    };
    readonly 'images.convertToFloating': {
        readonly memberPath: "images.convertToFloating";
        readonly description: "Convert an inline image to floating placement.";
        readonly expectedResult: "Returns an ImagesMutationResult; reports NO_OP if already floating.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "images/convert-to-floating.mdx";
        readonly referenceGroup: "images";
    };
    readonly 'images.setSize': {
        readonly memberPath: "images.setSize";
        readonly description: "Set explicit width/height for an image.";
        readonly expectedResult: "Returns an ImagesMutationResult; reports NO_OP if the size already matches.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "images/set-size.mdx";
        readonly referenceGroup: "images";
    };
    readonly 'images.setWrapType': {
        readonly memberPath: "images.setWrapType";
        readonly description: "Set the text wrapping type for a floating image.";
        readonly expectedResult: "Returns an ImagesMutationResult; reports NO_OP if already set.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "images/set-wrap-type.mdx";
        readonly referenceGroup: "images";
    };
    readonly 'images.setWrapSide': {
        readonly memberPath: "images.setWrapSide";
        readonly description: "Set which side(s) text wraps around a floating image.";
        readonly expectedResult: "Returns an ImagesMutationResult; reports NO_OP if already set.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "images/set-wrap-side.mdx";
        readonly referenceGroup: "images";
    };
    readonly 'images.setWrapDistances': {
        readonly memberPath: "images.setWrapDistances";
        readonly description: "Set the text-wrap distance margins for a floating image.";
        readonly expectedResult: "Returns an ImagesMutationResult; reports NO_OP if already set.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "images/set-wrap-distances.mdx";
        readonly referenceGroup: "images";
    };
    readonly 'images.setPosition': {
        readonly memberPath: "images.setPosition";
        readonly description: "Set the anchor position for a floating image.";
        readonly expectedResult: "Returns an ImagesMutationResult.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "images/set-position.mdx";
        readonly referenceGroup: "images";
    };
    readonly 'images.setAnchorOptions': {
        readonly memberPath: "images.setAnchorOptions";
        readonly description: "Set anchor behavior options for a floating image.";
        readonly expectedResult: "Returns an ImagesMutationResult.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "images/set-anchor-options.mdx";
        readonly referenceGroup: "images";
    };
    readonly 'images.setZOrder': {
        readonly memberPath: "images.setZOrder";
        readonly description: "Set the z-order (relativeHeight) for a floating image.";
        readonly expectedResult: "Returns an ImagesMutationResult.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "images/set-z-order.mdx";
        readonly referenceGroup: "images";
    };
    readonly 'images.scale': {
        readonly memberPath: "images.scale";
        readonly description: "Scale an image by a uniform factor applied to both dimensions.";
        readonly expectedResult: "Returns an ImagesMutationResult with the updated image address.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "images/scale.mdx";
        readonly referenceGroup: "images";
    };
    readonly 'images.setLockAspectRatio': {
        readonly memberPath: "images.setLockAspectRatio";
        readonly description: "Lock or unlock the aspect ratio for an image.";
        readonly expectedResult: "Returns an ImagesMutationResult; reports NO_OP if already set.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "images/set-lock-aspect-ratio.mdx";
        readonly referenceGroup: "images";
    };
    readonly 'images.rotate': {
        readonly memberPath: "images.rotate";
        readonly description: "Set the absolute rotation angle for an image.";
        readonly expectedResult: "Returns an ImagesMutationResult; reports NO_OP if already set.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "images/rotate.mdx";
        readonly referenceGroup: "images";
    };
    readonly 'images.flip': {
        readonly memberPath: "images.flip";
        readonly description: "Set horizontal and/or vertical flip state for an image.";
        readonly expectedResult: "Returns an ImagesMutationResult; reports NO_OP if already set.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "images/flip.mdx";
        readonly referenceGroup: "images";
    };
    readonly 'images.crop': {
        readonly memberPath: "images.crop";
        readonly description: "Apply rectangular edge-percentage crop to an image.";
        readonly expectedResult: "Returns an ImagesMutationResult; reports NO_OP if unchanged.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "images/crop.mdx";
        readonly referenceGroup: "images";
    };
    readonly 'images.resetCrop': {
        readonly memberPath: "images.resetCrop";
        readonly description: "Remove all cropping from an image.";
        readonly expectedResult: "Returns an ImagesMutationResult; reports NO_OP if no crop is set.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "images/reset-crop.mdx";
        readonly referenceGroup: "images";
    };
    readonly 'images.replaceSource': {
        readonly memberPath: "images.replaceSource";
        readonly description: "Replace the image source while preserving identity and placement.";
        readonly expectedResult: "Returns an ImagesMutationResult with the updated image address.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "images/replace-source.mdx";
        readonly referenceGroup: "images";
    };
    readonly 'images.setAltText': {
        readonly memberPath: "images.setAltText";
        readonly description: "Set the accessibility description (alt text) for an image.";
        readonly expectedResult: "Returns an ImagesMutationResult; reports NO_OP if unchanged.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "images/set-alt-text.mdx";
        readonly referenceGroup: "images";
    };
    readonly 'images.setDecorative': {
        readonly memberPath: "images.setDecorative";
        readonly description: "Mark or unmark an image as decorative.";
        readonly expectedResult: "Returns an ImagesMutationResult; reports NO_OP if unchanged.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "images/set-decorative.mdx";
        readonly referenceGroup: "images";
    };
    readonly 'images.setName': {
        readonly memberPath: "images.setName";
        readonly description: "Set the object name for an image.";
        readonly expectedResult: "Returns an ImagesMutationResult; reports NO_OP if unchanged.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "images/set-name.mdx";
        readonly referenceGroup: "images";
    };
    readonly 'images.setHyperlink': {
        readonly memberPath: "images.setHyperlink";
        readonly description: "Set or remove the hyperlink attached to an image.";
        readonly expectedResult: "Returns an ImagesMutationResult; reports NO_OP if unchanged.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "images/set-hyperlink.mdx";
        readonly referenceGroup: "images";
    };
    readonly 'images.insertCaption': {
        readonly memberPath: "images.insertCaption";
        readonly description: "Insert a caption paragraph below the image.";
        readonly expectedResult: "Returns an ImagesMutationResult with the image address.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "images/insert-caption.mdx";
        readonly referenceGroup: "images";
    };
    readonly 'images.updateCaption': {
        readonly memberPath: "images.updateCaption";
        readonly description: "Update the text of an existing caption paragraph.";
        readonly expectedResult: "Returns an ImagesMutationResult; reports NO_OP if text unchanged.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "images/update-caption.mdx";
        readonly referenceGroup: "images";
    };
    readonly 'images.removeCaption': {
        readonly memberPath: "images.removeCaption";
        readonly description: "Remove the caption paragraph from below the image.";
        readonly expectedResult: "Returns an ImagesMutationResult; reports NO_OP if no caption exists.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "images/remove-caption.mdx";
        readonly referenceGroup: "images";
    };
    readonly 'hyperlinks.list': {
        readonly memberPath: "hyperlinks.list";
        readonly description: "List all hyperlinks in the document, with optional filtering by href, anchor, or display text.";
        readonly expectedResult: "Returns a HyperlinksListResult with an array of hyperlink discovery items and pagination metadata.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "hyperlinks/list.mdx";
        readonly referenceGroup: "hyperlinks";
    };
    readonly 'hyperlinks.get': {
        readonly memberPath: "hyperlinks.get";
        readonly description: "Retrieve details of a specific hyperlink by its inline address.";
        readonly expectedResult: "Returns a HyperlinkInfo object with the address, destination properties, and display text.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "hyperlinks/get.mdx";
        readonly referenceGroup: "hyperlinks";
    };
    readonly 'hyperlinks.wrap': {
        readonly memberPath: "hyperlinks.wrap";
        readonly description: "Wrap an existing text range with a hyperlink.";
        readonly expectedResult: "Returns a HyperlinkMutationResult with the created hyperlink address on success, or a failure code on no-op.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "hyperlinks/wrap.mdx";
        readonly referenceGroup: "hyperlinks";
    };
    readonly 'hyperlinks.insert': {
        readonly memberPath: "hyperlinks.insert";
        readonly description: "Insert new linked text at a target position.";
        readonly expectedResult: "Returns a HyperlinkMutationResult with the created hyperlink address on success, or a failure code.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "hyperlinks/insert.mdx";
        readonly referenceGroup: "hyperlinks";
    };
    readonly 'hyperlinks.patch': {
        readonly memberPath: "hyperlinks.patch";
        readonly description: "Update hyperlink metadata (destination, tooltip, target, rel) without changing display text.";
        readonly expectedResult: "Returns a HyperlinkMutationResult with the updated hyperlink address on success, or NO_OP if unchanged.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "hyperlinks/patch.mdx";
        readonly referenceGroup: "hyperlinks";
    };
    readonly 'hyperlinks.remove': {
        readonly memberPath: "hyperlinks.remove";
        readonly description: "Remove a hyperlink. Mode 'unwrap' preserves display text; 'deleteText' removes the linked content entirely.";
        readonly expectedResult: "Returns a HyperlinkMutationResult with the removed hyperlink address on success, or a failure code on no-op.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "hyperlinks/remove.mdx";
        readonly referenceGroup: "hyperlinks";
    };
    readonly 'headerFooters.list': {
        readonly memberPath: "headerFooters.list";
        readonly description: "List header/footer slot entries across sections.";
        readonly expectedResult: "Returns a paginated DiscoveryOutput of HeaderFooterSlotEntry items.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "header-footers/list.mdx";
        readonly referenceGroup: "headerFooters";
    };
    readonly 'headerFooters.get': {
        readonly memberPath: "headerFooters.get";
        readonly description: "Get a single header/footer slot entry by address.";
        readonly expectedResult: "Returns a HeaderFooterSlotEntry for the targeted section slot.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "header-footers/get.mdx";
        readonly referenceGroup: "headerFooters";
    };
    readonly 'headerFooters.resolve': {
        readonly memberPath: "headerFooters.resolve";
        readonly description: "Resolve the effective header/footer reference for a slot, walking the section inheritance chain.";
        readonly expectedResult: "Returns a HeaderFooterResolveResult indicating explicit, inherited, or none status with the resolved refId.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "header-footers/resolve.mdx";
        readonly referenceGroup: "headerFooters";
    };
    readonly 'headerFooters.refs.set': {
        readonly memberPath: "headerFooters.refs.set";
        readonly description: "Set an explicit header/footer reference on a section slot.";
        readonly expectedResult: "Returns a SectionMutationResult receipt; reports NO_OP if the reference already matches, INVALID_TARGET if the relationship does not exist.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "header-footers/refs/set.mdx";
        readonly referenceGroup: "headerFooters";
    };
    readonly 'headerFooters.refs.clear': {
        readonly memberPath: "headerFooters.refs.clear";
        readonly description: "Clear an explicit header/footer reference from a section slot.";
        readonly expectedResult: "Returns a SectionMutationResult receipt; reports NO_OP if no explicit reference existed.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "header-footers/refs/clear.mdx";
        readonly referenceGroup: "headerFooters";
    };
    readonly 'headerFooters.refs.setLinkedToPrevious': {
        readonly memberPath: "headerFooters.refs.setLinkedToPrevious";
        readonly description: "Link or unlink a header/footer slot to/from the previous section.";
        readonly expectedResult: "Returns a SectionMutationResult receipt; reports NO_OP if the link state already matches, INVALID_TARGET for the first section.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "header-footers/refs/set-linked-to-previous.mdx";
        readonly referenceGroup: "headerFooters";
    };
    readonly 'headerFooters.parts.list': {
        readonly memberPath: "headerFooters.parts.list";
        readonly description: "List unique header/footer part records from document relationships.";
        readonly expectedResult: "Returns a paginated DiscoveryOutput of HeaderFooterPartEntry items.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "header-footers/parts/list.mdx";
        readonly referenceGroup: "headerFooters";
    };
    readonly 'headerFooters.parts.create': {
        readonly memberPath: "headerFooters.parts.create";
        readonly description: "Create a new independent header/footer part, optionally cloned from an existing part.";
        readonly expectedResult: "Returns a HeaderFooterPartsMutationResult with the new refId/partPath on success, INVALID_TARGET failure when sourceRefId is invalid or mismatched.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "header-footers/parts/create.mdx";
        readonly referenceGroup: "headerFooters";
    };
    readonly 'headerFooters.parts.delete': {
        readonly memberPath: "headerFooters.parts.delete";
        readonly description: "Delete a header/footer part and its associated relationship when no section slots reference it.";
        readonly expectedResult: "Returns a HeaderFooterPartsMutationResult on success; INVALID_TARGET failure if sections still reference the part.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "header-footers/parts/delete.mdx";
        readonly referenceGroup: "headerFooters";
    };
    readonly 'create.contentControl': {
        readonly memberPath: "create.contentControl";
        readonly description: "Create a new content control (SDT) in the document, optionally seeded with plain text or structured block preset content.";
        readonly expectedResult: "Returns a ContentControlMutationResult with the created content control target.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "content-controls/create.mdx";
        readonly referenceGroup: "contentControls";
    };
    readonly 'contentControls.list': {
        readonly memberPath: "contentControls.list";
        readonly description: "List all content controls in the document with optional type/tag filtering.";
        readonly expectedResult: "Returns a ContentControlsListResult with items and total count.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "content-controls/list.mdx";
        readonly referenceGroup: "contentControls";
    };
    readonly 'contentControls.get': {
        readonly memberPath: "contentControls.get";
        readonly description: "Retrieve a single content control by target.";
        readonly expectedResult: "Returns a ContentControlInfo with full properties.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "content-controls/get.mdx";
        readonly referenceGroup: "contentControls";
    };
    readonly 'contentControls.listInRange': {
        readonly memberPath: "contentControls.listInRange";
        readonly description: "List content controls within a block range.";
        readonly expectedResult: "Returns a ContentControlsListResult scoped to the range.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "content-controls/list-in-range.mdx";
        readonly referenceGroup: "contentControls";
    };
    readonly 'contentControls.selectByTag': {
        readonly memberPath: "contentControls.selectByTag";
        readonly description: "Select content controls matching a specific tag value.";
        readonly expectedResult: "Returns a ContentControlsListResult with matching items.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "content-controls/select-by-tag.mdx";
        readonly referenceGroup: "contentControls";
    };
    readonly 'contentControls.selectByTitle': {
        readonly memberPath: "contentControls.selectByTitle";
        readonly description: "Select content controls matching a specific title (alias) value.";
        readonly expectedResult: "Returns a ContentControlsListResult with matching items.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "content-controls/select-by-title.mdx";
        readonly referenceGroup: "contentControls";
    };
    readonly 'contentControls.listChildren': {
        readonly memberPath: "contentControls.listChildren";
        readonly description: "List direct child content controls nested inside the target.";
        readonly expectedResult: "Returns a ContentControlsListResult with child items.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "content-controls/list-children.mdx";
        readonly referenceGroup: "contentControls";
    };
    readonly 'contentControls.getParent': {
        readonly memberPath: "contentControls.getParent";
        readonly description: "Get the parent content control of the target, if any.";
        readonly expectedResult: "Returns a ContentControlInfo for the parent, or null if no parent SDT exists.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "content-controls/get-parent.mdx";
        readonly referenceGroup: "contentControls";
    };
    readonly 'contentControls.wrap': {
        readonly memberPath: "contentControls.wrap";
        readonly description: "Wrap existing content with a new content control.";
        readonly expectedResult: "Returns a ContentControlMutationResult with the wrapper target.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "content-controls/wrap.mdx";
        readonly referenceGroup: "contentControls";
    };
    readonly 'contentControls.unwrap': {
        readonly memberPath: "contentControls.unwrap";
        readonly description: "Remove the content control wrapper, preserving its content in place.";
        readonly expectedResult: "Returns a ContentControlMutationResult; reports NO_OP if already unwrapped.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "content-controls/unwrap.mdx";
        readonly referenceGroup: "contentControls";
    };
    readonly 'contentControls.delete': {
        readonly memberPath: "contentControls.delete";
        readonly description: "Delete a content control and its content from the document.";
        readonly expectedResult: "Returns a ContentControlMutationResult; reports NO_OP if already removed.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "content-controls/delete.mdx";
        readonly referenceGroup: "contentControls";
    };
    readonly 'contentControls.copy': {
        readonly memberPath: "contentControls.copy";
        readonly description: "Copy a content control to a destination position. Copied SDTs receive new IDs.";
        readonly expectedResult: "Returns a ContentControlMutationResult with the copied content control target.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "content-controls/copy.mdx";
        readonly referenceGroup: "contentControls";
    };
    readonly 'contentControls.move': {
        readonly memberPath: "contentControls.move";
        readonly description: "Move a content control to a new position: before or after another SDT, to the document start or end, or to an arbitrary caret inside a paragraph (the inParagraph destination) for drag-and-drop. Direct moves preserve the original ID; tracked-mode authoring supports safe top-level block SDTs (SDT-to-SDT destinations only) and remaps the destination SDT ID to avoid duplicate live anchors.";
        readonly expectedResult: "Returns a ContentControlMutationResult with the updated target position. Tracked-mode results include `trackedChangeRefs` pointing at the paired move review entity.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "content-controls/move.mdx";
        readonly referenceGroup: "contentControls";
    };
    readonly 'contentControls.patch': {
        readonly memberPath: "contentControls.patch";
        readonly description: "Patch metadata properties on a content control (tag, alias, appearance, color, etc.).";
        readonly expectedResult: "Returns a ContentControlMutationResult; reports NO_OP if no fields changed.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "content-controls/patch.mdx";
        readonly referenceGroup: "contentControls";
    };
    readonly 'contentControls.setLockMode': {
        readonly memberPath: "contentControls.setLockMode";
        readonly description: "Set the lock mode on a content control.";
        readonly expectedResult: "Returns a ContentControlMutationResult; reports NO_OP if lock mode unchanged.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "content-controls/set-lock-mode.mdx";
        readonly referenceGroup: "contentControls";
    };
    readonly 'contentControls.setType': {
        readonly memberPath: "contentControls.setType";
        readonly description: "Transition a content control to a different semantic type. Metadata-only; no implicit content rewrite.";
        readonly expectedResult: "Returns a ContentControlMutationResult; reports NO_OP if type unchanged.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "content-controls/set-type.mdx";
        readonly referenceGroup: "contentControls";
    };
    readonly 'contentControls.getContent': {
        readonly memberPath: "contentControls.getContent";
        readonly description: "Get the text content of a content control.";
        readonly expectedResult: "Returns a ContentControlsGetContentResult with the content string and format.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "content-controls/get-content.mdx";
        readonly referenceGroup: "contentControls";
    };
    readonly 'contentControls.replaceContent': {
        readonly memberPath: "contentControls.replaceContent";
        readonly description: "Replace the entire content of a content control.";
        readonly expectedResult: "Returns a ContentControlMutationResult with the updated target.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "content-controls/replace-content.mdx";
        readonly referenceGroup: "contentControls";
    };
    readonly 'contentControls.clearContent': {
        readonly memberPath: "contentControls.clearContent";
        readonly description: "Clear all content inside a content control, leaving it empty.";
        readonly expectedResult: "Returns a ContentControlMutationResult; reports NO_OP if already empty.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "content-controls/clear-content.mdx";
        readonly referenceGroup: "contentControls";
    };
    readonly 'contentControls.appendContent': {
        readonly memberPath: "contentControls.appendContent";
        readonly description: "Append content to the end of a content control.";
        readonly expectedResult: "Returns a ContentControlMutationResult with the updated target.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "content-controls/append-content.mdx";
        readonly referenceGroup: "contentControls";
    };
    readonly 'contentControls.prependContent': {
        readonly memberPath: "contentControls.prependContent";
        readonly description: "Prepend content to the beginning of a content control.";
        readonly expectedResult: "Returns a ContentControlMutationResult with the updated target.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "content-controls/prepend-content.mdx";
        readonly referenceGroup: "contentControls";
    };
    readonly 'contentControls.insertBefore': {
        readonly memberPath: "contentControls.insertBefore";
        readonly description: "Insert content immediately before a content control.";
        readonly expectedResult: "Returns a ContentControlMutationResult with the target.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "content-controls/insert-before.mdx";
        readonly referenceGroup: "contentControls";
    };
    readonly 'contentControls.insertAfter': {
        readonly memberPath: "contentControls.insertAfter";
        readonly description: "Insert content immediately after a content control.";
        readonly expectedResult: "Returns a ContentControlMutationResult with the target.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "content-controls/insert-after.mdx";
        readonly referenceGroup: "contentControls";
    };
    readonly 'contentControls.getBinding': {
        readonly memberPath: "contentControls.getBinding";
        readonly description: "Get the data binding metadata (w:dataBinding) of a content control.";
        readonly expectedResult: "Returns the ContentControlBinding or null if no binding is set.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "content-controls/get-binding.mdx";
        readonly referenceGroup: "contentControls";
    };
    readonly 'contentControls.setBinding': {
        readonly memberPath: "contentControls.setBinding";
        readonly description: "Set data binding metadata on a content control.";
        readonly expectedResult: "Returns a ContentControlMutationResult; reports NO_OP if binding unchanged.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "content-controls/set-binding.mdx";
        readonly referenceGroup: "contentControls";
    };
    readonly 'contentControls.clearBinding': {
        readonly memberPath: "contentControls.clearBinding";
        readonly description: "Remove data binding metadata from a content control.";
        readonly expectedResult: "Returns a ContentControlMutationResult; reports NO_OP if no binding existed.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "content-controls/clear-binding.mdx";
        readonly referenceGroup: "contentControls";
    };
    readonly 'contentControls.getRawProperties': {
        readonly memberPath: "contentControls.getRawProperties";
        readonly description: "Get the raw sdtPr properties of a content control as a passthrough hash.";
        readonly expectedResult: "Returns a ContentControlsGetRawPropertiesResult with the raw properties.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "content-controls/get-raw-properties.mdx";
        readonly referenceGroup: "contentControls";
    };
    readonly 'contentControls.patchRawProperties': {
        readonly memberPath: "contentControls.patchRawProperties";
        readonly description: "Apply raw XML-level patches to the sdtPr subtree of a content control.";
        readonly expectedResult: "Returns a ContentControlMutationResult; reports NO_OP if no effective changes.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "content-controls/patch-raw-properties.mdx";
        readonly referenceGroup: "contentControls";
    };
    readonly 'contentControls.validateWordCompatibility': {
        readonly memberPath: "contentControls.validateWordCompatibility";
        readonly description: "Validate a content control for Word compatibility issues.";
        readonly expectedResult: "Returns a compatibility result with diagnostics.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "content-controls/validate-word-compatibility.mdx";
        readonly referenceGroup: "contentControls";
    };
    readonly 'contentControls.normalizeWordCompatibility': {
        readonly memberPath: "contentControls.normalizeWordCompatibility";
        readonly description: "Normalize a content control to resolve Word compatibility issues.";
        readonly expectedResult: "Returns a ContentControlMutationResult; reports NO_OP if already compatible.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "content-controls/normalize-word-compatibility.mdx";
        readonly referenceGroup: "contentControls";
    };
    readonly 'contentControls.normalizeTagPayload': {
        readonly memberPath: "contentControls.normalizeTagPayload";
        readonly description: "Normalize a content control tag between plain-string and JSON-encoded formats.";
        readonly expectedResult: "Returns a ContentControlMutationResult; reports NO_OP if already normalized.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "content-controls/normalize-tag-payload.mdx";
        readonly referenceGroup: "contentControls";
    };
    readonly 'contentControls.text.setMultiline': {
        readonly memberPath: "contentControls.text.setMultiline";
        readonly description: "Set or clear the multiline attribute on a plain-text content control.";
        readonly expectedResult: "Returns a ContentControlMutationResult; reports NO_OP if unchanged.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "content-controls/text/set-multiline.mdx";
        readonly referenceGroup: "contentControls";
    };
    readonly 'contentControls.text.setValue': {
        readonly memberPath: "contentControls.text.setValue";
        readonly description: "Set the text value of a plain-text content control.";
        readonly expectedResult: "Returns a ContentControlMutationResult; reports NO_OP if unchanged.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "content-controls/text/set-value.mdx";
        readonly referenceGroup: "contentControls";
    };
    readonly 'contentControls.text.clearValue': {
        readonly memberPath: "contentControls.text.clearValue";
        readonly description: "Clear the text value of a plain-text content control.";
        readonly expectedResult: "Returns a ContentControlMutationResult; reports NO_OP if already empty.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "content-controls/text/clear-value.mdx";
        readonly referenceGroup: "contentControls";
    };
    readonly 'contentControls.date.setValue': {
        readonly memberPath: "contentControls.date.setValue";
        readonly description: "Set the date value of a date content control.";
        readonly expectedResult: "Returns a ContentControlMutationResult; reports NO_OP if unchanged.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "content-controls/date/set-value.mdx";
        readonly referenceGroup: "contentControls";
    };
    readonly 'contentControls.date.clearValue': {
        readonly memberPath: "contentControls.date.clearValue";
        readonly description: "Clear the date value of a date content control.";
        readonly expectedResult: "Returns a ContentControlMutationResult; reports NO_OP if already empty.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "content-controls/date/clear-value.mdx";
        readonly referenceGroup: "contentControls";
    };
    readonly 'contentControls.date.setDisplayFormat': {
        readonly memberPath: "contentControls.date.setDisplayFormat";
        readonly description: "Set the display format string for a date content control.";
        readonly expectedResult: "Returns a ContentControlMutationResult; reports NO_OP if unchanged.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "content-controls/date/set-display-format.mdx";
        readonly referenceGroup: "contentControls";
    };
    readonly 'contentControls.date.setDisplayLocale': {
        readonly memberPath: "contentControls.date.setDisplayLocale";
        readonly description: "Set the display locale for a date content control.";
        readonly expectedResult: "Returns a ContentControlMutationResult; reports NO_OP if unchanged.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "content-controls/date/set-display-locale.mdx";
        readonly referenceGroup: "contentControls";
    };
    readonly 'contentControls.date.setStorageFormat': {
        readonly memberPath: "contentControls.date.setStorageFormat";
        readonly description: "Set the XML storage format for a date content control.";
        readonly expectedResult: "Returns a ContentControlMutationResult; reports NO_OP if unchanged.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "content-controls/date/set-storage-format.mdx";
        readonly referenceGroup: "contentControls";
    };
    readonly 'contentControls.date.setCalendar': {
        readonly memberPath: "contentControls.date.setCalendar";
        readonly description: "Set the calendar type for a date content control.";
        readonly expectedResult: "Returns a ContentControlMutationResult; reports NO_OP if unchanged.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "content-controls/date/set-calendar.mdx";
        readonly referenceGroup: "contentControls";
    };
    readonly 'contentControls.checkbox.getState': {
        readonly memberPath: "contentControls.checkbox.getState";
        readonly description: "Get the checked state of a checkbox content control.";
        readonly expectedResult: "Returns a CheckboxGetStateResult with the checked boolean.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "content-controls/checkbox/get-state.mdx";
        readonly referenceGroup: "contentControls";
    };
    readonly 'contentControls.checkbox.setState': {
        readonly memberPath: "contentControls.checkbox.setState";
        readonly description: "Set the checked state of a checkbox content control.";
        readonly expectedResult: "Returns a ContentControlMutationResult; reports NO_OP if unchanged.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "content-controls/checkbox/set-state.mdx";
        readonly referenceGroup: "contentControls";
    };
    readonly 'contentControls.checkbox.toggle': {
        readonly memberPath: "contentControls.checkbox.toggle";
        readonly description: "Toggle the checked state of a checkbox content control.";
        readonly expectedResult: "Returns a ContentControlMutationResult with the updated state.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "content-controls/checkbox/toggle.mdx";
        readonly referenceGroup: "contentControls";
    };
    readonly 'contentControls.checkbox.setSymbolPair': {
        readonly memberPath: "contentControls.checkbox.setSymbolPair";
        readonly description: "Set the checked and unchecked symbol glyphs for a checkbox content control.";
        readonly expectedResult: "Returns a ContentControlMutationResult; reports NO_OP if symbols unchanged.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "content-controls/checkbox/set-symbol-pair.mdx";
        readonly referenceGroup: "contentControls";
    };
    readonly 'contentControls.choiceList.getItems': {
        readonly memberPath: "contentControls.choiceList.getItems";
        readonly description: "Get the list items and selected value of a comboBox or dropDownList content control.";
        readonly expectedResult: "Returns a ChoiceListGetItemsResult with items and selectedValue.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "content-controls/choice-list/get-items.mdx";
        readonly referenceGroup: "contentControls";
    };
    readonly 'contentControls.choiceList.setItems': {
        readonly memberPath: "contentControls.choiceList.setItems";
        readonly description: "Replace the list items of a comboBox or dropDownList content control.";
        readonly expectedResult: "Returns a ContentControlMutationResult; reports NO_OP if items unchanged.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "content-controls/choice-list/set-items.mdx";
        readonly referenceGroup: "contentControls";
    };
    readonly 'contentControls.choiceList.setSelected': {
        readonly memberPath: "contentControls.choiceList.setSelected";
        readonly description: "Set the selected value of a comboBox or dropDownList content control.";
        readonly expectedResult: "Returns a ContentControlMutationResult; reports NO_OP if selection unchanged.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "content-controls/choice-list/set-selected.mdx";
        readonly referenceGroup: "contentControls";
    };
    readonly 'contentControls.repeatingSection.listItems': {
        readonly memberPath: "contentControls.repeatingSection.listItems";
        readonly description: "List the repeating section items inside a repeating section content control.";
        readonly expectedResult: "Returns a RepeatingSectionListItemsResult with child item info.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "content-controls/repeating-section/list-items.mdx";
        readonly referenceGroup: "contentControls";
    };
    readonly 'contentControls.repeatingSection.insertItemBefore': {
        readonly memberPath: "contentControls.repeatingSection.insertItemBefore";
        readonly description: "Insert a new item before a specific index in a repeating section.";
        readonly expectedResult: "Returns a ContentControlMutationResult with the new item target.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "content-controls/repeating-section/insert-item-before.mdx";
        readonly referenceGroup: "contentControls";
    };
    readonly 'contentControls.repeatingSection.insertItemAfter': {
        readonly memberPath: "contentControls.repeatingSection.insertItemAfter";
        readonly description: "Insert a new item after a specific index in a repeating section.";
        readonly expectedResult: "Returns a ContentControlMutationResult with the new item target.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "content-controls/repeating-section/insert-item-after.mdx";
        readonly referenceGroup: "contentControls";
    };
    readonly 'contentControls.repeatingSection.cloneItem': {
        readonly memberPath: "contentControls.repeatingSection.cloneItem";
        readonly description: "Clone a repeating section item at the given index. Cloned SDTs receive new IDs.";
        readonly expectedResult: "Returns a ContentControlMutationResult with the cloned item target.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "content-controls/repeating-section/clone-item.mdx";
        readonly referenceGroup: "contentControls";
    };
    readonly 'contentControls.repeatingSection.deleteItem': {
        readonly memberPath: "contentControls.repeatingSection.deleteItem";
        readonly description: "Delete a repeating section item at the given index.";
        readonly expectedResult: "Returns a ContentControlMutationResult; reports NO_OP if item does not exist.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "content-controls/repeating-section/delete-item.mdx";
        readonly referenceGroup: "contentControls";
    };
    readonly 'contentControls.repeatingSection.setAllowInsertDelete': {
        readonly memberPath: "contentControls.repeatingSection.setAllowInsertDelete";
        readonly description: "Set the allowInsertDelete flag on a repeating section.";
        readonly expectedResult: "Returns a ContentControlMutationResult; reports NO_OP if unchanged.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "content-controls/repeating-section/set-allow-insert-delete.mdx";
        readonly referenceGroup: "contentControls";
    };
    readonly 'contentControls.group.wrap': {
        readonly memberPath: "contentControls.group.wrap";
        readonly description: "Wrap a content control inside a new group content control. Always nests; not idempotent.";
        readonly expectedResult: "Returns a ContentControlMutationResult with the new group wrapper target.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "content-controls/group/wrap.mdx";
        readonly referenceGroup: "contentControls";
    };
    readonly 'contentControls.group.ungroup': {
        readonly memberPath: "contentControls.group.ungroup";
        readonly description: "Remove the group designation from a group content control.";
        readonly expectedResult: "Returns a ContentControlMutationResult; reports NO_OP if not a group.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "content-controls/group/ungroup.mdx";
        readonly referenceGroup: "contentControls";
    };
    readonly 'bookmarks.list': {
        readonly memberPath: "bookmarks.list";
        readonly description: "List all bookmarks in the document.";
        readonly expectedResult: "Returns a BookmarksListResult containing discovered bookmarks with address and domain data.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "bookmarks/list.mdx";
        readonly referenceGroup: "bookmarks";
    };
    readonly 'bookmarks.get': {
        readonly memberPath: "bookmarks.get";
        readonly description: "Get detailed information about a specific bookmark.";
        readonly expectedResult: "Returns a BookmarkInfo object with the bookmark's name, range, and optional table-column data.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "bookmarks/get.mdx";
        readonly referenceGroup: "bookmarks";
    };
    readonly 'bookmarks.insert': {
        readonly memberPath: "bookmarks.insert";
        readonly description: "Insert a new named bookmark at a target location.";
        readonly expectedResult: "Returns a BookmarkMutationResult indicating success with the bookmark address or a failure.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "bookmarks/insert.mdx";
        readonly referenceGroup: "bookmarks";
    };
    readonly 'bookmarks.rename': {
        readonly memberPath: "bookmarks.rename";
        readonly description: "Rename an existing bookmark.";
        readonly expectedResult: "Returns a BookmarkMutationResult indicating success with the updated bookmark address or a failure.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "bookmarks/rename.mdx";
        readonly referenceGroup: "bookmarks";
    };
    readonly 'bookmarks.remove': {
        readonly memberPath: "bookmarks.remove";
        readonly description: "Remove a bookmark from the document.";
        readonly expectedResult: "Returns a BookmarkMutationResult indicating success or a failure.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "bookmarks/remove.mdx";
        readonly referenceGroup: "bookmarks";
    };
    readonly 'footnotes.list': {
        readonly memberPath: "footnotes.list";
        readonly description: "List all footnotes and endnotes in the document.";
        readonly expectedResult: "Returns a FootnotesListResult containing discovered footnotes with address and domain data.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "footnotes/list.mdx";
        readonly referenceGroup: "footnotes";
    };
    readonly 'footnotes.get': {
        readonly memberPath: "footnotes.get";
        readonly description: "Get detailed information about a specific footnote or endnote.";
        readonly expectedResult: "Returns a FootnoteInfo object with the note's type, display number, and content.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "footnotes/get.mdx";
        readonly referenceGroup: "footnotes";
    };
    readonly 'footnotes.insert': {
        readonly memberPath: "footnotes.insert";
        readonly description: "Insert a new footnote or endnote at a target location or the current selection. Structured `body` content is currently available on v2-backed sessions only; v1-backed sessions return `CAPABILITY_UNAVAILABLE` for those shapes.";
        readonly expectedResult: "Returns a FootnoteMutationResult indicating success with the footnote address or a failure.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "footnotes/insert.mdx";
        readonly referenceGroup: "footnotes";
    };
    readonly 'footnotes.update': {
        readonly memberPath: "footnotes.update";
        readonly description: "Update the content of an existing footnote or endnote. Structured `body` content is currently available on v2-backed sessions only; v1-backed sessions return `CAPABILITY_UNAVAILABLE` for those shapes.";
        readonly expectedResult: "Returns a FootnoteMutationResult indicating success with the updated footnote address or a failure.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "footnotes/update.mdx";
        readonly referenceGroup: "footnotes";
    };
    readonly 'footnotes.remove': {
        readonly memberPath: "footnotes.remove";
        readonly description: "Remove a footnote or endnote from the document.";
        readonly expectedResult: "Returns a FootnoteMutationResult indicating success or a failure.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "footnotes/remove.mdx";
        readonly referenceGroup: "footnotes";
    };
    readonly 'footnotes.configure': {
        readonly memberPath: "footnotes.configure";
        readonly description: "Configure numbering and placement for footnotes or endnotes.";
        readonly expectedResult: "Returns a FootnoteConfigResult indicating success or a failure.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "footnotes/configure.mdx";
        readonly referenceGroup: "footnotes";
    };
    readonly 'clipboard.parse': {
        readonly memberPath: "clipboard.parse";
        readonly description: "Parse and sanitize a ClipboardPayload into a deterministic v2 clipboard insert plan with diagnostics. Does not mutate the document.";
        readonly expectedResult: "Returns a ClipboardParseResult with a ClipboardInsertPlan or a named fail-closed reason.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "clipboard/parse.mdx";
        readonly referenceGroup: "clipboard";
    };
    readonly 'clipboard.insert': {
        readonly memberPath: "clipboard.insert";
        readonly description: "Insert a parsed clipboard plan, v2 fragment, or raw ClipboardPayload through the v2 pasteFragment kernel operation.";
        readonly expectedResult: "Returns a ClipboardInsertResult with inserted refs, diagnostics, and one paste transaction receipt, or a named fail-closed reason.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "clipboard/insert.mdx";
        readonly referenceGroup: "clipboard";
    };
    readonly 'clipboard.serializeSelection': {
        readonly memberPath: "clipboard.serializeSelection";
        readonly description: "Serialize the current or supplied model selection into text/plain, text/html, and application/x-superdoc-v2-fragment clipboard payloads.";
        readonly expectedResult: "Returns a ClipboardSerializeResult containing the payload and normalized insert plan.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "clipboard/serialize-selection.mdx";
        readonly referenceGroup: "clipboard";
    };
    readonly 'crossRefs.list': {
        readonly memberPath: "crossRefs.list";
        readonly description: "List all cross-reference fields in the document.";
        readonly expectedResult: "Returns a CrossRefsListResult containing discovered cross-references with address and domain data.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "cross-refs/list.mdx";
        readonly referenceGroup: "crossRefs";
    };
    readonly 'crossRefs.get': {
        readonly memberPath: "crossRefs.get";
        readonly description: "Get detailed information about a specific cross-reference field.";
        readonly expectedResult: "Returns a CrossRefInfo object with the cross-reference's target, display, and resolved text.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "cross-refs/get.mdx";
        readonly referenceGroup: "crossRefs";
    };
    readonly 'crossRefs.insert': {
        readonly memberPath: "crossRefs.insert";
        readonly description: "Insert a new cross-reference field at a target location.";
        readonly expectedResult: "Returns a CrossRefMutationResult indicating success with the cross-reference address or a failure.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "cross-refs/insert.mdx";
        readonly referenceGroup: "crossRefs";
    };
    readonly 'crossRefs.rebuild': {
        readonly memberPath: "crossRefs.rebuild";
        readonly description: "Rebuild (recalculate) a cross-reference field.";
        readonly expectedResult: "Returns a CrossRefMutationResult indicating success or a failure.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "cross-refs/rebuild.mdx";
        readonly referenceGroup: "crossRefs";
    };
    readonly 'crossRefs.remove': {
        readonly memberPath: "crossRefs.remove";
        readonly description: "Remove a cross-reference field from the document.";
        readonly expectedResult: "Returns a CrossRefMutationResult indicating success or a failure.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "cross-refs/remove.mdx";
        readonly referenceGroup: "crossRefs";
    };
    readonly 'index.list': {
        readonly memberPath: "index.list";
        readonly description: "List all index blocks in the document.";
        readonly expectedResult: "Returns an IndexListResult containing discovered index blocks with address and domain data.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "index/list.mdx";
        readonly referenceGroup: "index";
    };
    readonly 'index.get': {
        readonly memberPath: "index.get";
        readonly description: "Get detailed information about a specific index block.";
        readonly expectedResult: "Returns an IndexInfo object with the index's instruction, configuration, and entry count.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "index/get.mdx";
        readonly referenceGroup: "index";
    };
    readonly 'index.insert': {
        readonly memberPath: "index.insert";
        readonly description: "Insert a new index block at a target location.";
        readonly expectedResult: "Returns an IndexMutationResult indicating success with the index address or a failure.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "index/insert.mdx";
        readonly referenceGroup: "index";
    };
    readonly 'index.configure': {
        readonly memberPath: "index.configure";
        readonly description: "Update the configuration of an existing index block.";
        readonly expectedResult: "Returns an IndexMutationResult indicating success or a failure.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "index/configure.mdx";
        readonly referenceGroup: "index";
    };
    readonly 'index.rebuild': {
        readonly memberPath: "index.rebuild";
        readonly description: "Rebuild (regenerate) an index block from its entries.";
        readonly expectedResult: "Returns an IndexMutationResult indicating success or a failure.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "index/rebuild.mdx";
        readonly referenceGroup: "index";
    };
    readonly 'index.remove': {
        readonly memberPath: "index.remove";
        readonly description: "Remove an index block from the document.";
        readonly expectedResult: "Returns an IndexMutationResult indicating success or a failure.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "index/remove.mdx";
        readonly referenceGroup: "index";
    };
    readonly 'index.entries.list': {
        readonly memberPath: "index.entries.list";
        readonly description: "List all XE (index entry) fields in the document.";
        readonly expectedResult: "Returns an IndexEntryListResult containing discovered index entries with address and domain data.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "index/entries-list.mdx";
        readonly referenceGroup: "index";
    };
    readonly 'index.entries.get': {
        readonly memberPath: "index.entries.get";
        readonly description: "Get detailed information about a specific XE index entry.";
        readonly expectedResult: "Returns an IndexEntryInfo object with the entry's text, sub-entry, formatting, and instruction.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "index/entries-get.mdx";
        readonly referenceGroup: "index";
    };
    readonly 'index.entries.insert': {
        readonly memberPath: "index.entries.insert";
        readonly description: "Insert a new XE index entry field at a target location.";
        readonly expectedResult: "Returns an IndexEntryMutationResult indicating success with the entry address or a failure.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "index/entries-insert.mdx";
        readonly referenceGroup: "index";
    };
    readonly 'index.entries.update': {
        readonly memberPath: "index.entries.update";
        readonly description: "Update the properties of an existing XE index entry.";
        readonly expectedResult: "Returns an IndexEntryMutationResult indicating success or a failure.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "index/entries-update.mdx";
        readonly referenceGroup: "index";
    };
    readonly 'index.entries.remove': {
        readonly memberPath: "index.entries.remove";
        readonly description: "Remove an XE index entry field from the document.";
        readonly expectedResult: "Returns an IndexEntryMutationResult indicating success or a failure.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "index/entries-remove.mdx";
        readonly referenceGroup: "index";
    };
    readonly 'captions.list': {
        readonly memberPath: "captions.list";
        readonly description: "List all caption paragraphs in the document.";
        readonly expectedResult: "Returns a CaptionsListResult containing discovered captions with address and domain data.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "captions/list.mdx";
        readonly referenceGroup: "captions";
    };
    readonly 'captions.get': {
        readonly memberPath: "captions.get";
        readonly description: "Get detailed information about a specific caption paragraph.";
        readonly expectedResult: "Returns a CaptionInfo object with the caption's label, number, text, and instruction.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "captions/get.mdx";
        readonly referenceGroup: "captions";
    };
    readonly 'captions.insert': {
        readonly memberPath: "captions.insert";
        readonly description: "Insert a new caption paragraph adjacent to a target block.";
        readonly expectedResult: "Returns a CaptionMutationResult indicating success with the caption address or a failure.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "captions/insert.mdx";
        readonly referenceGroup: "captions";
    };
    readonly 'captions.update': {
        readonly memberPath: "captions.update";
        readonly description: "Append patch text to an existing caption paragraph.";
        readonly expectedResult: "Returns a CaptionMutationResult indicating success after appending patch.text to the existing caption body, or NO_OP when no text patch is provided.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "captions/update.mdx";
        readonly referenceGroup: "captions";
    };
    readonly 'captions.remove': {
        readonly memberPath: "captions.remove";
        readonly description: "Remove a caption paragraph from the document.";
        readonly expectedResult: "Returns a CaptionMutationResult indicating success or a failure.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "captions/remove.mdx";
        readonly referenceGroup: "captions";
    };
    readonly 'captions.configure': {
        readonly memberPath: "captions.configure";
        readonly description: "Configure numbering format for a caption label.";
        readonly expectedResult: "Returns a CaptionConfigResult indicating success or a failure.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "captions/configure.mdx";
        readonly referenceGroup: "captions";
    };
    readonly 'fields.list': {
        readonly memberPath: "fields.list";
        readonly description: "List all fields in the document.";
        readonly expectedResult: "Returns a FieldsListResult containing discovered fields with address and domain data.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "fields/list.mdx";
        readonly referenceGroup: "fields";
    };
    readonly 'fields.get': {
        readonly memberPath: "fields.get";
        readonly description: "Get detailed information about a specific field.";
        readonly expectedResult: "Returns a FieldInfo object with the field's instruction, result text, and nesting data.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "fields/get.mdx";
        readonly referenceGroup: "fields";
    };
    readonly 'fields.insert': {
        readonly memberPath: "fields.insert";
        readonly description: "Insert a raw field code at a target location, optionally preserving cached result text. The current v1 runtime supports rebuild flows; `cachedResultText` / `updatePolicy: \"preserveCached\"` currently return `CAPABILITY_UNAVAILABLE`.";
        readonly expectedResult: "Returns a FieldMutationResult indicating success with the field address or a failure.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "fields/insert.mdx";
        readonly referenceGroup: "fields";
    };
    readonly 'fields.rebuild': {
        readonly memberPath: "fields.rebuild";
        readonly description: "Rebuild (recalculate) a field.";
        readonly expectedResult: "Returns a FieldMutationResult indicating success or a failure.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "fields/rebuild.mdx";
        readonly referenceGroup: "fields";
    };
    readonly 'fields.remove': {
        readonly memberPath: "fields.remove";
        readonly description: "Remove a field from the document.";
        readonly expectedResult: "Returns a FieldMutationResult indicating success or a failure.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "fields/remove.mdx";
        readonly referenceGroup: "fields";
    };
    readonly 'citations.list': {
        readonly memberPath: "citations.list";
        readonly description: "List all citation marks in the document.";
        readonly expectedResult: "Returns a CitationsListResult containing discovered citation marks with address and domain data.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "citations/list.mdx";
        readonly referenceGroup: "citations";
    };
    readonly 'citations.get': {
        readonly memberPath: "citations.get";
        readonly description: "Get detailed information about a specific citation mark.";
        readonly expectedResult: "Returns a CitationInfo object with the citation's source references and display text.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "citations/get.mdx";
        readonly referenceGroup: "citations";
    };
    readonly 'citations.insert': {
        readonly memberPath: "citations.insert";
        readonly description: "Insert a new citation mark at a target location.";
        readonly expectedResult: "Returns a CitationMutationResult indicating success with the citation address or a failure.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "citations/insert.mdx";
        readonly referenceGroup: "citations";
    };
    readonly 'citations.update': {
        readonly memberPath: "citations.update";
        readonly description: "Update an existing citation mark's source references.";
        readonly expectedResult: "Returns a CitationMutationResult indicating success or a failure.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "citations/update.mdx";
        readonly referenceGroup: "citations";
    };
    readonly 'citations.remove': {
        readonly memberPath: "citations.remove";
        readonly description: "Remove a citation mark from the document.";
        readonly expectedResult: "Returns a CitationMutationResult indicating success or a failure.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "citations/remove.mdx";
        readonly referenceGroup: "citations";
    };
    readonly 'citations.sources.list': {
        readonly memberPath: "citations.sources.list";
        readonly description: "List all citation sources in the document store.";
        readonly expectedResult: "Returns a CitationSourcesListResult containing discovered sources with address and domain data.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "citations/sources-list.mdx";
        readonly referenceGroup: "citations";
    };
    readonly 'citations.sources.get': {
        readonly memberPath: "citations.sources.get";
        readonly description: "Get detailed information about a specific citation source.";
        readonly expectedResult: "Returns a CitationSourceInfo object with the source's type, fields, and metadata.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "citations/sources-get.mdx";
        readonly referenceGroup: "citations";
    };
    readonly 'citations.sources.insert': {
        readonly memberPath: "citations.sources.insert";
        readonly description: "Register a new citation source in the document store.";
        readonly expectedResult: "Returns a CitationSourceMutationResult indicating success with the source address or a failure.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "citations/sources-insert.mdx";
        readonly referenceGroup: "citations";
    };
    readonly 'citations.sources.update': {
        readonly memberPath: "citations.sources.update";
        readonly description: "Update the fields of an existing citation source.";
        readonly expectedResult: "Returns a CitationSourceMutationResult indicating success or a failure.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "citations/sources-update.mdx";
        readonly referenceGroup: "citations";
    };
    readonly 'citations.sources.remove': {
        readonly memberPath: "citations.sources.remove";
        readonly description: "Remove a citation source from the document store.";
        readonly expectedResult: "Returns a CitationSourceMutationResult indicating success or a failure.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "citations/sources-remove.mdx";
        readonly referenceGroup: "citations";
    };
    readonly 'citations.bibliography.get': {
        readonly memberPath: "citations.bibliography.get";
        readonly description: "Get information about the bibliography block.";
        readonly expectedResult: "Returns a BibliographyInfo object with the bibliography's address and configuration.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "citations/bibliography-get.mdx";
        readonly referenceGroup: "citations";
    };
    readonly 'citations.bibliography.insert': {
        readonly memberPath: "citations.bibliography.insert";
        readonly description: "Insert a bibliography block at a target location.";
        readonly expectedResult: "Returns a BibliographyMutationResult indicating success with the bibliography address or a failure.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "citations/bibliography-insert.mdx";
        readonly referenceGroup: "citations";
    };
    readonly 'citations.bibliography.rebuild': {
        readonly memberPath: "citations.bibliography.rebuild";
        readonly description: "Rebuild the bibliography from current sources.";
        readonly expectedResult: "Returns a BibliographyMutationResult indicating success or a failure.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "citations/bibliography-rebuild.mdx";
        readonly referenceGroup: "citations";
    };
    readonly 'citations.bibliography.configure': {
        readonly memberPath: "citations.bibliography.configure";
        readonly description: "Configure the bibliography style.";
        readonly expectedResult: "Returns a BibliographyMutationResult indicating success or a failure.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "citations/bibliography-configure.mdx";
        readonly referenceGroup: "citations";
    };
    readonly 'citations.bibliography.remove': {
        readonly memberPath: "citations.bibliography.remove";
        readonly description: "Remove the bibliography block from the document.";
        readonly expectedResult: "Returns a BibliographyMutationResult indicating success or a failure.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "citations/bibliography-remove.mdx";
        readonly referenceGroup: "citations";
    };
    readonly 'authorities.list': {
        readonly memberPath: "authorities.list";
        readonly description: "List all table-of-authorities blocks in the document.";
        readonly expectedResult: "Returns an AuthoritiesListResult containing discovered TOA blocks with address and domain data.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "authorities/list.mdx";
        readonly referenceGroup: "authorities";
    };
    readonly 'authorities.get': {
        readonly memberPath: "authorities.get";
        readonly description: "Get detailed information about a specific table-of-authorities block.";
        readonly expectedResult: "Returns an AuthoritiesInfo object with the TOA's category filter and configuration.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "authorities/get.mdx";
        readonly referenceGroup: "authorities";
    };
    readonly 'authorities.insert': {
        readonly memberPath: "authorities.insert";
        readonly description: "Insert a new table-of-authorities block at a target location.";
        readonly expectedResult: "Returns an AuthoritiesMutationResult indicating success with the TOA address or a failure.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "authorities/insert.mdx";
        readonly referenceGroup: "authorities";
    };
    readonly 'authorities.configure': {
        readonly memberPath: "authorities.configure";
        readonly description: "Update the configuration of an existing table-of-authorities block.";
        readonly expectedResult: "Returns an AuthoritiesMutationResult indicating success or a failure.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "authorities/configure.mdx";
        readonly referenceGroup: "authorities";
    };
    readonly 'authorities.rebuild': {
        readonly memberPath: "authorities.rebuild";
        readonly description: "Rebuild a table-of-authorities block from its entries.";
        readonly expectedResult: "Returns an AuthoritiesMutationResult indicating success or a failure.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "authorities/rebuild.mdx";
        readonly referenceGroup: "authorities";
    };
    readonly 'authorities.remove': {
        readonly memberPath: "authorities.remove";
        readonly description: "Remove a table-of-authorities block from the document.";
        readonly expectedResult: "Returns an AuthoritiesMutationResult indicating success or a failure.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "authorities/remove.mdx";
        readonly referenceGroup: "authorities";
    };
    readonly 'authorities.entries.list': {
        readonly memberPath: "authorities.entries.list";
        readonly description: "List all TA (authority entry) fields in the document.";
        readonly expectedResult: "Returns an AuthorityEntryListResult containing discovered entries with address and domain data.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "authorities/entries-list.mdx";
        readonly referenceGroup: "authorities";
    };
    readonly 'authorities.entries.get': {
        readonly memberPath: "authorities.entries.get";
        readonly description: "Get detailed information about a specific TA authority entry.";
        readonly expectedResult: "Returns an AuthorityEntryInfo object with the entry's citations and category.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "authorities/entries-get.mdx";
        readonly referenceGroup: "authorities";
    };
    readonly 'authorities.entries.insert': {
        readonly memberPath: "authorities.entries.insert";
        readonly description: "Insert a new TA authority entry field at a target location.";
        readonly expectedResult: "Returns an AuthorityEntryMutationResult indicating success with the entry address or a failure.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "authorities/entries-insert.mdx";
        readonly referenceGroup: "authorities";
    };
    readonly 'authorities.entries.update': {
        readonly memberPath: "authorities.entries.update";
        readonly description: "Update the properties of an existing TA authority entry.";
        readonly expectedResult: "Returns an AuthorityEntryMutationResult indicating success or a failure.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "authorities/entries-update.mdx";
        readonly referenceGroup: "authorities";
    };
    readonly 'authorities.entries.remove': {
        readonly memberPath: "authorities.entries.remove";
        readonly description: "Remove a TA authority entry field from the document.";
        readonly expectedResult: "Returns an AuthorityEntryMutationResult indicating success or a failure.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "authorities/entries-remove.mdx";
        readonly referenceGroup: "authorities";
    };
    readonly 'diff.capture': {
        readonly memberPath: "diff.capture";
        readonly description: string;
        readonly expectedResult: "Returns a DiffSnapshot with a fingerprint and opaque payload.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "diff/capture.mdx";
        readonly referenceGroup: "diff";
        readonly skipAsATool: true;
    };
    readonly 'diff.compare': {
        readonly memberPath: "diff.compare";
        readonly description: string;
        readonly expectedResult: "Returns a DiffPayload with a summary and opaque payload.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "diff/compare.mdx";
        readonly referenceGroup: "diff";
        readonly skipAsATool: true;
    };
    readonly 'diff.apply': {
        readonly memberPath: "diff.apply";
        readonly description: string;
        readonly expectedResult: "Returns a DiffApplyResult with per-operation review receipts, applied operation count, and diagnostics.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "diff/apply.mdx";
        readonly referenceGroup: "diff";
        readonly skipAsATool: true;
    };
    readonly 'export.toDocx': {
        readonly memberPath: "export.toDocx";
        readonly description: string;
        readonly expectedResult: "Returns an ExportToDocxResult with the resolved mode, base64 DOCX bytes, byte length, and a report.warnings array.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "export/to-docx.mdx";
        readonly referenceGroup: "export";
        readonly skipAsATool: true;
    };
    readonly 'protection.get': {
        readonly memberPath: "protection.get";
        readonly description: "Read the current document protection state including editing restrictions, write protection, and read-only recommendation.";
        readonly expectedResult: "Returns a DocumentProtectionState with editingRestriction, writeProtection, and readOnlyRecommended fields.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "protection/get.mdx";
        readonly referenceGroup: "protection";
        readonly skipAsATool: true;
    };
    readonly 'protection.setEditingRestriction': {
        readonly memberPath: "protection.setEditingRestriction";
        readonly description: "Enable Word-style editing restriction on the document. Only readOnly mode is supported in v1.";
        readonly expectedResult: "Returns a ProtectionMutationResult with the updated protection state on success.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "protection/set-editing-restriction.mdx";
        readonly referenceGroup: "protection";
        readonly skipAsATool: true;
    };
    readonly 'protection.clearEditingRestriction': {
        readonly memberPath: "protection.clearEditingRestriction";
        readonly description: "Disable document-level editing restriction by setting enforcement to off. Preserves the protection element and its metadata for round-trip fidelity.";
        readonly expectedResult: "Returns a ProtectionMutationResult with the updated protection state on success.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "protection/clear-editing-restriction.mdx";
        readonly referenceGroup: "protection";
        readonly skipAsATool: true;
    };
    readonly 'permissionRanges.list': {
        readonly memberPath: "permissionRanges.list";
        readonly description: "List all permission ranges in the document. Returns only complete paired ranges (both start and end markers present).";
        readonly expectedResult: "Returns a PermissionRangesListResult containing discovered permission ranges with principal and position data.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "permission-ranges/list.mdx";
        readonly referenceGroup: "permissionRanges";
        readonly skipAsATool: true;
    };
    readonly 'permissionRanges.get': {
        readonly memberPath: "permissionRanges.get";
        readonly description: "Get detailed information about a specific permission range by ID.";
        readonly expectedResult: "Returns a PermissionRangeInfo object with the range principal, kind, and positions.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "permission-ranges/get.mdx";
        readonly referenceGroup: "permissionRanges";
        readonly skipAsATool: true;
    };
    readonly 'permissionRanges.create': {
        readonly memberPath: "permissionRanges.create";
        readonly description: "Create a permission range exception region in the document. Inserts matched permStart/permEnd markers at the target.";
        readonly expectedResult: "Returns a PermissionRangeMutationResult with the created range info on success.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "permission-ranges/create.mdx";
        readonly referenceGroup: "permissionRanges";
        readonly skipAsATool: true;
    };
    readonly 'permissionRanges.remove': {
        readonly memberPath: "permissionRanges.remove";
        readonly description: "Remove a permission range by ID. Removes whichever markers exist for the given ID (start, end, or both).";
        readonly expectedResult: "Returns a PermissionRangeRemoveResult indicating success or a failure.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "permission-ranges/remove.mdx";
        readonly referenceGroup: "permissionRanges";
        readonly skipAsATool: true;
    };
    readonly 'permissionRanges.updatePrincipal': {
        readonly memberPath: "permissionRanges.updatePrincipal";
        readonly description: "Change which principal is allowed to edit a permission range. Updates the principal fields on the start marker.";
        readonly expectedResult: "Returns a PermissionRangeMutationResult with the updated range info on success.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "permission-ranges/update-principal.mdx";
        readonly referenceGroup: "permissionRanges";
        readonly skipAsATool: true;
    };
    readonly 'customXml.parts.list': {
        readonly memberPath: "customXml.parts.list";
        readonly description: "List Custom XML Data Storage Parts in the document, optionally filtered by root namespace or schema reference.";
        readonly expectedResult: "Returns a CustomXmlPartsListResult with summary entries (no content); fetch content via get.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "custom-xml/parts/list.mdx";
        readonly referenceGroup: "customXml";
    };
    readonly 'customXml.parts.get': {
        readonly memberPath: "customXml.parts.get";
        readonly description: string;
        readonly expectedResult: "Returns a CustomXmlPartInfo with id, partName, namespaces, schemaRefs, and content; or null if not found.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "custom-xml/parts/get.mdx";
        readonly referenceGroup: "customXml";
    };
    readonly 'customXml.parts.create': {
        readonly memberPath: "customXml.parts.create";
        readonly description: "Add a new Custom XML Data Storage Part to the document. Generates a fresh itemID GUID and emits the Properties Part.";
        readonly expectedResult: "Returns a CustomXmlPartsCreateResult with the generated id and package part names on success.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "custom-xml/parts/create.mdx";
        readonly referenceGroup: "customXml";
    };
    readonly 'customXml.parts.patch': {
        readonly memberPath: "customXml.parts.patch";
        readonly description: string;
        readonly expectedResult: "Returns a CustomXmlPartsMutationResult indicating success with the resolved target or a failure.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "custom-xml/parts/patch.mdx";
        readonly referenceGroup: "customXml";
    };
    readonly 'customXml.parts.remove': {
        readonly memberPath: "customXml.parts.remove";
        readonly description: string;
        readonly expectedResult: "Returns a CustomXmlPartsMutationResult indicating success or a failure.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "custom-xml/parts/remove.mdx";
        readonly referenceGroup: "customXml";
    };
    readonly 'metadata.attach': {
        readonly memberPath: "metadata.attach";
        readonly description: string;
        readonly expectedResult: "Returns an AnchoredMetadataAttachResult with the assigned id and the backing Storage Part name on success.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "metadata/attach.mdx";
        readonly referenceGroup: "metadata";
    };
    readonly 'metadata.list': {
        readonly memberPath: "metadata.list";
        readonly description: "List anchored-metadata entries in the document, optionally filtered by consumer namespace and/or a `within` selection (returns only entries whose anchor overlaps `within`).";
        readonly expectedResult: "Returns an AnchoredMetadataListResult with summary entries (no payload); fetch payload via get.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "metadata/list.mdx";
        readonly referenceGroup: "metadata";
    };
    readonly 'metadata.get': {
        readonly memberPath: "metadata.get";
        readonly description: "Get a single anchored-metadata entry by id, including its JSON payload.";
        readonly expectedResult: "Returns an AnchoredMetadataInfo with id, namespace, partName, and payload; or null if not found.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "metadata/get.mdx";
        readonly referenceGroup: "metadata";
    };
    readonly 'metadata.update': {
        readonly memberPath: "metadata.update";
        readonly description: "Replace the JSON payload of an existing anchored-metadata entry. Replace semantics; no merge. The anchor is left untouched.";
        readonly expectedResult: "Returns an AnchoredMetadataMutationResult with the entry id on success or a failure.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "metadata/update.mdx";
        readonly referenceGroup: "metadata";
    };
    readonly 'metadata.remove': {
        readonly memberPath: "metadata.remove";
        readonly description: "Remove an anchored-metadata entry. Strips the anchor content-control wrapper (its content stays in the document) and deletes the payload entry from the Storage Part. In v1 these writes are sequenced, not transactional: the adapter resolves the target up-front so missing-target failures land before any state change, but a crash strictly between the two writes can leave a dangling payload. When the backing part has no remaining entries, the part itself is removed.";
        readonly expectedResult: "Returns an AnchoredMetadataMutationResult with the removed entry id on success or a failure.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "metadata/remove.mdx";
        readonly referenceGroup: "metadata";
    };
    readonly 'metadata.resolve': {
        readonly memberPath: "metadata.resolve";
        readonly description: "Find where an anchored-metadata entry is anchored in the document. Returns the SelectionTarget covering the anchor content.";
        readonly expectedResult: "Returns an AnchoredMetadataResolveInfo with id and target SelectionTarget; or null if the anchor is no longer present.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "metadata/resolve.mdx";
        readonly referenceGroup: "metadata";
    };
    readonly "format.bold": OperationDefinitionEntry;
    readonly "format.strike": OperationDefinitionEntry;
    readonly "format.color": OperationDefinitionEntry;
    readonly "format.italic": OperationDefinitionEntry;
    readonly "format.rtl": OperationDefinitionEntry;
    readonly "format.cs": OperationDefinitionEntry;
    readonly "format.shading": OperationDefinitionEntry;
    readonly "format.fontFamily": OperationDefinitionEntry;
    readonly "format.lang": OperationDefinitionEntry;
    readonly "format.fontSize": OperationDefinitionEntry;
    readonly "format.fontSizeCs": OperationDefinitionEntry;
    readonly "format.highlight": OperationDefinitionEntry;
    readonly "format.underline": OperationDefinitionEntry;
    readonly "format.caps": OperationDefinitionEntry;
    readonly "format.smallCaps": OperationDefinitionEntry;
    readonly "format.outline": OperationDefinitionEntry;
    readonly "format.shadow": OperationDefinitionEntry;
    readonly "format.emboss": OperationDefinitionEntry;
    readonly "format.imprint": OperationDefinitionEntry;
    readonly "format.vanish": OperationDefinitionEntry;
    readonly "format.webHidden": OperationDefinitionEntry;
    readonly "format.specVanish": OperationDefinitionEntry;
    readonly "format.border": OperationDefinitionEntry;
    readonly "format.fitText": OperationDefinitionEntry;
    readonly "format.dstrike": OperationDefinitionEntry;
    readonly "format.vertAlign": OperationDefinitionEntry;
    readonly "format.position": OperationDefinitionEntry;
    readonly "format.bCs": OperationDefinitionEntry;
    readonly "format.iCs": OperationDefinitionEntry;
    readonly "format.snapToGrid": OperationDefinitionEntry;
    readonly "format.oMath": OperationDefinitionEntry;
    readonly "format.letterSpacing": OperationDefinitionEntry;
    readonly "format.charScale": OperationDefinitionEntry;
    readonly "format.kerning": OperationDefinitionEntry;
    readonly "format.rStyle": OperationDefinitionEntry;
    readonly "format.rFonts": OperationDefinitionEntry;
    readonly "format.eastAsianLayout": OperationDefinitionEntry;
    readonly "format.em": OperationDefinitionEntry;
    readonly "format.ligatures": OperationDefinitionEntry;
    readonly "format.numForm": OperationDefinitionEntry;
    readonly "format.numSpacing": OperationDefinitionEntry;
    readonly "format.stylisticSets": OperationDefinitionEntry;
    readonly "format.contextualAlternates": OperationDefinitionEntry;
    readonly get: {
        readonly memberPath: "get";
        readonly description: "Read the full document as an SDDocument structure.";
        readonly expectedResult: "Returns an SDDocument with body content projected into SDM/1 canonical shapes.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "get.mdx";
        readonly referenceGroup: ReferenceGroupKey;
    };
    readonly find: {
        readonly memberPath: "find";
        readonly description: "Search the document for text or node matches using SDM/1 selectors. Returns discovery-grade results: for mutation targeting, use query.match instead.";
        readonly expectedResult: "Returns an SDFindResult envelope ({ total, limit, offset, items }). Each item is an SDNodeResult ({ node, address }).";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "find.mdx";
        readonly referenceGroup: "core";
        readonly skipAsATool: true;
    };
    readonly getNode: {
        readonly memberPath: "getNode";
        readonly description: "Retrieve a single node by target position.";
        readonly expectedResult: "Returns an SDNodeResult envelope with the projected SDM/1 node and canonical address.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "get-node.mdx";
        readonly referenceGroup: "core";
    };
    readonly getNodeById: {
        readonly memberPath: "getNodeById";
        readonly description: "Retrieve a single node by its unique ID.";
        readonly expectedResult: "Returns an SDNodeResult envelope with the projected SDM/1 node and canonical address.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "get-node-by-id.mdx";
        readonly referenceGroup: "core";
    };
    readonly getText: {
        readonly memberPath: "getText";
        readonly description: "Extract the plain-text content of the document.";
        readonly expectedResult: "Returns the full plain-text content of the document as a string.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "get-text.mdx";
        readonly referenceGroup: "core";
        readonly intentGroup: "get_content";
        readonly intentAction: "text";
    };
    readonly getMarkdown: {
        readonly memberPath: "getMarkdown";
        readonly description: "Extract the document content as a Markdown string.";
        readonly expectedResult: "Returns the full document content as a Markdown-formatted string.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "get-markdown.mdx";
        readonly referenceGroup: "core";
        readonly intentGroup: "get_content";
        readonly intentAction: "markdown";
    };
    readonly getHtml: {
        readonly memberPath: "getHtml";
        readonly description: "Extract the document content as an HTML string.";
        readonly expectedResult: "Returns the full document content as an HTML-formatted string.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "get-html.mdx";
        readonly referenceGroup: "core";
        readonly intentGroup: "get_content";
        readonly intentAction: "html";
    };
    readonly projectMarkdown: {
        readonly memberPath: "projectMarkdown";
        readonly description: "Project document content as Markdown with review, scope, diagnostics, and provenance metadata.";
        readonly expectedResult: "Returns a Promise resolving to a detailed Markdown content projection result.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "project-markdown.mdx";
        readonly referenceGroup: "core";
        readonly intentGroup: "get_content";
        readonly intentAction: "markdown_projection";
    };
    readonly projectHtml: {
        readonly memberPath: "projectHtml";
        readonly description: "Project document content as HTML with review, scope, diagnostics, and provenance metadata.";
        readonly expectedResult: "Returns a Promise resolving to a detailed HTML content projection result.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "project-html.mdx";
        readonly referenceGroup: "core";
        readonly intentGroup: "get_content";
        readonly intentAction: "html_projection";
    };
    readonly markdownToFragment: {
        readonly memberPath: "markdownToFragment";
        readonly description: "Convert a Markdown string into an SDM/1 structural fragment.";
        readonly expectedResult: "Returns an SDMarkdownToFragmentResult with the converted fragment, lossy flag, and diagnostics.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "markdown-to-fragment.mdx";
        readonly referenceGroup: "core";
    };
    readonly htmlToFragment: {
        readonly memberPath: "htmlToFragment";
        readonly description: "Convert an HTML string into an SDM/1 structural fragment.";
        readonly expectedResult: "Returns an SDHtmlToFragmentResult with the converted fragment, lossy flag, and diagnostics.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "html-to-fragment.mdx";
        readonly referenceGroup: "core";
    };
    readonly info: {
        readonly memberPath: "info";
        readonly description: "Return document summary info including word, character, paragraph, heading, table, image, comment, tracked-change, SDT-field, list, and page counts, plus outline and capabilities.";
        readonly expectedResult: "Returns a DocumentInfo object with counts (words, characters, paragraphs, headings, tables, images, comments, trackedChanges, sdtFields, lists, and optionally pages when pagination is active), document outline, capability flags, and revision.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "info.mdx";
        readonly referenceGroup: "core";
        readonly intentGroup: "get_content";
        readonly intentAction: "info";
    };
    readonly extract: {
        readonly memberPath: "extract";
        readonly description: "Extract all document content with stable IDs for RAG pipelines. Returns blocks with full text, comments, and tracked changes: each with an ID compatible with scrollToElement().";
        readonly expectedResult: "Returns an ExtractResult with blocks (nodeId, type, text, headingLevel), comments (entityId, text, anchoredText, blockId, status, author), tracked changes (entityId, type, excerpt, author, date), and revision.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "extract.mdx";
        readonly referenceGroup: "core";
        readonly intentGroup: "get_content";
        readonly intentAction: "extract";
    };
    readonly clearContent: {
        readonly memberPath: "clearContent";
        readonly description: "Clear all document body content, leaving a single empty paragraph.";
        readonly expectedResult: "Returns a Receipt with success status; reports NO_OP if the document is already empty.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "clear-content.mdx";
        readonly referenceGroup: "core";
    };
    readonly insert: {
        readonly memberPath: "insert";
        readonly description: string;
        readonly expectedResult: "Returns an SDMutationReceipt with applied status; resolution reports the resolved insertion point/target. Created visible text and structural blocks are reported through effects.insertedText and effects.insertedBlocks when available. Receipt reports NO_OP if the insertion point is invalid or content is empty.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "insert.mdx";
        readonly referenceGroup: "core";
        readonly intentGroup: "edit";
        readonly intentAction: "insert";
    };
    readonly replace: {
        readonly memberPath: "replace";
        readonly description: string;
        readonly expectedResult: "Returns an SDMutationReceipt with applied status; receipt reports NO_OP if the target range already contains identical content.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "replace.mdx";
        readonly referenceGroup: "core";
        readonly intentGroup: "edit";
        readonly intentAction: "replace";
    };
    readonly delete: {
        readonly memberPath: "delete";
        readonly description: "Delete content at a contiguous document selection. Accepts a SelectionTarget or mutation-ready ref. Supports cross-block deletion and optional block-edge expansion via behavior mode.";
        readonly expectedResult: "Returns a TextMutationReceipt with applied status; receipt reports NO_OP if the target range is collapsed or empty.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "delete.mdx";
        readonly referenceGroup: "core";
        readonly intentGroup: "edit";
        readonly intentAction: "delete";
    };
    readonly formatRange: {
        readonly memberPath: "formatRange";
        readonly description: "Legacy root-level alias for inline range formatting. Routes to `format.apply` for compatibility with older callers.";
        readonly expectedResult: "Returns a TextMutationReceipt confirming inline styles were applied to the target range.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "format/apply.mdx";
        readonly referenceGroup: "format";
        readonly skipAsATool: true;
    };
    readonly 'blocks.list': {
        readonly memberPath: "blocks.list";
        readonly description: "List top-level blocks in document order with IDs, types, text previews, and optional full text when includeText:true. Supports pagination via offset/limit, optional nodeType filtering, and single-story scoping via `in: <StoryLocator>`.";
        readonly expectedResult: "Returns a BlocksListResult with total block count, an ordered array of block entries (ordinal, nodeId, nodeType, textPreview, optional text, isEmpty), and the current document revision.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "blocks/list.mdx";
        readonly referenceGroup: "blocks";
        readonly intentGroup: "get_content";
        readonly intentAction: "blocks";
    };
    readonly 'blocks.delete': {
        readonly memberPath: "blocks.delete";
        readonly description: "Delete an entire block node (paragraph, heading, list item, table, image, or sdt) deterministically.";
        readonly expectedResult: "Returns a BlocksDeleteResult receipt confirming the block was removed, including a deletedBlock summary with ordinal, nodeType, and textPreview.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "blocks/delete.mdx";
        readonly referenceGroup: "blocks";
    };
    readonly 'blocks.deleteRange': {
        readonly memberPath: "blocks.deleteRange";
        readonly description: "Delete a contiguous range of top-level blocks between two endpoints (inclusive). Both endpoints must be direct children of the document node. Supports dry-run preview.";
        readonly expectedResult: "Returns a BlocksDeleteRangeResult with deletedCount, deletedBlocks array (each with ordinal, nodeId, nodeType, textPreview), before/after revision, and dryRun flag.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "blocks/delete-range.mdx";
        readonly referenceGroup: "blocks";
    };
    readonly 'blocks.split': {
        readonly memberPath: "blocks.split";
        readonly description: string;
        readonly expectedResult: "Returns a BlocksSplitResult; on success carries the new tail paragraph address, affectedStories, and (for engines that report them) story-absolute textRangeShifts and a txId for history correlation.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "blocks/split.mdx";
        readonly referenceGroup: "blocks";
    };
    readonly 'blocks.merge': {
        readonly memberPath: "blocks.merge";
        readonly description: string;
        readonly expectedResult: "Returns a BlocksMergeResult; on success carries the removed paragraph address plus affectedStories, textRangeShifts, and a txId.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "blocks/merge.mdx";
        readonly referenceGroup: "blocks";
    };
    readonly 'blocks.move': {
        readonly memberPath: "blocks.move";
        readonly description: string;
        readonly expectedResult: "Returns a BlocksMoveResult; on success carries the moved paragraph address plus affectedStories and a txId. Tracked-mode results include `trackedChangeRefs` pointing at the paired move review entity.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "blocks/move.mdx";
        readonly referenceGroup: "blocks";
    };
    readonly 'format.apply': {
        readonly memberPath: "format.apply";
        readonly description: "Apply inline run-property patch changes to the target range with explicit set/clear semantics.";
        readonly expectedResult: "Returns a TextMutationReceipt confirming inline styles were applied to the target range.";
        readonly requiresDocumentContext: true;
        readonly metadata: CommandStaticMetadata;
        readonly referenceDocPath: "format/apply.mdx";
        readonly referenceGroup: "format";
        readonly intentGroup: "format";
        readonly intentAction: "inline";
    };
};
export type OperationId = keyof typeof OPERATION_DEFINITIONS;
export declare const OPERATION_IDS: readonly OperationId[];
export declare const SINGLETON_OPERATION_IDS: readonly OperationId[];
export declare const NAMESPACED_OPERATION_IDS: readonly OperationId[];
/**
 * Projects a value from each operation definition entry into a keyed record.
 *
 * The cast is needed because `Object.fromEntries` returns `Record<string, V>`;
 * all callers validate the result via explicit type annotations.
 */
export declare function projectFromDefinitions<V>(fn: (id: OperationId, entry: OperationDefinitionEntry) => V): Record<OperationId, V>;
