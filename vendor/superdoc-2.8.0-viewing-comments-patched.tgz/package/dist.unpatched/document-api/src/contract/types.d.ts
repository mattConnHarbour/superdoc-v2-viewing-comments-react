import { OperationId } from './operation-definitions.js';
import { CommandStaticMetadata } from './metadata-types.js';
export { OPERATION_IDEMPOTENCY_VALUES, type OperationIdempotency, PRE_APPLY_THROW_CODES, type PreApplyThrowCode, type CommandThrowPolicy, type CommandStaticMetadata, } from './metadata-types.js';
export { type OperationId, OPERATION_IDS, SINGLETON_OPERATION_IDS, NAMESPACED_OPERATION_IDS, } from './operation-definitions.js';
export declare const CONTRACT_VERSION = "0.1.0";
export declare const JSON_SCHEMA_DIALECT = "https://json-schema.org/draft/2020-12/schema";
export type CommandCatalog = {
    readonly [K in OperationId]: CommandStaticMetadata;
};
/**
 * Checks whether a string matches the syntactic format of an operation ID
 * (`camelCase`, `namespace.camelCase`, or `group.subgroup.camelCase`).
 *
 * @param operationId - The string to validate.
 * @returns `true` if the string matches the expected format.
 */
export declare function isValidOperationIdFormat(operationId: string): boolean;
/**
 * Type-guard that narrows a string to the {@link OperationId} union.
 *
 * @param operationId - The string to check.
 * @returns `true` if the string is a known operation ID.
 */
export declare function isOperationId(operationId: string): operationId is OperationId;
/**
 * Asserts that a string is a valid, known {@link OperationId}.
 *
 * @param operationId - The string to assert.
 * @throws {Error} If the string is not a recognised operation ID.
 */
export declare function assertOperationId(operationId: string): asserts operationId is OperationId;
