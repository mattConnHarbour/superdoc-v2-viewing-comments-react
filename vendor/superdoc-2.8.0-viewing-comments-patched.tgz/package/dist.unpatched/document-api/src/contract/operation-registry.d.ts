import { OperationId } from './types.js';
import { NodeAddress } from '../types/index.js';
import { SDNodeResult, SDFindInput, SDFindResult, SDGetInput } from '../types/sd-envelope.js';
import { TextMutationReceipt, Receipt } from '../types/receipt.js';
import { SDHtmlToFragmentResult, SDMutationReceipt, SDMarkdownToFragmentResult } from '../types/sd-contract.js';
import { DocumentInfo } from '../types/info.types.js';
import { SDDocument } from '../types/fragment.js';
import { CreateParagraphInput, CreateParagraphResult, CreateHeadingInput, CreateHeadingResult } from '../types/create.types.js';
import { BlocksDeleteInput, BlocksDeleteResult, BlocksListInput, BlocksListResult, BlocksDeleteRangeInput, BlocksDeleteRangeResult, BlocksMergeInput, BlocksMergeResult, BlocksMoveInput, BlocksMoveResult, BlocksSplitInput, BlocksSplitResult } from '../types/blocks.types.js';
import { GetNodeByIdInput } from '../get-node/get-node.js';
import { GetTextInput } from '../get-text/get-text.js';
import { GetMarkdownInput } from '../get-markdown/get-markdown.js';
import { GetHtmlInput } from '../get-html/get-html.js';
import { ProjectHtmlInput, ProjectMarkdownInput, SDContentProjectionResult } from '../types/content-projection.js';
import { MarkdownToFragmentInput } from '../markdown-to-fragment/markdown-to-fragment.js';
import { HtmlToFragmentInput } from '../html-to-fragment/html-to-fragment.js';
import { InfoInput } from '../info/info.js';
import { ExtractInput } from '../extract/extract.js';
import { ExtractResult } from '../types/extract.types.js';
import { ClearContentInput } from '../clear-content/clear-content.js';
import { InsertInput } from '../insert/insert.js';
import { ReplaceInput } from '../replace/replace.js';
import { DeleteInput } from '../delete/delete.js';
import { MutationOptions, RevisionGuardOptions, RichContentMutationOptions } from '../write/write.js';
import { FormatInlineAliasInput, FormatRangeInput, StyleApplyInput } from '../format/format.js';
import { InlineRunPatchKey } from '../format/inline-run-patch.js';
import { StylesApplyInput, StylesApplyOptions, StylesApplyReceipt, StylesGetCatalogInput, StylesGetCatalogResult } from '../styles/index.js';
import { TemplatesApplyInput, TemplatesApplyOptions, TemplatesApplyReceipt } from '../templates/index.js';
import { CommentsCreateReceipt, CommentsCreateInput, CommentsPatchInput, CommentsDeleteInput, GetCommentInput } from '../comments/comments.js';
import { CommentInfo, CommentsListQuery, CommentsListResult } from '../comments/comments.types.js';
import { TrackChangesListInput, TrackChangesGetInput, ReviewDecideInput } from '../track-changes/track-changes.js';
import { TrackChangeInfo, TrackChangesListResult } from '../types/track-changes.types.js';
import { DocumentApiCapabilities } from '../capabilities/capabilities.js';
import { SDHtmlMarkdownSupportCheckInput, SDHtmlMarkdownSupportCheckResult } from '../capabilities/html-markdown-support.js';
import { HistoryState, HistoryActionResult } from '../history/history.types.js';
import { DiffSnapshot, DiffPayload, DiffApplyResult, DiffCompareInput, DiffApplyInput, DiffApplyOptions } from '../diff/diff.types.js';
import { ExportToDocxInput, ExportToDocxResult } from '../export/export.types.js';
import { DocumentProtectionState, ProtectionGetInput, SetEditingRestrictionInput, ClearEditingRestrictionInput, ProtectionMutationResult } from '../protection/protection.types.js';
import { PermissionRangesListInput, PermissionRangesListResult, PermissionRangesGetInput, PermissionRangeInfo, PermissionRangesCreateInput, PermissionRangesRemoveInput, PermissionRangesUpdatePrincipalInput, PermissionRangeMutationResult, PermissionRangeRemoveResult } from '../permission-ranges/permission-ranges.types.js';
import { ListsListQuery, ListsListResult, ListsGetInput, ListItemInfo, ListInsertInput, ListsInsertResult, ListsMutateItemResult, ListTargetInput, ListsCreateInput, ListsCreateResult, ListsAttachInput, ListsDetachInput, ListsDetachResult, ListsDeleteInput, ListsDeleteResult, ListsJoinInput, ListsJoinResult, ListsCanJoinInput, ListsCanJoinResult, ListsSeparateInput, ListsSeparateResult, ListsMergeInput, ListsMergeResult, ListsSplitInput, ListsSplitResult, ListsSetLevelInput, ListsSetValueInput, ListsContinuePreviousInput, ListsCanContinuePreviousInput, ListsCanContinuePreviousResult, ListsSetLevelRestartInput, ListsConvertToTextInput, ListsConvertToTextResult, ListsApplyTemplateInput, ListsApplyPresetInput, ListsSetTypeInput, ListsCaptureTemplateInput, ListsCaptureTemplateResult, ListsSetLevelNumberingInput, ListsSetLevelBulletInput, ListsSetLevelPictureBulletInput, ListsSetLevelAlignmentInput, ListsSetLevelIndentsInput, ListsSetLevelTrailingCharacterInput, ListsSetLevelMarkerFontInput, ListsClearLevelOverridesInput, ListsGetStyleInput, ListsGetStyleResult, ListsApplyStyleInput, ListsRestartAtInput, ListsSetLevelNumberStyleInput, ListsSetLevelTextInput, ListsSetLevelStartInput, ListsSetLevelLayoutInput, ListsGetStateInput, ListsGetStateResult, ListsApplyInput, ListsContinueV2Input, ListsRestartV2Input, ListsRemoveV2Input } from '../lists/lists.types.js';
import { ParagraphMutationResult, ParagraphsSetStyleInput, ParagraphsSetStyleRefInput, ParagraphsClearStyleInput, ParagraphsResetDirectFormattingInput, ParagraphsSetAlignmentInput, ParagraphsClearAlignmentInput, ParagraphsSetIndentationInput, ParagraphsClearIndentationInput, ParagraphsSetSpacingInput, ParagraphsClearSpacingInput, ParagraphsSetKeepOptionsInput, ParagraphsSetOutlineLevelInput, ParagraphsSetFlowOptionsInput, ParagraphsSetTabStopInput, ParagraphsClearTabStopInput, ParagraphsClearAllTabStopsInput, ParagraphsSetBorderInput, ParagraphsClearBorderInput, ParagraphsSetShadingInput, ParagraphsClearShadingInput, ParagraphsSetMarkRunPropsInput, ParagraphsSetDirectionInput, ParagraphsClearDirectionInput, ParagraphsSetNumberingInput } from '../paragraphs/paragraphs.js';
import { CreateSectionBreakInput, CreateSectionBreakResult, DocumentMutationResult, SectionInfo, SectionMutationResult, SectionsClearHeaderFooterRefInput, SectionsClearPageBordersInput, SectionsGetInput, SectionsListQuery, SectionsListResult, SectionsSetBreakTypeInput, SectionsSetColumnsInput, SectionsSetHeaderFooterMarginsInput, SectionsSetHeaderFooterRefInput, SectionsSetLineNumberingInput, SectionsSetLinkToPreviousInput, SectionsSetOddEvenHeadersFootersInput, SectionsSetPageBordersInput, SectionsSetPageMarginsInput, SectionsSetPageNumberingInput, SectionsSetPageSetupInput, SectionsSetSectionDirectionInput, SectionsSetTitlePageInput, SectionsSetVerticalAlignInput } from '../sections/sections.types.js';
import { QueryMatchInput, QueryMatchOutput } from '../types/query-match.types.js';
import { ResolveRangeInput, ResolveRangeOutput } from '../ranges/ranges.types.js';
import { SelectionCurrentInput, SelectionInfo } from '../selection/selection.js';
import { CreateImageInput, CreateImageResult, ImagesListInput, ImagesListResult, ImagesGetInput, ImageSummary, ImagesDeleteInput, ImagesMutationResult, MoveImageInput, ConvertToInlineInput, ConvertToFloatingInput, SetSizeInput, SetWrapTypeInput, SetWrapSideInput, SetWrapDistancesInput, SetPositionInput, SetAnchorOptionsInput, SetZOrderInput, ScaleInput, SetLockAspectRatioInput, RotateInput, FlipInput, CropInput, ResetCropInput, ReplaceSourceInput, SetAltTextInput, SetDecorativeInput, SetNameInput, SetHyperlinkInput, InsertCaptionInput, UpdateCaptionInput, RemoveCaptionInput } from '../images/images.types.js';
import { MutationsApplyInput, MutationsPreviewInput, MutationsPreviewOutput, PlanReceipt } from '../types/mutation-plan.types.js';
import { PlanExecuteInput, PlanExecuteResult } from '../plan/plan.js';
import { CreateTableOfContentsInput, CreateTableOfContentsResult, TocListQuery, TocListResult, TocGetInput, TocInfo, TocConfigureInput, TocUpdateInput, TocRemoveInput, TocMutationResult, TocMarkEntryInput, TocUnmarkEntryInput, TocListEntriesQuery, TocListEntriesResult, TocGetEntryInput, TocEntryInfo, TocEditEntryInput, TocEntryMutationResult } from '../toc/toc.types.js';
import { BookmarkListInput, BookmarksListResult, BookmarkGetInput, BookmarkInfo, BookmarkInsertInput, BookmarkRenameInput, BookmarkRemoveInput, BookmarkMutationResult } from '../bookmarks/bookmarks.types.js';
import { CustomXmlPartsListInput, CustomXmlPartsListResult, CustomXmlPartsGetInput, CustomXmlPartInfo, CustomXmlPartsCreateInput, CustomXmlPartsCreateResult, CustomXmlPartsPatchInput, CustomXmlPartsRemoveInput, CustomXmlPartsMutationResult } from '../customXml/customXml.types.js';
import { AnchoredMetadataAttachInput, AnchoredMetadataAttachResult, AnchoredMetadataListInput, AnchoredMetadataListResult, AnchoredMetadataGetInput, AnchoredMetadataInfo, AnchoredMetadataUpdateInput, AnchoredMetadataRemoveInput, AnchoredMetadataResolveInput, AnchoredMetadataMutationResult, AnchoredMetadataResolveInfo } from '../metadata/anchored-metadata.types.js';
import { FootnoteListInput, FootnotesListResult, FootnoteGetInput, FootnoteInfo, FootnoteInsertInput, FootnoteUpdateInput, FootnoteRemoveInput, FootnoteMutationResult, FootnoteConfigureInput, FootnoteConfigResult } from '../footnotes/footnotes.types.js';
import { ClipboardInsertInput, ClipboardInsertResult, ClipboardParseOptions, ClipboardParseResult, ClipboardPayload, ClipboardSerializeInput, ClipboardSerializeResult } from '../types/clipboard.js';
import { CrossRefListInput, CrossRefsListResult, CrossRefGetInput, CrossRefInfo, CrossRefInsertInput, CrossRefRebuildInput, CrossRefRemoveInput, CrossRefMutationResult } from '../cross-refs/cross-refs.types.js';
import { IndexListInput, IndexListResult, IndexGetInput, IndexInfo, IndexInsertInput, IndexConfigureInput, IndexRebuildInput, IndexRemoveInput, IndexMutationResult, IndexEntryListInput, IndexEntryListResult, IndexEntryGetInput, IndexEntryInfo, IndexEntryInsertInput, IndexEntryUpdateInput, IndexEntryRemoveInput, IndexEntryMutationResult } from '../index/index.types.js';
import { CaptionListInput, CaptionsListResult, CaptionGetInput, CaptionInfo, CaptionInsertInput, CaptionUpdateInput, CaptionRemoveInput, CaptionMutationResult, CaptionConfigureInput, CaptionConfigResult } from '../captions/captions.types.js';
import { FieldListInput, FieldsListResult, FieldGetInput, FieldInfo, FieldInsertInput, FieldRebuildInput, FieldRemoveInput, FieldMutationResult } from '../fields/fields.types.js';
import { CitationListInput, CitationsListResult, CitationGetInput, CitationInfo, CitationInsertInput, CitationUpdateInput, CitationRemoveInput, CitationMutationResult, CitationSourceListInput, CitationSourcesListResult, CitationSourceGetInput, CitationSourceInfo, CitationSourceInsertInput, CitationSourceUpdateInput, CitationSourceRemoveInput, CitationSourceMutationResult, BibliographyGetInput, BibliographyInfo, BibliographyInsertInput, BibliographyRebuildInput, BibliographyConfigureInput, BibliographyRemoveInput, BibliographyMutationResult } from '../citations/citations.types.js';
import { AuthoritiesListInput, AuthoritiesListResult, AuthoritiesGetInput, AuthoritiesInfo, AuthoritiesInsertInput, AuthoritiesConfigureInput, AuthoritiesRebuildInput, AuthoritiesRemoveInput, AuthoritiesMutationResult, AuthorityEntryListInput, AuthorityEntryListResult, AuthorityEntryGetInput, AuthorityEntryInfo, AuthorityEntryInsertInput, AuthorityEntryUpdateInput, AuthorityEntryRemoveInput, AuthorityEntryMutationResult } from '../authorities/authorities.types.js';
import { CreateTableInput, CreateTableResult, TablesConvertFromTextInput, TableLocator, TablesMoveInput, TablesSplitInput, TablesConvertToTextInput, TablesSetLayoutInput, TablesInsertRowInput, TablesDeleteRowInput, TablesMoveRowInput, TablesSetRowHeightInput, TablesDistributeRowsInput, TablesSetRowOptionsInput, TablesInsertColumnInput, TablesDeleteColumnInput, TablesSetColumnWidthInput, TablesDistributeColumnsInput, TablesInsertCellInput, TablesDeleteCellInput, TablesMergeCellsInput, TablesUnmergeCellsInput, TablesSplitCellInput, TablesSetCellPropertiesInput, TablesSetCellTextInput, TablesSortInput, TablesSetAltTextInput, TablesSetStyleInput, TablesClearStyleInput, TablesSetStyleOptionInput, TablesSetBorderInput, TablesClearBorderInput, TablesApplyBorderPresetInput, TablesSetShadingInput, TablesClearShadingInput, TablesSetTablePaddingInput, TablesSetCellPaddingInput, TablesSetCellSpacingInput, TablesClearCellSpacingInput, TablesApplyStyleInput, TablesSetBordersInput, TablesSetTableOptionsInput, TablesApplyPresetInput, TableMutationResult, TablesGetInput, TablesGetOutput, TablesGetCellsInput, TablesGetCellsOutput, TablesGetPropertiesInput, TablesGetPropertiesOutput, TablesGetStylesInput, TablesGetStylesOutput, TablesSetDefaultStyleInput, TablesClearDefaultStyleInput } from '../types/table-operations.types.js';
import { HyperlinksListQuery, HyperlinksListResult, HyperlinksGetInput, HyperlinkInfo, HyperlinksWrapInput, HyperlinksInsertInput, HyperlinksPatchInput, HyperlinksRemoveInput, HyperlinkMutationResult } from '../hyperlinks/hyperlinks.types.js';
import { HeaderFootersListQuery, HeaderFootersListResult, HeaderFootersGetInput, HeaderFooterSlotEntry, HeaderFootersResolveInput, HeaderFooterResolveResult, HeaderFootersRefsSetInput, HeaderFootersRefsClearInput, HeaderFootersRefsSetLinkedToPreviousInput, HeaderFootersPartsListQuery, HeaderFootersPartsListResult, HeaderFootersPartsCreateInput, HeaderFootersPartsDeleteInput, HeaderFooterPartsMutationResult } from '../header-footers/header-footers.types.js';
import { ContentControlInfo, ContentControlMutationResult, ContentControlsListResult, ContentControlsListQuery, ContentControlsGetInput, ContentControlsListInRangeInput, ContentControlsSelectByTagInput, ContentControlsSelectByTitleInput, ContentControlsListChildrenInput, ContentControlsGetParentInput, ContentControlsWrapInput, ContentControlsUnwrapInput, ContentControlsDeleteInput, ContentControlsCopyInput, ContentControlsMoveInput, ContentControlsPatchInput, ContentControlsSetLockModeInput, ContentControlsSetTypeInput, ContentControlsGetContentInput, ContentControlsGetContentResult, ContentControlsReplaceContentInput, ContentControlsClearContentInput, ContentControlsAppendContentInput, ContentControlsPrependContentInput, ContentControlsInsertBeforeInput, ContentControlsInsertAfterInput, ContentControlsGetBindingInput, ContentControlBinding, ContentControlsSetBindingInput, ContentControlsClearBindingInput, ContentControlsGetRawPropertiesInput, ContentControlsGetRawPropertiesResult, ContentControlsPatchRawPropertiesInput, ContentControlsValidateWordCompatibilityInput, ContentControlsValidateWordCompatibilityResult, ContentControlsNormalizeWordCompatibilityInput, ContentControlsNormalizeTagPayloadInput, ContentControlsTextSetMultilineInput, ContentControlsTextSetValueInput, ContentControlsTextClearValueInput, ContentControlsDateSetValueInput, ContentControlsDateClearValueInput, ContentControlsDateSetDisplayFormatInput, ContentControlsDateSetDisplayLocaleInput, ContentControlsDateSetStorageFormatInput, ContentControlsDateSetCalendarInput, ContentControlsCheckboxGetStateInput, ContentControlsCheckboxGetStateResult, ContentControlsCheckboxSetStateInput, ContentControlsCheckboxToggleInput, ContentControlsCheckboxSetSymbolPairInput, ContentControlsChoiceListGetItemsInput, ContentControlsChoiceListGetItemsResult, ContentControlsChoiceListSetItemsInput, ContentControlsChoiceListSetSelectedInput, ContentControlsRepeatingSectionListItemsInput, ContentControlsRepeatingSectionListItemsResult, ContentControlsRepeatingSectionInsertItemBeforeInput, ContentControlsRepeatingSectionInsertItemAfterInput, ContentControlsRepeatingSectionCloneItemInput, ContentControlsRepeatingSectionDeleteItemInput, ContentControlsRepeatingSectionSetAllowInsertDeleteInput, ContentControlsGroupWrapInput, ContentControlsGroupUngroupInput, CreateContentControlInput } from '../content-controls/content-controls.types.js';
type FormatInlineAliasOperationRegistry = {
    [K in InlineRunPatchKey as `format.${K}`]: {
        input: FormatInlineAliasInput<K>;
        options: MutationOptions;
        output: TextMutationReceipt;
    };
};
export interface OperationRegistry extends FormatInlineAliasOperationRegistry {
    get: {
        input: SDGetInput;
        options: never;
        output: SDDocument;
    };
    find: {
        input: SDFindInput;
        options: never;
        output: SDFindResult;
    };
    getNode: {
        input: NodeAddress;
        options: never;
        output: SDNodeResult;
    };
    getNodeById: {
        input: GetNodeByIdInput;
        options: never;
        output: SDNodeResult;
    };
    getText: {
        input: GetTextInput;
        options: never;
        output: string;
    };
    getMarkdown: {
        input: GetMarkdownInput;
        options: never;
        output: string;
    };
    getHtml: {
        input: GetHtmlInput;
        options: never;
        output: string;
    };
    projectMarkdown: {
        input: ProjectMarkdownInput;
        options: never;
        output: Promise<SDContentProjectionResult<'markdown'>>;
    };
    projectHtml: {
        input: ProjectHtmlInput;
        options: never;
        output: Promise<SDContentProjectionResult<'html'>>;
    };
    markdownToFragment: {
        input: MarkdownToFragmentInput;
        options: never;
        output: SDMarkdownToFragmentResult;
    };
    htmlToFragment: {
        input: HtmlToFragmentInput;
        options: never;
        output: SDHtmlToFragmentResult;
    };
    info: {
        input: InfoInput;
        options: never;
        output: DocumentInfo;
    };
    extract: {
        input: ExtractInput;
        options: never;
        output: ExtractResult;
    };
    clearContent: {
        input: ClearContentInput;
        options: RevisionGuardOptions;
        output: Receipt;
    };
    insert: {
        input: InsertInput;
        options: RichContentMutationOptions;
        output: SDMutationReceipt;
    };
    replace: {
        input: ReplaceInput;
        options: RichContentMutationOptions;
        output: SDMutationReceipt;
    };
    delete: {
        input: DeleteInput;
        options: MutationOptions;
        output: TextMutationReceipt;
    };
    formatRange: {
        input: FormatRangeInput;
        options: MutationOptions;
        output: TextMutationReceipt;
    };
    'blocks.list': {
        input: BlocksListInput | undefined;
        options: never;
        output: BlocksListResult;
    };
    'blocks.delete': {
        input: BlocksDeleteInput;
        options: MutationOptions;
        output: BlocksDeleteResult;
    };
    'blocks.deleteRange': {
        input: BlocksDeleteRangeInput;
        options: MutationOptions;
        output: BlocksDeleteRangeResult;
    };
    'blocks.split': {
        input: BlocksSplitInput;
        options: MutationOptions;
        output: BlocksSplitResult;
    };
    'blocks.merge': {
        input: BlocksMergeInput;
        options: MutationOptions;
        output: BlocksMergeResult;
    };
    'blocks.move': {
        input: BlocksMoveInput;
        options: MutationOptions;
        output: BlocksMoveResult;
    };
    'format.apply': {
        input: StyleApplyInput;
        options: MutationOptions;
        output: TextMutationReceipt;
    };
    'styles.paragraph.setStyle': {
        input: ParagraphsSetStyleInput;
        options: MutationOptions;
        output: ParagraphMutationResult;
    };
    'styles.paragraph.setStyleRef': {
        input: ParagraphsSetStyleRefInput;
        options: MutationOptions;
        output: ParagraphMutationResult;
    };
    'styles.paragraph.clearStyle': {
        input: ParagraphsClearStyleInput;
        options: MutationOptions;
        output: ParagraphMutationResult;
    };
    'format.paragraph.resetDirectFormatting': {
        input: ParagraphsResetDirectFormattingInput;
        options: MutationOptions;
        output: ParagraphMutationResult;
    };
    'format.paragraph.setAlignment': {
        input: ParagraphsSetAlignmentInput;
        options: MutationOptions;
        output: ParagraphMutationResult;
    };
    'format.paragraph.clearAlignment': {
        input: ParagraphsClearAlignmentInput;
        options: MutationOptions;
        output: ParagraphMutationResult;
    };
    'format.paragraph.setIndentation': {
        input: ParagraphsSetIndentationInput;
        options: MutationOptions;
        output: ParagraphMutationResult;
    };
    'format.paragraph.clearIndentation': {
        input: ParagraphsClearIndentationInput;
        options: MutationOptions;
        output: ParagraphMutationResult;
    };
    'format.paragraph.setSpacing': {
        input: ParagraphsSetSpacingInput;
        options: MutationOptions;
        output: ParagraphMutationResult;
    };
    'format.paragraph.clearSpacing': {
        input: ParagraphsClearSpacingInput;
        options: MutationOptions;
        output: ParagraphMutationResult;
    };
    'format.paragraph.setKeepOptions': {
        input: ParagraphsSetKeepOptionsInput;
        options: MutationOptions;
        output: ParagraphMutationResult;
    };
    'format.paragraph.setOutlineLevel': {
        input: ParagraphsSetOutlineLevelInput;
        options: MutationOptions;
        output: ParagraphMutationResult;
    };
    'format.paragraph.setFlowOptions': {
        input: ParagraphsSetFlowOptionsInput;
        options: MutationOptions;
        output: ParagraphMutationResult;
    };
    'format.paragraph.setTabStop': {
        input: ParagraphsSetTabStopInput;
        options: MutationOptions;
        output: ParagraphMutationResult;
    };
    'format.paragraph.clearTabStop': {
        input: ParagraphsClearTabStopInput;
        options: MutationOptions;
        output: ParagraphMutationResult;
    };
    'format.paragraph.clearAllTabStops': {
        input: ParagraphsClearAllTabStopsInput;
        options: MutationOptions;
        output: ParagraphMutationResult;
    };
    'format.paragraph.setBorder': {
        input: ParagraphsSetBorderInput;
        options: MutationOptions;
        output: ParagraphMutationResult;
    };
    'format.paragraph.clearBorder': {
        input: ParagraphsClearBorderInput;
        options: MutationOptions;
        output: ParagraphMutationResult;
    };
    'format.paragraph.setShading': {
        input: ParagraphsSetShadingInput;
        options: MutationOptions;
        output: ParagraphMutationResult;
    };
    'format.paragraph.clearShading': {
        input: ParagraphsClearShadingInput;
        options: MutationOptions;
        output: ParagraphMutationResult;
    };
    'format.paragraph.setMarkRunProps': {
        input: ParagraphsSetMarkRunPropsInput;
        options: MutationOptions;
        output: ParagraphMutationResult;
    };
    'format.paragraph.setDirection': {
        input: ParagraphsSetDirectionInput;
        options: MutationOptions;
        output: ParagraphMutationResult;
    };
    'format.paragraph.clearDirection': {
        input: ParagraphsClearDirectionInput;
        options: MutationOptions;
        output: ParagraphMutationResult;
    };
    'format.paragraph.setNumbering': {
        input: ParagraphsSetNumberingInput;
        options: MutationOptions;
        output: ParagraphMutationResult;
    };
    'styles.apply': {
        input: StylesApplyInput;
        options: StylesApplyOptions;
        output: StylesApplyReceipt;
    };
    'styles.getCatalog': {
        input: StylesGetCatalogInput | undefined;
        options: never;
        output: StylesGetCatalogResult;
    };
    'templates.apply': {
        input: TemplatesApplyInput;
        options: TemplatesApplyOptions;
        output: Promise<TemplatesApplyReceipt>;
    };
    'create.paragraph': {
        input: CreateParagraphInput;
        options: MutationOptions;
        output: CreateParagraphResult;
    };
    'create.heading': {
        input: CreateHeadingInput;
        options: MutationOptions;
        output: CreateHeadingResult;
    };
    'create.sectionBreak': {
        input: CreateSectionBreakInput;
        options: MutationOptions;
        output: CreateSectionBreakResult;
    };
    'lists.list': {
        input: ListsListQuery | undefined;
        options: never;
        output: ListsListResult;
    };
    'lists.get': {
        input: ListsGetInput;
        options: never;
        output: ListItemInfo;
    };
    'lists.insert': {
        input: ListInsertInput;
        options: MutationOptions;
        output: ListsInsertResult;
    };
    'lists.create': {
        input: ListsCreateInput;
        options: MutationOptions;
        output: ListsCreateResult;
    };
    'lists.attach': {
        input: ListsAttachInput;
        options: MutationOptions;
        output: ListsMutateItemResult;
    };
    'lists.detach': {
        input: ListsDetachInput;
        options: MutationOptions;
        output: ListsDetachResult;
    };
    'lists.delete': {
        input: ListsDeleteInput;
        options: MutationOptions;
        output: ListsDeleteResult;
    };
    'lists.indent': {
        input: ListTargetInput;
        options: MutationOptions;
        output: ListsMutateItemResult;
    };
    'lists.outdent': {
        input: ListTargetInput;
        options: MutationOptions;
        output: ListsMutateItemResult;
    };
    'lists.join': {
        input: ListsJoinInput;
        options: MutationOptions;
        output: ListsJoinResult;
    };
    'lists.canJoin': {
        input: ListsCanJoinInput;
        options: never;
        output: ListsCanJoinResult;
    };
    'lists.separate': {
        input: ListsSeparateInput;
        options: MutationOptions;
        output: ListsSeparateResult;
    };
    'lists.merge': {
        input: ListsMergeInput;
        options: MutationOptions;
        output: ListsMergeResult;
    };
    'lists.split': {
        input: ListsSplitInput;
        options: MutationOptions;
        output: ListsSplitResult;
    };
    'lists.setLevel': {
        input: ListsSetLevelInput;
        options: MutationOptions;
        output: ListsMutateItemResult;
    };
    'lists.setValue': {
        input: ListsSetValueInput;
        options: MutationOptions;
        output: ListsMutateItemResult;
    };
    'lists.continuePrevious': {
        input: ListsContinuePreviousInput;
        options: MutationOptions;
        output: ListsMutateItemResult;
    };
    'lists.canContinuePrevious': {
        input: ListsCanContinuePreviousInput;
        options: never;
        output: ListsCanContinuePreviousResult;
    };
    'lists.setLevelRestart': {
        input: ListsSetLevelRestartInput;
        options: MutationOptions;
        output: ListsMutateItemResult;
    };
    'lists.convertToText': {
        input: ListsConvertToTextInput;
        options: MutationOptions;
        output: ListsConvertToTextResult;
    };
    'lists.applyTemplate': {
        input: ListsApplyTemplateInput;
        options: MutationOptions;
        output: ListsMutateItemResult;
    };
    'lists.applyPreset': {
        input: ListsApplyPresetInput;
        options: MutationOptions;
        output: ListsMutateItemResult;
    };
    'lists.setType': {
        input: ListsSetTypeInput;
        options: MutationOptions;
        output: ListsMutateItemResult;
    };
    'lists.captureTemplate': {
        input: ListsCaptureTemplateInput;
        options: never;
        output: ListsCaptureTemplateResult;
    };
    'lists.setLevelNumbering': {
        input: ListsSetLevelNumberingInput;
        options: MutationOptions;
        output: ListsMutateItemResult;
    };
    'lists.setLevelBullet': {
        input: ListsSetLevelBulletInput;
        options: MutationOptions;
        output: ListsMutateItemResult;
    };
    'lists.setLevelPictureBullet': {
        input: ListsSetLevelPictureBulletInput;
        options: MutationOptions;
        output: ListsMutateItemResult;
    };
    'lists.setLevelAlignment': {
        input: ListsSetLevelAlignmentInput;
        options: MutationOptions;
        output: ListsMutateItemResult;
    };
    'lists.setLevelIndents': {
        input: ListsSetLevelIndentsInput;
        options: MutationOptions;
        output: ListsMutateItemResult;
    };
    'lists.setLevelTrailingCharacter': {
        input: ListsSetLevelTrailingCharacterInput;
        options: MutationOptions;
        output: ListsMutateItemResult;
    };
    'lists.setLevelMarkerFont': {
        input: ListsSetLevelMarkerFontInput;
        options: MutationOptions;
        output: ListsMutateItemResult;
    };
    'lists.clearLevelOverrides': {
        input: ListsClearLevelOverridesInput;
        options: MutationOptions;
        output: ListsMutateItemResult;
    };
    'lists.getStyle': {
        input: ListsGetStyleInput;
        options: never;
        output: ListsGetStyleResult;
    };
    'lists.applyStyle': {
        input: ListsApplyStyleInput;
        options: MutationOptions;
        output: ListsMutateItemResult;
    };
    'lists.restartAt': {
        input: ListsRestartAtInput;
        options: MutationOptions;
        output: ListsMutateItemResult;
    };
    'lists.setLevelNumberStyle': {
        input: ListsSetLevelNumberStyleInput;
        options: MutationOptions;
        output: ListsMutateItemResult;
    };
    'lists.setLevelText': {
        input: ListsSetLevelTextInput;
        options: MutationOptions;
        output: ListsMutateItemResult;
    };
    'lists.setLevelStart': {
        input: ListsSetLevelStartInput;
        options: MutationOptions;
        output: ListsMutateItemResult;
    };
    'lists.setLevelLayout': {
        input: ListsSetLevelLayoutInput;
        options: MutationOptions;
        output: ListsMutateItemResult;
    };
    'lists.getState': {
        input: ListsGetStateInput;
        options: never;
        output: ListsGetStateResult;
    };
    'lists.apply': {
        input: ListsApplyInput;
        options: MutationOptions;
        output: ListsMutateItemResult;
    };
    'lists.continue': {
        input: ListsContinueV2Input;
        options: MutationOptions;
        output: ListsMutateItemResult;
    };
    'lists.restart': {
        input: ListsRestartV2Input;
        options: MutationOptions;
        output: ListsMutateItemResult;
    };
    'lists.remove': {
        input: ListsRemoveV2Input;
        options: MutationOptions;
        output: ListsMutateItemResult;
    };
    'sections.list': {
        input: SectionsListQuery | undefined;
        options: never;
        output: SectionsListResult;
    };
    'sections.get': {
        input: SectionsGetInput;
        options: never;
        output: SectionInfo;
    };
    'sections.setBreakType': {
        input: SectionsSetBreakTypeInput;
        options: MutationOptions;
        output: SectionMutationResult;
    };
    'sections.setPageMargins': {
        input: SectionsSetPageMarginsInput;
        options: MutationOptions;
        output: SectionMutationResult;
    };
    'sections.setHeaderFooterMargins': {
        input: SectionsSetHeaderFooterMarginsInput;
        options: MutationOptions;
        output: SectionMutationResult;
    };
    'sections.setPageSetup': {
        input: SectionsSetPageSetupInput;
        options: MutationOptions;
        output: SectionMutationResult;
    };
    'sections.setColumns': {
        input: SectionsSetColumnsInput;
        options: MutationOptions;
        output: SectionMutationResult;
    };
    'sections.setLineNumbering': {
        input: SectionsSetLineNumberingInput;
        options: MutationOptions;
        output: SectionMutationResult;
    };
    'sections.setPageNumbering': {
        input: SectionsSetPageNumberingInput;
        options: MutationOptions;
        output: SectionMutationResult;
    };
    'sections.setTitlePage': {
        input: SectionsSetTitlePageInput;
        options: MutationOptions;
        output: SectionMutationResult;
    };
    'sections.setOddEvenHeadersFooters': {
        input: SectionsSetOddEvenHeadersFootersInput;
        options: MutationOptions;
        output: DocumentMutationResult;
    };
    'sections.setVerticalAlign': {
        input: SectionsSetVerticalAlignInput;
        options: MutationOptions;
        output: SectionMutationResult;
    };
    'sections.setSectionDirection': {
        input: SectionsSetSectionDirectionInput;
        options: MutationOptions;
        output: SectionMutationResult;
    };
    'sections.setHeaderFooterRef': {
        input: SectionsSetHeaderFooterRefInput;
        options: MutationOptions;
        output: SectionMutationResult;
    };
    'sections.clearHeaderFooterRef': {
        input: SectionsClearHeaderFooterRefInput;
        options: MutationOptions;
        output: SectionMutationResult;
    };
    'sections.setLinkToPrevious': {
        input: SectionsSetLinkToPreviousInput;
        options: MutationOptions;
        output: SectionMutationResult;
    };
    'sections.setPageBorders': {
        input: SectionsSetPageBordersInput;
        options: MutationOptions;
        output: SectionMutationResult;
    };
    'sections.clearPageBorders': {
        input: SectionsClearPageBordersInput;
        options: MutationOptions;
        output: SectionMutationResult;
    };
    'comments.create': {
        input: CommentsCreateInput;
        options: RevisionGuardOptions;
        output: CommentsCreateReceipt;
    };
    'comments.patch': {
        input: CommentsPatchInput;
        options: RevisionGuardOptions;
        output: Receipt;
    };
    'comments.delete': {
        input: CommentsDeleteInput;
        options: RevisionGuardOptions;
        output: Receipt;
    };
    'comments.get': {
        input: GetCommentInput;
        options: never;
        output: CommentInfo;
    };
    'comments.list': {
        input: CommentsListQuery | undefined;
        options: never;
        output: CommentsListResult;
    };
    'trackChanges.list': {
        input: TrackChangesListInput | undefined;
        options: never;
        output: TrackChangesListResult;
    };
    'trackChanges.get': {
        input: TrackChangesGetInput;
        options: never;
        output: TrackChangeInfo;
    };
    'trackChanges.decide': {
        input: ReviewDecideInput;
        options: RevisionGuardOptions;
        output: Receipt;
    };
    'query.match': {
        input: QueryMatchInput;
        options: never;
        output: QueryMatchOutput;
    };
    'ranges.resolve': {
        input: ResolveRangeInput;
        options: never;
        output: ResolveRangeOutput;
    };
    'selection.current': {
        input: SelectionCurrentInput | undefined;
        options: never;
        output: SelectionInfo;
    };
    'mutations.preview': {
        input: MutationsPreviewInput;
        options: never;
        output: MutationsPreviewOutput;
    };
    'mutations.apply': {
        input: MutationsApplyInput;
        options: never;
        output: PlanReceipt;
    };
    'plan.execute': {
        input: PlanExecuteInput;
        options: never;
        output: PlanExecuteResult;
    };
    'capabilities.get': {
        input: undefined;
        options: never;
        output: DocumentApiCapabilities;
    };
    'capabilities.check': {
        input: SDHtmlMarkdownSupportCheckInput;
        options: never;
        output: Promise<SDHtmlMarkdownSupportCheckResult>;
    };
    'history.get': {
        input: undefined;
        options: never;
        output: HistoryState;
    };
    'history.undo': {
        input: undefined;
        options: never;
        output: HistoryActionResult;
    };
    'history.redo': {
        input: undefined;
        options: never;
        output: HistoryActionResult;
    };
    'create.table': {
        input: CreateTableInput;
        options: MutationOptions;
        output: CreateTableResult;
    };
    'tables.convertFromText': {
        input: TablesConvertFromTextInput;
        options: MutationOptions;
        output: TableMutationResult;
    };
    'tables.delete': {
        input: TableLocator;
        options: MutationOptions;
        output: TableMutationResult;
    };
    'tables.clearContents': {
        input: TableLocator;
        options: MutationOptions;
        output: TableMutationResult;
    };
    'tables.move': {
        input: TablesMoveInput;
        options: MutationOptions;
        output: TableMutationResult;
    };
    'tables.split': {
        input: TablesSplitInput;
        options: MutationOptions;
        output: TableMutationResult;
    };
    'tables.convertToText': {
        input: TablesConvertToTextInput;
        options: MutationOptions;
        output: TableMutationResult;
    };
    'tables.setLayout': {
        input: TablesSetLayoutInput;
        options: MutationOptions;
        output: TableMutationResult;
    };
    'tables.insertRow': {
        input: TablesInsertRowInput;
        options: MutationOptions;
        output: TableMutationResult;
    };
    'tables.deleteRow': {
        input: TablesDeleteRowInput;
        options: MutationOptions;
        output: TableMutationResult;
    };
    'tables.moveRow': {
        input: TablesMoveRowInput;
        options: MutationOptions;
        output: TableMutationResult;
    };
    'tables.setRowHeight': {
        input: TablesSetRowHeightInput;
        options: MutationOptions;
        output: TableMutationResult;
    };
    'tables.distributeRows': {
        input: TablesDistributeRowsInput;
        options: MutationOptions;
        output: TableMutationResult;
    };
    'tables.setRowOptions': {
        input: TablesSetRowOptionsInput;
        options: MutationOptions;
        output: TableMutationResult;
    };
    'tables.insertColumn': {
        input: TablesInsertColumnInput;
        options: MutationOptions;
        output: TableMutationResult;
    };
    'tables.deleteColumn': {
        input: TablesDeleteColumnInput;
        options: MutationOptions;
        output: TableMutationResult;
    };
    'tables.setColumnWidth': {
        input: TablesSetColumnWidthInput;
        options: MutationOptions;
        output: TableMutationResult;
    };
    'tables.distributeColumns': {
        input: TablesDistributeColumnsInput;
        options: MutationOptions;
        output: TableMutationResult;
    };
    'tables.insertCell': {
        input: TablesInsertCellInput;
        options: MutationOptions;
        output: TableMutationResult;
    };
    'tables.deleteCell': {
        input: TablesDeleteCellInput;
        options: MutationOptions;
        output: TableMutationResult;
    };
    'tables.mergeCells': {
        input: TablesMergeCellsInput;
        options: MutationOptions;
        output: TableMutationResult;
    };
    'tables.unmergeCells': {
        input: TablesUnmergeCellsInput;
        options: MutationOptions;
        output: TableMutationResult;
    };
    'tables.splitCell': {
        input: TablesSplitCellInput;
        options: MutationOptions;
        output: TableMutationResult;
    };
    'tables.setCellProperties': {
        input: TablesSetCellPropertiesInput;
        options: MutationOptions;
        output: TableMutationResult;
    };
    'tables.setCellText': {
        input: TablesSetCellTextInput;
        options: MutationOptions;
        output: TableMutationResult;
    };
    'tables.sort': {
        input: TablesSortInput;
        options: MutationOptions;
        output: TableMutationResult;
    };
    'tables.setAltText': {
        input: TablesSetAltTextInput;
        options: MutationOptions;
        output: TableMutationResult;
    };
    'tables.setStyle': {
        input: TablesSetStyleInput;
        options: MutationOptions;
        output: TableMutationResult;
    };
    'tables.clearStyle': {
        input: TablesClearStyleInput;
        options: MutationOptions;
        output: TableMutationResult;
    };
    'tables.setStyleOption': {
        input: TablesSetStyleOptionInput;
        options: MutationOptions;
        output: TableMutationResult;
    };
    'tables.setBorder': {
        input: TablesSetBorderInput;
        options: MutationOptions;
        output: TableMutationResult;
    };
    'tables.clearBorder': {
        input: TablesClearBorderInput;
        options: MutationOptions;
        output: TableMutationResult;
    };
    'tables.applyBorderPreset': {
        input: TablesApplyBorderPresetInput;
        options: MutationOptions;
        output: TableMutationResult;
    };
    'tables.setShading': {
        input: TablesSetShadingInput;
        options: MutationOptions;
        output: TableMutationResult;
    };
    'tables.clearShading': {
        input: TablesClearShadingInput;
        options: MutationOptions;
        output: TableMutationResult;
    };
    'tables.setTablePadding': {
        input: TablesSetTablePaddingInput;
        options: MutationOptions;
        output: TableMutationResult;
    };
    'tables.setCellPadding': {
        input: TablesSetCellPaddingInput;
        options: MutationOptions;
        output: TableMutationResult;
    };
    'tables.setCellSpacing': {
        input: TablesSetCellSpacingInput;
        options: MutationOptions;
        output: TableMutationResult;
    };
    'tables.clearCellSpacing': {
        input: TablesClearCellSpacingInput;
        options: MutationOptions;
        output: TableMutationResult;
    };
    'tables.applyStyle': {
        input: TablesApplyStyleInput;
        options: MutationOptions;
        output: TableMutationResult;
    };
    'tables.setBorders': {
        input: TablesSetBordersInput;
        options: MutationOptions;
        output: TableMutationResult;
    };
    'tables.setTableOptions': {
        input: TablesSetTableOptionsInput;
        options: MutationOptions;
        output: TableMutationResult;
    };
    'tables.applyPreset': {
        input: TablesApplyPresetInput;
        options: MutationOptions;
        output: TableMutationResult;
    };
    'tables.get': {
        input: TablesGetInput;
        options: never;
        output: TablesGetOutput;
    };
    'tables.getCells': {
        input: TablesGetCellsInput;
        options: never;
        output: TablesGetCellsOutput;
    };
    'tables.getProperties': {
        input: TablesGetPropertiesInput;
        options: never;
        output: TablesGetPropertiesOutput;
    };
    'tables.getStyles': {
        input: TablesGetStylesInput | undefined;
        options: never;
        output: TablesGetStylesOutput;
    };
    'tables.setDefaultStyle': {
        input: TablesSetDefaultStyleInput;
        options: MutationOptions;
        output: DocumentMutationResult;
    };
    'tables.clearDefaultStyle': {
        input: TablesClearDefaultStyleInput | undefined;
        options: MutationOptions;
        output: DocumentMutationResult;
    };
    'create.tableOfContents': {
        input: CreateTableOfContentsInput;
        options: MutationOptions;
        output: CreateTableOfContentsResult;
    };
    'toc.list': {
        input: TocListQuery | undefined;
        options: never;
        output: TocListResult;
    };
    'toc.get': {
        input: TocGetInput;
        options: never;
        output: TocInfo;
    };
    'toc.configure': {
        input: TocConfigureInput;
        options: MutationOptions;
        output: TocMutationResult;
    };
    'toc.update': {
        input: TocUpdateInput;
        options: MutationOptions;
        output: TocMutationResult;
    };
    'toc.remove': {
        input: TocRemoveInput;
        options: MutationOptions;
        output: TocMutationResult;
    };
    'toc.markEntry': {
        input: TocMarkEntryInput;
        options: MutationOptions;
        output: TocEntryMutationResult;
    };
    'toc.unmarkEntry': {
        input: TocUnmarkEntryInput;
        options: MutationOptions;
        output: TocEntryMutationResult;
    };
    'toc.listEntries': {
        input: TocListEntriesQuery | undefined;
        options: never;
        output: TocListEntriesResult;
    };
    'toc.getEntry': {
        input: TocGetEntryInput;
        options: never;
        output: TocEntryInfo;
    };
    'toc.editEntry': {
        input: TocEditEntryInput;
        options: MutationOptions;
        output: TocEntryMutationResult;
    };
    'create.image': {
        input: CreateImageInput;
        options: MutationOptions;
        output: CreateImageResult;
    };
    'images.list': {
        input: ImagesListInput | undefined;
        options: never;
        output: ImagesListResult;
    };
    'images.get': {
        input: ImagesGetInput;
        options: never;
        output: ImageSummary;
    };
    'images.delete': {
        input: ImagesDeleteInput;
        options: MutationOptions;
        output: ImagesMutationResult;
    };
    'images.move': {
        input: MoveImageInput;
        options: MutationOptions;
        output: ImagesMutationResult;
    };
    'images.convertToInline': {
        input: ConvertToInlineInput;
        options: MutationOptions;
        output: ImagesMutationResult;
    };
    'images.convertToFloating': {
        input: ConvertToFloatingInput;
        options: MutationOptions;
        output: ImagesMutationResult;
    };
    'images.setSize': {
        input: SetSizeInput;
        options: MutationOptions;
        output: ImagesMutationResult;
    };
    'images.setWrapType': {
        input: SetWrapTypeInput;
        options: MutationOptions;
        output: ImagesMutationResult;
    };
    'images.setWrapSide': {
        input: SetWrapSideInput;
        options: MutationOptions;
        output: ImagesMutationResult;
    };
    'images.setWrapDistances': {
        input: SetWrapDistancesInput;
        options: MutationOptions;
        output: ImagesMutationResult;
    };
    'images.setPosition': {
        input: SetPositionInput;
        options: MutationOptions;
        output: ImagesMutationResult;
    };
    'images.setAnchorOptions': {
        input: SetAnchorOptionsInput;
        options: MutationOptions;
        output: ImagesMutationResult;
    };
    'images.setZOrder': {
        input: SetZOrderInput;
        options: MutationOptions;
        output: ImagesMutationResult;
    };
    'images.scale': {
        input: ScaleInput;
        options: MutationOptions;
        output: ImagesMutationResult;
    };
    'images.setLockAspectRatio': {
        input: SetLockAspectRatioInput;
        options: MutationOptions;
        output: ImagesMutationResult;
    };
    'images.rotate': {
        input: RotateInput;
        options: MutationOptions;
        output: ImagesMutationResult;
    };
    'images.flip': {
        input: FlipInput;
        options: MutationOptions;
        output: ImagesMutationResult;
    };
    'images.crop': {
        input: CropInput;
        options: MutationOptions;
        output: ImagesMutationResult;
    };
    'images.resetCrop': {
        input: ResetCropInput;
        options: MutationOptions;
        output: ImagesMutationResult;
    };
    'images.replaceSource': {
        input: ReplaceSourceInput;
        options: MutationOptions;
        output: ImagesMutationResult;
    };
    'images.setAltText': {
        input: SetAltTextInput;
        options: MutationOptions;
        output: ImagesMutationResult;
    };
    'images.setDecorative': {
        input: SetDecorativeInput;
        options: MutationOptions;
        output: ImagesMutationResult;
    };
    'images.setName': {
        input: SetNameInput;
        options: MutationOptions;
        output: ImagesMutationResult;
    };
    'images.setHyperlink': {
        input: SetHyperlinkInput;
        options: MutationOptions;
        output: ImagesMutationResult;
    };
    'images.insertCaption': {
        input: InsertCaptionInput;
        options: MutationOptions;
        output: ImagesMutationResult;
    };
    'images.updateCaption': {
        input: UpdateCaptionInput;
        options: MutationOptions;
        output: ImagesMutationResult;
    };
    'images.removeCaption': {
        input: RemoveCaptionInput;
        options: MutationOptions;
        output: ImagesMutationResult;
    };
    'hyperlinks.list': {
        input: HyperlinksListQuery | undefined;
        options: never;
        output: HyperlinksListResult;
    };
    'hyperlinks.get': {
        input: HyperlinksGetInput;
        options: never;
        output: HyperlinkInfo;
    };
    'hyperlinks.wrap': {
        input: HyperlinksWrapInput;
        options: MutationOptions;
        output: HyperlinkMutationResult;
    };
    'hyperlinks.insert': {
        input: HyperlinksInsertInput;
        options: MutationOptions;
        output: HyperlinkMutationResult;
    };
    'hyperlinks.patch': {
        input: HyperlinksPatchInput;
        options: MutationOptions;
        output: HyperlinkMutationResult;
    };
    'hyperlinks.remove': {
        input: HyperlinksRemoveInput;
        options: MutationOptions;
        output: HyperlinkMutationResult;
    };
    'headerFooters.list': {
        input: HeaderFootersListQuery | undefined;
        options: never;
        output: HeaderFootersListResult;
    };
    'headerFooters.get': {
        input: HeaderFootersGetInput;
        options: never;
        output: HeaderFooterSlotEntry;
    };
    'headerFooters.resolve': {
        input: HeaderFootersResolveInput;
        options: never;
        output: HeaderFooterResolveResult;
    };
    'headerFooters.refs.set': {
        input: HeaderFootersRefsSetInput;
        options: MutationOptions;
        output: SectionMutationResult;
    };
    'headerFooters.refs.clear': {
        input: HeaderFootersRefsClearInput;
        options: MutationOptions;
        output: SectionMutationResult;
    };
    'headerFooters.refs.setLinkedToPrevious': {
        input: HeaderFootersRefsSetLinkedToPreviousInput;
        options: MutationOptions;
        output: SectionMutationResult;
    };
    'headerFooters.parts.list': {
        input: HeaderFootersPartsListQuery | undefined;
        options: never;
        output: HeaderFootersPartsListResult;
    };
    'headerFooters.parts.create': {
        input: HeaderFootersPartsCreateInput;
        options: MutationOptions;
        output: HeaderFooterPartsMutationResult;
    };
    'headerFooters.parts.delete': {
        input: HeaderFootersPartsDeleteInput;
        options: MutationOptions;
        output: HeaderFooterPartsMutationResult;
    };
    'create.contentControl': {
        input: CreateContentControlInput;
        options: MutationOptions;
        output: ContentControlMutationResult;
    };
    'contentControls.list': {
        input: ContentControlsListQuery | undefined;
        options: never;
        output: ContentControlsListResult;
    };
    'contentControls.get': {
        input: ContentControlsGetInput;
        options: never;
        output: ContentControlInfo;
    };
    'contentControls.listInRange': {
        input: ContentControlsListInRangeInput;
        options: never;
        output: ContentControlsListResult;
    };
    'contentControls.selectByTag': {
        input: ContentControlsSelectByTagInput;
        options: never;
        output: ContentControlsListResult;
    };
    'contentControls.selectByTitle': {
        input: ContentControlsSelectByTitleInput;
        options: never;
        output: ContentControlsListResult;
    };
    'contentControls.listChildren': {
        input: ContentControlsListChildrenInput;
        options: never;
        output: ContentControlsListResult;
    };
    'contentControls.getParent': {
        input: ContentControlsGetParentInput;
        options: never;
        output: ContentControlInfo | null;
    };
    'contentControls.wrap': {
        input: ContentControlsWrapInput;
        options: MutationOptions;
        output: ContentControlMutationResult;
    };
    'contentControls.unwrap': {
        input: ContentControlsUnwrapInput;
        options: MutationOptions;
        output: ContentControlMutationResult;
    };
    'contentControls.delete': {
        input: ContentControlsDeleteInput;
        options: MutationOptions;
        output: ContentControlMutationResult;
    };
    'contentControls.copy': {
        input: ContentControlsCopyInput;
        options: MutationOptions;
        output: ContentControlMutationResult;
    };
    'contentControls.move': {
        input: ContentControlsMoveInput;
        options: MutationOptions;
        output: ContentControlMutationResult;
    };
    'contentControls.patch': {
        input: ContentControlsPatchInput;
        options: MutationOptions;
        output: ContentControlMutationResult;
    };
    'contentControls.setLockMode': {
        input: ContentControlsSetLockModeInput;
        options: MutationOptions;
        output: ContentControlMutationResult;
    };
    'contentControls.setType': {
        input: ContentControlsSetTypeInput;
        options: MutationOptions;
        output: ContentControlMutationResult;
    };
    'contentControls.getContent': {
        input: ContentControlsGetContentInput;
        options: never;
        output: ContentControlsGetContentResult;
    };
    'contentControls.replaceContent': {
        input: ContentControlsReplaceContentInput;
        options: MutationOptions;
        output: ContentControlMutationResult;
    };
    'contentControls.clearContent': {
        input: ContentControlsClearContentInput;
        options: MutationOptions;
        output: ContentControlMutationResult;
    };
    'contentControls.appendContent': {
        input: ContentControlsAppendContentInput;
        options: MutationOptions;
        output: ContentControlMutationResult;
    };
    'contentControls.prependContent': {
        input: ContentControlsPrependContentInput;
        options: MutationOptions;
        output: ContentControlMutationResult;
    };
    'contentControls.insertBefore': {
        input: ContentControlsInsertBeforeInput;
        options: MutationOptions;
        output: ContentControlMutationResult;
    };
    'contentControls.insertAfter': {
        input: ContentControlsInsertAfterInput;
        options: MutationOptions;
        output: ContentControlMutationResult;
    };
    'contentControls.getBinding': {
        input: ContentControlsGetBindingInput;
        options: never;
        output: ContentControlBinding | null;
    };
    'contentControls.setBinding': {
        input: ContentControlsSetBindingInput;
        options: MutationOptions;
        output: ContentControlMutationResult;
    };
    'contentControls.clearBinding': {
        input: ContentControlsClearBindingInput;
        options: MutationOptions;
        output: ContentControlMutationResult;
    };
    'contentControls.getRawProperties': {
        input: ContentControlsGetRawPropertiesInput;
        options: never;
        output: ContentControlsGetRawPropertiesResult;
    };
    'contentControls.patchRawProperties': {
        input: ContentControlsPatchRawPropertiesInput;
        options: MutationOptions;
        output: ContentControlMutationResult;
    };
    'contentControls.validateWordCompatibility': {
        input: ContentControlsValidateWordCompatibilityInput;
        options: never;
        output: ContentControlsValidateWordCompatibilityResult;
    };
    'contentControls.normalizeWordCompatibility': {
        input: ContentControlsNormalizeWordCompatibilityInput;
        options: MutationOptions;
        output: ContentControlMutationResult;
    };
    'contentControls.normalizeTagPayload': {
        input: ContentControlsNormalizeTagPayloadInput;
        options: MutationOptions;
        output: ContentControlMutationResult;
    };
    'contentControls.text.setMultiline': {
        input: ContentControlsTextSetMultilineInput;
        options: MutationOptions;
        output: ContentControlMutationResult;
    };
    'contentControls.text.setValue': {
        input: ContentControlsTextSetValueInput;
        options: MutationOptions;
        output: ContentControlMutationResult;
    };
    'contentControls.text.clearValue': {
        input: ContentControlsTextClearValueInput;
        options: MutationOptions;
        output: ContentControlMutationResult;
    };
    'contentControls.date.setValue': {
        input: ContentControlsDateSetValueInput;
        options: MutationOptions;
        output: ContentControlMutationResult;
    };
    'contentControls.date.clearValue': {
        input: ContentControlsDateClearValueInput;
        options: MutationOptions;
        output: ContentControlMutationResult;
    };
    'contentControls.date.setDisplayFormat': {
        input: ContentControlsDateSetDisplayFormatInput;
        options: MutationOptions;
        output: ContentControlMutationResult;
    };
    'contentControls.date.setDisplayLocale': {
        input: ContentControlsDateSetDisplayLocaleInput;
        options: MutationOptions;
        output: ContentControlMutationResult;
    };
    'contentControls.date.setStorageFormat': {
        input: ContentControlsDateSetStorageFormatInput;
        options: MutationOptions;
        output: ContentControlMutationResult;
    };
    'contentControls.date.setCalendar': {
        input: ContentControlsDateSetCalendarInput;
        options: MutationOptions;
        output: ContentControlMutationResult;
    };
    'contentControls.checkbox.getState': {
        input: ContentControlsCheckboxGetStateInput;
        options: never;
        output: ContentControlsCheckboxGetStateResult;
    };
    'contentControls.checkbox.setState': {
        input: ContentControlsCheckboxSetStateInput;
        options: MutationOptions;
        output: ContentControlMutationResult;
    };
    'contentControls.checkbox.toggle': {
        input: ContentControlsCheckboxToggleInput;
        options: MutationOptions;
        output: ContentControlMutationResult;
    };
    'contentControls.checkbox.setSymbolPair': {
        input: ContentControlsCheckboxSetSymbolPairInput;
        options: MutationOptions;
        output: ContentControlMutationResult;
    };
    'contentControls.choiceList.getItems': {
        input: ContentControlsChoiceListGetItemsInput;
        options: never;
        output: ContentControlsChoiceListGetItemsResult;
    };
    'contentControls.choiceList.setItems': {
        input: ContentControlsChoiceListSetItemsInput;
        options: MutationOptions;
        output: ContentControlMutationResult;
    };
    'contentControls.choiceList.setSelected': {
        input: ContentControlsChoiceListSetSelectedInput;
        options: MutationOptions;
        output: ContentControlMutationResult;
    };
    'contentControls.repeatingSection.listItems': {
        input: ContentControlsRepeatingSectionListItemsInput;
        options: never;
        output: ContentControlsRepeatingSectionListItemsResult;
    };
    'contentControls.repeatingSection.insertItemBefore': {
        input: ContentControlsRepeatingSectionInsertItemBeforeInput;
        options: MutationOptions;
        output: ContentControlMutationResult;
    };
    'contentControls.repeatingSection.insertItemAfter': {
        input: ContentControlsRepeatingSectionInsertItemAfterInput;
        options: MutationOptions;
        output: ContentControlMutationResult;
    };
    'contentControls.repeatingSection.cloneItem': {
        input: ContentControlsRepeatingSectionCloneItemInput;
        options: MutationOptions;
        output: ContentControlMutationResult;
    };
    'contentControls.repeatingSection.deleteItem': {
        input: ContentControlsRepeatingSectionDeleteItemInput;
        options: MutationOptions;
        output: ContentControlMutationResult;
    };
    'contentControls.repeatingSection.setAllowInsertDelete': {
        input: ContentControlsRepeatingSectionSetAllowInsertDeleteInput;
        options: MutationOptions;
        output: ContentControlMutationResult;
    };
    'contentControls.group.wrap': {
        input: ContentControlsGroupWrapInput;
        options: MutationOptions;
        output: ContentControlMutationResult;
    };
    'contentControls.group.ungroup': {
        input: ContentControlsGroupUngroupInput;
        options: MutationOptions;
        output: ContentControlMutationResult;
    };
    'bookmarks.list': {
        input: BookmarkListInput | undefined;
        options: never;
        output: BookmarksListResult;
    };
    'bookmarks.get': {
        input: BookmarkGetInput;
        options: never;
        output: BookmarkInfo;
    };
    'bookmarks.insert': {
        input: BookmarkInsertInput;
        options: MutationOptions;
        output: BookmarkMutationResult;
    };
    'bookmarks.rename': {
        input: BookmarkRenameInput;
        options: MutationOptions;
        output: BookmarkMutationResult;
    };
    'bookmarks.remove': {
        input: BookmarkRemoveInput;
        options: MutationOptions;
        output: BookmarkMutationResult;
    };
    'footnotes.list': {
        input: FootnoteListInput | undefined;
        options: never;
        output: FootnotesListResult;
    };
    'footnotes.get': {
        input: FootnoteGetInput;
        options: never;
        output: FootnoteInfo;
    };
    'footnotes.insert': {
        input: FootnoteInsertInput;
        options: MutationOptions;
        output: FootnoteMutationResult;
    };
    'footnotes.update': {
        input: FootnoteUpdateInput;
        options: MutationOptions;
        output: FootnoteMutationResult;
    };
    'footnotes.remove': {
        input: FootnoteRemoveInput;
        options: MutationOptions;
        output: FootnoteMutationResult;
    };
    'footnotes.configure': {
        input: FootnoteConfigureInput;
        options: MutationOptions;
        output: FootnoteConfigResult;
    };
    'clipboard.parse': {
        input: ClipboardPayload;
        options: ClipboardParseOptions;
        output: ClipboardParseResult;
    };
    'clipboard.insert': {
        input: ClipboardInsertInput;
        options: MutationOptions;
        output: ClipboardInsertResult;
    };
    'clipboard.serializeSelection': {
        input: ClipboardSerializeInput | undefined;
        options: never;
        output: ClipboardSerializeResult;
    };
    'crossRefs.list': {
        input: CrossRefListInput | undefined;
        options: never;
        output: CrossRefsListResult;
    };
    'crossRefs.get': {
        input: CrossRefGetInput;
        options: never;
        output: CrossRefInfo;
    };
    'crossRefs.insert': {
        input: CrossRefInsertInput;
        options: MutationOptions;
        output: CrossRefMutationResult;
    };
    'crossRefs.rebuild': {
        input: CrossRefRebuildInput;
        options: MutationOptions;
        output: CrossRefMutationResult;
    };
    'crossRefs.remove': {
        input: CrossRefRemoveInput;
        options: MutationOptions;
        output: CrossRefMutationResult;
    };
    'index.list': {
        input: IndexListInput | undefined;
        options: never;
        output: IndexListResult;
    };
    'index.get': {
        input: IndexGetInput;
        options: never;
        output: IndexInfo;
    };
    'index.insert': {
        input: IndexInsertInput;
        options: MutationOptions;
        output: IndexMutationResult;
    };
    'index.configure': {
        input: IndexConfigureInput;
        options: MutationOptions;
        output: IndexMutationResult;
    };
    'index.rebuild': {
        input: IndexRebuildInput;
        options: MutationOptions;
        output: IndexMutationResult;
    };
    'index.remove': {
        input: IndexRemoveInput;
        options: MutationOptions;
        output: IndexMutationResult;
    };
    'index.entries.list': {
        input: IndexEntryListInput | undefined;
        options: never;
        output: IndexEntryListResult;
    };
    'index.entries.get': {
        input: IndexEntryGetInput;
        options: never;
        output: IndexEntryInfo;
    };
    'index.entries.insert': {
        input: IndexEntryInsertInput;
        options: MutationOptions;
        output: IndexEntryMutationResult;
    };
    'index.entries.update': {
        input: IndexEntryUpdateInput;
        options: MutationOptions;
        output: IndexEntryMutationResult;
    };
    'index.entries.remove': {
        input: IndexEntryRemoveInput;
        options: MutationOptions;
        output: IndexEntryMutationResult;
    };
    'captions.list': {
        input: CaptionListInput | undefined;
        options: never;
        output: CaptionsListResult;
    };
    'captions.get': {
        input: CaptionGetInput;
        options: never;
        output: CaptionInfo;
    };
    'captions.insert': {
        input: CaptionInsertInput;
        options: MutationOptions;
        output: CaptionMutationResult;
    };
    'captions.update': {
        input: CaptionUpdateInput;
        options: MutationOptions;
        output: CaptionMutationResult;
    };
    'captions.remove': {
        input: CaptionRemoveInput;
        options: MutationOptions;
        output: CaptionMutationResult;
    };
    'captions.configure': {
        input: CaptionConfigureInput;
        options: MutationOptions;
        output: CaptionConfigResult;
    };
    'fields.list': {
        input: FieldListInput | undefined;
        options: never;
        output: FieldsListResult;
    };
    'fields.get': {
        input: FieldGetInput;
        options: never;
        output: FieldInfo;
    };
    'fields.insert': {
        input: FieldInsertInput;
        options: MutationOptions;
        output: FieldMutationResult;
    };
    'fields.rebuild': {
        input: FieldRebuildInput;
        options: MutationOptions;
        output: FieldMutationResult;
    };
    'fields.remove': {
        input: FieldRemoveInput;
        options: MutationOptions;
        output: FieldMutationResult;
    };
    'citations.list': {
        input: CitationListInput | undefined;
        options: never;
        output: CitationsListResult;
    };
    'citations.get': {
        input: CitationGetInput;
        options: never;
        output: CitationInfo;
    };
    'citations.insert': {
        input: CitationInsertInput;
        options: MutationOptions;
        output: CitationMutationResult;
    };
    'citations.update': {
        input: CitationUpdateInput;
        options: MutationOptions;
        output: CitationMutationResult;
    };
    'citations.remove': {
        input: CitationRemoveInput;
        options: MutationOptions;
        output: CitationMutationResult;
    };
    'citations.sources.list': {
        input: CitationSourceListInput | undefined;
        options: never;
        output: CitationSourcesListResult;
    };
    'citations.sources.get': {
        input: CitationSourceGetInput;
        options: never;
        output: CitationSourceInfo;
    };
    'citations.sources.insert': {
        input: CitationSourceInsertInput;
        options: MutationOptions;
        output: CitationSourceMutationResult;
    };
    'citations.sources.update': {
        input: CitationSourceUpdateInput;
        options: MutationOptions;
        output: CitationSourceMutationResult;
    };
    'citations.sources.remove': {
        input: CitationSourceRemoveInput;
        options: MutationOptions;
        output: CitationSourceMutationResult;
    };
    'citations.bibliography.get': {
        input: BibliographyGetInput;
        options: never;
        output: BibliographyInfo;
    };
    'citations.bibliography.insert': {
        input: BibliographyInsertInput;
        options: MutationOptions;
        output: BibliographyMutationResult;
    };
    'citations.bibliography.rebuild': {
        input: BibliographyRebuildInput;
        options: MutationOptions;
        output: BibliographyMutationResult;
    };
    'citations.bibliography.configure': {
        input: BibliographyConfigureInput;
        options: MutationOptions;
        output: BibliographyMutationResult;
    };
    'citations.bibliography.remove': {
        input: BibliographyRemoveInput;
        options: MutationOptions;
        output: BibliographyMutationResult;
    };
    'authorities.list': {
        input: AuthoritiesListInput | undefined;
        options: never;
        output: AuthoritiesListResult;
    };
    'authorities.get': {
        input: AuthoritiesGetInput;
        options: never;
        output: AuthoritiesInfo;
    };
    'authorities.insert': {
        input: AuthoritiesInsertInput;
        options: MutationOptions;
        output: AuthoritiesMutationResult;
    };
    'authorities.configure': {
        input: AuthoritiesConfigureInput;
        options: MutationOptions;
        output: AuthoritiesMutationResult;
    };
    'authorities.rebuild': {
        input: AuthoritiesRebuildInput;
        options: MutationOptions;
        output: AuthoritiesMutationResult;
    };
    'authorities.remove': {
        input: AuthoritiesRemoveInput;
        options: MutationOptions;
        output: AuthoritiesMutationResult;
    };
    'authorities.entries.list': {
        input: AuthorityEntryListInput | undefined;
        options: never;
        output: AuthorityEntryListResult;
    };
    'authorities.entries.get': {
        input: AuthorityEntryGetInput;
        options: never;
        output: AuthorityEntryInfo;
    };
    'authorities.entries.insert': {
        input: AuthorityEntryInsertInput;
        options: MutationOptions;
        output: AuthorityEntryMutationResult;
    };
    'authorities.entries.update': {
        input: AuthorityEntryUpdateInput;
        options: MutationOptions;
        output: AuthorityEntryMutationResult;
    };
    'authorities.entries.remove': {
        input: AuthorityEntryRemoveInput;
        options: MutationOptions;
        output: AuthorityEntryMutationResult;
    };
    'diff.capture': {
        input: undefined;
        options: never;
        output: DiffSnapshot;
    };
    'diff.compare': {
        input: DiffCompareInput;
        options: never;
        output: DiffPayload;
    };
    'diff.apply': {
        input: DiffApplyInput;
        options: DiffApplyOptions;
        output: DiffApplyResult;
    };
    'export.toDocx': {
        input: ExportToDocxInput;
        options: never;
        output: ExportToDocxResult;
    };
    'protection.get': {
        input: ProtectionGetInput;
        options: never;
        output: DocumentProtectionState;
    };
    'protection.setEditingRestriction': {
        input: SetEditingRestrictionInput;
        options: MutationOptions;
        output: ProtectionMutationResult;
    };
    'protection.clearEditingRestriction': {
        input: ClearEditingRestrictionInput;
        options: MutationOptions;
        output: ProtectionMutationResult;
    };
    'permissionRanges.list': {
        input: PermissionRangesListInput | undefined;
        options: never;
        output: PermissionRangesListResult;
    };
    'permissionRanges.get': {
        input: PermissionRangesGetInput;
        options: never;
        output: PermissionRangeInfo;
    };
    'permissionRanges.create': {
        input: PermissionRangesCreateInput;
        options: MutationOptions;
        output: PermissionRangeMutationResult;
    };
    'permissionRanges.remove': {
        input: PermissionRangesRemoveInput;
        options: MutationOptions;
        output: PermissionRangeRemoveResult;
    };
    'permissionRanges.updatePrincipal': {
        input: PermissionRangesUpdatePrincipalInput;
        options: MutationOptions;
        output: PermissionRangeMutationResult;
    };
    'customXml.parts.list': {
        input: CustomXmlPartsListInput | undefined;
        options: never;
        output: CustomXmlPartsListResult;
    };
    'customXml.parts.get': {
        input: CustomXmlPartsGetInput;
        options: never;
        output: CustomXmlPartInfo | null;
    };
    'customXml.parts.create': {
        input: CustomXmlPartsCreateInput;
        options: MutationOptions;
        output: CustomXmlPartsCreateResult;
    };
    'customXml.parts.patch': {
        input: CustomXmlPartsPatchInput;
        options: MutationOptions;
        output: CustomXmlPartsMutationResult;
    };
    'customXml.parts.remove': {
        input: CustomXmlPartsRemoveInput;
        options: MutationOptions;
        output: CustomXmlPartsMutationResult;
    };
    'metadata.attach': {
        input: AnchoredMetadataAttachInput;
        options: MutationOptions;
        output: AnchoredMetadataAttachResult;
    };
    'metadata.list': {
        input: AnchoredMetadataListInput | undefined;
        options: never;
        output: AnchoredMetadataListResult;
    };
    'metadata.get': {
        input: AnchoredMetadataGetInput;
        options: never;
        output: AnchoredMetadataInfo | null;
    };
    'metadata.update': {
        input: AnchoredMetadataUpdateInput;
        options: MutationOptions;
        output: AnchoredMetadataMutationResult;
    };
    'metadata.remove': {
        input: AnchoredMetadataRemoveInput;
        options: MutationOptions;
        output: AnchoredMetadataMutationResult;
    };
    'metadata.resolve': {
        input: AnchoredMetadataResolveInput;
        options: never;
        output: AnchoredMetadataResolveInfo | null;
    };
}
/**
 * Typed invoke request. TypeScript narrows input and options based on operationId.
 *
 * When an operation has no options (`options: never` in the registry), the
 * request shape forbids `options` via `options?: never` rather than via an
 * intersection with `Record<string, never>` (which would also forbid
 * `operationId` and `input`, making the typed overload unmatchable and
 * silently falling through to the dynamic `unknown` return).
 */
export type InvokeRequest<T extends OperationId> = OperationRegistry[T]['options'] extends never ? {
    operationId: T;
    input: OperationRegistry[T]['input'];
    options?: never;
} : {
    operationId: T;
    input: OperationRegistry[T]['input'];
    options?: OperationRegistry[T]['options'];
};
/**
 * Typed invoke result, narrowed by operationId.
 */
export type InvokeResult<T extends OperationId> = OperationRegistry[T]['output'];
/**
 * Loose invoke request for dynamic callers who don't know the operation at compile time.
 * Invalid inputs will produce adapter-level errors, not input-validation errors.
 */
export type DynamicInvokeRequest = {
    operationId: OperationId;
    input: unknown;
    options?: unknown;
};
export {};
