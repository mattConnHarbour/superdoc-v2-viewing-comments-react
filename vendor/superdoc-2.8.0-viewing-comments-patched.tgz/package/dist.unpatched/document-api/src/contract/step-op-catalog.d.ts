import { OperationId } from './types.js';
export type StepOpDomain = 'assert' | 'text' | 'format' | 'create' | 'tables' | 'structural' | 'internal';
export type StepOpSurface = 'public' | 'internal';
export interface StepOpCatalogEntry<OpId extends string = string, Domain extends StepOpDomain = StepOpDomain, Surface extends StepOpSurface = StepOpSurface> {
    opId: OpId;
    domain: Domain;
    surface: Surface;
    description: string;
    referenceOperationId?: OperationId;
}
declare const STEP_OP_CATALOG_UNFROZEN: readonly [StepOpCatalogEntry<"assert", "assert", StepOpSurface>, StepOpCatalogEntry<"text.rewrite", "text", StepOpSurface>, StepOpCatalogEntry<"text.insert", "text", StepOpSurface>, StepOpCatalogEntry<"text.delete", "text", StepOpSurface>, StepOpCatalogEntry<"format.apply", "format", StepOpSurface>, StepOpCatalogEntry<"create.paragraph", "create", StepOpSurface>, StepOpCatalogEntry<"create.heading", "create", StepOpSurface>, StepOpCatalogEntry<"create.table", "create", StepOpSurface>, StepOpCatalogEntry<"tables.delete", "tables", StepOpSurface>, StepOpCatalogEntry<"tables.clearContents", "tables", StepOpSurface>, StepOpCatalogEntry<"tables.move", "tables", StepOpSurface>, StepOpCatalogEntry<"tables.split", "tables", StepOpSurface>, StepOpCatalogEntry<"tables.convertFromText", "tables", StepOpSurface>, StepOpCatalogEntry<"tables.convertToText", "tables", StepOpSurface>, StepOpCatalogEntry<"tables.setLayout", "tables", StepOpSurface>, StepOpCatalogEntry<"tables.insertRow", "tables", StepOpSurface>, StepOpCatalogEntry<"tables.deleteRow", "tables", StepOpSurface>, StepOpCatalogEntry<"tables.moveRow", "tables", StepOpSurface>, StepOpCatalogEntry<"tables.setRowHeight", "tables", StepOpSurface>, StepOpCatalogEntry<"tables.distributeRows", "tables", StepOpSurface>, StepOpCatalogEntry<"tables.setRowOptions", "tables", StepOpSurface>, StepOpCatalogEntry<"tables.insertColumn", "tables", StepOpSurface>, StepOpCatalogEntry<"tables.deleteColumn", "tables", StepOpSurface>, StepOpCatalogEntry<"tables.setColumnWidth", "tables", StepOpSurface>, StepOpCatalogEntry<"tables.distributeColumns", "tables", StepOpSurface>, StepOpCatalogEntry<"tables.insertCell", "tables", StepOpSurface>, StepOpCatalogEntry<"tables.deleteCell", "tables", StepOpSurface>, StepOpCatalogEntry<"tables.mergeCells", "tables", StepOpSurface>, StepOpCatalogEntry<"tables.unmergeCells", "tables", StepOpSurface>, StepOpCatalogEntry<"tables.splitCell", "tables", StepOpSurface>, StepOpCatalogEntry<"tables.setCellProperties", "tables", StepOpSurface>, StepOpCatalogEntry<"tables.sort", "tables", StepOpSurface>, StepOpCatalogEntry<"tables.setAltText", "tables", StepOpSurface>, StepOpCatalogEntry<"tables.setStyle", "tables", StepOpSurface>, StepOpCatalogEntry<"tables.clearStyle", "tables", StepOpSurface>, StepOpCatalogEntry<"tables.setStyleOption", "tables", StepOpSurface>, StepOpCatalogEntry<"tables.setBorder", "tables", StepOpSurface>, StepOpCatalogEntry<"tables.clearBorder", "tables", StepOpSurface>, StepOpCatalogEntry<"tables.applyBorderPreset", "tables", StepOpSurface>, StepOpCatalogEntry<"tables.setShading", "tables", StepOpSurface>, StepOpCatalogEntry<"tables.clearShading", "tables", StepOpSurface>, StepOpCatalogEntry<"tables.setTablePadding", "tables", StepOpSurface>, StepOpCatalogEntry<"tables.setCellPadding", "tables", StepOpSurface>, StepOpCatalogEntry<"tables.setCellSpacing", "tables", StepOpSurface>, StepOpCatalogEntry<"tables.clearCellSpacing", "tables", StepOpSurface>, StepOpCatalogEntry<"structural.insert", "structural", StepOpSurface>, StepOpCatalogEntry<"structural.replace", "structural", StepOpSurface>, StepOpCatalogEntry<"domain.command", "internal", "internal">];
export declare const STEP_OP_CATALOG: readonly StepOpCatalogEntry[];
export type MutationStepOpId = (typeof STEP_OP_CATALOG_UNFROZEN)[number]['opId'];
type InternalStepOpCatalogEntry = Extract<(typeof STEP_OP_CATALOG_UNFROZEN)[number], {
    surface: 'internal';
}>;
type InternalMutationStepOpId = InternalStepOpCatalogEntry['opId'];
export type PublicMutationStepOpId = Exclude<MutationStepOpId, InternalMutationStepOpId>;
declare const PUBLIC_STEP_OP_CATALOG_UNFROZEN: readonly StepOpCatalogEntry<PublicMutationStepOpId, StepOpDomain, "public">[];
export type PublicStepOpCatalogEntry = (typeof PUBLIC_STEP_OP_CATALOG_UNFROZEN)[number];
export declare const PUBLIC_STEP_OP_CATALOG: readonly StepOpCatalogEntry[];
export declare const KNOWN_MUTATION_STEP_OP_IDS: readonly MutationStepOpId[];
export declare const PUBLIC_MUTATION_STEP_OP_IDS: readonly PublicMutationStepOpId[];
export declare function isKnownMutationStepOp(opId: string): opId is MutationStepOpId;
export declare function isPublicMutationStepOp(opId: string): opId is PublicMutationStepOpId;
export {};
