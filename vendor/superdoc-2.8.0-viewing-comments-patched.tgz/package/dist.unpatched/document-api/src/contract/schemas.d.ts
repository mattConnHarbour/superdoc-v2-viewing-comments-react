import { OperationId } from './types.js';
type JsonSchema = Record<string, unknown>;
/** JSON Schema descriptors for a single operation's input, output, and result variants. */
export interface OperationSchemaSet {
    /** Schema describing the operation's accepted input payload. */
    input: JsonSchema;
    /** Schema describing the full output (success | failure union for mutations). */
    output: JsonSchema;
    /** Schema describing only the success branch of a mutation result. */
    success?: JsonSchema;
    /** Schema describing only the failure branch of a mutation result. */
    failure?: JsonSchema;
}
/** Top-level contract envelope containing versioned operation schemas. */
export interface InternalContractSchemas {
    /** JSON Schema dialect URI (e.g. `https://json-schema.org/draft/2020-12/schema`). */
    $schema: string;
    /** Semantic version of the document-api contract these schemas describe. */
    contractVersion: string;
    /** Shared schema definitions referenced by `$ref` in operation schemas. */
    $defs?: Record<string, JsonSchema>;
    /** Per-operation schema sets keyed by {@link OperationId}. */
    operations: Record<OperationId, OperationSchemaSet>;
}
/**
 * Builds the complete set of JSON Schema definitions for every document-api operation.
 *
 * Validates that every {@link OperationId} has a corresponding schema entry and
 * that no unknown operations are present.
 *
 * @returns A versioned {@link InternalContractSchemas} envelope.
 * @throws {Error} If any operation is missing a schema or an unknown operation is found.
 */
export declare function buildInternalContractSchemas(): InternalContractSchemas;
export {};
