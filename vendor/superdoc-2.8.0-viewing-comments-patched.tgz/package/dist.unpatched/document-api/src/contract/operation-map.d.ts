import { OPERATION_DEFINITIONS, OperationId } from './operation-definitions.js';
export type DocumentApiMemberPath = (typeof OPERATION_DEFINITIONS)[OperationId]['memberPath'];
export declare function memberPathForOperation(operationId: OperationId): DocumentApiMemberPath;
export declare const OPERATION_MEMBER_PATH_MAP: Record<OperationId, DocumentApiMemberPath>;
export declare const DOCUMENT_API_MEMBER_PATHS: readonly DocumentApiMemberPath[];
