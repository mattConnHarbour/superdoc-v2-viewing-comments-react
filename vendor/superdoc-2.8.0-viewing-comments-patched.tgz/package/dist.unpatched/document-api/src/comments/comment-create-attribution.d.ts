import { CommentCreateAttributionInput } from './comments.types.js';
export declare function normalizeCommentCreateAttribution(input: CommentCreateAttributionInput): CommentCreateAttributionInput | null;
