import { Receipt, ReceiptFailureResult, ReceiptSuccess, StoryLocator } from '../types/index.js';
import { CommentInfo, CommentCreateAttributionInput, CommentTarget, CommentsListQuery, CommentsListResult, TextSearchCommentTarget, TrackedChangeCommentTarget, TrackedChangeCommentTargetSide } from './comments.types.js';
import { RevisionGuardOptions } from '../write/write.js';
export type { TextSearchCommentTarget, TrackedChangeCommentTarget, TrackedChangeCommentTargetSide };
export type { CommentCreateAttributionInput, CommentMetadata, CommentMetadataValue } from './comments.types.js';
/**
 * Input for adding a comment to a text range.
 *
 * `target` accepts either a single-block {@link TextAddress} or a multi-
 * segment {@link TextTarget}. A multi-segment target anchors the comment
 * across contiguous blocks: use it directly from `editor.doc.selection.current().target`
 * without picking a single segment.
 */
export interface AddCommentInput extends CommentCreateAttributionInput {
    /**
     * The text range to attach the comment to.
     *
     * Pass a {@link TextAddress} for single-block ranges (e.g. from `find`'s
     * `textRanges[0]`), a {@link TextTarget} with multi-segment for
     * selections that span multiple blocks, or a
     * {@link TrackedChangeCommentTarget} that names a logical tracked-change
     * id as a convenience anchor (the adapter normalizes it to the actual
     * content range on the relevant revision side).
     */
    target?: CommentTarget;
    /** The comment body text. */
    text: string;
}
export interface EditCommentInput {
    commentId: string;
    text: string;
}
export interface ReplyToCommentInput extends CommentCreateAttributionInput {
    parentCommentId: string;
    text: string;
}
export interface MoveCommentInput {
    commentId: string;
    /**
     * New anchor target. Accepts a plain {@link TextAddress}, a
     * {@link SelectionTarget}, or a {@link TrackedChangeCommentTarget} that
     * names a logical tracked-change id as a convenience re-anchor target.
     */
    target: CommentTarget;
}
export interface ResolveCommentInput {
    commentId: string;
}
/**
 * Input for reopening a previously-resolved comment. Accepted as the
 * `status: 'active'` branch of `comments.patch`.
 */
export interface ReopenCommentInput {
    commentId: string;
}
export interface RemoveCommentInput {
    commentId: string;
}
export interface SetCommentInternalInput {
    commentId: string;
    isInternal: boolean;
}
export interface SetCommentActiveInput {
    commentId: string | null;
}
export interface GoToCommentInput {
    commentId: string;
}
export interface GetCommentInput {
    commentId: string;
}
/**
 * Input for `comments.create`: creates a new comment thread or a reply.
 *
 * When `parentCommentId` is provided, creates a reply on an existing thread.
 * Otherwise, creates a new root comment anchored to the given text range.
 */
export interface CommentsCreateInput extends CommentCreateAttributionInput {
    /** The comment body text. */
    text: string;
    /**
     * Compatibility alias for {@link CommentCreateAttributionInput.externalId},
     * matching the caller-supplied `commentId` accepted by the v1 editor.
     *
     * V2 still mints a separate Word-compatible id for the document. Pass
     * either `commentId` or `externalId`; when both are present they must agree.
     */
    commentId?: string;
    /**
     * The text range to attach the comment to (root comments only).
     *
     * Accepts either a single-block {@link TextAddress}, a multi-segment
     * {@link TextTarget}, or a {@link TrackedChangeCommentTarget} that
     * names a logical tracked-change id as a convenience anchor. Prefer
     * passing `editor.doc.selection.current().target` directly for
     * selections that may span multiple blocks.
     */
    target?: CommentTarget;
    /**
     * Compatibility shorthand for {@link TrackedChangeCommentTarget}. When
     * `target` is omitted, execute normalizes this to
     * `target: { trackedChangeId, side, story }` before validation.
     */
    trackedChangeId?: string;
    /** Optional side for the `trackedChangeId` shorthand. */
    side?: TrackedChangeCommentTargetSide;
    /** Optional story for the `trackedChangeId` shorthand. */
    story?: StoryLocator;
    /** Parent comment ID: when provided, creates a reply instead of a root comment. */
    parentCommentId?: string;
    /**
     * Public contract alias for {@link parentCommentId}. Pass either key, or
     * both when they contain the same value.
     */
    parentId?: string;
}
/**
 * Input for `comments.patch`: field-level patch on an existing comment.
 *
 * Exactly one mutation field (`text`, `target`, `status`, `isInternal`)
 * must be provided per call. Providing zero or multiple fields throws
 * `INVALID_INPUT`.
 */
export interface CommentsPatchInput {
    /** The ID of the comment to patch. */
    commentId: string;
    /** New body text (routes to edit). */
    text?: string;
    /**
     * New anchor range (routes to move). Accepts a plain
     * {@link TextAddress} or {@link SelectionTarget} for direct anchor replacement, or a
     * {@link TrackedChangeCommentTarget} that names a logical
     * tracked-change id as a convenience re-anchor target.
     */
    target?: CommentTarget;
    /**
     * Lifecycle transition. `'resolved'` routes to resolve, `'active'`
     * routes to reopen: symmetric inverse that removes the resolve
     * anchors and restores the live comment mark.
     */
    status?: 'resolved' | 'active';
    /** Set the internal/private flag (routes to setInternal). */
    isInternal?: boolean;
}
/**
 * Input for `comments.delete`: removes a comment by ID.
 */
export interface CommentsDeleteInput {
    /** The ID of the comment to delete. */
    commentId: string;
}
export type CommentsCreateReceiptSuccess = ReceiptSuccess & {
    /** Convenience alias for the created comment id. */
    id: string;
};
export type CommentsCreateReceipt = CommentsCreateReceiptSuccess | ReceiptFailureResult;
/**
 * Engine-specific adapter that the comments API delegates to.
 */
export interface CommentsAdapter {
    /** Add a comment at the specified text range. */
    add(input: AddCommentInput, options?: RevisionGuardOptions): CommentsCreateReceipt;
    /** Edit the body text of an existing comment. */
    edit(input: EditCommentInput, options?: RevisionGuardOptions): Receipt;
    /** Reply to an existing comment thread. */
    reply(input: ReplyToCommentInput, options?: RevisionGuardOptions): CommentsCreateReceipt;
    /** Move a comment to a different text range. */
    move(input: MoveCommentInput, options?: RevisionGuardOptions): Receipt;
    /** Resolve an open comment. */
    resolve(input: ResolveCommentInput, options?: RevisionGuardOptions): Receipt;
    /**
     * Reopen a previously-resolved comment. Symmetric inverse of
     * {@link CommentsAdapter.resolve}: removes the
     * `commentRangeStart` / `commentRangeEnd` anchor nodes inserted at
     * resolve time and restores the live `comment` mark across the
     * original range so subsequent operations see the comment as active.
     */
    reopen(input: ReopenCommentInput, options?: RevisionGuardOptions): Receipt;
    /** Remove a comment from the document. */
    remove(input: RemoveCommentInput, options?: RevisionGuardOptions): Receipt;
    /** Set the internal/private flag on a comment. */
    setInternal(input: SetCommentInternalInput, options?: RevisionGuardOptions): Receipt;
    /** Set which comment is currently active/focused. Pass `null` to clear. */
    setActive(input: SetCommentActiveInput, options?: RevisionGuardOptions): Receipt;
    /** Scroll to and focus a comment in the document. */
    goTo(input: GoToCommentInput): Receipt;
    /** Retrieve full information for a single comment. */
    get(input: GetCommentInput): CommentInfo;
    /** List comments matching the given query. */
    list(query?: CommentsListQuery): CommentsListResult;
}
/**
 * Public comments API surface exposed on `editor.doc.comments`.
 *
 * Canonical operations: `create`, `patch`, `delete`, `get`, `list`.
 *
 * Excludes UI-state operations (`setActive`, `goTo`) that live on
 * {@link CommentsAdapter} for internal editor use but are not part
 * of the document-api contract.
 */
export interface CommentsApi {
    create(input: CommentsCreateInput, options?: RevisionGuardOptions): CommentsCreateReceipt;
    patch(input: CommentsPatchInput, options?: RevisionGuardOptions): Receipt;
    delete(input: CommentsDeleteInput, options?: RevisionGuardOptions): Receipt;
    get(input: GetCommentInput): CommentInfo;
    list(query?: CommentsListQuery): CommentsListResult;
}
/**
 * Execute `comments.create`: routes to `adapter.add` or `adapter.reply`
 * depending on whether `parentCommentId` is provided.
 *
 * Accepts {@link RevisionGuardOptions} instead of `MutationOptions` because
 * comments route to specialized adapter methods (add/edit/reply/move/resolve/remove)
 * outside the plan engine, so changeMode and dryRun are not applicable.
 */
export declare function executeCommentsCreate(adapter: CommentsAdapter, input: CommentsCreateInput, options?: RevisionGuardOptions): CommentsCreateReceipt;
/**
 * Execute `comments.patch`: routes to exactly one adapter method based on
 * the single mutation field provided. Validation enforces one-field-per-call.
 *
 * Accepts {@link RevisionGuardOptions} instead of `MutationOptions` because
 * comments route to specialized adapter methods (add/edit/reply/move/resolve/remove)
 * outside the plan engine, so changeMode and dryRun are not applicable.
 */
export declare function executeCommentsPatch(adapter: CommentsAdapter, input: CommentsPatchInput, options?: RevisionGuardOptions): Receipt;
/**
 * Execute `comments.delete`: routes to `adapter.remove`.
 */
export declare function executeCommentsDelete(adapter: CommentsAdapter, input: CommentsDeleteInput, options?: RevisionGuardOptions): Receipt;
export declare function executeGetComment(adapter: CommentsAdapter, input: GetCommentInput): CommentInfo;
export declare function executeListComments(adapter: CommentsAdapter, query?: CommentsListQuery): CommentsListResult;
