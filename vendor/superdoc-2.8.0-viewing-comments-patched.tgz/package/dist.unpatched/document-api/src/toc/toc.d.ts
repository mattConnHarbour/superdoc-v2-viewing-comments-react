import { MutationOptions } from '../write/write.js';
import { TocGetInput, TocInfo, TocConfigureInput, TocUpdateInput, TocRemoveInput, TocMutationResult, TocListQuery, TocListResult, TocMarkEntryInput, TocUnmarkEntryInput, TocListEntriesQuery, TocListEntriesResult, TocGetEntryInput, TocEntryInfo, TocEditEntryInput, TocEntryMutationResult } from './toc.types.js';
export interface TocApi {
    list(query?: TocListQuery): TocListResult;
    get(input: TocGetInput): TocInfo;
    configure(input: TocConfigureInput, options?: MutationOptions): TocMutationResult;
    update(input: TocUpdateInput, options?: MutationOptions): TocMutationResult;
    remove(input: TocRemoveInput, options?: MutationOptions): TocMutationResult;
    markEntry(input: TocMarkEntryInput, options?: MutationOptions): TocEntryMutationResult;
    unmarkEntry(input: TocUnmarkEntryInput, options?: MutationOptions): TocEntryMutationResult;
    listEntries(query?: TocListEntriesQuery): TocListEntriesResult;
    getEntry(input: TocGetEntryInput): TocEntryInfo;
    editEntry(input: TocEditEntryInput, options?: MutationOptions): TocEntryMutationResult;
}
export type TocAdapter = TocApi;
export declare function executeTocList(adapter: TocAdapter, query?: TocListQuery): TocListResult;
export declare function executeTocGet(adapter: TocAdapter, input: TocGetInput): TocInfo;
export declare function executeTocConfigure(adapter: TocAdapter, input: TocConfigureInput, options?: MutationOptions): TocMutationResult;
export declare function executeTocUpdate(adapter: TocAdapter, input: TocUpdateInput, options?: MutationOptions): TocMutationResult;
export declare function executeTocRemove(adapter: TocAdapter, input: TocRemoveInput, options?: MutationOptions): TocMutationResult;
export declare function executeTocMarkEntry(adapter: TocAdapter, input: TocMarkEntryInput, options?: MutationOptions): TocEntryMutationResult;
export declare function executeTocUnmarkEntry(adapter: TocAdapter, input: TocUnmarkEntryInput, options?: MutationOptions): TocEntryMutationResult;
export declare function executeTocListEntries(adapter: TocAdapter, query?: TocListEntriesQuery): TocListEntriesResult;
export declare function executeTocGetEntry(adapter: TocAdapter, input: TocGetEntryInput): TocEntryInfo;
export declare function executeTocEditEntry(adapter: TocAdapter, input: TocEditEntryInput, options?: MutationOptions): TocEntryMutationResult;
