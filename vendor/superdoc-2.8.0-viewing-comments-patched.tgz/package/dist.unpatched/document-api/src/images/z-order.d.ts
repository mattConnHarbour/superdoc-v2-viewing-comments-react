/**
 * OOXML unsignedInt bounds for wp:anchor@relativeHeight.
 * ECMA-376 defines unsignedInt as 0..4294967295.
 */
export declare const Z_ORDER_RELATIVE_HEIGHT_MIN = 0;
export declare const Z_ORDER_RELATIVE_HEIGHT_MAX = 4294967295;
/**
 * Returns true when the value is an unsigned 32-bit integer.
 */
export declare function isUnsignedInt32(value: unknown): value is number;
