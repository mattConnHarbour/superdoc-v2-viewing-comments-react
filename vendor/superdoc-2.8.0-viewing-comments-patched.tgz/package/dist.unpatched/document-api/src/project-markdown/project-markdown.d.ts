import { ProjectMarkdownInput, SDContentProjectionResult } from '../types/content-projection.js';
export interface ProjectMarkdownAdapter {
    projectMarkdown(input: ProjectMarkdownInput): Promise<SDContentProjectionResult<'markdown'>>;
}
export declare function executeProjectMarkdown(adapter: ProjectMarkdownAdapter | undefined, input: ProjectMarkdownInput): Promise<SDContentProjectionResult<'markdown'>>;
