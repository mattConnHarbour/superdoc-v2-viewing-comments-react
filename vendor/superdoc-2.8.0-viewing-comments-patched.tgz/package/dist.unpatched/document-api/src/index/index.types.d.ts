import { InlineAnchor } from '../types/base.js';
import { TextTarget } from '../types/address.js';
import { AdapterMutationFailure } from '../types/adapter-result.js';
import { DiscoveryOutput } from '../types/discovery.js';
import { TocCreateLocation } from '../toc/toc.types.js';
export interface IndexAddress {
    kind: 'block';
    nodeType: 'index';
    nodeId: string;
}
export interface IndexEntryAddress {
    kind: 'inline';
    nodeType: 'indexEntry';
    anchor: InlineAnchor;
}
export interface IndexConfig {
    headingSeparator?: string;
    entryPageSeparator?: string;
    pageRangeSeparator?: string;
    sequenceId?: string;
    columns?: number;
    entryTypeFilter?: string;
    pageRangeBookmark?: string;
    letterRange?: {
        from: string;
        to: string;
    };
    runIn?: boolean;
    accentedSorting?: boolean;
}
export interface IndexEntryData {
    text: string;
    subEntry?: string;
    bold?: boolean;
    italic?: boolean;
    crossReference?: string;
    pageRangeBookmark?: string;
    entryType?: string;
    yomi?: string;
}
export interface IndexListInput {
    limit?: number;
    offset?: number;
}
export interface IndexGetInput {
    target: IndexAddress;
}
export interface IndexInsertInput {
    at: TocCreateLocation;
    config?: IndexConfig;
}
export interface IndexConfigureInput {
    target: IndexAddress;
    patch: IndexConfig;
}
export interface IndexRebuildInput {
    target: IndexAddress;
}
export interface IndexRemoveInput {
    target: IndexAddress;
}
export interface IndexEntryListInput {
    entryType?: string;
    limit?: number;
    offset?: number;
}
export interface IndexEntryGetInput {
    target: IndexEntryAddress;
}
export interface IndexEntryInsertInput {
    at: TextTarget;
    entry: IndexEntryData;
}
export interface IndexEntryUpdateInput {
    target: IndexEntryAddress;
    patch: Partial<IndexEntryData>;
}
export interface IndexEntryRemoveInput {
    target: IndexEntryAddress;
}
export interface IndexInfo {
    address: IndexAddress;
    instruction: string;
    config: IndexConfig;
    entryCount: number;
}
export interface IndexDomain {
    address: IndexAddress;
    instruction: string;
    config: IndexConfig;
    entryCount: number;
}
export interface IndexEntryInfo {
    address: IndexEntryAddress;
    text: string;
    subEntry?: string;
    bold: boolean;
    italic: boolean;
    crossReference?: string;
    pageRangeBookmark?: string;
    entryType?: string;
    yomi?: string;
    instruction: string;
}
export interface IndexEntryDomain {
    address: IndexEntryAddress;
    text: string;
    subEntry?: string;
    bold: boolean;
    italic: boolean;
    yomi?: string;
    instruction: string;
}
export interface IndexMutationSuccess {
    success: true;
    index: IndexAddress;
}
export type IndexMutationResult = IndexMutationSuccess | AdapterMutationFailure;
export interface IndexEntryMutationSuccess {
    success: true;
    entry: IndexEntryAddress;
}
export type IndexEntryMutationResult = IndexEntryMutationSuccess | AdapterMutationFailure;
export type IndexListResult = DiscoveryOutput<IndexDomain>;
export type IndexEntryListResult = DiscoveryOutput<IndexEntryDomain>;
