import { MutationOptions } from '../write/write.js';
import { IndexListInput, IndexListResult, IndexGetInput, IndexInfo, IndexInsertInput, IndexConfigureInput, IndexRebuildInput, IndexRemoveInput, IndexMutationResult, IndexEntryListInput, IndexEntryListResult, IndexEntryGetInput, IndexEntryInfo, IndexEntryInsertInput, IndexEntryUpdateInput, IndexEntryRemoveInput, IndexEntryMutationResult } from './index.types.js';
export interface IndexApi {
    list(input?: IndexListInput): IndexListResult;
    get(input: IndexGetInput): IndexInfo;
    insert(input: IndexInsertInput, options?: MutationOptions): IndexMutationResult;
    configure(input: IndexConfigureInput, options?: MutationOptions): IndexMutationResult;
    rebuild(input: IndexRebuildInput, options?: MutationOptions): IndexMutationResult;
    remove(input: IndexRemoveInput, options?: MutationOptions): IndexMutationResult;
    entries: {
        list(input?: IndexEntryListInput): IndexEntryListResult;
        get(input: IndexEntryGetInput): IndexEntryInfo;
        insert(input: IndexEntryInsertInput, options?: MutationOptions): IndexEntryMutationResult;
        update(input: IndexEntryUpdateInput, options?: MutationOptions): IndexEntryMutationResult;
        remove(input: IndexEntryRemoveInput, options?: MutationOptions): IndexEntryMutationResult;
    };
}
export type IndexAdapter = IndexApi;
export declare function executeIndexList(adapter: IndexAdapter, input?: IndexListInput): IndexListResult;
export declare function executeIndexGet(adapter: IndexAdapter, input: IndexGetInput): IndexInfo;
export declare function executeIndexInsert(adapter: IndexAdapter, input: IndexInsertInput, options?: MutationOptions): IndexMutationResult;
export declare function executeIndexConfigure(adapter: IndexAdapter, input: IndexConfigureInput, options?: MutationOptions): IndexMutationResult;
export declare function executeIndexRebuild(adapter: IndexAdapter, input: IndexRebuildInput, options?: MutationOptions): IndexMutationResult;
export declare function executeIndexRemove(adapter: IndexAdapter, input: IndexRemoveInput, options?: MutationOptions): IndexMutationResult;
export declare function executeIndexEntryList(adapter: IndexAdapter, input?: IndexEntryListInput): IndexEntryListResult;
export declare function executeIndexEntryGet(adapter: IndexAdapter, input: IndexEntryGetInput): IndexEntryInfo;
export declare function executeIndexEntryInsert(adapter: IndexAdapter, input: IndexEntryInsertInput, options?: MutationOptions): IndexEntryMutationResult;
export declare function executeIndexEntryUpdate(adapter: IndexAdapter, input: IndexEntryUpdateInput, options?: MutationOptions): IndexEntryMutationResult;
export declare function executeIndexEntryRemove(adapter: IndexAdapter, input: IndexEntryRemoveInput, options?: MutationOptions): IndexEntryMutationResult;
