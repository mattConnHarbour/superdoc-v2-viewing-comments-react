import { Receipt } from '../types/receipt.js';
import { RevisionGuardOptions } from '../write/write.js';
export type ClearContentInput = Record<string, never>;
/**
 * Engine-specific adapter that clears all document body content.
 */
export interface ClearContentAdapter {
    /**
     * Clear the document body, replacing all content with a single empty paragraph.
     */
    clearContent(input: ClearContentInput, options?: RevisionGuardOptions): Receipt;
}
/**
 * Execute a clearContent operation through the provided adapter.
 *
 * clearContent is a destructive reset: tracked mode and dry run are not
 * meaningful, so this accepts {@link RevisionGuardOptions} rather than
 * `MutationOptions`.
 *
 * @param adapter - Engine-specific clear-content adapter.
 * @param input - Canonical clear-content input (empty object).
 * @param options - Optional revision guard options.
 * @returns A Receipt indicating success or NO_OP if already empty.
 */
export declare function executeClearContent(adapter: ClearContentAdapter, input: ClearContentInput, options?: RevisionGuardOptions): Receipt;
