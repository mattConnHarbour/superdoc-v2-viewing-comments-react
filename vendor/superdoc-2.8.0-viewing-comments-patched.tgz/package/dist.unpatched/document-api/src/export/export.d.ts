import { ExportToDocxInput, ExportToDocxResult, SDExportMode } from './export.types.js';
export interface ExportAdapter {
    toDocx(input: {
        mode: SDExportMode;
    }): ExportToDocxResult;
}
export interface ExportApi {
    toDocx(input?: ExportToDocxInput): ExportToDocxResult;
}
export declare function executeExportToDocx(adapter: ExportAdapter | undefined, input?: ExportToDocxInput): ExportToDocxResult;
