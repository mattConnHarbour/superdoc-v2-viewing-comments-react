import { ReviewWarning } from '../types/receipt.js';
/** Canonical tracked-change export modes accepted by every public export surface. */
export declare const SD_EXPORT_MODES: readonly ["review-preserving", "final", "original"];
/**
 * Tracked-change export mode.
 *
 * - `review-preserving` (default): keep open tracked changes as Word revision
 *   markup so the saved document is still reviewable.
 * - `final`: resolve every open tracked change as accepted.
 * - `original`: resolve every open tracked change as rejected.
 */
export type SDExportMode = (typeof SD_EXPORT_MODES)[number];
/** Default mode for modeful DOCX export. */
export declare const DEFAULT_SD_EXPORT_MODE: SDExportMode;
/** Input for `export.toDocx`. */
export interface ExportToDocxInput {
    /** Tracked-change export mode. Defaults to `review-preserving`. */
    mode?: SDExportMode;
}
/** Structured degradation report for an export. */
export interface ExportToDocxReport {
    /**
     * Allowed, non-load-bearing degradation warnings produced while projecting
     * the document for the requested mode (for example a tracked replacement
     * exported as Word delete+insert). Forbidden semantic loss never reaches
     * this lane — those failures fail closed before bytes are produced.
     */
    warnings: ReviewWarning[];
}
/** Result of `export.toDocx`. */
export interface ExportToDocxResult {
    /** The mode the export was produced under. */
    mode: SDExportMode;
    /** Byte length of the exported DOCX package. */
    byteLength: number;
    /** Base64-encoded exported DOCX package bytes. */
    contentBase64: string;
    /** Degradation report for the export. */
    report: ExportToDocxReport;
}
