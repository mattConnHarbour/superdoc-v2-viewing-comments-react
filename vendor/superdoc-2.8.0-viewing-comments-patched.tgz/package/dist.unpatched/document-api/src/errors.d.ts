/**
 * Structured validation error thrown by document-api execute* functions.
 *
 * Consumers should prefer checking `error.code` over `instanceof` for resilience
 * across package boundaries and bundling scenarios.
 */
export declare class DocumentApiValidationError extends Error {
    readonly code: string;
    readonly details?: Record<string, unknown>;
    constructor(code: string, message: string, details?: Record<string, unknown>);
}
