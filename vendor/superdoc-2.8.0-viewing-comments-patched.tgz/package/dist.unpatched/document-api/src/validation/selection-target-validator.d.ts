import { SelectionTarget, SelectionPoint, SelectionEdgeNodeAddress } from '../types/address.js';
/** Type guard for SelectionEdgeNodeAddress. */
export declare function isSelectionEdgeNodeAddress(value: unknown): value is SelectionEdgeNodeAddress;
/** Type guard for SelectionPoint. */
export declare function isSelectionPoint(value: unknown): value is SelectionPoint;
/** Type guard for SelectionTarget. */
export declare function isSelectionTarget(value: unknown): value is SelectionTarget;
