import { SDFragment } from '../types/fragment.js';
/**
 * Validates an SDM/1 fragment for structural correctness.
 *
 * Uses SDErrorCode vocabulary for all error codes.
 */
export declare function validateSDFragment(fragment: unknown): asserts fragment is SDFragment;
/**
 * Backward-compatible entry point: validates both legacy and SDM/1 shapes.
 *
 * Routes to SDM/1 or legacy validation based on the presence of `kind` vs `type`.
 */
export declare function validateDocumentFragment(fragment: unknown): asserts fragment is SDFragment;
