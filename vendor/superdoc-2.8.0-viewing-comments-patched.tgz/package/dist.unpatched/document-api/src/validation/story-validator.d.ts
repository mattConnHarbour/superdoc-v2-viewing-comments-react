import { StoryLocator } from '../types/story.types.js';
/**
 * Validates that `value` is a valid StoryLocator if present.
 * Throws INVALID_INPUT if the shape is wrong.
 */
export declare function validateStoryLocator(value: unknown, field: string): void;
/**
 * Validates the story resolution precedence rules.
 * - within must not carry story
 * - input.in and target.story must match if both present
 */
export declare function validateStoryConsistency(inputIn: StoryLocator | undefined, targetStory: StoryLocator | undefined, withinStory: StoryLocator | undefined): void;
