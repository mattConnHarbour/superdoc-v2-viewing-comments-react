import { TocCreateLocation } from '../toc/toc.types.js';
export declare function validateTargetOnlyTocCreateLocation(at: TocCreateLocation, operationName: string): void;
