export interface PlanCaptureRefMarker {
    kind: 'capture-ref';
    captureKey: string;
    /** Dotted lookup path into the captured value (supports array indices and `length`). */
    path?: string;
    /** Structural filter applied to an array at `path`; may nest further markers. */
    where?: unknown;
    /** Index into the (filtered) array; negative counts from the end. */
    occurrence?: number;
    /** Dotted lookup applied after `where`/`occurrence` selection. */
    selectPath?: string;
}
export interface PlanProjectTextOffsetMarker {
    kind: 'project-text-offset';
    rawText: string;
    rawOffset: number;
    publicText: string | PlanCaptureRefMarker;
}
export interface PlanExecuteEntryExpect {
    /** `false` marks the entry as an expected failure. */
    success?: boolean;
    failureCode?: string;
    failureMessageIncludes?: string;
    allowFailureMessageIncludes?: string;
}
export interface PlanExecuteEntry {
    operationId: string;
    input?: unknown;
    options?: unknown;
    captureAs?: string;
    expect?: PlanExecuteEntryExpect;
}
export interface PlanExecuteInput {
    entries: PlanExecuteEntry[];
    /** Capture keys to return to the client, or '*' for the full capture map. */
    captureReturns?: '*' | string[];
}
export type PlanEntryReceiptStatus = 'passed' | 'allowed-failure' | 'expected-failure';
export interface PlanEntryReceipt {
    entryIndex: number;
    operationId: string;
    status: PlanEntryReceiptStatus;
    captureAs: string | null;
    error?: string;
}
export interface PlanExecuteFailure {
    entryIndex: number;
    operationId: string;
    message: string;
}
export interface PlanExecuteResult {
    receipts: PlanEntryReceipt[];
    captures: Record<string, unknown>;
    failure?: PlanExecuteFailure;
}
export interface PlanApi<TExecuteResult = PlanExecuteResult> {
    /**
     * Execute a compiled run of operation entries with host-side capture
     * resolution. Capture state persists across `plan.execute` calls within the
     * same document session, so chunked plans share one capture space.
     */
    execute(input: PlanExecuteInput): TExecuteResult;
}
type DynamicInvoke = (operationId: string, input: unknown, options: unknown) => unknown;
type AsyncDynamicInvoke = (operationId: string, input: unknown, options: unknown) => PromiseLike<unknown>;
/**
 * Build the `plan` namespace bound to one document session's dynamic dispatch.
 * The capture map lives in this closure, so it persists across chunked
 * `plan.execute` calls for the lifetime of the owning DocumentApi instance.
 */
export declare function createPlanApi(invoke: AsyncDynamicInvoke): PlanApi<Promise<PlanExecuteResult>>;
export declare function createPlanApi(invoke: DynamicInvoke): PlanApi;
export {};
