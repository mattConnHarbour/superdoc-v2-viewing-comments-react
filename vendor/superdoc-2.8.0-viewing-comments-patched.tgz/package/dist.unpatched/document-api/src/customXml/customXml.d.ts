import { MutationOptions } from '../write/write.js';
import { CustomXmlPartsCreateInput, CustomXmlPartsCreateResult, CustomXmlPartsGetInput, CustomXmlPartsListInput, CustomXmlPartsListResult, CustomXmlPartsMutationResult, CustomXmlPartsPatchInput, CustomXmlPartsRemoveInput, CustomXmlPartInfo } from './customXml.types.js';
export interface CustomXmlPartsApi {
    list(query?: CustomXmlPartsListInput): CustomXmlPartsListResult;
    get(input: CustomXmlPartsGetInput): CustomXmlPartInfo | null;
    create(input: CustomXmlPartsCreateInput, options?: MutationOptions): CustomXmlPartsCreateResult;
    patch(input: CustomXmlPartsPatchInput, options?: MutationOptions): CustomXmlPartsMutationResult;
    remove(input: CustomXmlPartsRemoveInput, options?: MutationOptions): CustomXmlPartsMutationResult;
}
export type CustomXmlPartsAdapter = CustomXmlPartsApi;
export interface CustomXmlApi {
    parts: CustomXmlPartsApi;
}
export type CustomXmlAdapter = CustomXmlApi;
export declare function executeCustomXmlPartsList(adapter: CustomXmlPartsAdapter, query?: CustomXmlPartsListInput): CustomXmlPartsListResult;
export declare function executeCustomXmlPartsGet(adapter: CustomXmlPartsAdapter, input: CustomXmlPartsGetInput): CustomXmlPartInfo | null;
export declare function executeCustomXmlPartsCreate(adapter: CustomXmlPartsAdapter, input: CustomXmlPartsCreateInput, options?: MutationOptions): CustomXmlPartsCreateResult;
export declare function executeCustomXmlPartsPatch(adapter: CustomXmlPartsAdapter, input: CustomXmlPartsPatchInput, options?: MutationOptions): CustomXmlPartsMutationResult;
export declare function executeCustomXmlPartsRemove(adapter: CustomXmlPartsAdapter, input: CustomXmlPartsRemoveInput, options?: MutationOptions): CustomXmlPartsMutationResult;
