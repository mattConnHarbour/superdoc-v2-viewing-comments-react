import { ValueSchema, StylesChannel } from './registry.js';
/**
 * Validates a value against a ValueSchema AST node.
 *
 * @param path - Dot-delimited path for error messages (e.g. "patch.borders.top.size")
 * @param value - The value to validate
 * @param schema - The schema to validate against
 */
export declare function validateValue(path: string, value: unknown, schema: ValueSchema): void;
export type StylesApplyInputShape = {
    target: {
        scope: 'docDefaults';
        channel: StylesChannel;
    };
    patch: Record<string, unknown>;
};
export declare function validateStylesApplyInput(input: unknown): asserts input is StylesApplyInputShape;
export declare function validateStylesApplyOptions(options: unknown): void;
/** Discriminated union returned by `classifyPatchKey`. */
export type PatchKeyClassification = {
    status: 'valid';
} | {
    status: 'excluded';
    reason: string;
} | {
    status: 'cross_channel';
    ownerChannel: StylesChannel;
} | {
    status: 'unknown';
};
/**
 * Classifies a patch key relative to a given channel.
 *
 * Returns a discriminated union so callers can switch on `status` instead of
 * nesting conditionals across excluded-key maps, allowed-key sets, and
 * cross-channel lookups.
 */
export declare function classifyPatchKey(key: string, channel: StylesChannel): PatchKeyClassification;
