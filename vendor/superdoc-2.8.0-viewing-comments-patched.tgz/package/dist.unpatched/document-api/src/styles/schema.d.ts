import { ValueSchema, StylesChannel } from './registry.js';
type JsonSchema = Record<string, unknown>;
/** Converts a ValueSchema AST node to a JSON Schema object. */
export declare function toJsonSchema(schema: ValueSchema): JsonSchema;
/** Builds a JSON Schema for the patch object of a given channel. */
export declare function buildPatchSchema(channel: StylesChannel): JsonSchema;
/** Builds a JSON Schema for the before/after state map covering all registry keys. */
export declare function buildStateSchema(): JsonSchema;
export {};
