import { ST_UNDERLINE_VALUES } from '../inline-semantics/token-sets.js';
export declare const ST_VERTICAL_ALIGN_RUN: readonly ["superscript", "subscript", "baseline"];
export declare const ST_EM: readonly ["none", "dot", "comma", "circle", "sesame"];
export declare const ST_TEXT_ALIGNMENT: readonly ["top", "center", "baseline", "bottom", "auto"];
export declare const ST_TEXT_DIRECTION: readonly ["lrTb", "tbRl", "btLr", "lrTbV", "tbRlV", "tbLrV"];
export declare const ST_TEXTBOX_TIGHT_WRAP: readonly ["none", "allLines", "firstAndLastLine", "firstLineOnly", "lastLineOnly"];
export declare const ST_TEXT_TRANSFORM: readonly ["uppercase", "none"];
export declare const ST_JUSTIFICATION: readonly ["left", "center", "right", "justify", "distribute"];
export { ST_UNDERLINE_VALUES };
/** Recursive schema AST describing the shape of a property value. */
export type ValueSchema = {
    kind: 'boolean';
} | {
    kind: 'integer';
    min?: number;
    max?: number;
} | {
    kind: 'enum';
    values: readonly string[];
} | {
    kind: 'string';
} | {
    kind: 'object';
    children: Record<string, ValueSchema>;
} | {
    kind: 'array';
    item: ValueSchema;
};
export type StylesChannel = 'run' | 'paragraph';
export type MergeStrategy = 'replace' | 'shallowMerge' | 'edgeMerge';
export interface PropertyDefinition {
    key: string;
    channel: StylesChannel;
    schema: ValueSchema;
    mergeStrategy: MergeStrategy;
}
export declare const PROPERTY_REGISTRY: PropertyDefinition[];
/** Allowed patch keys per channel, derived from the registry. */
export declare const ALLOWED_KEYS_BY_CHANNEL: Record<StylesChannel, Set<string>>;
/** Lookup a property definition by key and channel. */
export declare function getPropertyDefinition(key: string, channel: StylesChannel): PropertyDefinition | undefined;
export declare const EXCLUDED_KEYS: Record<StylesChannel, Map<string, string>>;
export declare const XML_PATH_BY_CHANNEL: Record<StylesChannel, string>;
