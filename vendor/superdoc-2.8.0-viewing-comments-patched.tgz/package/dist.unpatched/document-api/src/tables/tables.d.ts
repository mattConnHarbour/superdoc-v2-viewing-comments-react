import { MutationOptions } from '../write/write.js';
import { TablesApplyStyleInput, TablesSetBordersInput, TablesSetCellPaddingInput, TablesSetLayoutInput, TablesSetTableOptionsInput } from '../types/table-operations.types.js';
type RowLocatorInput = {
    target?: unknown;
    nodeId?: unknown;
    rowIndex?: unknown;
};
/**
 * Validation options for the row locator.
 *
 * `allowAppendShorthand`: when true, a table-level locator (target/nodeId
 * pointing at a table) with NEITHER `rowIndex` NOR `position` is accepted —
 * the caller's adapter is expected to compute "below the last row". Used by
 * `tables.insertRow`. All other row ops require `rowIndex` when targeting a
 * table; pass this as `false` (the default) for them.
 */
interface RowLocatorOptions {
    allowAppendShorthand?: boolean;
}
type CellOrTableScopedCellLocatorInput = {
    target?: unknown;
    nodeId?: unknown;
    rowIndex?: unknown;
    columnIndex?: unknown;
};
/**
 * Returns `true` when the input carries non-`undefined` row + column coordinates,
 * meaning it can participate in table-scoped cell targeting.
 *
 * This is the validation-time check for coordinate presence. Adapter-level
 * resolution may still refine ambiguous `nodeId` handoffs by resolved node
 * type so payloads like `TableCellInfo` from `tables.getCells()` continue to
 * work as direct cell locators.
 */
export declare function hasTableScopedCellCoordinates(input: CellOrTableScopedCellLocatorInput): boolean;
/**
 * Normalizes legacy `atRowIndex` to canonical `rowIndex` for tables.split.
 *
 * Accepts either name, prefers `rowIndex` when both match, and rejects
 * conflicting dual-name input. Returns the input unchanged when only
 * `rowIndex` is present.
 */
export declare function normalizeTablesSplitInput<T extends {
    rowIndex?: number;
}>(input: T): T;
/**
 * Execute a table operation that uses the standard locator (target/nodeId).
 * Validates the locator and normalizes MutationOptions.
 */
export declare function executeTableLocatorOp<TInput extends {
    target?: unknown;
    nodeId?: unknown;
}, TResult>(operationName: string, adapter: (input: TInput, options?: MutationOptions) => TResult, input: TInput, options?: MutationOptions): TResult;
export declare function executeTablesSetLayoutOp<TResult>(adapter: (input: TablesSetLayoutInput, options?: MutationOptions) => TResult, input: TablesSetLayoutInput, options?: MutationOptions): TResult;
export declare function executeRowLocatorOp<TInput extends RowLocatorInput, TResult>(operationName: string, adapter: (input: TInput, options?: MutationOptions) => TResult, input: TInput, options?: MutationOptions, rowLocatorOptions?: RowLocatorOptions): TResult;
export declare function executeCellOrTableScopedCellLocatorOp<TInput extends CellOrTableScopedCellLocatorInput, TResult>(operationName: string, adapter: (input: TInput, options?: MutationOptions) => TResult, input: TInput, options?: MutationOptions): TResult;
/**
 * Execute a document-level table mutation (no locator validation needed).
 * Only normalizes MutationOptions.
 */
export declare function executeDocumentLevelTableOp<TInput, TResult>(adapter: (input: TInput, options?: MutationOptions) => TResult, input: TInput, options?: MutationOptions): TResult;
/**
 * Validate and execute `tables.applyStyle`.
 */
export declare function executeTablesApplyStyle<TResult>(operationName: string, adapter: (input: TablesApplyStyleInput, options?: MutationOptions) => TResult, input: TablesApplyStyleInput, options?: MutationOptions): TResult;
/**
 * Validate and execute `tables.setBorders`.
 */
export declare function executeTablesSetBorders<TResult>(operationName: string, adapter: (input: TablesSetBordersInput, options?: MutationOptions) => TResult, input: TablesSetBordersInput, options?: MutationOptions): TResult;
/**
 * Validate and execute `tables.setTableOptions`.
 */
export declare function executeTablesSetTableOptions<TResult>(operationName: string, adapter: (input: TablesSetTableOptionsInput, options?: MutationOptions) => TResult, input: TablesSetTableOptionsInput, options?: MutationOptions): TResult;
/**
 * Validate and execute `tables.setCellPadding`.
 *
 * Partial side updates are accepted and preserve omitted sides, but at least
 * one of `topPt`, `rightPt`, `bottomPt`, or `leftPt` must be present. An
 * all-omitted call is rejected so the direct typed API agrees with the schema's
 * any-of side requirement (and the adapter never authors an empty `w:tcMar`).
 */
export declare function executeTablesSetCellPadding<TResult>(operationName: string, adapter: (input: TablesSetCellPaddingInput, options?: MutationOptions) => TResult, input: TablesSetCellPaddingInput, options?: MutationOptions): TResult;
export {};
