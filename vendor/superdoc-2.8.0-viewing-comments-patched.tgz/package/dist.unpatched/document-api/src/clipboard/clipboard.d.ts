import { MutationOptions } from '../write/write.js';
import { ClipboardInsertInput, ClipboardInsertResult, ClipboardParseOptions, ClipboardParseResult, ClipboardPayload, ClipboardSerializeInput, ClipboardSerializeResult } from '../types/clipboard.js';
export interface ClipboardApi {
    parse(payload: ClipboardPayload, options?: ClipboardParseOptions): ClipboardParseResult;
    insert(input: ClipboardInsertInput, options?: MutationOptions): ClipboardInsertResult;
    serializeSelection(input?: ClipboardSerializeInput): ClipboardSerializeResult;
}
export type ClipboardAdapter = ClipboardApi;
export declare function executeClipboardParse(adapter: ClipboardAdapter, payload: ClipboardPayload, options?: ClipboardParseOptions): ClipboardParseResult;
export declare function executeClipboardInsert(adapter: ClipboardAdapter, input: ClipboardInsertInput, options?: MutationOptions): ClipboardInsertResult;
export declare function executeClipboardSerializeSelection(adapter: ClipboardAdapter, input?: ClipboardSerializeInput): ClipboardSerializeResult;
