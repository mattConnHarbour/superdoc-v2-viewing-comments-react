import { SelectionTarget, DeleteBehavior, TargetLocator } from '../types/address.js';
import { TextMutationReceipt } from '../types/receipt.js';
import { MutationOptions } from '../types/mutation-plan.types.js';
import { StoryLocator } from '../types/story.types.js';
import { SelectionMutationAdapter } from '../selection-mutation.js';
export type DeleteInput = TargetLocator & {
    /** Explicit selection target. Exactly one of `target` or `ref` is required. */
    target?: SelectionTarget;
    /** Mutation-ready ref from `query.match` or `find`. */
    ref?: string;
    /**
     * Delete behavior mode.
     * - `'selection'` (default): expand to block edges when boundary blocks are fully covered.
     * - `'exact'`: delete only the exact resolved range.
     */
    behavior?: DeleteBehavior;
    /** Target a specific document story (body, header, footer, footnote, endnote). */
    in?: StoryLocator;
};
export declare function executeDelete(adapter: SelectionMutationAdapter, input: DeleteInput, options?: MutationOptions): TextMutationReceipt;
