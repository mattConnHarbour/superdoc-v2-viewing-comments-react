import { InlineAnchor } from '../types/base.js';
import { TextTarget } from '../types/address.js';
import { AdapterMutationFailure } from '../types/adapter-result.js';
import { DiscoveryOutput } from '../types/discovery.js';
export interface CrossRefAddress {
    kind: 'inline';
    nodeType: 'crossRef';
    anchor: InlineAnchor;
}
export type CrossRefTarget = {
    kind: 'bookmark';
    name: string;
} | {
    kind: 'heading';
    nodeId: string;
} | {
    kind: 'note';
    noteId: string;
} | {
    kind: 'caption';
    nodeId: string;
} | {
    kind: 'numberedItem';
    nodeId: string;
} | {
    kind: 'styledParagraph';
    styleName: string;
    direction?: 'before' | 'after';
};
export type CrossRefDisplay = 'content' | 'pageNumber' | 'noteNumber' | 'labelAndNumber' | 'aboveBelow' | 'numberOnly' | 'numberFullContext' | 'styledContent' | 'styledPageNumber';
export interface CrossRefListInput {
    limit?: number;
    offset?: number;
}
export interface CrossRefGetInput {
    target: CrossRefAddress;
}
export interface CrossRefRemoveInput {
    target: CrossRefAddress;
}
export interface CrossRefRebuildInput {
    target: CrossRefAddress;
}
export interface CrossRefInsertInput {
    at: TextTarget;
    target: CrossRefTarget;
    display: CrossRefDisplay;
}
export interface CrossRefInfo {
    address: CrossRefAddress;
    target: CrossRefTarget;
    display: CrossRefDisplay;
    resolvedText: string;
    instruction: string;
}
export interface CrossRefDomain {
    address: CrossRefAddress;
    target: CrossRefTarget;
    display: CrossRefDisplay;
    resolvedText: string;
    instruction: string;
}
export interface CrossRefMutationSuccess {
    success: true;
    crossRef: CrossRefAddress;
}
export type CrossRefMutationResult = CrossRefMutationSuccess | AdapterMutationFailure;
export type CrossRefsListResult = DiscoveryOutput<CrossRefDomain>;
