import { MutationOptions } from '../write/write.js';
import { CrossRefGetInput, CrossRefInfo, CrossRefInsertInput, CrossRefRebuildInput, CrossRefRemoveInput, CrossRefMutationResult, CrossRefListInput, CrossRefsListResult } from './cross-refs.types.js';
export interface CrossRefsApi {
    list(query?: CrossRefListInput): CrossRefsListResult;
    get(input: CrossRefGetInput): CrossRefInfo;
    insert(input: CrossRefInsertInput, options?: MutationOptions): CrossRefMutationResult;
    rebuild(input: CrossRefRebuildInput, options?: MutationOptions): CrossRefMutationResult;
    remove(input: CrossRefRemoveInput, options?: MutationOptions): CrossRefMutationResult;
}
export type CrossRefsAdapter = CrossRefsApi;
export declare function executeCrossRefsList(adapter: CrossRefsAdapter, query?: CrossRefListInput): CrossRefsListResult;
export declare function executeCrossRefsGet(adapter: CrossRefsAdapter, input: CrossRefGetInput): CrossRefInfo;
export declare function executeCrossRefsInsert(adapter: CrossRefsAdapter, input: CrossRefInsertInput, options?: MutationOptions): CrossRefMutationResult;
export declare function executeCrossRefsRebuild(adapter: CrossRefsAdapter, input: CrossRefRebuildInput, options?: MutationOptions): CrossRefMutationResult;
export declare function executeCrossRefsRemove(adapter: CrossRefsAdapter, input: CrossRefRemoveInput, options?: MutationOptions): CrossRefMutationResult;
