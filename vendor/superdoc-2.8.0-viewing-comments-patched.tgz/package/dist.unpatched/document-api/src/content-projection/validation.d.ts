import { SDProjectionReadInput } from '../types/content-projection.js';
export declare function validateProjectionReadInput(input: unknown, operationName: string, allowedFields: ReadonlySet<string>): asserts input is SDProjectionReadInput;
export declare function validateOptionalBoolean(value: unknown, field: string, operationName: string): void;
