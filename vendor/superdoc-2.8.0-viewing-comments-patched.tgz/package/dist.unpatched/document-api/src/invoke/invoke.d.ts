import { OperationId } from '../contract/types.js';
import { OperationRegistry } from '../contract/operation-registry.js';
import { DocumentApi } from '../index.js';
type TypedDispatchHandler<K extends OperationId> = OperationRegistry[K]['options'] extends never ? (input: OperationRegistry[K]['input']) => OperationRegistry[K]['output'] : (input: OperationRegistry[K]['input'], options?: OperationRegistry[K]['options']) => OperationRegistry[K]['output'];
export type TypedDispatchTable = {
    [K in OperationId]: TypedDispatchHandler<K>;
};
/**
 * Builds a dispatch table that maps every OperationId to the corresponding
 * direct method call on the given DocumentApi instance.
 *
 * Each entry delegates to the direct method: no parallel execution path.
 * The return type is {@link TypedDispatchTable}, which validates at compile
 * time that each handler conforms to the {@link OperationRegistry} contract.
 */
export declare function buildDispatchTable(api: DocumentApi): TypedDispatchTable;
export {};
