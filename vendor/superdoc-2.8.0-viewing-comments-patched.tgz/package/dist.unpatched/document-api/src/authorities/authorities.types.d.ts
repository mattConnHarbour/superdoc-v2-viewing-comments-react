import { InlineAnchor } from '../types/base.js';
import { TextTarget } from '../types/address.js';
import { AdapterMutationFailure } from '../types/adapter-result.js';
import { DiscoveryOutput } from '../types/discovery.js';
import { TocCreateLocation } from '../toc/toc.types.js';
export interface AuthoritiesAddress {
    kind: 'block';
    nodeType: 'tableOfAuthorities';
    nodeId: string;
}
export interface AuthorityEntryAddress {
    kind: 'inline';
    nodeType: 'authorityEntry';
    anchor: InlineAnchor;
}
export type AuthorityCategory = 'cases' | 'statutes' | 'otherAuthorities' | 'rules' | 'treatises' | 'regulations' | 'constitutional' | number;
export interface AuthoritiesConfig {
    category?: number;
    entryPageSeparator?: string;
    usePassim?: boolean;
    includeHeadings?: boolean;
    tabLeader?: 'none' | 'dot' | 'hyphen' | 'underscore';
    pageRangeSeparator?: string;
}
export interface AuthoritiesListInput {
    limit?: number;
    offset?: number;
}
export interface AuthoritiesGetInput {
    target: AuthoritiesAddress;
}
export interface AuthoritiesRemoveInput {
    target: AuthoritiesAddress;
}
export interface AuthoritiesRebuildInput {
    target: AuthoritiesAddress;
}
export interface AuthoritiesInsertInput {
    at: TocCreateLocation;
    config?: AuthoritiesConfig;
}
export interface AuthoritiesConfigureInput {
    target: AuthoritiesAddress;
    patch: AuthoritiesConfig;
}
export interface AuthoritiesInfo {
    address: AuthoritiesAddress;
    instruction: string;
    config: AuthoritiesConfig;
    entryCount: number;
}
export interface AuthoritiesDomain {
    address: AuthoritiesAddress;
    instruction: string;
    config: AuthoritiesConfig;
    entryCount: number;
}
export interface AuthorityEntryData {
    longCitation: string;
    shortCitation?: string;
    category: AuthorityCategory;
    bold?: boolean;
    italic?: boolean;
}
export interface AuthorityEntryListInput {
    category?: AuthorityCategory;
    limit?: number;
    offset?: number;
}
export interface AuthorityEntryGetInput {
    target: AuthorityEntryAddress;
}
export interface AuthorityEntryRemoveInput {
    target: AuthorityEntryAddress;
}
export interface AuthorityEntryInsertInput {
    at: TextTarget;
    entry: AuthorityEntryData;
}
export interface AuthorityEntryUpdateInput {
    target: AuthorityEntryAddress;
    patch: Partial<AuthorityEntryData>;
}
export interface AuthorityEntryInfo {
    address: AuthorityEntryAddress;
    longCitation: string;
    shortCitation?: string;
    category: AuthorityCategory;
    bold: boolean;
    italic: boolean;
    instruction: string;
}
export interface AuthorityEntryDomain {
    address: AuthorityEntryAddress;
    longCitation: string;
    shortCitation?: string;
    category: AuthorityCategory;
    bold: boolean;
    italic: boolean;
    instruction: string;
}
export interface AuthoritiesMutationSuccess {
    success: true;
    authorities: AuthoritiesAddress;
}
export type AuthoritiesMutationResult = AuthoritiesMutationSuccess | AdapterMutationFailure;
export interface AuthorityEntryMutationSuccess {
    success: true;
    entry: AuthorityEntryAddress;
}
export type AuthorityEntryMutationResult = AuthorityEntryMutationSuccess | AdapterMutationFailure;
export type AuthoritiesListResult = DiscoveryOutput<AuthoritiesDomain>;
export type AuthorityEntryListResult = DiscoveryOutput<AuthorityEntryDomain>;
