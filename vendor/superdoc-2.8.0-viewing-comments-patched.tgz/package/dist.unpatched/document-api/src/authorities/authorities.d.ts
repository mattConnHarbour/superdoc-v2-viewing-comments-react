import { MutationOptions } from '../write/write.js';
import { AuthoritiesListInput, AuthoritiesGetInput, AuthoritiesInsertInput, AuthoritiesConfigureInput, AuthoritiesRebuildInput, AuthoritiesRemoveInput, AuthoritiesInfo, AuthoritiesMutationResult, AuthoritiesListResult, AuthorityEntryListInput, AuthorityEntryGetInput, AuthorityEntryInsertInput, AuthorityEntryUpdateInput, AuthorityEntryRemoveInput, AuthorityEntryInfo, AuthorityEntryMutationResult, AuthorityEntryListResult } from './authorities.types.js';
export interface AuthoritiesApi {
    list(query?: AuthoritiesListInput): AuthoritiesListResult;
    get(input: AuthoritiesGetInput): AuthoritiesInfo;
    insert(input: AuthoritiesInsertInput, options?: MutationOptions): AuthoritiesMutationResult;
    configure(input: AuthoritiesConfigureInput, options?: MutationOptions): AuthoritiesMutationResult;
    rebuild(input: AuthoritiesRebuildInput, options?: MutationOptions): AuthoritiesMutationResult;
    remove(input: AuthoritiesRemoveInput, options?: MutationOptions): AuthoritiesMutationResult;
    entries: {
        list(query?: AuthorityEntryListInput): AuthorityEntryListResult;
        get(input: AuthorityEntryGetInput): AuthorityEntryInfo;
        insert(input: AuthorityEntryInsertInput, options?: MutationOptions): AuthorityEntryMutationResult;
        update(input: AuthorityEntryUpdateInput, options?: MutationOptions): AuthorityEntryMutationResult;
        remove(input: AuthorityEntryRemoveInput, options?: MutationOptions): AuthorityEntryMutationResult;
    };
}
export type AuthoritiesAdapter = AuthoritiesApi;
export declare function executeAuthoritiesList(adapter: AuthoritiesAdapter, query?: AuthoritiesListInput): AuthoritiesListResult;
export declare function executeAuthoritiesGet(adapter: AuthoritiesAdapter, input: AuthoritiesGetInput): AuthoritiesInfo;
export declare function executeAuthoritiesInsert(adapter: AuthoritiesAdapter, input: AuthoritiesInsertInput, options?: MutationOptions): AuthoritiesMutationResult;
export declare function executeAuthoritiesConfigure(adapter: AuthoritiesAdapter, input: AuthoritiesConfigureInput, options?: MutationOptions): AuthoritiesMutationResult;
export declare function executeAuthoritiesRebuild(adapter: AuthoritiesAdapter, input: AuthoritiesRebuildInput, options?: MutationOptions): AuthoritiesMutationResult;
export declare function executeAuthoritiesRemove(adapter: AuthoritiesAdapter, input: AuthoritiesRemoveInput, options?: MutationOptions): AuthoritiesMutationResult;
export declare function executeAuthorityEntriesList(adapter: AuthoritiesAdapter, query?: AuthorityEntryListInput): AuthorityEntryListResult;
export declare function executeAuthorityEntriesGet(adapter: AuthoritiesAdapter, input: AuthorityEntryGetInput): AuthorityEntryInfo;
export declare function executeAuthorityEntriesInsert(adapter: AuthoritiesAdapter, input: AuthorityEntryInsertInput, options?: MutationOptions): AuthorityEntryMutationResult;
export declare function executeAuthorityEntriesUpdate(adapter: AuthoritiesAdapter, input: AuthorityEntryUpdateInput, options?: MutationOptions): AuthorityEntryMutationResult;
export declare function executeAuthorityEntriesRemove(adapter: AuthoritiesAdapter, input: AuthorityEntryRemoveInput, options?: MutationOptions): AuthorityEntryMutationResult;
