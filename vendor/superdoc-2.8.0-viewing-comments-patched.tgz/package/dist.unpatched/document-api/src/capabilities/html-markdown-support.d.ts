import { RichContentInsertInput } from '../insert/insert.js';
import { RichContentReplaceInput } from '../replace/replace.js';
import { ChangeMode } from '../write/write.js';
import { ProjectHtmlInput, ProjectMarkdownInput, SDContentProjectionResult, SDProjectionReviewMode, SDResolvedProjectionScope } from '../types/content-projection.js';
import { SDFragment } from '../types/fragment.js';
import { SDError, SDHtmlMarkdownOutcome, SDMutationConversionReport, SDMutationReceipt } from '../types/sd-contract.js';
import { StoryLocator } from '../types/story.types.js';
export interface SDHtmlMarkdownCheckGuard {
    version: 'sd-html-markdown-check/1';
    operation: 'insert' | 'replace';
    evaluatedRevision: string;
    requestSha256: string;
    analysisSha256: string;
}
export type SDHtmlMarkdownSupportCheckInput = {
    operation: 'insert';
    input: RichContentInsertInput;
    options?: {
        changeMode?: ChangeMode;
    };
} | {
    operation: 'replace';
    input: RichContentReplaceInput;
    options?: {
        changeMode?: ChangeMode;
    };
} | {
    operation: 'projectHtml';
    input?: ProjectHtmlInput;
} | {
    operation: 'projectMarkdown';
    input?: ProjectMarkdownInput;
};
interface SDHtmlMarkdownCheckCommon {
    operation: SDHtmlMarkdownSupportCheckInput['operation'];
    format: 'html' | 'markdown';
    supported: boolean;
    outcome: SDHtmlMarkdownOutcome;
    evaluatedRevision: string;
    failure?: SDError;
}
export interface SDHtmlMarkdownWriteCheckResult extends SDHtmlMarkdownCheckCommon {
    operation: 'insert' | 'replace';
    wouldChange: boolean;
    conversion: SDMutationConversionReport;
    plan?: {
        fragment: SDFragment;
        resolution: NonNullable<SDMutationReceipt['resolution']>;
        changeMode: ChangeMode;
        atomic: true;
    };
    guard?: SDHtmlMarkdownCheckGuard;
}
export interface SDHtmlMarkdownProjectionCheckResult extends SDHtmlMarkdownCheckCommon {
    operation: 'projectHtml' | 'projectMarkdown';
    plan?: {
        reviewMode: SDProjectionReviewMode;
        story: StoryLocator;
        scope: SDResolvedProjectionScope;
        includeSourceMap: boolean;
    };
    projection?: SDContentProjectionResult<'html' | 'markdown'>;
}
export type SDHtmlMarkdownSupportCheckResult = SDHtmlMarkdownWriteCheckResult | SDHtmlMarkdownProjectionCheckResult;
export declare function validateSDHtmlMarkdownSupportCheckInput(input: unknown): asserts input is SDHtmlMarkdownSupportCheckInput;
export {};
