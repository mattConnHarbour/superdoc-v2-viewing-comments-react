/**
 * OOXML token acceptance sets: strict, case-sensitive, per-property.
 *
 * These are the exhaustive sets of accepted values for inline property tokens.
 * Any value not in these sets is an invalid token and must produce a structured
 * diagnostic (import) or error (runtime).
 */
/**
 * Accepted `w:val` values for ST_OnOff properties (case-sensitive, per OOXML spec).
 * Absent `w:val` (bare element like `<w:b/>`) normalizes to ON: handled by parsers, not here.
 */
export declare const ST_ON_OFF_VALUES: readonly ["true", "false", "1", "0", "on", "off"];
export type StOnOffValue = (typeof ST_ON_OFF_VALUES)[number];
/** Runtime set for O(1) ST_OnOff validation. */
export declare const ST_ON_OFF_VALUE_SET: ReadonlySet<string>;
/** ST_OnOff values that normalize to ON. */
export declare const ST_ON_OFF_ON_VALUES: ReadonlySet<string>;
/** ST_OnOff values that normalize to OFF. */
export declare const ST_ON_OFF_OFF_VALUES: ReadonlySet<string>;
/**
 * Accepted `w:val` values for ST_Underline (exhaustive, case-sensitive).
 * `'none'` maps to OFF; all others map to ON with the specified underline type.
 */
export declare const ST_UNDERLINE_VALUES: readonly ["single", "double", "thick", "dotted", "dottedHeavy", "dash", "dashedHeavy", "dashLong", "dashLongHeavy", "dotDash", "dashDotHeavy", "dotDotDash", "dashDotDotHeavy", "wave", "wavyHeavy", "wavyDouble", "words", "none"];
export type StUnderlineValue = (typeof ST_UNDERLINE_VALUES)[number];
/** Runtime set for O(1) ST_Underline validation. */
export declare const ST_UNDERLINE_VALUE_SET: ReadonlySet<string>;
/**
 * Accepted values for ST_ThemeColor (exhaustive, case-sensitive, per ECMA-376 §17.18.97).
 */
export declare const ST_THEME_COLOR_VALUES: readonly ["dark1", "light1", "dark2", "light2", "accent1", "accent2", "accent3", "accent4", "accent5", "accent6", "hyperlink", "followedHyperlink", "background1", "text1", "background2", "text2", "none"];
export type StThemeColorValue = (typeof ST_THEME_COLOR_VALUES)[number];
/** Runtime set for O(1) ST_ThemeColor validation. */
export declare const ST_THEME_COLOR_VALUE_SET: ReadonlySet<string>;
