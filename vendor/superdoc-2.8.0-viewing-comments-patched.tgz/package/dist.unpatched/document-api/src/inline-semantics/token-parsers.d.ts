import { CoreTogglePropertyId } from './property-ids.js';
import { InvalidInlineTokenError } from './error-types.js';
import { DirectState } from './directives.js';
export type TokenParseOk<T> = {
    ok: true;
    value: T;
};
export type TokenParseError = {
    ok: false;
    error: InvalidInlineTokenError;
};
export type TokenParseResult<T> = TokenParseOk<T> | TokenParseError;
/**
 * Parsed result for an ST_OnOff property.
 * `direct` is the canonical tri-state directive; `canonical` is the
 * normalized OOXML value for export (`null` = ON bare element, `'0'` = OFF).
 */
export interface StOnOffParsed {
    direct: DirectState;
}
/**
 * Parses a `w:val` attribute value for an ST_OnOff property.
 *
 * @param property - The property being parsed (bold/italic/strike).
 * @param val - The `w:val` attribute value, or `null` for bare element (e.g., `<w:b/>`).
 * @param xpath - Attribute-level xpath for error reporting.
 */
export declare function parseStOnOff(property: CoreTogglePropertyId, val: string | null, xpath: string): TokenParseResult<StOnOffParsed>;
export interface StUnderlineParsed {
    direct: DirectState;
    /** Underline type for ON states; `'none'` for OFF; `undefined` for absent. */
    underlineType?: string;
}
/**
 * Parses a `w:val` attribute for ST_Underline.
 *
 * @param val - The `w:val` attribute value, or `null` for bare `<w:u/>`.
 * @param xpath - Attribute-level xpath for error reporting.
 */
export declare function parseStUnderline(val: string | null, xpath: string): TokenParseResult<StUnderlineParsed>;
/**
 * Parses and normalizes a `w:color` attribute on `<w:u>`.
 *
 * Accepts: 6-digit hex (with or without `#`), `auto`.
 * - Valid hex → lowercase 6-digit with `#` prefix.
 * - `auto` → `undefined` (theme-resolved, not stored as direct).
 * - Invalid → error.
 */
export declare function parseUnderlineColor(val: string | null, xpath: string): TokenParseResult<string | undefined>;
/**
 * Parses a `w:themeColor` attribute on `<w:u>`.
 * Must be an exact match from ST_ThemeColor (case-sensitive).
 */
export declare function parseUnderlineThemeColor(val: string | null, xpath: string): TokenParseResult<string | undefined>;
/**
 * Parses a `w:themeTint` or `w:themeShade` attribute on `<w:u>`.
 * Must be a 2-digit hex string (00–FF). Normalizes to uppercase.
 */
export declare function parseUnderlineThemeModifier(val: string | null, attribute: 'themeTint' | 'themeShade', xpath: string): TokenParseResult<string | undefined>;
