import { MutationOptions } from '../write/write.js';
import { HyperlinksListQuery, HyperlinksListResult, HyperlinksGetInput, HyperlinkInfo, HyperlinksWrapInput, HyperlinkMutationResult, HyperlinksInsertInput, HyperlinksPatchInput, HyperlinksRemoveInput } from './hyperlinks.types.js';
export interface HyperlinksApi {
    list(query?: HyperlinksListQuery): HyperlinksListResult;
    get(input: HyperlinksGetInput): HyperlinkInfo;
    wrap(input: HyperlinksWrapInput, options?: MutationOptions): HyperlinkMutationResult;
    insert(input: HyperlinksInsertInput, options?: MutationOptions): HyperlinkMutationResult;
    patch(input: HyperlinksPatchInput, options?: MutationOptions): HyperlinkMutationResult;
    remove(input: HyperlinksRemoveInput, options?: MutationOptions): HyperlinkMutationResult;
}
export type HyperlinksAdapter = HyperlinksApi;
export declare function executeHyperlinksList(adapter: HyperlinksAdapter, query?: HyperlinksListQuery): HyperlinksListResult;
export declare function executeHyperlinksGet(adapter: HyperlinksAdapter, input: HyperlinksGetInput): HyperlinkInfo;
export declare function executeHyperlinksWrap(adapter: HyperlinksAdapter, input: HyperlinksWrapInput, options?: MutationOptions): HyperlinkMutationResult;
export declare function executeHyperlinksInsert(adapter: HyperlinksAdapter, input: HyperlinksInsertInput, options?: MutationOptions): HyperlinkMutationResult;
export declare function executeHyperlinksPatch(adapter: HyperlinksAdapter, input: HyperlinksPatchInput, options?: MutationOptions): HyperlinkMutationResult;
export declare function executeHyperlinksRemove(adapter: HyperlinksAdapter, input: HyperlinksRemoveInput, options?: MutationOptions): HyperlinkMutationResult;
