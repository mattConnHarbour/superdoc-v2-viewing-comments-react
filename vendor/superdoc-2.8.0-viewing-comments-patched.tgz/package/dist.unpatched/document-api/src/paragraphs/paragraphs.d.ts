import { MutationOptions } from '../write/write.js';
import { ParagraphMutationResult, ParagraphsSetStyleInput, ParagraphsSetStyleRefInput, ParagraphsClearStyleInput, ParagraphsResetDirectFormattingInput, ParagraphsSetAlignmentInput, ParagraphsClearAlignmentInput, ParagraphsSetIndentationInput, ParagraphsClearIndentationInput, ParagraphsSetSpacingInput, ParagraphsClearSpacingInput, ParagraphsSetKeepOptionsInput, ParagraphsSetOutlineLevelInput, ParagraphsSetFlowOptionsInput, ParagraphsSetTabStopInput, ParagraphsClearTabStopInput, ParagraphsClearAllTabStopsInput, ParagraphsSetBorderInput, ParagraphsClearBorderInput, ParagraphsSetShadingInput, ParagraphsClearShadingInput, ParagraphsSetMarkRunPropsInput, ParagraphsSetDirectionInput, ParagraphsClearDirectionInput, ParagraphsSetNumberingInput } from './paragraphs.types.js';
export type { ParagraphTarget, ParagraphBlockType, ParagraphMutationResult, ParagraphMutationSuccess, ParagraphMutationFailure, MutationResolution, ParagraphAlignment, TabStopAlignment, TabStopLeader, BorderSide, ClearBorderSide, LineRule, ParagraphsSetStyleInput, ParagraphSemanticStyleRole, ParagraphsSetStyleRefInput, ParagraphsClearStyleInput, ParagraphsResetDirectFormattingInput, ParagraphsSetAlignmentInput, ParagraphsClearAlignmentInput, ParagraphsSetIndentationInput, ParagraphsClearIndentationInput, ParagraphsSetSpacingInput, ParagraphsClearSpacingInput, ParagraphsSetKeepOptionsInput, ParagraphsSetOutlineLevelInput, ParagraphsSetFlowOptionsInput, ParagraphsSetTabStopInput, ParagraphsClearTabStopInput, ParagraphsClearAllTabStopsInput, ParagraphsSetBorderInput, ParagraphsClearBorderInput, ParagraphsSetShadingInput, ParagraphsClearShadingInput, ParagraphsSetMarkRunPropsInput, ParagraphsSetDirectionInput, ParagraphsClearDirectionInput, ParagraphsSetNumberingInput, ParagraphDirection, AlignmentPolicy, } from './paragraphs.types.js';
export { PARAGRAPH_ALIGNMENTS, TAB_STOP_ALIGNMENTS, TAB_STOP_LEADERS, BORDER_SIDES, CLEAR_BORDER_SIDES, LINE_RULES, PARAGRAPH_DIRECTIONS, ALIGNMENT_POLICIES, } from './paragraphs.types.js';
export interface ParagraphsAdapter {
    setStyle(input: ParagraphsSetStyleInput, options?: MutationOptions): ParagraphMutationResult;
    setStyleRef(input: ParagraphsSetStyleRefInput, options?: MutationOptions): ParagraphMutationResult;
    clearStyle(input: ParagraphsClearStyleInput, options?: MutationOptions): ParagraphMutationResult;
    resetDirectFormatting(input: ParagraphsResetDirectFormattingInput, options?: MutationOptions): ParagraphMutationResult;
    setAlignment(input: ParagraphsSetAlignmentInput, options?: MutationOptions): ParagraphMutationResult;
    clearAlignment(input: ParagraphsClearAlignmentInput, options?: MutationOptions): ParagraphMutationResult;
    setIndentation(input: ParagraphsSetIndentationInput, options?: MutationOptions): ParagraphMutationResult;
    clearIndentation(input: ParagraphsClearIndentationInput, options?: MutationOptions): ParagraphMutationResult;
    setSpacing(input: ParagraphsSetSpacingInput, options?: MutationOptions): ParagraphMutationResult;
    clearSpacing(input: ParagraphsClearSpacingInput, options?: MutationOptions): ParagraphMutationResult;
    setKeepOptions(input: ParagraphsSetKeepOptionsInput, options?: MutationOptions): ParagraphMutationResult;
    setOutlineLevel(input: ParagraphsSetOutlineLevelInput, options?: MutationOptions): ParagraphMutationResult;
    setFlowOptions(input: ParagraphsSetFlowOptionsInput, options?: MutationOptions): ParagraphMutationResult;
    setTabStop(input: ParagraphsSetTabStopInput, options?: MutationOptions): ParagraphMutationResult;
    clearTabStop(input: ParagraphsClearTabStopInput, options?: MutationOptions): ParagraphMutationResult;
    clearAllTabStops(input: ParagraphsClearAllTabStopsInput, options?: MutationOptions): ParagraphMutationResult;
    setBorder(input: ParagraphsSetBorderInput, options?: MutationOptions): ParagraphMutationResult;
    clearBorder(input: ParagraphsClearBorderInput, options?: MutationOptions): ParagraphMutationResult;
    setShading(input: ParagraphsSetShadingInput, options?: MutationOptions): ParagraphMutationResult;
    clearShading(input: ParagraphsClearShadingInput, options?: MutationOptions): ParagraphMutationResult;
    setMarkRunProps?(input: ParagraphsSetMarkRunPropsInput, options?: MutationOptions): ParagraphMutationResult;
    setDirection(input: ParagraphsSetDirectionInput, options?: MutationOptions): ParagraphMutationResult;
    clearDirection(input: ParagraphsClearDirectionInput, options?: MutationOptions): ParagraphMutationResult;
    setNumbering(input: ParagraphsSetNumberingInput, options?: MutationOptions): ParagraphMutationResult;
}
/** Public API surface for `format.paragraph.*`: direct paragraph formatting. */
export interface ParagraphFormatApi {
    resetDirectFormatting(input: ParagraphsResetDirectFormattingInput, options?: MutationOptions): ParagraphMutationResult;
    setAlignment(input: ParagraphsSetAlignmentInput, options?: MutationOptions): ParagraphMutationResult;
    clearAlignment(input: ParagraphsClearAlignmentInput, options?: MutationOptions): ParagraphMutationResult;
    setIndentation(input: ParagraphsSetIndentationInput, options?: MutationOptions): ParagraphMutationResult;
    clearIndentation(input: ParagraphsClearIndentationInput, options?: MutationOptions): ParagraphMutationResult;
    setSpacing(input: ParagraphsSetSpacingInput, options?: MutationOptions): ParagraphMutationResult;
    clearSpacing(input: ParagraphsClearSpacingInput, options?: MutationOptions): ParagraphMutationResult;
    setKeepOptions(input: ParagraphsSetKeepOptionsInput, options?: MutationOptions): ParagraphMutationResult;
    setOutlineLevel(input: ParagraphsSetOutlineLevelInput, options?: MutationOptions): ParagraphMutationResult;
    setFlowOptions(input: ParagraphsSetFlowOptionsInput, options?: MutationOptions): ParagraphMutationResult;
    setTabStop(input: ParagraphsSetTabStopInput, options?: MutationOptions): ParagraphMutationResult;
    clearTabStop(input: ParagraphsClearTabStopInput, options?: MutationOptions): ParagraphMutationResult;
    clearAllTabStops(input: ParagraphsClearAllTabStopsInput, options?: MutationOptions): ParagraphMutationResult;
    setBorder(input: ParagraphsSetBorderInput, options?: MutationOptions): ParagraphMutationResult;
    clearBorder(input: ParagraphsClearBorderInput, options?: MutationOptions): ParagraphMutationResult;
    setShading(input: ParagraphsSetShadingInput, options?: MutationOptions): ParagraphMutationResult;
    clearShading(input: ParagraphsClearShadingInput, options?: MutationOptions): ParagraphMutationResult;
    setMarkRunProps(input: ParagraphsSetMarkRunPropsInput, options?: MutationOptions): ParagraphMutationResult;
    setDirection(input: ParagraphsSetDirectionInput, options?: MutationOptions): ParagraphMutationResult;
    clearDirection(input: ParagraphsClearDirectionInput, options?: MutationOptions): ParagraphMutationResult;
    setNumbering(input: ParagraphsSetNumberingInput, options?: MutationOptions): ParagraphMutationResult;
}
/** Public API surface for `styles.paragraph.*`: Word-like paragraph style application operations. */
export interface ParagraphStylesApi {
    setStyle(input: ParagraphsSetStyleInput, options?: MutationOptions): ParagraphMutationResult;
    setStyleRef(input: ParagraphsSetStyleRefInput, options?: MutationOptions): ParagraphMutationResult;
    clearStyle(input: ParagraphsClearStyleInput, options?: MutationOptions): ParagraphMutationResult;
}
export declare function executeParagraphsSetStyle(adapter: ParagraphsAdapter, input: ParagraphsSetStyleInput, options?: MutationOptions): ParagraphMutationResult;
export declare function executeParagraphsSetStyleRef(adapter: ParagraphsAdapter, input: ParagraphsSetStyleRefInput, options?: MutationOptions): ParagraphMutationResult;
export declare function executeParagraphsClearStyle(adapter: ParagraphsAdapter, input: ParagraphsClearStyleInput, options?: MutationOptions): ParagraphMutationResult;
export declare function executeParagraphsResetDirectFormatting(adapter: ParagraphsAdapter, input: ParagraphsResetDirectFormattingInput, options?: MutationOptions): ParagraphMutationResult;
export declare function executeParagraphsSetAlignment(adapter: ParagraphsAdapter, input: ParagraphsSetAlignmentInput, options?: MutationOptions): ParagraphMutationResult;
export declare function executeParagraphsClearAlignment(adapter: ParagraphsAdapter, input: ParagraphsClearAlignmentInput, options?: MutationOptions): ParagraphMutationResult;
export declare function executeParagraphsSetIndentation(adapter: ParagraphsAdapter, input: ParagraphsSetIndentationInput, options?: MutationOptions): ParagraphMutationResult;
export declare function executeParagraphsClearIndentation(adapter: ParagraphsAdapter, input: ParagraphsClearIndentationInput, options?: MutationOptions): ParagraphMutationResult;
export declare function executeParagraphsSetSpacing(adapter: ParagraphsAdapter, input: ParagraphsSetSpacingInput, options?: MutationOptions): ParagraphMutationResult;
export declare function executeParagraphsClearSpacing(adapter: ParagraphsAdapter, input: ParagraphsClearSpacingInput, options?: MutationOptions): ParagraphMutationResult;
export declare function executeParagraphsSetKeepOptions(adapter: ParagraphsAdapter, input: ParagraphsSetKeepOptionsInput, options?: MutationOptions): ParagraphMutationResult;
export declare function executeParagraphsSetOutlineLevel(adapter: ParagraphsAdapter, input: ParagraphsSetOutlineLevelInput, options?: MutationOptions): ParagraphMutationResult;
export declare function executeParagraphsSetFlowOptions(adapter: ParagraphsAdapter, input: ParagraphsSetFlowOptionsInput, options?: MutationOptions): ParagraphMutationResult;
export declare function executeParagraphsSetTabStop(adapter: ParagraphsAdapter, input: ParagraphsSetTabStopInput, options?: MutationOptions): ParagraphMutationResult;
export declare function executeParagraphsClearTabStop(adapter: ParagraphsAdapter, input: ParagraphsClearTabStopInput, options?: MutationOptions): ParagraphMutationResult;
export declare function executeParagraphsClearAllTabStops(adapter: ParagraphsAdapter, input: ParagraphsClearAllTabStopsInput, options?: MutationOptions): ParagraphMutationResult;
export declare function executeParagraphsSetBorder(adapter: ParagraphsAdapter, input: ParagraphsSetBorderInput, options?: MutationOptions): ParagraphMutationResult;
export declare function executeParagraphsClearBorder(adapter: ParagraphsAdapter, input: ParagraphsClearBorderInput, options?: MutationOptions): ParagraphMutationResult;
export declare function executeParagraphsSetShading(adapter: ParagraphsAdapter, input: ParagraphsSetShadingInput, options?: MutationOptions): ParagraphMutationResult;
export declare function executeParagraphsClearShading(adapter: ParagraphsAdapter, input: ParagraphsClearShadingInput, options?: MutationOptions): ParagraphMutationResult;
export declare function executeParagraphsSetMarkRunProps(adapter: ParagraphsAdapter, input: ParagraphsSetMarkRunPropsInput, options?: MutationOptions): ParagraphMutationResult;
export declare function executeParagraphsSetDirection(adapter: ParagraphsAdapter, input: ParagraphsSetDirectionInput, options?: MutationOptions): ParagraphMutationResult;
export declare function executeParagraphsClearDirection(adapter: ParagraphsAdapter, input: ParagraphsClearDirectionInput, options?: MutationOptions): ParagraphMutationResult;
export declare function executeParagraphsSetNumbering(adapter: ParagraphsAdapter, input: ParagraphsSetNumberingInput, options?: MutationOptions): ParagraphMutationResult;
