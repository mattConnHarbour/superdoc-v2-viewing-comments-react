import { MutationOptions } from '../write/write.js';
import { DocumentProtectionState, ProtectionGetInput, SetEditingRestrictionInput, ClearEditingRestrictionInput, ProtectionMutationResult } from './protection.types.js';
export interface ProtectionApi {
    get(input?: ProtectionGetInput): DocumentProtectionState;
    setEditingRestriction(input: SetEditingRestrictionInput, options?: MutationOptions): ProtectionMutationResult;
    clearEditingRestriction(input?: ClearEditingRestrictionInput, options?: MutationOptions): ProtectionMutationResult;
}
export type ProtectionAdapter = ProtectionApi;
export declare function executeProtectionGet(adapter: ProtectionAdapter, _input?: ProtectionGetInput): DocumentProtectionState;
export declare function executeSetEditingRestriction(adapter: ProtectionAdapter, input: SetEditingRestrictionInput, options?: MutationOptions): ProtectionMutationResult;
export declare function executeClearEditingRestriction(adapter: ProtectionAdapter, _input?: ClearEditingRestrictionInput, options?: MutationOptions): ProtectionMutationResult;
