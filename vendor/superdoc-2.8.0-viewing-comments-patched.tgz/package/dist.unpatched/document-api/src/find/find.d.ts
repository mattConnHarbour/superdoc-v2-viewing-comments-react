import { BlockNodeAddress, Query, Selector } from '../types/index.js';
import { SDFindInput, SDFindResult } from '../types/sd-envelope.js';
import { StoryLocator } from '../types/story.types.js';
/**
 * Options for the `find` method when using a selector shorthand.
 */
export interface FindOptions {
    /** Maximum number of results to return. */
    limit?: number;
    /** Number of results to skip before returning matches. */
    offset?: number;
    /** Constrain the search to descendants of the specified block node. */
    within?: BlockNodeAddress;
    /** Cardinality requirement for the result set. */
    require?: Query['require'];
    /** Whether to hydrate `result.nodes` for matched addresses. */
    includeNodes?: Query['includeNodes'];
    /** Whether to include unknown/unsupported nodes in diagnostics. */
    includeUnknown?: Query['includeUnknown'];
    /** Target a specific document story (body, header, footer, footnote, endnote). */
    in?: StoryLocator;
}
/**
 * Engine-specific adapter that the find API delegates to.
 *
 * Adapters return a standardized `SDFindResult` envelope.
 */
export interface FindAdapter {
    /**
     * Execute a find operation against the document.
     *
     * @param input - The SDFindInput to execute.
     * @returns The find result as an SDFindResult envelope.
     */
    find(input: SDFindInput): SDFindResult;
}
/**
 * Normalizes a selector-or-query argument into a canonical {@link Query} object.
 *
 * @param selectorOrQuery - A selector shorthand or a full query object.
 * @param options - Options applied when `selectorOrQuery` is a selector.
 * @returns A normalized query.
 */
export declare function normalizeFindQuery(selectorOrQuery: Selector | Query, options?: FindOptions): Query;
/**
 * Executes an SDM/1 find operation via the adapter.
 *
 * @param adapter - The engine-specific find adapter.
 * @param input - The SDFindInput to execute.
 * @returns An SDFindResult envelope.
 */
export declare function executeFind(adapter: FindAdapter, input: SDFindInput): SDFindResult;
