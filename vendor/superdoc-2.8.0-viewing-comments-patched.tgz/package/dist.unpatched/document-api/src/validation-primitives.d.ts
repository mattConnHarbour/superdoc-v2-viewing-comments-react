import { BlockNodeAddress, TextAddress, TextTarget } from './types/index.js';
/**
 * Throws INVALID_TARGET if target is null or undefined.
 * Shared preamble for optional adapter namespace validators.
 */
export declare function assertTargetPresent(target: unknown, operationName: string): void;
export declare function isRecord(value: unknown): value is Record<string, unknown>;
export declare function isInteger(value: unknown): value is number;
export declare function isTextAddress(value: unknown): value is TextAddress;
/**
 * Type guard for TextTarget: multi-segment text target used by read
 * operations and (since round 2 of the drop-in assessment) by
 * `comments.create` for selections that span multiple blocks.
 */
export declare function isTextTarget(value: unknown): value is TextTarget;
/** Type guard for BlockNodeAddress. Checks shape and nodeType membership. */
export declare function isBlockNodeAddress(value: unknown): value is BlockNodeAddress;
/**
 * Throws INVALID_INPUT if any key on the input object is not in the allowlist.
 * Unknown fields are a payload shape issue, not a locator problem.
 */
export declare function assertNoUnknownFields(input: Record<string, unknown>, allowlist: ReadonlySet<string>, operationName: string): void;
/**
 * Validates a nestingPolicy value: must be an object with only known keys,
 * and the `tables` field (if present) must be a valid TableNestingPolicy value.
 *
 * Used by both insert and replace structural validators.
 */
export declare function validateNestingPolicyValue(value: unknown): void;
