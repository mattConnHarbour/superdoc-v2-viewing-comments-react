import { MutationOptions } from '../write/write.js';
import { AnchoredMetadataAttachInput, AnchoredMetadataAttachResult, AnchoredMetadataGetInput, AnchoredMetadataInfo, AnchoredMetadataListInput, AnchoredMetadataListResult, AnchoredMetadataMutationResult, AnchoredMetadataRemoveInput, AnchoredMetadataResolveInfo, AnchoredMetadataResolveInput, AnchoredMetadataUpdateInput } from './anchored-metadata.types.js';
/**
 * Anchored-metadata operations. Composition over `customXml.parts.*` and
 * `contentControls.*`.
 *
 * An entry pairs a hidden inline SDT (the anchor) with a JSON payload in a
 * namespaced Custom XML Data Storage Part. The SDT's `w:tag` carries the
 * stable id linking the two.
 *
 * v1 storage model: one Storage Part per namespace, entries collected
 * inside a `<refs xmlns="namespace">` envelope, payload serialized as
 * escaped JSON inside `<ref id="..." encoding="json">…</ref>`.
 *
 * Consumers who need a different anchor (block-level, image, table cell)
 * or a different storage shape can fall back to `customXml.parts.*` and
 * `contentControls.*` directly.
 */
export interface AnchoredMetadataApi {
    attach(input: AnchoredMetadataAttachInput, options?: MutationOptions): AnchoredMetadataAttachResult;
    list(query?: AnchoredMetadataListInput): AnchoredMetadataListResult;
    get(input: AnchoredMetadataGetInput): AnchoredMetadataInfo | null;
    update(input: AnchoredMetadataUpdateInput, options?: MutationOptions): AnchoredMetadataMutationResult;
    remove(input: AnchoredMetadataRemoveInput, options?: MutationOptions): AnchoredMetadataMutationResult;
    resolve(input: AnchoredMetadataResolveInput): AnchoredMetadataResolveInfo | null;
}
export type AnchoredMetadataAdapter = AnchoredMetadataApi;
export declare function executeAnchoredMetadataAttach(adapter: AnchoredMetadataAdapter, input: AnchoredMetadataAttachInput, options?: MutationOptions): AnchoredMetadataAttachResult;
export declare function executeAnchoredMetadataList(adapter: AnchoredMetadataAdapter, query?: AnchoredMetadataListInput): AnchoredMetadataListResult;
export declare function executeAnchoredMetadataGet(adapter: AnchoredMetadataAdapter, input: AnchoredMetadataGetInput): AnchoredMetadataInfo | null;
export declare function executeAnchoredMetadataUpdate(adapter: AnchoredMetadataAdapter, input: AnchoredMetadataUpdateInput, options?: MutationOptions): AnchoredMetadataMutationResult;
export declare function executeAnchoredMetadataRemove(adapter: AnchoredMetadataAdapter, input: AnchoredMetadataRemoveInput, options?: MutationOptions): AnchoredMetadataMutationResult;
export declare function executeAnchoredMetadataResolve(adapter: AnchoredMetadataAdapter, input: AnchoredMetadataResolveInput): AnchoredMetadataResolveInfo | null;
