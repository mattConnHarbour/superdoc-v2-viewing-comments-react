import { ProjectHtmlInput, SDContentProjectionResult } from '../types/content-projection.js';
export interface ProjectHtmlAdapter {
    projectHtml(input: ProjectHtmlInput): Promise<SDContentProjectionResult<'html'>>;
}
export declare function executeProjectHtml(adapter: ProjectHtmlAdapter | undefined, input: ProjectHtmlInput): Promise<SDContentProjectionResult<'html'>>;
