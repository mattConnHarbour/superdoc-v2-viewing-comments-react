export type InlinePropertyStorage = 'mark' | 'runAttribute';
export type InlinePropertyType = 'boolean' | 'string' | 'number' | 'object' | 'array';
export interface UnderlinePatch {
    style?: string | null;
    color?: string | null;
    themeColor?: string | null;
}
export interface ShadingPatch {
    fill?: string | null;
    color?: string | null;
    val?: string | null;
}
export interface BorderPatch {
    val?: string | null;
    sz?: number | null;
    color?: string | null;
    space?: number | null;
}
export interface FitTextPatch {
    val?: number | null;
    id?: string | null;
}
export interface LangPatch {
    val?: string | null;
    eastAsia?: string | null;
    bidi?: string | null;
}
export interface RFontsPatch {
    ascii?: string | null;
    hAnsi?: string | null;
    eastAsia?: string | null;
    cs?: string | null;
    asciiTheme?: string | null;
    hAnsiTheme?: string | null;
    eastAsiaTheme?: string | null;
    csTheme?: string | null;
    hint?: string | null;
}
export interface EastAsianLayoutPatch {
    id?: string | null;
    combine?: boolean | null;
    combineBrackets?: string | null;
    vert?: boolean | null;
    vertCompress?: boolean | null;
}
export interface StylisticSetPatch {
    id: number;
    val?: boolean;
}
export interface InlineRunPatch {
    bold?: boolean | null;
    italic?: boolean | null;
    strike?: boolean | null;
    dstrike?: boolean | null;
    smallCaps?: boolean | null;
    caps?: boolean | null;
    underline?: true | false | UnderlinePatch | null;
    highlight?: string | null;
    shading?: ShadingPatch | null;
    color?: string | null;
    border?: BorderPatch | null;
    outline?: boolean | null;
    shadow?: boolean | null;
    emboss?: boolean | null;
    imprint?: boolean | null;
    vertAlign?: 'superscript' | 'subscript' | 'baseline' | null;
    position?: number | null;
    rtl?: boolean | null;
    cs?: boolean | null;
    bCs?: boolean | null;
    iCs?: boolean | null;
    vanish?: boolean | null;
    webHidden?: boolean | null;
    specVanish?: boolean | null;
    snapToGrid?: boolean | null;
    oMath?: boolean | null;
    fontSize?: number | null;
    fontFamily?: string | null;
    fontSizeCs?: number | null;
    letterSpacing?: number | null;
    charScale?: number | null;
    kerning?: number | null;
    fitText?: FitTextPatch | null;
    lang?: LangPatch | null;
    rStyle?: string | null;
    rFonts?: RFontsPatch | null;
    eastAsianLayout?: EastAsianLayoutPatch | null;
    em?: string | null;
    ligatures?: string | null;
    numForm?: string | null;
    numSpacing?: string | null;
    stylisticSets?: StylisticSetPatch[] | null;
    contextualAlternates?: boolean | null;
}
export type InlineRunPatchKey = keyof InlineRunPatch;
interface InlinePropertyCarrierMark {
    storage: 'mark';
    markName: 'bold' | 'italic' | 'underline' | 'strike' | 'highlight' | 'textStyle';
    textStyleAttr?: string;
}
interface InlinePropertyCarrierRunAttribute {
    storage: 'runAttribute';
    nodeName: 'run';
    runPropertyKey: string;
}
export type InlinePropertyCarrier = InlinePropertyCarrierMark | InlinePropertyCarrierRunAttribute;
export interface InlinePropertyRegistryEntry {
    key: InlineRunPatchKey;
    type: InlinePropertyType;
    ooxmlElement: string;
    storage: InlinePropertyStorage;
    tracked: boolean;
    carrier: InlinePropertyCarrier;
    schema: Record<string, unknown>;
}
export declare const INLINE_PROPERTY_REGISTRY: readonly [InlinePropertyRegistryEntry, InlinePropertyRegistryEntry, InlinePropertyRegistryEntry, {
    readonly key: "underline";
    readonly type: "object";
    readonly ooxmlElement: "w:u";
    readonly storage: "mark";
    readonly tracked: true;
    readonly carrier: InlinePropertyCarrierMark;
    readonly schema: Record<string, unknown>;
}, {
    readonly key: "highlight";
    readonly type: "string";
    readonly ooxmlElement: "w:highlight";
    readonly storage: "mark";
    readonly tracked: true;
    readonly carrier: InlinePropertyCarrierMark;
    readonly schema: Record<string, unknown>;
}, InlinePropertyRegistryEntry, InlinePropertyRegistryEntry, InlinePropertyRegistryEntry, InlinePropertyRegistryEntry, InlinePropertyRegistryEntry, InlinePropertyRegistryEntry, InlinePropertyRegistryEntry, InlinePropertyRegistryEntry, InlinePropertyRegistryEntry, InlinePropertyRegistryEntry, InlinePropertyRegistryEntry, InlinePropertyRegistryEntry, InlinePropertyRegistryEntry, InlinePropertyRegistryEntry, InlinePropertyRegistryEntry, InlinePropertyRegistryEntry, InlinePropertyRegistryEntry, InlinePropertyRegistryEntry, InlinePropertyRegistryEntry, InlinePropertyRegistryEntry, InlinePropertyRegistryEntry, InlinePropertyRegistryEntry, InlinePropertyRegistryEntry, InlinePropertyRegistryEntry, InlinePropertyRegistryEntry, InlinePropertyRegistryEntry, InlinePropertyRegistryEntry, InlinePropertyRegistryEntry, InlinePropertyRegistryEntry, InlinePropertyRegistryEntry, InlinePropertyRegistryEntry, InlinePropertyRegistryEntry, InlinePropertyRegistryEntry, InlinePropertyRegistryEntry, InlinePropertyRegistryEntry, InlinePropertyRegistryEntry, InlinePropertyRegistryEntry, InlinePropertyRegistryEntry];
export declare const INLINE_PROPERTY_KEY_SET: ReadonlySet<string>;
export declare const INLINE_PROPERTY_BY_KEY: Readonly<Record<InlineRunPatchKey, InlinePropertyRegistryEntry>>;
export declare const INLINE_PROPERTY_KEYS_BY_STORAGE: Readonly<Record<InlinePropertyStorage, readonly InlineRunPatchKey[]>>;
export declare function validateInlineRunPatch(patch: unknown): asserts patch is InlineRunPatch;
export declare function buildInlineRunPatchSchema(): Record<string, unknown>;
export {};
