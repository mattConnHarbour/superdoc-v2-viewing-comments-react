import { MutationOptions } from '../types/mutation-plan.types.js';
import { SelectionTarget, TargetLocator } from '../types/address.js';
import { TextMutationReceipt } from '../types/receipt.js';
import { StoryLocator } from '../types/story.types.js';
import { SelectionMutationAdapter } from '../selection-mutation.js';
import { InlineRunPatch, InlineRunPatchKey } from './inline-run-patch.js';
/** Input payload for `format.bold`. */
export type FormatBoldInput = FormatInlineAliasInput<'bold'>;
/** Input payload for `format.italic`. */
export type FormatItalicInput = FormatInlineAliasInput<'italic'>;
/** Input payload for `format.underline`. */
export type FormatUnderlineInput = FormatInlineAliasInput<'underline'>;
/** Input payload for `format.strikethrough`. */
export type FormatStrikethroughInput = FormatInlineAliasInput<'strike'>;
/**
 * Keys where `value` may be omitted: booleans (defaults to `true`) and
 * `underline` (defaults to `true` for simple on/off).
 */
type ImplicitTrueKey = {
    [K in InlineRunPatchKey]: InlineRunPatch[K] extends boolean | null | undefined ? K : never;
}[InlineRunPatchKey] | 'underline';
/**
 * Input payload for direct per-property aliases (`format.<inlineKey>`).
 *
 * `value` is optional only for boolean-like keys (including `underline`), where
 * omission defaults to `true` for ergonomic "turn on" calls.
 */
export type FormatInlineAliasInput<K extends InlineRunPatchKey> = K extends ImplicitTrueKey ? TargetLocator & {
    target?: SelectionTarget;
    ref?: string;
    in?: StoryLocator;
    value?: InlineRunPatch[K];
} : TargetLocator & {
    target?: SelectionTarget;
    ref?: string;
    in?: StoryLocator;
    value: InlineRunPatch[K];
};
/**
 * Input payload for `format.apply`.
 *
 * Accepts either `target` (SelectionTarget) or `ref` (string): exactly one required.
 */
export type StyleApplyInput = TargetLocator & {
    target?: SelectionTarget;
    ref?: string;
    inline: InlineRunPatch;
    /** Target a specific document story (body, header, footer, footnote, endnote). */
    in?: StoryLocator;
};
/**
 * Legacy root-level alias input for `doc.formatRange(...)`.
 *
 * Kept for SDK compatibility while routing through the canonical
 * `format.apply` implementation.
 */
export type FormatRangeInput = TargetLocator & {
    target?: SelectionTarget;
    ref?: string;
    properties: InlineRunPatch;
    /** Target a specific document story (body, header, footer, footnote, endnote). */
    in?: StoryLocator;
    changeMode?: MutationOptions['changeMode'];
    dryRun?: boolean;
    expectedRevision?: string;
};
/**
 * Named alias for MutationOptions on format.apply.
 *
 * Exists as a distinct type so the styles system can add style-specific
 * options (e.g. scope, priority) without changing the public API shape.
 */
export type StyleApplyOptions = MutationOptions;
/** Direct alias methods (`format.<inlineKey>`) that route to `format.apply`. */
export type FormatInlineAliasApi = {
    [K in InlineRunPatchKey]: (input: FormatInlineAliasInput<K>, options?: MutationOptions) => TextMutationReceipt;
};
/** Public helper surface exposed on `DocumentApi.format`. */
export interface FormatApi extends FormatInlineAliasApi {
    strikethrough(input: FormatStrikethroughInput, options?: MutationOptions): TextMutationReceipt;
    apply(input: StyleApplyInput, options?: MutationOptions): TextMutationReceipt;
}
/**
 * Executes `format.apply` via the selection mutation adapter (plan engine).
 */
export declare function executeStyleApply(adapter: SelectionMutationAdapter, input: StyleApplyInput, options?: MutationOptions): TextMutationReceipt;
/**
 * Executes a direct alias operation (`format.<inlineKey>`) by translating it
 * into a single-key `format.apply` payload.
 */
export declare function executeInlineAlias<K extends InlineRunPatchKey>(adapter: SelectionMutationAdapter, key: K, input: FormatInlineAliasInput<K>, options?: MutationOptions): TextMutationReceipt;
export {};
