import { SelectionTarget, DeleteBehavior, TargetLocator } from './types/address.js';
import { TextMutationReceipt } from './types/receipt.js';
import { MutationOptions } from './types/mutation-plan.types.js';
import { InlineRunPatch } from './format/inline-run-patch.js';
import { StoryLocator } from './types/story.types.js';
export type SelectionDeleteRequest = TargetLocator & {
    kind: 'delete';
    target?: SelectionTarget;
    ref?: string;
    behavior: DeleteBehavior;
    /** Story locator threaded from the operation input's `in` field. */
    in?: StoryLocator;
};
export type SelectionReplaceRequest = TargetLocator & {
    kind: 'replace';
    target?: SelectionTarget;
    ref?: string;
    text: string;
    /** Story locator threaded from the operation input's `in` field. */
    in?: StoryLocator;
};
export type SelectionInsertRequest = TargetLocator & {
    kind: 'insert';
    target?: SelectionTarget;
    ref?: string;
    text: string;
    /** Story locator threaded from the operation input's `in` field. */
    in?: StoryLocator;
};
export type SelectionFormatRequest = TargetLocator & {
    kind: 'format';
    target?: SelectionTarget;
    ref?: string;
    inline: InlineRunPatch;
    /** Story locator threaded from the operation input's `in` field. */
    in?: StoryLocator;
};
export type SelectionMutationRequest = SelectionDeleteRequest | SelectionReplaceRequest | SelectionInsertRequest | SelectionFormatRequest;
/**
 * Adapter that the plan engine implements for selection-based mutations.
 * Delete, replace-text, insert-with-locator, and format.apply go through this
 * single interface.
 */
export interface SelectionMutationAdapter {
    execute(request: SelectionMutationRequest, options?: MutationOptions): TextMutationReceipt;
}
