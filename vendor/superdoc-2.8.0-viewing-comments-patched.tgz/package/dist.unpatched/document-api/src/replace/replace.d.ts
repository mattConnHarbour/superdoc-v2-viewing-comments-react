import { RichContentMutationOptions, WriteAdapter } from '../write/write.js';
import { SelectionTarget, TargetLocator } from '../types/address.js';
import { SDMutationReceipt } from '../types/sd-contract.js';
import { SDReplaceInput } from '../types/structural-input.js';
import { BodyStoryLocator, StoryLocator } from '../types/story.types.js';
import { BlockNodeAddress } from '../types/base.js';
import { NestingPolicy } from '../types/placement.js';
import { SelectionMutationAdapter } from '../selection-mutation.js';
/** Text replacement input: uses SelectionTarget / ref, or the complete main body. */
export type TextReplaceInput = (TargetLocator & {
    target?: SelectionTarget;
    ref?: string;
    text: string;
    /** Target a specific document story (body, header, footer, footnote, endnote). */
    in?: StoryLocator;
}) | {
    target: BodyStoryLocator;
    text: string;
    ref?: never;
    in?: never;
};
/** HTML or Markdown replacement input for conversion and structured application. */
export type RichContentReplaceInput = {
    value: string;
    type: 'html' | 'markdown';
    target?: SelectionTarget | BlockNodeAddress;
    ref?: string;
    in?: StoryLocator;
    nestingPolicy?: NestingPolicy;
} | {
    value: string;
    type: 'html' | 'markdown';
    target: BodyStoryLocator;
    ref?: never;
    in?: never;
    nestingPolicy?: never;
};
/**
 * Input payload for the `doc.replace` operation.
 *
 * Discrimination: `text` (plain), `value` (HTML/Markdown), or `content` (SDFragment).
 */
export type ReplaceInput = TextReplaceInput | RichContentReplaceInput | SDReplaceInput;
/** Returns true when the input uses the structural SDFragment shape. */
export declare function isStructuralReplaceInput(input: ReplaceInput): input is SDReplaceInput;
export declare function isRichContentReplaceInput(input: ReplaceInput): input is RichContentReplaceInput;
export declare function validateReplaceInput(input: unknown): asserts input is ReplaceInput;
export declare function executeReplace(selectionAdapter: SelectionMutationAdapter, writeAdapter: WriteAdapter, input: ReplaceInput, options?: RichContentMutationOptions): SDMutationReceipt;
