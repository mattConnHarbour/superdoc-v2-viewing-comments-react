import { DiffSnapshot, DiffPayload, DiffApplyResult, DiffCompareInput, DiffApplyInput, DiffApplyOptions } from './diff.types.js';
export interface DiffAdapter {
    capture(): DiffSnapshot;
    compare(input: DiffCompareInput): DiffPayload;
    apply(input: DiffApplyInput, options?: DiffApplyOptions): DiffApplyResult;
}
export interface DiffApi {
    capture(): DiffSnapshot;
    compare(input: DiffCompareInput): DiffPayload;
    apply(input: DiffApplyInput, options?: DiffApplyOptions): DiffApplyResult;
}
export declare function executeDiffCapture(adapter: DiffAdapter): DiffSnapshot;
export declare function executeDiffCompare(adapter: DiffAdapter, input: DiffCompareInput): DiffPayload;
export declare function executeDiffApply(adapter: DiffAdapter, input: DiffApplyInput, options?: DiffApplyOptions): DiffApplyResult;
