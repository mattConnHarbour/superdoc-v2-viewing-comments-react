import { TrackedChangeAddress } from '../types/address.js';
import { StoryLocator } from '../types/story.types.js';
import { TrackChangeNavigationTarget } from '../types/track-changes.types.js';
/** Identifier for the engine adapter that produced the opaque payload. */
export type DiffEngineId = 'superdoc-v2';
/** Declares which document components are included in a snapshot or diff. */
export interface DiffCoverage {
    body: true;
    comments: boolean;
    styles: boolean;
    numbering: boolean;
    headerFooters: boolean;
}
/** Versioned, fingerprinted snapshot of a document's diffable state. */
export interface DiffSnapshot {
    version: 'sd-diff-snapshot/v1' | 'sd-diff-snapshot/v2';
    engine: DiffEngineId;
    fingerprint: string;
    coverage: DiffCoverage;
    /** Opaque engine-owned snapshot data. Do not inspect or modify. */
    payload: Record<string, unknown>;
}
/** Coarse change summary for a diff payload. */
export interface DiffSummary {
    hasChanges: boolean;
    changedComponents: Array<'body' | 'comments' | 'styles' | 'numbering' | 'headerFooters' | 'parts'>;
    body: {
        hasChanges: boolean;
    };
    comments: {
        hasChanges: boolean;
    };
    styles: {
        hasChanges: boolean;
    };
    numbering: {
        hasChanges: boolean;
    };
    headerFooters: {
        hasChanges: boolean;
    };
    parts: {
        hasChanges: boolean;
    };
}
/** Versioned diff payload describing changes from a base to a target document. */
export interface DiffPayload {
    version: 'sd-diff-payload/v1' | 'sd-diff-payload/v2';
    engine: DiffEngineId;
    baseFingerprint: string;
    targetFingerprint: string;
    coverage: DiffCoverage;
    summary: DiffSummary;
    /** Opaque engine-owned diff data. Do not inspect or modify. */
    payload: Record<string, unknown>;
}
export interface DiffApplyReviewItem {
    id: string;
    story: StoryLocator;
    address: TrackedChangeAddress;
    navigationTarget?: TrackChangeNavigationTarget;
}
export type DiffApplyOperationReceipt = {
    operationId: string;
    disposition: 'review-created';
    reviewItems: [DiffApplyReviewItem, ...DiffApplyReviewItem[]];
} | {
    operationId: string;
    disposition: 'applied-directly';
    reviewItems: [];
};
export interface DiffApplyResult {
    appliedOperations: number;
    operationReceipts: DiffApplyOperationReceipt[];
    baseFingerprint: string;
    targetFingerprint: string;
    coverage: DiffCoverage;
    summary: DiffSummary;
    diagnostics: string[];
}
/** Input for `diff.compare`. */
export interface DiffCompareInput {
    targetSnapshot: DiffSnapshot;
}
/** Input for `diff.apply`. */
export interface DiffApplyInput {
    diff: DiffPayload;
}
/** How body content changes are applied. */
export type DiffChangeMode = 'direct' | 'tracked';
/** Options for `diff.apply`. Omitted `changeMode` applies story content directly. */
export interface DiffApplyOptions {
    changeMode?: DiffChangeMode;
}
