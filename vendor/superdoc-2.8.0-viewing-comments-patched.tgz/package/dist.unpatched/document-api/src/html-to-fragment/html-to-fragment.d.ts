import { SDHtmlToFragmentResult } from '../types/sd-contract.js';
export interface HtmlToFragmentInput {
    html: string;
}
export interface HtmlToFragmentAdapter {
    htmlToFragment(input: HtmlToFragmentInput): SDHtmlToFragmentResult;
}
export declare function executeHtmlToFragment(adapter: HtmlToFragmentAdapter | undefined, input: HtmlToFragmentInput): SDHtmlToFragmentResult;
