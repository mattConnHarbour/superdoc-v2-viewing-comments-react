import { SDMarkdownToFragmentResult } from '../types/sd-contract.js';
export interface MarkdownToFragmentInput {
    /** The Markdown source text to convert. */
    markdown: string;
}
/**
 * Engine-specific adapter that the markdownToFragment API delegates to.
 */
export interface MarkdownToFragmentAdapter {
    markdownToFragment(input: MarkdownToFragmentInput): SDMarkdownToFragmentResult;
}
/**
 * Execute a markdownToFragment operation via the provided adapter.
 */
export declare function executeMarkdownToFragment(adapter: MarkdownToFragmentAdapter, input: MarkdownToFragmentInput): SDMarkdownToFragmentResult;
