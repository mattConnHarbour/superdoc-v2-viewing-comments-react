import { SDProjectionReadInput } from '../types/content-projection.js';
export interface GetMarkdownInput extends SDProjectionReadInput {
}
/**
 * Engine-specific adapter that the getMarkdown API delegates to.
 */
export interface GetMarkdownAdapter {
    /**
     * Return the full document content as a Markdown string.
     */
    getMarkdown(input: GetMarkdownInput): string;
}
/**
 * Execute a getMarkdown operation via the provided adapter.
 *
 * @param adapter - Engine-specific getMarkdown adapter.
 * @param input - Canonical getMarkdown input object.
 * @returns The full document content as a Markdown-formatted string.
 */
export declare function executeGetMarkdown(adapter: GetMarkdownAdapter, input: GetMarkdownInput): string;
