import { MutationOptions } from '../write/write.js';
import { ContentControlInfo, ContentControlMutationResult, ContentControlsListResult, ContentControlsListQuery, ContentControlsGetInput, ContentControlsListInRangeInput, ContentControlsSelectByTagInput, ContentControlsSelectByTitleInput, ContentControlsListChildrenInput, ContentControlsGetParentInput, ContentControlsWrapInput, ContentControlsUnwrapInput, ContentControlsDeleteInput, ContentControlsCopyInput, ContentControlsMoveInput, ContentControlsPatchInput, ContentControlsSetLockModeInput, ContentControlsSetTypeInput, ContentControlsGetContentInput, ContentControlsGetContentResult, ContentControlsReplaceContentInput, ContentControlsClearContentInput, ContentControlsAppendContentInput, ContentControlsPrependContentInput, ContentControlsInsertBeforeInput, ContentControlsInsertAfterInput, ContentControlsGetBindingInput, ContentControlBinding, ContentControlsSetBindingInput, ContentControlsClearBindingInput, ContentControlsGetRawPropertiesInput, ContentControlsGetRawPropertiesResult, ContentControlsPatchRawPropertiesInput, ContentControlsValidateWordCompatibilityInput, ContentControlsValidateWordCompatibilityResult, ContentControlsNormalizeWordCompatibilityInput, ContentControlsNormalizeTagPayloadInput, ContentControlsTextSetMultilineInput, ContentControlsTextSetValueInput, ContentControlsTextClearValueInput, ContentControlsDateSetValueInput, ContentControlsDateClearValueInput, ContentControlsDateSetDisplayFormatInput, ContentControlsDateSetDisplayLocaleInput, ContentControlsDateSetStorageFormatInput, ContentControlsDateSetCalendarInput, ContentControlsCheckboxGetStateInput, ContentControlsCheckboxGetStateResult, ContentControlsCheckboxSetStateInput, ContentControlsCheckboxToggleInput, ContentControlsCheckboxSetSymbolPairInput, ContentControlsChoiceListGetItemsInput, ContentControlsChoiceListGetItemsResult, ContentControlsChoiceListSetItemsInput, ContentControlsChoiceListSetSelectedInput, ContentControlsRepeatingSectionListItemsInput, ContentControlsRepeatingSectionListItemsResult, ContentControlsRepeatingSectionInsertItemBeforeInput, ContentControlsRepeatingSectionInsertItemAfterInput, ContentControlsRepeatingSectionCloneItemInput, ContentControlsRepeatingSectionDeleteItemInput, ContentControlsRepeatingSectionSetAllowInsertDeleteInput, ContentControlsGroupWrapInput, ContentControlsGroupUngroupInput, CreateContentControlInput } from './content-controls.types.js';
export interface ContentControlsTextApi {
    setMultiline(input: ContentControlsTextSetMultilineInput, options?: MutationOptions): ContentControlMutationResult;
    setValue(input: ContentControlsTextSetValueInput, options?: MutationOptions): ContentControlMutationResult;
    clearValue(input: ContentControlsTextClearValueInput, options?: MutationOptions): ContentControlMutationResult;
}
export interface ContentControlsDateApi {
    setValue(input: ContentControlsDateSetValueInput, options?: MutationOptions): ContentControlMutationResult;
    clearValue(input: ContentControlsDateClearValueInput, options?: MutationOptions): ContentControlMutationResult;
    setDisplayFormat(input: ContentControlsDateSetDisplayFormatInput, options?: MutationOptions): ContentControlMutationResult;
    setDisplayLocale(input: ContentControlsDateSetDisplayLocaleInput, options?: MutationOptions): ContentControlMutationResult;
    setStorageFormat(input: ContentControlsDateSetStorageFormatInput, options?: MutationOptions): ContentControlMutationResult;
    setCalendar(input: ContentControlsDateSetCalendarInput, options?: MutationOptions): ContentControlMutationResult;
}
export interface ContentControlsCheckboxApi {
    getState(input: ContentControlsCheckboxGetStateInput): ContentControlsCheckboxGetStateResult;
    setState(input: ContentControlsCheckboxSetStateInput, options?: MutationOptions): ContentControlMutationResult;
    toggle(input: ContentControlsCheckboxToggleInput, options?: MutationOptions): ContentControlMutationResult;
    setSymbolPair(input: ContentControlsCheckboxSetSymbolPairInput, options?: MutationOptions): ContentControlMutationResult;
}
export interface ContentControlsChoiceListApi {
    getItems(input: ContentControlsChoiceListGetItemsInput): ContentControlsChoiceListGetItemsResult;
    setItems(input: ContentControlsChoiceListSetItemsInput, options?: MutationOptions): ContentControlMutationResult;
    setSelected(input: ContentControlsChoiceListSetSelectedInput, options?: MutationOptions): ContentControlMutationResult;
}
export interface ContentControlsRepeatingSectionApi {
    listItems(input: ContentControlsRepeatingSectionListItemsInput): ContentControlsRepeatingSectionListItemsResult;
    insertItemBefore(input: ContentControlsRepeatingSectionInsertItemBeforeInput, options?: MutationOptions): ContentControlMutationResult;
    insertItemAfter(input: ContentControlsRepeatingSectionInsertItemAfterInput, options?: MutationOptions): ContentControlMutationResult;
    cloneItem(input: ContentControlsRepeatingSectionCloneItemInput, options?: MutationOptions): ContentControlMutationResult;
    deleteItem(input: ContentControlsRepeatingSectionDeleteItemInput, options?: MutationOptions): ContentControlMutationResult;
    setAllowInsertDelete(input: ContentControlsRepeatingSectionSetAllowInsertDeleteInput, options?: MutationOptions): ContentControlMutationResult;
}
export interface ContentControlsGroupApi {
    wrap(input: ContentControlsGroupWrapInput, options?: MutationOptions): ContentControlMutationResult;
    ungroup(input: ContentControlsGroupUngroupInput, options?: MutationOptions): ContentControlMutationResult;
}
export interface ContentControlsApi {
    list(query?: ContentControlsListQuery): ContentControlsListResult;
    get(input: ContentControlsGetInput): ContentControlInfo;
    listInRange(input: ContentControlsListInRangeInput): ContentControlsListResult;
    selectByTag(input: ContentControlsSelectByTagInput): ContentControlsListResult;
    selectByTitle(input: ContentControlsSelectByTitleInput): ContentControlsListResult;
    listChildren(input: ContentControlsListChildrenInput): ContentControlsListResult;
    getParent(input: ContentControlsGetParentInput): ContentControlInfo | null;
    wrap(input: ContentControlsWrapInput, options?: MutationOptions): ContentControlMutationResult;
    unwrap(input: ContentControlsUnwrapInput, options?: MutationOptions): ContentControlMutationResult;
    delete(input: ContentControlsDeleteInput, options?: MutationOptions): ContentControlMutationResult;
    copy(input: ContentControlsCopyInput, options?: MutationOptions): ContentControlMutationResult;
    move(input: ContentControlsMoveInput, options?: MutationOptions): ContentControlMutationResult;
    patch(input: ContentControlsPatchInput, options?: MutationOptions): ContentControlMutationResult;
    setLockMode(input: ContentControlsSetLockModeInput, options?: MutationOptions): ContentControlMutationResult;
    setType(input: ContentControlsSetTypeInput, options?: MutationOptions): ContentControlMutationResult;
    getContent(input: ContentControlsGetContentInput): ContentControlsGetContentResult;
    replaceContent(input: ContentControlsReplaceContentInput, options?: MutationOptions): ContentControlMutationResult;
    clearContent(input: ContentControlsClearContentInput, options?: MutationOptions): ContentControlMutationResult;
    appendContent(input: ContentControlsAppendContentInput, options?: MutationOptions): ContentControlMutationResult;
    prependContent(input: ContentControlsPrependContentInput, options?: MutationOptions): ContentControlMutationResult;
    insertBefore(input: ContentControlsInsertBeforeInput, options?: MutationOptions): ContentControlMutationResult;
    insertAfter(input: ContentControlsInsertAfterInput, options?: MutationOptions): ContentControlMutationResult;
    getBinding(input: ContentControlsGetBindingInput): ContentControlBinding | null;
    setBinding(input: ContentControlsSetBindingInput, options?: MutationOptions): ContentControlMutationResult;
    clearBinding(input: ContentControlsClearBindingInput, options?: MutationOptions): ContentControlMutationResult;
    getRawProperties(input: ContentControlsGetRawPropertiesInput): ContentControlsGetRawPropertiesResult;
    patchRawProperties(input: ContentControlsPatchRawPropertiesInput, options?: MutationOptions): ContentControlMutationResult;
    validateWordCompatibility(input: ContentControlsValidateWordCompatibilityInput): ContentControlsValidateWordCompatibilityResult;
    normalizeWordCompatibility(input: ContentControlsNormalizeWordCompatibilityInput, options?: MutationOptions): ContentControlMutationResult;
    normalizeTagPayload(input: ContentControlsNormalizeTagPayloadInput, options?: MutationOptions): ContentControlMutationResult;
    text: ContentControlsTextApi;
    date: ContentControlsDateApi;
    checkbox: ContentControlsCheckboxApi;
    choiceList: ContentControlsChoiceListApi;
    repeatingSection: ContentControlsRepeatingSectionApi;
    group: ContentControlsGroupApi;
}
export type ContentControlsAdapter = ContentControlsApi;
export declare function executeContentControlsList(adapter: ContentControlsAdapter, query?: ContentControlsListQuery): ContentControlsListResult;
export declare function executeContentControlsGet(adapter: ContentControlsAdapter, input: ContentControlsGetInput): ContentControlInfo;
export declare function executeContentControlsListInRange(adapter: ContentControlsAdapter, input: ContentControlsListInRangeInput): ContentControlsListResult;
export declare function executeContentControlsSelectByTag(adapter: ContentControlsAdapter, input: ContentControlsSelectByTagInput): ContentControlsListResult;
export declare function executeContentControlsSelectByTitle(adapter: ContentControlsAdapter, input: ContentControlsSelectByTitleInput): ContentControlsListResult;
export declare function executeContentControlsListChildren(adapter: ContentControlsAdapter, input: ContentControlsListChildrenInput): ContentControlsListResult;
export declare function executeContentControlsGetParent(adapter: ContentControlsAdapter, input: ContentControlsGetParentInput): ContentControlInfo | null;
export declare function executeContentControlsWrap(adapter: ContentControlsAdapter, input: ContentControlsWrapInput, options?: MutationOptions): ContentControlMutationResult;
export declare function executeContentControlsUnwrap(adapter: ContentControlsAdapter, input: ContentControlsUnwrapInput, options?: MutationOptions): ContentControlMutationResult;
export declare function executeContentControlsDelete(adapter: ContentControlsAdapter, input: ContentControlsDeleteInput, options?: MutationOptions): ContentControlMutationResult;
export declare function executeContentControlsCopy(adapter: ContentControlsAdapter, input: ContentControlsCopyInput, options?: MutationOptions): ContentControlMutationResult;
export declare function executeContentControlsMove(adapter: ContentControlsAdapter, input: ContentControlsMoveInput, options?: MutationOptions): ContentControlMutationResult;
export declare function executeContentControlsPatch(adapter: ContentControlsAdapter, input: ContentControlsPatchInput, options?: MutationOptions): ContentControlMutationResult;
export declare function executeContentControlsSetLockMode(adapter: ContentControlsAdapter, input: ContentControlsSetLockModeInput, options?: MutationOptions): ContentControlMutationResult;
export declare function executeContentControlsSetType(adapter: ContentControlsAdapter, input: ContentControlsSetTypeInput, options?: MutationOptions): ContentControlMutationResult;
export declare function executeContentControlsGetContent(adapter: ContentControlsAdapter, input: ContentControlsGetContentInput): ContentControlsGetContentResult;
export declare function executeContentControlsReplaceContent(adapter: ContentControlsAdapter, input: ContentControlsReplaceContentInput, options?: MutationOptions): ContentControlMutationResult;
export declare function executeContentControlsClearContent(adapter: ContentControlsAdapter, input: ContentControlsClearContentInput, options?: MutationOptions): ContentControlMutationResult;
export declare function executeContentControlsAppendContent(adapter: ContentControlsAdapter, input: ContentControlsAppendContentInput, options?: MutationOptions): ContentControlMutationResult;
export declare function executeContentControlsPrependContent(adapter: ContentControlsAdapter, input: ContentControlsPrependContentInput, options?: MutationOptions): ContentControlMutationResult;
export declare function executeContentControlsInsertBefore(adapter: ContentControlsAdapter, input: ContentControlsInsertBeforeInput, options?: MutationOptions): ContentControlMutationResult;
export declare function executeContentControlsInsertAfter(adapter: ContentControlsAdapter, input: ContentControlsInsertAfterInput, options?: MutationOptions): ContentControlMutationResult;
export declare function executeContentControlsGetBinding(adapter: ContentControlsAdapter, input: ContentControlsGetBindingInput): ContentControlBinding | null;
export declare function executeContentControlsSetBinding(adapter: ContentControlsAdapter, input: ContentControlsSetBindingInput, options?: MutationOptions): ContentControlMutationResult;
export declare function executeContentControlsClearBinding(adapter: ContentControlsAdapter, input: ContentControlsClearBindingInput, options?: MutationOptions): ContentControlMutationResult;
export declare function executeContentControlsGetRawProperties(adapter: ContentControlsAdapter, input: ContentControlsGetRawPropertiesInput): ContentControlsGetRawPropertiesResult;
export declare function executeContentControlsPatchRawProperties(adapter: ContentControlsAdapter, input: ContentControlsPatchRawPropertiesInput, options?: MutationOptions): ContentControlMutationResult;
export declare function executeContentControlsValidateWordCompatibility(adapter: ContentControlsAdapter, input: ContentControlsValidateWordCompatibilityInput): ContentControlsValidateWordCompatibilityResult;
export declare function executeContentControlsNormalizeWordCompatibility(adapter: ContentControlsAdapter, input: ContentControlsNormalizeWordCompatibilityInput, options?: MutationOptions): ContentControlMutationResult;
export declare function executeContentControlsNormalizeTagPayload(adapter: ContentControlsAdapter, input: ContentControlsNormalizeTagPayloadInput, options?: MutationOptions): ContentControlMutationResult;
export declare function executeContentControlsTextSetMultiline(adapter: ContentControlsAdapter, input: ContentControlsTextSetMultilineInput, options?: MutationOptions): ContentControlMutationResult;
export declare function executeContentControlsTextSetValue(adapter: ContentControlsAdapter, input: ContentControlsTextSetValueInput, options?: MutationOptions): ContentControlMutationResult;
export declare function executeContentControlsTextClearValue(adapter: ContentControlsAdapter, input: ContentControlsTextClearValueInput, options?: MutationOptions): ContentControlMutationResult;
export declare function executeContentControlsDateSetValue(adapter: ContentControlsAdapter, input: ContentControlsDateSetValueInput, options?: MutationOptions): ContentControlMutationResult;
export declare function executeContentControlsDateClearValue(adapter: ContentControlsAdapter, input: ContentControlsDateClearValueInput, options?: MutationOptions): ContentControlMutationResult;
export declare function executeContentControlsDateSetDisplayFormat(adapter: ContentControlsAdapter, input: ContentControlsDateSetDisplayFormatInput, options?: MutationOptions): ContentControlMutationResult;
export declare function executeContentControlsDateSetDisplayLocale(adapter: ContentControlsAdapter, input: ContentControlsDateSetDisplayLocaleInput, options?: MutationOptions): ContentControlMutationResult;
export declare function executeContentControlsDateSetStorageFormat(adapter: ContentControlsAdapter, input: ContentControlsDateSetStorageFormatInput, options?: MutationOptions): ContentControlMutationResult;
export declare function executeContentControlsDateSetCalendar(adapter: ContentControlsAdapter, input: ContentControlsDateSetCalendarInput, options?: MutationOptions): ContentControlMutationResult;
export declare function executeContentControlsCheckboxGetState(adapter: ContentControlsAdapter, input: ContentControlsCheckboxGetStateInput): ContentControlsCheckboxGetStateResult;
export declare function executeContentControlsCheckboxSetState(adapter: ContentControlsAdapter, input: ContentControlsCheckboxSetStateInput, options?: MutationOptions): ContentControlMutationResult;
export declare function executeContentControlsCheckboxToggle(adapter: ContentControlsAdapter, input: ContentControlsCheckboxToggleInput, options?: MutationOptions): ContentControlMutationResult;
export declare function executeContentControlsCheckboxSetSymbolPair(adapter: ContentControlsAdapter, input: ContentControlsCheckboxSetSymbolPairInput, options?: MutationOptions): ContentControlMutationResult;
export declare function executeContentControlsChoiceListGetItems(adapter: ContentControlsAdapter, input: ContentControlsChoiceListGetItemsInput): ContentControlsChoiceListGetItemsResult;
export declare function executeContentControlsChoiceListSetItems(adapter: ContentControlsAdapter, input: ContentControlsChoiceListSetItemsInput, options?: MutationOptions): ContentControlMutationResult;
export declare function executeContentControlsChoiceListSetSelected(adapter: ContentControlsAdapter, input: ContentControlsChoiceListSetSelectedInput, options?: MutationOptions): ContentControlMutationResult;
export declare function executeContentControlsRepeatingSectionListItems(adapter: ContentControlsAdapter, input: ContentControlsRepeatingSectionListItemsInput): ContentControlsRepeatingSectionListItemsResult;
export declare function executeContentControlsRepeatingSectionInsertItemBefore(adapter: ContentControlsAdapter, input: ContentControlsRepeatingSectionInsertItemBeforeInput, options?: MutationOptions): ContentControlMutationResult;
export declare function executeContentControlsRepeatingSectionInsertItemAfter(adapter: ContentControlsAdapter, input: ContentControlsRepeatingSectionInsertItemAfterInput, options?: MutationOptions): ContentControlMutationResult;
export declare function executeContentControlsRepeatingSectionCloneItem(adapter: ContentControlsAdapter, input: ContentControlsRepeatingSectionCloneItemInput, options?: MutationOptions): ContentControlMutationResult;
export declare function executeContentControlsRepeatingSectionDeleteItem(adapter: ContentControlsAdapter, input: ContentControlsRepeatingSectionDeleteItemInput, options?: MutationOptions): ContentControlMutationResult;
export declare function executeContentControlsRepeatingSectionSetAllowInsertDelete(adapter: ContentControlsAdapter, input: ContentControlsRepeatingSectionSetAllowInsertDeleteInput, options?: MutationOptions): ContentControlMutationResult;
export declare function executeContentControlsGroupWrap(adapter: ContentControlsAdapter, input: ContentControlsGroupWrapInput, options?: MutationOptions): ContentControlMutationResult;
export declare function executeContentControlsGroupUngroup(adapter: ContentControlsAdapter, input: ContentControlsGroupUngroupInput, options?: MutationOptions): ContentControlMutationResult;
export declare function executeCreateContentControl(adapter: ContentControlsCreateAdapter, input: CreateContentControlInput, options?: MutationOptions): ContentControlMutationResult;
/** Adapter extension for create.contentControl. */
export interface ContentControlsCreateAdapter {
    create(input: CreateContentControlInput, options?: MutationOptions): ContentControlMutationResult;
}
