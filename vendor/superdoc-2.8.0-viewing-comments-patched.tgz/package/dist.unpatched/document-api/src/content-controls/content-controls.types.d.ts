import { BlockNodeAddress, NodeKind } from '../types/base.js';
import { SelectionTarget } from '../types/address.js';
import { SDFragment } from '../types/fragment.js';
import { ReceiptFailure, ReceiptInsert } from '../types/receipt.js';
/**
 * Semantic SDT subtype derived from `w:sdtPr` children.
 *
 * `richText` covers both explicit `<w:richText/>` and the OOXML default for
 * sdtPr with no type child (ECMA-376 §17.5.2.26: typeless SDT shall be of
 * type richText). `unknown` means an unsupported or unrecognized type child.
 */
export type ContentControlType = 'text' | 'richText' | 'date' | 'checkbox' | 'comboBox' | 'dropDownList' | 'repeatingSection' | 'repeatingSectionItem' | 'group' | 'unknown';
export declare const CONTENT_CONTROL_TYPES: readonly ["text", "richText", "date", "checkbox", "comboBox", "dropDownList", "repeatingSection", "repeatingSectionItem", "group", "unknown"];
/** ECMA-376 `w:lock` modes. */
export type LockMode = 'unlocked' | 'sdtLocked' | 'contentLocked' | 'sdtContentLocked';
export declare const LOCK_MODES: readonly ["unlocked", "sdtLocked", "contentLocked", "sdtContentLocked"];
/** Visual appearance of the content control wrapper in Word. */
export type ContentControlAppearance = 'boundingBox' | 'tags' | 'hidden';
export declare const CONTENT_CONTROL_APPEARANCES: readonly ["boundingBox", "tags", "hidden"];
/** Symbol specification for checkbox checked/unchecked glyphs. */
export interface ContentControlSymbol {
    font: string;
    char: string;
}
/** Choice list item (shared by comboBox and dropDownList). */
export interface ContentControlListItem {
    displayText: string;
    value: string;
}
/** Data binding metadata from `w:dataBinding`. */
export interface ContentControlBinding {
    storeItemId: string;
    xpath: string;
    prefixMappings?: string;
}
export interface TextControlProperties {
    multiline?: boolean;
}
export interface DateControlProperties {
    dateFormat?: string;
    dateLocale?: string;
    storageFormat?: string;
    calendar?: string;
}
export interface CheckboxControlProperties {
    checked?: boolean;
    checkedSymbol?: ContentControlSymbol;
    uncheckedSymbol?: ContentControlSymbol;
}
export interface ChoiceControlProperties {
    items?: ContentControlListItem[];
    selectedValue?: string;
}
export interface RepeatingSectionControlProperties {
    allowInsertDelete?: boolean;
}
export interface ContentControlProperties {
    tag?: string;
    alias?: string;
    /**
     * Visual chrome behavior (`<w15:appearance w15:val="…">`).
     *
     * Returned verbatim from the imported XML. When the source omits
     * the element, this field is `undefined` — NOT silently set to
     * `boundingBox`. Word's effective default when the element is
     * absent is `boundingBox`, but consumers building UI on top of
     * appearance (e.g. deciding whether to draw chrome) must apply
     * that default themselves; the API does not fabricate it.
     *
     * Contract:
     *   - `'boundingBox'` → explicit; show chrome
     *   - `'tags'`        → explicit; show tag markers
     *   - `'hidden'`      → explicit; render transparently
     *   - `undefined`     → source XML omitted the element; treat as
     *                       Word's effective default (`'boundingBox'`).
     */
    appearance?: ContentControlAppearance;
    color?: string;
    placeholder?: string;
    showingPlaceholder?: boolean;
    /**
     * `<w:temporary/>` toggle (ECMA-376 §17.5.2.43).
     *
     * When enabled, Word treats the content control as temporary and may
     * remove the SDT wrapper after the user edits/fills the control.
     *
     * Returned verbatim from the imported XML:
     *   - `true`      → element present (`<w:temporary/>` or `w:val="true"`/`"1"`)
     *   - `false`     → element present with `w:val="false"`/`"0"`
     *   - `undefined` → element absent in source; treat as Word's
     *                   effective default (`false`).
     */
    temporary?: boolean;
    tabIndex?: number;
    multiline?: boolean;
    dateFormat?: string;
    dateLocale?: string;
    storageFormat?: string;
    calendar?: string;
    checked?: boolean;
    checkedSymbol?: ContentControlSymbol;
    uncheckedSymbol?: ContentControlSymbol;
    items?: ContentControlListItem[];
    selectedValue?: string;
    allowInsertDelete?: boolean;
}
export interface ContentControlTarget {
    kind: NodeKind;
    nodeType: 'sdt';
    nodeId: string;
}
export type ContentControlMoveDestination = ContentControlTarget | {
    kind: 'documentStart';
} | {
    kind: 'documentEnd';
} | {
    kind: 'before';
    target: ContentControlTarget;
} | {
    kind: 'after';
    target: ContentControlTarget;
}
/**
 * Drop the control at an arbitrary caret inside a paragraph (SD-3779). `target`
 * addresses the destination paragraph and `offset` is a text-character offset
 * within it (0 = paragraph start). Mirrors `ImageCreateLocation`'s `inParagraph`
 * variant so drag-and-drop can land a content control anywhere in the body, not
 * just relative to another SDT. Direct-mode only.
 */
 | {
    kind: 'inParagraph';
    target: BlockNodeAddress;
    offset?: number;
};
/**
 * Canonical content control info returned by all read/list operations.
 * Replaces the old `SdtNodeInfo`.
 */
export interface ContentControlInfo {
    nodeType: 'sdt';
    kind: NodeKind;
    id: string;
    controlType: ContentControlType;
    lockMode: LockMode;
    properties: ContentControlProperties;
    binding?: ContentControlBinding;
    raw?: Record<string, unknown>;
    target: ContentControlTarget;
    selectionTarget?: SelectionTarget | null;
    text?: string;
    /** Authoritative structural emptiness when the adapter can determine it. */
    isEmpty?: boolean;
}
export interface ContentControlMutationSuccess {
    success: true;
    contentControl: ContentControlTarget;
    updatedRef?: ContentControlTarget;
    trackedChangeRefs?: ReceiptInsert[];
}
export interface ContentControlMutationFailure {
    success: false;
    failure: ReceiptFailure;
}
export type ContentControlMutationResult = ContentControlMutationSuccess | ContentControlMutationFailure;
export interface ContentControlsListResult {
    items: ContentControlInfo[];
    total: number;
}
export interface ContentControlsPaginationOptions {
    offset?: number;
    limit?: number;
}
export interface CreateContentControlInput {
    kind: NodeKind;
    controlType?: ContentControlType;
    target?: ContentControlTarget;
    /**
     * Text range to wrap in the new content control. Mutually exclusive with `target`.
     * When `content` is also provided, it replaces the selected text inside the new SDT.
     * When `content` is omitted, the existing text in the range becomes the SDT content.
     */
    at?: SelectionTarget;
    tag?: string;
    alias?: string;
    lockMode?: LockMode;
    content?: string;
    /**
     * Structured block preset authored from HTML. Supported only for block
     * content controls. Mutually exclusive with `content` and `json`.
     */
    html?: string;
    /**
     * Structured block preset authored from SDFragment-compatible JSON. Legacy
     * type-discriminated fragment shapes are validated at runtime too.
     *
     * Supported only for block content controls. Mutually exclusive with
     * `content` and `html`.
     */
    json?: SDFragment | Record<string, unknown> | Array<Record<string, unknown>>;
}
export interface ContentControlsListQuery extends ContentControlsPaginationOptions {
    controlType?: ContentControlType;
    tag?: string;
}
export interface ContentControlsGetInput {
    target: ContentControlTarget;
}
export interface ContentControlsListInRangeInput extends ContentControlsPaginationOptions {
    startBlockId: string;
    endBlockId: string;
}
export interface ContentControlsSelectByTagInput extends ContentControlsPaginationOptions {
    tag: string;
}
export interface ContentControlsSelectByTitleInput extends ContentControlsPaginationOptions {
    title: string;
}
export interface ContentControlsListChildrenInput extends ContentControlsPaginationOptions {
    target: ContentControlTarget;
}
export interface ContentControlsGetParentInput {
    target: ContentControlTarget;
}
export interface ContentControlsWrapInput {
    kind: NodeKind;
    target: ContentControlTarget;
    tag?: string;
    alias?: string;
    lockMode?: LockMode;
}
export interface ContentControlsUnwrapInput {
    target: ContentControlTarget;
}
export interface ContentControlsDeleteInput {
    target: ContentControlTarget;
}
export interface ContentControlsCopyInput {
    target: ContentControlTarget;
    destination: ContentControlTarget;
}
export interface ContentControlsMoveInput {
    target: ContentControlTarget;
    destination: ContentControlMoveDestination;
}
export interface ContentControlsPatchInput {
    target: ContentControlTarget;
    alias?: string | null;
    tag?: string | null;
    appearance?: ContentControlAppearance | null;
    color?: string | null;
    placeholder?: string | null;
    showingPlaceholder?: boolean;
    temporary?: boolean;
    tabIndex?: number | null;
}
export interface ContentControlsSetLockModeInput {
    target: ContentControlTarget;
    lockMode: LockMode;
}
export interface ContentControlsSetTypeInput {
    target: ContentControlTarget;
    controlType: ContentControlType;
}
export interface ContentControlsGetContentInput {
    target: ContentControlTarget;
}
export interface ContentControlsGetContentResult {
    content: string;
    format: 'text' | 'html';
}
export interface ContentControlsReplaceContentInput {
    target: ContentControlTarget;
    content: string;
    format?: 'text' | 'html';
}
export interface ContentControlsClearContentInput {
    target: ContentControlTarget;
}
export interface ContentControlsAppendContentInput {
    target: ContentControlTarget;
    content: string;
    format?: 'text' | 'html';
}
export interface ContentControlsPrependContentInput {
    target: ContentControlTarget;
    content: string;
    format?: 'text' | 'html';
}
export interface ContentControlsInsertBeforeInput {
    target: ContentControlTarget;
    content: string;
    format?: 'text' | 'html';
}
export interface ContentControlsInsertAfterInput {
    target: ContentControlTarget;
    content: string;
    format?: 'text' | 'html';
}
export interface ContentControlsGetBindingInput {
    target: ContentControlTarget;
}
export interface ContentControlsSetBindingInput {
    target: ContentControlTarget;
    storeItemId: string;
    xpath: string;
    prefixMappings?: string;
}
export interface ContentControlsClearBindingInput {
    target: ContentControlTarget;
}
export interface ContentControlsGetRawPropertiesInput {
    target: ContentControlTarget;
}
export interface ContentControlsGetRawPropertiesResult {
    properties: Record<string, unknown>;
}
export type RawPatchOp = {
    op: 'set';
    name: string;
    element: Record<string, unknown>;
} | {
    op: 'remove';
    name: string;
} | {
    op: 'setAttr';
    name: string;
    attr: string;
    value: string;
} | {
    op: 'removeAttr';
    name: string;
    attr: string;
};
export interface ContentControlsPatchRawPropertiesInput {
    target: ContentControlTarget;
    patches: RawPatchOp[];
}
export interface ContentControlsValidateWordCompatibilityInput {
    target: ContentControlTarget;
}
export interface WordCompatibilityDiagnostic {
    code: string;
    severity: 'error' | 'warning';
    message: string;
}
export interface ContentControlsValidateWordCompatibilityResult {
    compatible: boolean;
    diagnostics: WordCompatibilityDiagnostic[];
}
export interface ContentControlsNormalizeWordCompatibilityInput {
    target: ContentControlTarget;
}
export interface ContentControlsNormalizeTagPayloadInput {
    target: ContentControlTarget;
}
export interface ContentControlsTextSetMultilineInput {
    target: ContentControlTarget;
    multiline: boolean;
}
export interface ContentControlsTextSetValueInput {
    target: ContentControlTarget;
    value: string;
}
export interface ContentControlsTextClearValueInput {
    target: ContentControlTarget;
}
export interface ContentControlsDateSetValueInput {
    target: ContentControlTarget;
    value: string;
}
export interface ContentControlsDateClearValueInput {
    target: ContentControlTarget;
}
export interface ContentControlsDateSetDisplayFormatInput {
    target: ContentControlTarget;
    format: string;
}
export interface ContentControlsDateSetDisplayLocaleInput {
    target: ContentControlTarget;
    locale: string;
}
export interface ContentControlsDateSetStorageFormatInput {
    target: ContentControlTarget;
    format: string;
}
export interface ContentControlsDateSetCalendarInput {
    target: ContentControlTarget;
    calendar: string;
}
export interface ContentControlsCheckboxGetStateInput {
    target: ContentControlTarget;
}
export interface ContentControlsCheckboxGetStateResult {
    checked: boolean;
}
export interface ContentControlsCheckboxSetStateInput {
    target: ContentControlTarget;
    checked: boolean;
}
export interface ContentControlsCheckboxToggleInput {
    target: ContentControlTarget;
}
export interface ContentControlsCheckboxSetSymbolPairInput {
    target: ContentControlTarget;
    checkedSymbol: ContentControlSymbol;
    uncheckedSymbol: ContentControlSymbol;
}
export interface ContentControlsChoiceListGetItemsInput {
    target: ContentControlTarget;
}
export interface ContentControlsChoiceListGetItemsResult {
    items: ContentControlListItem[];
    selectedValue?: string;
}
export interface ContentControlsChoiceListSetItemsInput {
    target: ContentControlTarget;
    items: ContentControlListItem[];
}
export interface ContentControlsChoiceListSetSelectedInput {
    target: ContentControlTarget;
    value: string;
}
export interface ContentControlsRepeatingSectionListItemsInput {
    target: ContentControlTarget;
}
export interface ContentControlsRepeatingSectionListItemsResult {
    items: ContentControlInfo[];
    total: number;
}
export interface ContentControlsRepeatingSectionInsertItemBeforeInput {
    target: ContentControlTarget;
    index: number;
}
export interface ContentControlsRepeatingSectionInsertItemAfterInput {
    target: ContentControlTarget;
    index: number;
}
export interface ContentControlsRepeatingSectionCloneItemInput {
    target: ContentControlTarget;
    index: number;
}
export interface ContentControlsRepeatingSectionDeleteItemInput {
    target: ContentControlTarget;
    index: number;
}
export interface ContentControlsRepeatingSectionSetAllowInsertDeleteInput {
    target: ContentControlTarget;
    allow: boolean;
}
export interface ContentControlsGroupWrapInput {
    target: ContentControlTarget;
}
export interface ContentControlsGroupUngroupInput {
    target: ContentControlTarget;
}
