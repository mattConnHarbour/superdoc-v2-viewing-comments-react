import { ResolveRangeInput, ResolveRangeOutput, RangeResolverAdapter } from './ranges.types.js';
export declare function executeResolveRange(adapter: RangeResolverAdapter, input: ResolveRangeInput): ResolveRangeOutput;
