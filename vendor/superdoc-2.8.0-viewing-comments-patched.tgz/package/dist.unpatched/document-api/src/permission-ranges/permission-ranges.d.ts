import { MutationOptions } from '../write/write.js';
import { PermissionRangesListInput, PermissionRangesListResult, PermissionRangesGetInput, PermissionRangeInfo, PermissionRangesCreateInput, PermissionRangesRemoveInput, PermissionRangesUpdatePrincipalInput, PermissionRangeMutationResult, PermissionRangeRemoveResult } from './permission-ranges.types.js';
export interface PermissionRangesApi {
    list(input?: PermissionRangesListInput): PermissionRangesListResult;
    get(input: PermissionRangesGetInput): PermissionRangeInfo;
    create(input: PermissionRangesCreateInput, options?: MutationOptions): PermissionRangeMutationResult;
    remove(input: PermissionRangesRemoveInput, options?: MutationOptions): PermissionRangeRemoveResult;
    updatePrincipal(input: PermissionRangesUpdatePrincipalInput, options?: MutationOptions): PermissionRangeMutationResult;
}
export type PermissionRangesAdapter = PermissionRangesApi;
export declare function executePermissionRangesList(adapter: PermissionRangesAdapter, input?: PermissionRangesListInput): PermissionRangesListResult;
export declare function executePermissionRangesGet(adapter: PermissionRangesAdapter, input: PermissionRangesGetInput): PermissionRangeInfo;
export declare function executePermissionRangesCreate(adapter: PermissionRangesAdapter, input: PermissionRangesCreateInput, options?: MutationOptions): PermissionRangeMutationResult;
export declare function executePermissionRangesRemove(adapter: PermissionRangesAdapter, input: PermissionRangesRemoveInput, options?: MutationOptions): PermissionRangeRemoveResult;
export declare function executePermissionRangesUpdatePrincipal(adapter: PermissionRangesAdapter, input: PermissionRangesUpdatePrincipalInput, options?: MutationOptions): PermissionRangeMutationResult;
