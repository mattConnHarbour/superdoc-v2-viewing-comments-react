import { Position } from '../types/base.js';
import { SelectionTarget } from '../types/address.js';
import { AdapterMutationFailure } from '../types/adapter-result.js';
import { DiscoveryOutput } from '../types/discovery.js';
export type PermissionRangePrincipal = {
    kind: 'everyone';
} | {
    kind: 'editor';
    id: string;
};
export type PermissionRangeKind = 'inline' | 'block';
export interface PermissionRangeInfo {
    id: string;
    principal: PermissionRangePrincipal;
    kind: PermissionRangeKind;
    start: Position;
    end: Position;
}
export interface PermissionRangesListInput {
    limit?: number;
    offset?: number;
}
export interface PermissionRangesGetInput {
    id: string;
}
export interface PermissionRangesCreateInput {
    /** Target range for the new permission markers. Uses the standard selection target model. */
    target: SelectionTarget;
    principal: PermissionRangePrincipal;
    id?: string;
}
export interface PermissionRangesRemoveInput {
    id: string;
}
export interface PermissionRangesUpdatePrincipalInput {
    id: string;
    principal: PermissionRangePrincipal;
}
export interface PermissionRangeMutationSuccess {
    success: true;
    range: PermissionRangeInfo;
}
export interface PermissionRangeRemoveSuccess {
    success: true;
    id: string;
}
export type PermissionRangeMutationResult = PermissionRangeMutationSuccess | AdapterMutationFailure;
export type PermissionRangeRemoveResult = PermissionRangeRemoveSuccess | AdapterMutationFailure;
export type PermissionRangesListResult = DiscoveryOutput<PermissionRangeInfo>;
