import { DocumentInfo, MutationsApplyInput, MutationsPreviewInput, MutationsPreviewOutput, NodeAddress, PlanReceipt, QueryMatchInput, QueryMatchOutput, TextSelector, NodeSelector, Receipt, TextMutationReceipt, SDMutationReceipt, ExtractResult } from './types/index.js';
import { CommentsAdapter, CommentsApi } from './comments/comments.js';
import { DeleteInput } from './delete/delete.js';
import { FindAdapter } from './find/find.js';
import { SDFindInput, SDFindResult, SDGetInput, SDNodeResult } from './types/sd-envelope.js';
import { FormatApi, FormatRangeInput } from './format/format.js';
import { StylesAdapter, StylesApi } from './styles/index.js';
import { TemplatesAdapter, TemplatesApi } from './templates/index.js';
import { GetNodeAdapter, GetNodeByIdInput } from './get-node/get-node.js';
import { GetAdapter } from './get/get.js';
import { SDDocument } from './types/fragment.js';
import { GetTextAdapter, GetTextInput } from './get-text/get-text.js';
import { GetMarkdownAdapter, GetMarkdownInput } from './get-markdown/get-markdown.js';
import { GetHtmlAdapter, GetHtmlInput } from './get-html/get-html.js';
import { ProjectHtmlAdapter } from './project-html/project-html.js';
import { ProjectMarkdownAdapter } from './project-markdown/project-markdown.js';
import { ProjectHtmlInput, ProjectMarkdownInput, SDContentProjectionResult } from './types/content-projection.js';
import { MarkdownToFragmentAdapter, MarkdownToFragmentInput } from './markdown-to-fragment/markdown-to-fragment.js';
import { HtmlToFragmentAdapter, HtmlToFragmentInput } from './html-to-fragment/html-to-fragment.js';
import { SDHtmlToFragmentResult, SDMarkdownToFragmentResult } from './types/sd-contract.js';
import { InfoAdapter, InfoInput } from './info/info.js';
import { ExtractAdapter, ExtractInput } from './extract/extract.js';
import { ClearContentAdapter, ClearContentInput } from './clear-content/clear-content.js';
import { InsertInput } from './insert/insert.js';
import { ResolveRangeInput, ResolveRangeOutput } from './ranges/ranges.types.js';
import { SelectionApi, SelectionAdapter } from './selection/selection.js';
import { ListsAdapter, ListsApi } from './lists/lists.js';
import { ReplaceInput } from './replace/replace.js';
import { CreateAdapter, CreateApi } from './create/create.js';
import { BlocksAdapter, BlocksApi } from './blocks/blocks.js';
import { TableLocator, TableMutationResult, TablesConvertFromTextInput, TablesMoveInput, TablesSplitInput, TablesConvertToTextInput, TablesSetLayoutInput, TablesInsertRowInput, TablesDeleteRowInput, TablesMoveRowInput, TablesSetRowHeightInput, TablesDistributeRowsInput, TablesSetRowOptionsInput, TablesInsertColumnInput, TablesDeleteColumnInput, TablesSetColumnWidthInput, TablesDistributeColumnsInput, TablesInsertCellInput, TablesDeleteCellInput, TablesMergeCellsInput, TablesUnmergeCellsInput, TablesSplitCellInput, TablesSetCellPropertiesInput, TablesSetCellTextInput, TablesSortInput, TablesSetAltTextInput, TablesSetStyleInput, TablesClearStyleInput, TablesSetStyleOptionInput, TablesSetBorderInput, TablesClearBorderInput, TablesApplyBorderPresetInput, TablesSetShadingInput, TablesClearShadingInput, TablesSetTablePaddingInput, TablesSetCellPaddingInput, TablesSetCellSpacingInput, TablesClearCellSpacingInput, TablesApplyStyleInput, TablesSetBordersInput, TablesSetTableOptionsInput, TablesApplyPresetInput, TablesGetInput, TablesGetOutput, TablesGetCellsInput, TablesGetCellsOutput, TablesGetPropertiesInput, TablesGetPropertiesOutput, TablesGetStylesInput, TablesGetStylesOutput, TablesSetDefaultStyleInput, TablesClearDefaultStyleInput } from './types/table-operations.types.js';
import { TrackChangesAdapter, TrackChangesApi } from './track-changes/track-changes.js';
import { MutationOptions, RevisionGuardOptions, RichContentMutationOptions, WriteAdapter } from './write/write.js';
import { SelectionMutationAdapter } from './selection-mutation.js';
import { CapabilitiesAdapter, DocumentApiCapabilities } from './capabilities/capabilities.js';
import { SDHtmlMarkdownSupportCheckInput, SDHtmlMarkdownSupportCheckResult } from './capabilities/html-markdown-support.js';
import { OperationId } from './contract/types.js';
import { DynamicInvokeRequest, InvokeRequest, InvokeResult } from './contract/operation-registry.js';
import { PlanApi } from './plan/plan.js';
import { HistoryAdapter, HistoryApi } from './history/history.js';
import { DiffAdapter, DiffApi } from './diff/diff.js';
import { ExportAdapter, ExportApi } from './export/export.js';
import { ParagraphsAdapter, ParagraphFormatApi, ParagraphStylesApi } from './paragraphs/paragraphs.js';
import { SectionsAdapter, SectionsApi } from './sections/sections.js';
import { HeaderFootersAdapter, HeaderFootersApi } from './header-footers/header-footers.js';
import { DocumentMutationResult } from './sections/sections.types.js';
import { ImagesAdapter, ImagesApi, CreateImageAdapter } from './images/images.js';
import { TocApi, TocAdapter } from './toc/toc.js';
import { HyperlinksApi, HyperlinksAdapter } from './hyperlinks/hyperlinks.js';
import { ContentControlsApi, ContentControlsAdapter, ContentControlsCreateAdapter } from './content-controls/content-controls.js';
import { BookmarksApi, BookmarksAdapter } from './bookmarks/bookmarks.js';
import { CustomXmlApi, CustomXmlAdapter } from './customXml/customXml.js';
import { AnchoredMetadataApi, AnchoredMetadataAdapter } from './metadata/anchored-metadata.js';
import { ProtectionApi, ProtectionAdapter } from './protection/protection.js';
import { PermissionRangesApi, PermissionRangesAdapter } from './permission-ranges/permission-ranges.js';
import { FootnotesApi, FootnotesAdapter } from './footnotes/footnotes.js';
import { ClipboardApi, ClipboardAdapter } from './clipboard/clipboard.js';
import { CrossRefsApi, CrossRefsAdapter } from './cross-refs/cross-refs.js';
import { IndexApi, IndexAdapter } from './index/index.js';
import { CaptionsApi, CaptionsAdapter } from './captions/captions.js';
import { FieldsApi, FieldsAdapter } from './fields/fields.js';
import { CitationsApi, CitationsAdapter } from './citations/citations.js';
import { AuthoritiesApi, AuthoritiesAdapter } from './authorities/authorities.js';
export * from './types/index.js';
export * from './contract/index.js';
export * from './capabilities/capabilities.js';
export * from './capabilities/html-markdown-support.js';
export * from './inline-semantics/index.js';
export type { HistoryAdapter, HistoryApi } from './history/history.js';
export { executeHistoryGet, executeHistoryUndo, executeHistoryRedo } from './history/history.js';
export type { DiffAdapter, DiffApi } from './diff/diff.js';
export * from './diff/diff.types.js';
export type { ExportAdapter, ExportApi } from './export/export.js';
export * from './export/export.types.js';
export type { SelectionMutationAdapter, SelectionMutationRequest, SelectionInsertRequest, } from './selection-mutation.js';
export type { RangeAnchor, DocumentEdgeAnchor, PointAnchor, RefBoundaryAnchor, ResolveRangeInput, ResolveRangeOutput, RangeBlockPreview, RangePreview, RangeResolverAdapter, ScrollIntoViewInput, ScrollIntoViewOutput, } from './ranges/index.js';
export { executeResolveRange } from './ranges/index.js';
export type { SelectionApi, SelectionAdapter, SelectionCurrentInput, SelectionInfo } from './selection/selection.js';
export { executeSelectionCurrent } from './selection/selection.js';
export type { HeaderFootersAdapter, HeaderFootersApi } from './header-footers/header-footers.js';
export * from './header-footers/header-footers.types.js';
export type { ClearContentAdapter, ClearContentInput } from './clear-content/clear-content.js';
export type { MarkdownToFragmentInput, MarkdownToFragmentAdapter, } from './markdown-to-fragment/markdown-to-fragment.js';
export { executeMarkdownToFragment } from './markdown-to-fragment/markdown-to-fragment.js';
export type { HtmlToFragmentInput, HtmlToFragmentAdapter } from './html-to-fragment/html-to-fragment.js';
export { executeHtmlToFragment } from './html-to-fragment/html-to-fragment.js';
export type { ProjectHtmlAdapter } from './project-html/project-html.js';
export { executeProjectHtml } from './project-html/project-html.js';
export type { ProjectMarkdownAdapter } from './project-markdown/project-markdown.js';
export { executeProjectMarkdown } from './project-markdown/project-markdown.js';
export type { HistoryState, HistoryActionResult, HistoryNoopReason, SDHistoryStatus, SDHistoryCollaborationMeta, } from './history/history.types.js';
export { executeTrackChangesGet, executeTrackChangesList, executeTrackChangesDecide, } from './track-changes/track-changes.js';
export { createPlanApi, type PlanApi, type PlanExecuteInput, type PlanExecuteEntry, type PlanExecuteEntryExpect, type PlanExecuteResult, type PlanEntryReceipt, type PlanEntryReceiptStatus, type PlanExecuteFailure, type PlanCaptureRefMarker, type PlanProjectTextOffsetMarker, } from './plan/plan.js';
export type { DiffSnapshot, DiffPayload, DiffApplyResult, DiffCompareInput, DiffApplyInput, DiffApplyOptions, DiffApplyOperationReceipt, DiffApplyReviewItem, } from './diff/diff.types.js';
export type { GetAdapter } from './get/get.js';
export type { FindAdapter, FindOptions } from './find/find.js';
export type { GetNodeAdapter, GetNodeByIdInput } from './get-node/get-node.js';
export type { GetTextAdapter, GetTextInput } from './get-text/get-text.js';
export type { GetMarkdownAdapter, GetMarkdownInput } from './get-markdown/get-markdown.js';
export type { GetHtmlAdapter, GetHtmlInput } from './get-html/get-html.js';
export type { InfoAdapter, InfoInput } from './info/info.js';
export type { ExtractAdapter, ExtractInput } from './extract/extract.js';
export type { WriteAdapter, WriteRequest, RichContentMutationOptions } from './write/write.js';
export type { FormatInlineAliasApi, FormatInlineAliasInput, FormatBoldInput, FormatItalicInput, FormatRangeInput, FormatUnderlineInput, FormatStrikethroughInput, StyleApplyInput, StyleApplyOptions, } from './format/format.js';
export type { InlineRunPatch, InlineRunPatchKey, InlinePropertyStorage, InlinePropertyType, InlinePropertyCarrier, InlinePropertyRegistryEntry, UnderlinePatch, ShadingPatch, BorderPatch, FitTextPatch, LangPatch, RFontsPatch, EastAsianLayoutPatch, StylisticSetPatch, } from './format/inline-run-patch.js';
export { INLINE_PROPERTY_REGISTRY, INLINE_PROPERTY_KEY_SET, INLINE_PROPERTY_BY_KEY, INLINE_PROPERTY_KEYS_BY_STORAGE, validateInlineRunPatch, buildInlineRunPatchSchema, } from './format/inline-run-patch.js';
export { PROPERTY_REGISTRY, EXCLUDED_KEYS, ALLOWED_KEYS_BY_CHANNEL, getPropertyDefinition, toJsonSchema, buildPatchSchema, buildStateSchema, } from './styles/index.js';
export type { ValueSchema, MergeStrategy, PropertyDefinition, StylesAdapter, StylesApplyInput, StylesApplyRunInput, StylesApplyParagraphInput, StylesApplyOptions, StylesApplyReceipt, StylesBooleanState, StylesNumberState, StylesEnumState, StylesObjectState, StylesArrayState, StylesStateMap, StylesChannel, StylesRunPatch, StylesParagraphPatch, StylesTargetResolution, StylesApplyReceiptSuccess, StylesApplyReceiptFailure, NormalizedStylesApplyOptions, StyleCatalogView, StyleCatalogItemType, StyleCatalogFilterType, StyleProvenance, StyleCatalogDiagnosticSeverity, StyleSourcePartStatus, StyleCatalogUsageStatus, StyleCatalogPreviewStatus, StyleCatalogViewStatus, StyleCatalogItemVisibility, StyleCatalogItemUsage, StyleCatalogItemPreview, StyleCatalogItem, StyleCatalogDefaults, StyleCatalogDiagnostic, StyleCatalogSourceStatus, StylesGetCatalogInput, StylesGetCatalogResult, StylesGetCatalogAdapter, } from './styles/index.js';
export { STYLE_CATALOG_VIEWS, STYLE_CATALOG_FILTER_TYPES, executeStylesGetCatalog, validateStylesGetCatalogInput, } from './styles/index.js';
export type { TemplatesAdapter, TemplatesApi, TemplatesApplyInput, TemplatesApplyOptions, TemplatesApplySource, TemplatesApplySourcePath, TemplatesApplySourceBase64, TemplateBodyPolicy, TemplateScope, NormalizedTemplatesApplyOptions, TemplateScopeReport, TemplateSkipReason, TemplateScopeSkip, TemplateUnsupportedItem, TemplateChangeKind, TemplateChangedPart, TemplateIdMapping, TemplateApplyWarning, TemplatesApplySourceInfo, TemplatesApplyReceiptSuccess, TemplatesApplyFailureCode, TemplatesApplyReceiptFailure, TemplatesApplyReceipt, } from './templates/index.js';
export { executeTemplatesApply } from './templates/index.js';
export type { CreateAdapter, CreateApi } from './create/create.js';
export { executeCreateParagraph, executeCreateHeading, executeCreateTable, executeCreateSectionBreak, executeCreateTableOfContents, } from './create/create.js';
export type { TrackChangesAdapter, TrackChangesApi, TrackChangesGetInput, TrackChangesListInput, TrackChangesAcceptInput, TrackChangesRejectInput, TrackChangesAcceptAllInput, TrackChangesRejectAllInput, TrackChangesRangeInput, ReviewDecideInput, ReviewDecideRangeInput, ReviewDecideTarget, LegacyReviewDecideTarget, ReviewDecisionTarget, } from './track-changes/track-changes.js';
export { validateReviewDecideInput } from './track-changes/track-changes.js';
export type { BlocksAdapter } from './blocks/blocks.js';
export type { ImagesAdapter, ImagesApi, CreateImageAdapter } from './images/images.js';
export type { ImageAddress, ImageCreateLocation, ImageSummary, ImageWrapDistances, ImagePositionInput, ImageAnchorOptionsInput, ImageZOrderInput, CreateImageInput, CreateImageResult, ImagesListInput, ImagesListResult, ImagesGetInput, ImagesDeleteInput, ImagesMutationResult, ImagesMutationSuccessResult, ImagesMutationFailureResult, MoveImageInput, ConvertToInlineInput, ConvertToFloatingInput, SetSizeInput, SetWrapTypeInput, SetWrapSideInput, SetWrapDistancesInput, SetPositionInput, SetAnchorOptionsInput, SetZOrderInput, ScaleInput, SetLockAspectRatioInput, RotateInput, FlipInput, CropInput, ResetCropInput, ReplaceSourceInput, SetAltTextInput, SetDecorativeInput, SetNameInput, SetHyperlinkInput, InsertCaptionInput, UpdateCaptionInput, RemoveCaptionInput, } from './images/images.types.js';
export type { TocApi, TocAdapter } from './toc/toc.js';
export type { BookmarksApi, BookmarksAdapter } from './bookmarks/bookmarks.js';
export type { CustomXmlApi, CustomXmlAdapter, CustomXmlPartsApi, CustomXmlPartsAdapter, } from './customXml/customXml.js';
export type { AnchoredMetadataApi, AnchoredMetadataAdapter } from './metadata/anchored-metadata.js';
export type { ProtectionApi, ProtectionAdapter } from './protection/protection.js';
export * from './protection/protection.types.js';
export type { PermissionRangesApi, PermissionRangesAdapter } from './permission-ranges/permission-ranges.js';
export type * from './permission-ranges/permission-ranges.types.js';
export type { FootnotesApi, FootnotesAdapter } from './footnotes/footnotes.js';
export type { ClipboardApi, ClipboardAdapter } from './clipboard/clipboard.js';
export { executeClipboardParse, executeClipboardInsert, executeClipboardSerializeSelection, } from './clipboard/clipboard.js';
export type { CrossRefsApi, CrossRefsAdapter } from './cross-refs/cross-refs.js';
export type { IndexApi, IndexAdapter } from './index/index.js';
export type { CaptionsApi, CaptionsAdapter } from './captions/captions.js';
export type { FieldsApi, FieldsAdapter } from './fields/fields.js';
export type { CitationsApi, CitationsAdapter } from './citations/citations.js';
export type { AuthoritiesApi, AuthoritiesAdapter } from './authorities/authorities.js';
export type { TocAddress, TocSourceConfig, TocDisplayConfig, TocPreservedSwitches, TocConfigurePatch, TocSwitchConfig, TocDomain, TocListQuery, TocListResult, TocGetInput, TocInfo, TocConfigureInput, TocUpdateInput, TocRemoveInput, TocMutationResult, TocMutationSuccess, TocMutationFailure, TocCreateLocation, CreateTableOfContentsInput, CreateTableOfContentsResult, CreateTableOfContentsSuccess, CreateTableOfContentsFailure, TocEntryAddress, TocEntryInsertionTarget, TocMarkEntryInput, TocUnmarkEntryInput, TocListEntriesQuery, TocListEntriesResult, TocGetEntryInput, TocEntryInfo, TocEditEntryInput, TocEntryMutationResult, TocEntryMutationSuccess, TocEntryMutationFailure, TocEntryDomain, TocEntryProperties, } from './toc/toc.types.js';
export type { HyperlinksApi, HyperlinksAdapter } from './hyperlinks/hyperlinks.js';
export type { ContentControlsApi, ContentControlsAdapter, ContentControlsCreateAdapter, } from './content-controls/content-controls.js';
export type { ContentControlMutationResult, ContentControlMutationSuccess, ContentControlMutationFailure, ContentControlsListResult, ContentControlsListQuery, ContentControlTarget, ContentControlType, ContentControlProperties, ContentControlBinding, ContentControlSymbol, ContentControlListItem, ContentControlAppearance, LockMode, CreateContentControlInput, ContentControlsGetInput, ContentControlsWrapInput, ContentControlsUnwrapInput, ContentControlsDeleteInput, ContentControlsCopyInput, ContentControlsMoveInput, ContentControlsPatchInput, ContentControlsSetLockModeInput, ContentControlsSetTypeInput, ContentControlsGetContentInput, ContentControlsGetContentResult, ContentControlsReplaceContentInput, ContentControlsClearContentInput, ContentControlsAppendContentInput, ContentControlsPrependContentInput, ContentControlsInsertBeforeInput, ContentControlsInsertAfterInput, ContentControlsGetBindingInput, ContentControlsSetBindingInput, ContentControlsClearBindingInput, ContentControlsGetRawPropertiesInput, ContentControlsGetRawPropertiesResult, ContentControlsPatchRawPropertiesInput, RawPatchOp, ContentControlsValidateWordCompatibilityInput, ContentControlsValidateWordCompatibilityResult, WordCompatibilityDiagnostic, ContentControlsNormalizeWordCompatibilityInput, ContentControlsNormalizeTagPayloadInput, ContentControlsListInRangeInput, ContentControlsSelectByTagInput, ContentControlsSelectByTitleInput, ContentControlsListChildrenInput, ContentControlsGetParentInput, ContentControlsTextSetMultilineInput, ContentControlsTextSetValueInput, ContentControlsTextClearValueInput, ContentControlsDateSetValueInput, ContentControlsDateClearValueInput, ContentControlsDateSetDisplayFormatInput, ContentControlsDateSetDisplayLocaleInput, ContentControlsDateSetStorageFormatInput, ContentControlsDateSetCalendarInput, ContentControlsCheckboxGetStateInput, ContentControlsCheckboxGetStateResult, ContentControlsCheckboxSetStateInput, ContentControlsCheckboxToggleInput, ContentControlsCheckboxSetSymbolPairInput, ContentControlsChoiceListGetItemsInput, ContentControlsChoiceListGetItemsResult, ContentControlsChoiceListSetItemsInput, ContentControlsChoiceListSetSelectedInput, ContentControlsRepeatingSectionListItemsInput, ContentControlsRepeatingSectionListItemsResult, ContentControlsRepeatingSectionInsertItemBeforeInput, ContentControlsRepeatingSectionInsertItemAfterInput, ContentControlsRepeatingSectionCloneItemInput, ContentControlsRepeatingSectionDeleteItemInput, ContentControlsRepeatingSectionSetAllowInsertDeleteInput, ContentControlsGroupWrapInput, ContentControlsGroupUngroupInput, ContentControlsPaginationOptions, TextControlProperties, DateControlProperties, CheckboxControlProperties, ChoiceControlProperties, RepeatingSectionControlProperties, } from './content-controls/content-controls.types.js';
export { CONTENT_CONTROL_TYPES, LOCK_MODES, CONTENT_CONTROL_APPEARANCES, } from './content-controls/content-controls.types.js';
export type { HyperlinkTarget, HyperlinkDestination, HyperlinkSpec, HyperlinkPatch, HyperlinkReadProperties, HyperlinkDomain, HyperlinkInfo, HyperlinkMutationResult, HyperlinkMutationSuccess, HyperlinkMutationFailure, HyperlinksListResult, HyperlinksListQuery, HyperlinksGetInput, HyperlinksWrapInput, HyperlinksInsertInput, HyperlinksPatchInput, HyperlinksRemoveInput, } from './hyperlinks/hyperlinks.types.js';
export type * from './bookmarks/bookmarks.types.js';
export type * from './customXml/customXml.types.js';
export type * from './metadata/anchored-metadata.types.js';
export type * from './footnotes/footnotes.types.js';
export type * from './cross-refs/cross-refs.types.js';
export type * from './index/index.types.js';
export type * from './captions/captions.types.js';
export type * from './fields/fields.types.js';
export type * from './citations/citations.types.js';
export type * from './authorities/authorities.types.js';
export type { ListsAdapter } from './lists/lists.js';
export type { SectionsAdapter } from './sections/sections.js';
export type { ParagraphsAdapter, ParagraphFormatApi, ParagraphStylesApi } from './paragraphs/paragraphs.js';
export type { ParagraphTarget, ParagraphBlockType, ParagraphMutationResult, ParagraphMutationSuccess, ParagraphMutationFailure, MutationResolution, ParagraphAlignment, TabStopAlignment, TabStopLeader, BorderSide, ClearBorderSide, LineRule, ParagraphsSetStyleInput, ParagraphSemanticStyleRole, ParagraphsSetStyleRefInput, ParagraphsClearStyleInput, ParagraphsResetDirectFormattingInput, ParagraphsSetAlignmentInput, ParagraphsClearAlignmentInput, ParagraphsSetIndentationInput, ParagraphsClearIndentationInput, ParagraphsSetSpacingInput, ParagraphsClearSpacingInput, ParagraphsSetKeepOptionsInput, ParagraphsSetOutlineLevelInput, ParagraphsSetFlowOptionsInput, ParagraphsSetTabStopInput, ParagraphsClearTabStopInput, ParagraphsClearAllTabStopsInput, ParagraphsSetBorderInput, ParagraphsClearBorderInput, ParagraphsSetShadingInput, ParagraphsClearShadingInput, ParagraphsSetMarkRunPropsInput, ParagraphsSetDirectionInput, ParagraphsClearDirectionInput, ParagraphsSetNumberingInput, ParagraphDirection, AlignmentPolicy, } from './paragraphs/paragraphs.js';
export { PARAGRAPH_ALIGNMENTS, TAB_STOP_ALIGNMENTS, TAB_STOP_LEADERS, BORDER_SIDES, CLEAR_BORDER_SIDES, LINE_RULES, PARAGRAPH_DIRECTIONS, ALIGNMENT_POLICIES, } from './paragraphs/paragraphs.js';
export type { BlockAddress, BlockRange, CanContinueReason, CanJoinReason, JoinDirection, ListInsertInput, ListItemAddress, ListItemInfo, ListKind, ListsAttachInput, ListsCanContinuePreviousInput, ListsCanContinuePreviousResult, ListsCanJoinInput, ListsCanJoinResult, ListsConvertToTextInput, ListsConvertToTextResult, ListsContinuePreviousInput, ListsCreateInput, ListsCreateResult, ListsDetachInput, ListsDetachResult, ListsDeleteInput, ListsDeleteResult, ListsFailureCode, ListsGetInput, ListsInsertResult, ListsJoinInput, ListsJoinResult, ListsListQuery, ListsListResult, ListsMutateItemResult, ListsSeparateInput, ListsSeparateResult, ListsMergeInput, ListsMergeResult, ListsSplitInput, ListsSplitResult, ListsSetLevelInput, ListsSetLevelRestartInput, ListsSetValueInput, ListTargetInput, MutationScope, LevelAlignment, TrailingCharacter, ListPresetId, ListPresetMarker, ListLevelTemplate, ListTemplate, ListsApplyTemplateInput, ListsApplyPresetInput, ListsCaptureTemplateInput, ListsCaptureTemplateResult, ListsCaptureTemplateSuccessResult, ListsSetLevelNumberingInput, ListsSetLevelBulletInput, ListsSetLevelPictureBulletInput, ListsSetLevelAlignmentInput, ListsSetLevelIndentsInput, ListsSetLevelTrailingCharacterInput, ListsSetLevelMarkerFontInput, ListsClearLevelOverridesInput, ListsSetTypeInput, ListStyle, ListLevelStyle, ListLevelLayout, ListsGetStyleInput, ListsGetStyleResult, ListsGetStyleSuccessResult, ListsApplyStyleInput, ListsRestartAtInput, ListsSetLevelNumberStyleInput, ListsSetLevelTextInput, ListsSetLevelStartInput, ListsSetLevelLayoutInput, ListsGetStateInput, ListsGetStateResult, ListsApplyInput, ListsContinueV2Input, ListsRestartV2Input, ListsRemoveV2Input, } from './lists/lists.types.js';
export { LIST_KINDS, LIST_INSERT_POSITIONS, JOIN_DIRECTIONS, MUTATION_SCOPES, LEVEL_ALIGNMENTS, TRAILING_CHARACTERS, LIST_PRESET_IDS, LIST_PRESET_MARKERS, } from './lists/lists.types.js';
export type { CreateSectionBreakInput, CreateSectionBreakResult, DocumentMutationResult, SectionAddress, SectionBorderSpec, SectionBreakCreateLocation, SectionBreakRepresentation, SectionBreakType, SectionColumns, SectionDirection, SectionDomain, SectionHeaderFooterKind, SectionHeaderFooterMargins, SectionHeaderFooterRefs, SectionHeaderFooterVariant, SectionInfo, SectionLineNumbering, SectionLineNumberRestart, SectionMutationResult, SectionOrientation, SectionPageBorders, SectionPageMargins, SectionPageNumbering, SectionPageNumberingChapterSeparator, SectionPageNumberingFormat, SectionPageSetup, SectionRangeDomain, SectionTargetInput, SectionVerticalAlign, SectionsClearHeaderFooterRefInput, SectionsClearPageBordersInput, SectionsGetInput, SectionsListQuery, SectionsListResult, SectionsSetBreakTypeInput, SectionsSetColumnsInput, SectionsSetHeaderFooterMarginsInput, SectionsSetHeaderFooterRefInput, SectionsSetLineNumberingInput, SectionsSetLinkToPreviousInput, SectionsSetOddEvenHeadersFootersInput, SectionsSetPageBordersInput, SectionsSetPageMarginsInput, SectionsSetPageNumberingInput, SectionsSetPageSetupInput, SectionsSetSectionDirectionInput, SectionsSetTitlePageInput, SectionsSetVerticalAlignInput, } from './sections/sections.types.js';
export type { CommentsCreateReceipt, CommentsCreateInput, CommentCreateAttributionInput, CommentsPatchInput, CommentsDeleteInput, CommentsAdapter, CommentsApi, GetCommentInput, TrackedChangeCommentTarget, TrackedChangeCommentTargetSide, TextSearchCommentTarget, AddCommentInput, EditCommentInput, ReplyToCommentInput, MoveCommentInput, ResolveCommentInput, ReopenCommentInput, RemoveCommentInput, SetCommentInternalInput, GoToCommentInput, SetCommentActiveInput, } from './comments/comments.js';
export { executeCommentsCreate, executeCommentsPatch, executeCommentsDelete, executeGetComment, executeListComments, } from './comments/comments.js';
export type { CommentInfo, CommentDomain, CommentMetadata, CommentMetadataValue, CommentsListQuery, CommentsListResult, CommentTrackedChangeSide, CommentTrackedChangeLink, CommentTarget, } from './comments/comments.types.js';
export type { BlocksApi } from './blocks/blocks.js';
export { executeBlocksList, executeBlocksDelete, executeBlocksDeleteRange, executeBlocksSplit, executeBlocksMerge, executeBlocksMove, } from './blocks/blocks.js';
export { executeListsIndent, executeListsOutdent, executeListsGetState, executeListsApply, executeListsContinueV2, executeListsRestartV2, executeListsRemoveV2, } from './lists/lists.js';
export { DocumentApiValidationError } from './errors.js';
export { textReceiptToSDReceipt, buildStructuralReceipt } from './receipt-bridge.js';
export type { MutationReceiptBridgeContext, StructuralReceiptParams } from './receipt-bridge.js';
export { isBlockNodeAddress } from './validation-primitives.js';
export type { InsertInput, InsertContentType, TextInsertInput, RichContentInsertInput, LegacyInsertInput, } from './insert/insert.js';
export { isStructuralInsertInput } from './insert/insert.js';
export type { ReplaceInput, TextReplaceInput, RichContentReplaceInput } from './replace/replace.js';
export { executeReplace, isStructuralReplaceInput, isRichContentReplaceInput } from './replace/replace.js';
export { executeFind } from './find/find.js';
export { validateDocumentFragment, validateSDFragment } from './validation/fragment-validator.js';
export type { DeleteInput } from './delete/delete.js';
export interface TablesApi {
    convertFromText(input: TablesConvertFromTextInput, options?: MutationOptions): TableMutationResult;
    delete(input: TableLocator, options?: MutationOptions): TableMutationResult;
    clearContents(input: TableLocator, options?: MutationOptions): TableMutationResult;
    move(input: TablesMoveInput, options?: MutationOptions): TableMutationResult;
    split(input: TablesSplitInput, options?: MutationOptions): TableMutationResult;
    convertToText(input: TablesConvertToTextInput, options?: MutationOptions): TableMutationResult;
    setLayout(input: TablesSetLayoutInput, options?: MutationOptions): TableMutationResult;
    insertRow(input: TablesInsertRowInput, options?: MutationOptions): TableMutationResult;
    deleteRow(input: TablesDeleteRowInput, options?: MutationOptions): TableMutationResult;
    moveRow(input: TablesMoveRowInput, options?: MutationOptions): TableMutationResult;
    setRowHeight(input: TablesSetRowHeightInput, options?: MutationOptions): TableMutationResult;
    distributeRows(input: TablesDistributeRowsInput, options?: MutationOptions): TableMutationResult;
    setRowOptions(input: TablesSetRowOptionsInput, options?: MutationOptions): TableMutationResult;
    insertColumn(input: TablesInsertColumnInput, options?: MutationOptions): TableMutationResult;
    deleteColumn(input: TablesDeleteColumnInput, options?: MutationOptions): TableMutationResult;
    setColumnWidth(input: TablesSetColumnWidthInput, options?: MutationOptions): TableMutationResult;
    distributeColumns(input: TablesDistributeColumnsInput, options?: MutationOptions): TableMutationResult;
    insertCell(input: TablesInsertCellInput, options?: MutationOptions): TableMutationResult;
    deleteCell(input: TablesDeleteCellInput, options?: MutationOptions): TableMutationResult;
    mergeCells(input: TablesMergeCellsInput, options?: MutationOptions): TableMutationResult;
    unmergeCells(input: TablesUnmergeCellsInput, options?: MutationOptions): TableMutationResult;
    splitCell(input: TablesSplitCellInput, options?: MutationOptions): TableMutationResult;
    setCellProperties(input: TablesSetCellPropertiesInput, options?: MutationOptions): TableMutationResult;
    setCellText(input: TablesSetCellTextInput, options?: MutationOptions): TableMutationResult;
    sort(input: TablesSortInput, options?: MutationOptions): TableMutationResult;
    setAltText(input: TablesSetAltTextInput, options?: MutationOptions): TableMutationResult;
    setStyle(input: TablesSetStyleInput, options?: MutationOptions): TableMutationResult;
    clearStyle(input: TablesClearStyleInput, options?: MutationOptions): TableMutationResult;
    setStyleOption(input: TablesSetStyleOptionInput, options?: MutationOptions): TableMutationResult;
    setBorder(input: TablesSetBorderInput, options?: MutationOptions): TableMutationResult;
    clearBorder(input: TablesClearBorderInput, options?: MutationOptions): TableMutationResult;
    applyBorderPreset(input: TablesApplyBorderPresetInput, options?: MutationOptions): TableMutationResult;
    setShading(input: TablesSetShadingInput, options?: MutationOptions): TableMutationResult;
    clearShading(input: TablesClearShadingInput, options?: MutationOptions): TableMutationResult;
    setTablePadding(input: TablesSetTablePaddingInput, options?: MutationOptions): TableMutationResult;
    setCellPadding(input: TablesSetCellPaddingInput, options?: MutationOptions): TableMutationResult;
    setCellSpacing(input: TablesSetCellSpacingInput, options?: MutationOptions): TableMutationResult;
    clearCellSpacing(input: TablesClearCellSpacingInput, options?: MutationOptions): TableMutationResult;
    applyStyle(input: TablesApplyStyleInput, options?: MutationOptions): TableMutationResult;
    setBorders(input: TablesSetBordersInput, options?: MutationOptions): TableMutationResult;
    setTableOptions(input: TablesSetTableOptionsInput, options?: MutationOptions): TableMutationResult;
    applyPreset(input: TablesApplyPresetInput, options?: MutationOptions): TableMutationResult;
    get(input: TablesGetInput): TablesGetOutput;
    getCells(input: TablesGetCellsInput): TablesGetCellsOutput;
    getProperties(input: TablesGetPropertiesInput): TablesGetPropertiesOutput;
    getStyles(input?: TablesGetStylesInput): TablesGetStylesOutput;
    setDefaultStyle(input: TablesSetDefaultStyleInput, options?: MutationOptions): DocumentMutationResult;
    clearDefaultStyle(input?: TablesClearDefaultStyleInput, options?: MutationOptions): DocumentMutationResult;
}
export type TablesAdapter = Omit<TablesApi, 'moveRow'> & {
    moveRow?: TablesApi['moveRow'];
};
/**
 * Callable capability accessor returned by `createDocumentApi`.
 *
 * Can be invoked directly (`capabilities()`) or via the `.get()` alias.
 */
export interface CapabilitiesApi {
    (): DocumentApiCapabilities;
    get(): DocumentApiCapabilities;
    check(input: SDHtmlMarkdownSupportCheckInput): Promise<SDHtmlMarkdownSupportCheckResult>;
}
export interface QueryApi {
    /** Accepts canonical nested input or a selector shorthand normalized to `{ select: ... }` internally. */
    match(input: QueryMatchInput | TextSelector | NodeSelector): QueryMatchOutput;
}
export interface MutationsApi {
    preview(input: MutationsPreviewInput): MutationsPreviewOutput;
    apply(input: MutationsApplyInput): PlanReceipt;
}
export interface RangesApi {
    resolve(input: ResolveRangeInput): ResolveRangeOutput;
}
export interface RangesAdapter {
    resolve(input: ResolveRangeInput): ResolveRangeOutput;
}
export interface QueryAdapter {
    match(input: QueryMatchInput): QueryMatchOutput;
}
export interface MutationsAdapter {
    preview(input: MutationsPreviewInput): MutationsPreviewOutput;
    apply(input: MutationsApplyInput): PlanReceipt;
}
/**
 * The Document API interface for querying and inspecting document nodes.
 */
export interface DocumentApi {
    /**
     * Read the full document as an SDDocument structure.
     * @param input - Get input with optional read options.
     * @returns An SDDocument with body content projected into SDM/1 canonical shapes.
     */
    get(input: SDGetInput): SDDocument;
    /**
     * Find nodes in the document matching an SDFindInput.
     * @param input - The find input with selector, pagination, and scope.
     * @returns An SDFindResult with matching SDNodeResult items.
     */
    find(input: SDFindInput): SDFindResult;
    /**
     * Get a node by its address as an SDNodeResult.
     * @param address - The node address to resolve.
     * @returns SDNodeResult with the projected node and its address.
     */
    getNode(address: NodeAddress): SDNodeResult;
    /**
     * Get a block node by its ID as an SDNodeResult.
     * @param input - The node-id input payload.
     * @returns SDNodeResult with the projected node and its address.
     */
    getNodeById(input: GetNodeByIdInput): SDNodeResult;
    /**
     * Return the full document text content.
     */
    getText(input: GetTextInput): string;
    /**
     * Return the full document content as a Markdown string.
     */
    getMarkdown(input: GetMarkdownInput): string;
    /**
     * Return the full document content as an HTML string.
     */
    getHtml(input: GetHtmlInput): string;
    projectHtml(input: ProjectHtmlInput): Promise<SDContentProjectionResult<'html'>>;
    projectMarkdown(input: ProjectMarkdownInput): Promise<SDContentProjectionResult<'markdown'>>;
    /**
     * Convert a Markdown string into an SDM/1 structural fragment.
     */
    markdownToFragment(input: MarkdownToFragmentInput): SDMarkdownToFragmentResult;
    /**
     * Convert an HTML string into an SDM/1 structural fragment.
     */
    htmlToFragment(input: HtmlToFragmentInput): SDHtmlToFragmentResult;
    /**
     * Return document summary info including document counts and capabilities.
     */
    info(input: InfoInput): DocumentInfo;
    /**
     * Extract all document content with stable IDs for RAG pipelines.
     * Returns blocks with full text, comments, and tracked changes.
     */
    extract(input: ExtractInput): ExtractResult;
    /**
     * Clear all document body content, leaving a single empty paragraph.
     */
    clearContent(input: ClearContentInput, options?: RevisionGuardOptions): Receipt;
    /**
     * Comment operations.
     */
    comments: CommentsApi;
    /**
     * Insert content at a target location.
     * If target is omitted, inserts at the end of the document.
     */
    insert(input: InsertInput, options?: RichContentMutationOptions): SDMutationReceipt;
    /**
     * Replace text at a target range.
     */
    replace(input: ReplaceInput, options?: RichContentMutationOptions): SDMutationReceipt;
    /**
     * Delete text at a target range.
     */
    delete(input: DeleteInput, options?: MutationOptions): TextMutationReceipt;
    /**
     * Formatting operations (inline and paragraph direct formatting).
     */
    format: FormatApi & {
        paragraph: ParagraphFormatApi;
    };
    /**
     * Legacy root-level alias for inline range formatting.
     *
     * Routes to {@link DocumentApi.format.apply}.
     */
    formatRange(input: FormatRangeInput, options?: MutationOptions): TextMutationReceipt;
    /**
     * Stylesheet operations (docDefaults, style definitions, paragraph style references).
     */
    styles: StylesApi & {
        paragraph: ParagraphStylesApi;
    };
    /**
     * Template/substrate operations (apply detected DOCX substrate from a source package).
     */
    templates: TemplatesApi;
    /**
     * Tracked-change operations (list, get, decide).
     */
    trackChanges: TrackChangesApi;
    /**
     * Block-level structural operations (list, delete, delete-range).
     */
    blocks: BlocksApi;
    /**
     * Structural creation operations.
     */
    create: CreateApi;
    /**
     * List item operations.
     */
    lists: ListsApi;
    /**
     * Section structure and page setup operations.
     */
    sections: SectionsApi;
    /**
     * Table operations.
     */
    tables: TablesApi;
    /**
     * Table of contents operations.
     */
    toc: TocApi;
    /**
     * Image lifecycle and placement operations.
     */
    images: ImagesApi;
    /**
     * Hyperlink discovery, creation, and metadata management.
     */
    hyperlinks: HyperlinksApi;
    /**
     * Header/footer structure, references, and part lifecycle operations.
     */
    headerFooters: HeaderFootersApi;
    /**
     * Content control (SDT) discovery, mutation, and typed-control operations.
     */
    contentControls: ContentControlsApi;
    /**
     * Bookmark operations.
     */
    bookmarks: BookmarksApi;
    /**
     * Footnote and endnote operations.
     */
    footnotes: FootnotesApi;
    /**
     * Clipboard parse, insert, and selection serialization operations.
     */
    clipboard: ClipboardApi;
    /**
     * Cross-reference field operations.
     */
    crossRefs: CrossRefsApi;
    /**
     * Index (INDEX field) and XE entry operations.
     */
    index: IndexApi;
    /**
     * Caption paragraph operations.
     */
    captions: CaptionsApi;
    /**
     * Raw field operations.
     */
    fields: FieldsApi;
    /**
     * Citation, source, and bibliography operations.
     */
    citations: CitationsApi;
    /**
     * Table of authorities and TA entry operations.
     */
    authorities: AuthoritiesApi;
    /**
     * Selector-based query with cardinality contracts for mutation targeting.
     */
    query: QueryApi;
    /**
     * Deterministic range construction from explicit document anchors.
     */
    ranges: RangesApi;
    /**
     * Read the editor's current selection as a portable SelectionInfo.
     * Primitive for custom UIs (toolbars, sidebars, popovers).
     */
    selection: SelectionApi;
    /**
     * Mutation plan engine: preview and apply atomic mutation plans.
     */
    mutations: MutationsApi;
    /**
     * Throughput-oriented batch executor with stepwise operation semantics.
     */
    plan: PlanApi;
    /**
     * Snapshot-based document comparison and replay.
     */
    diff: DiffApi;
    /**
     * Modeful DOCX export (review-preserving / final / original) with a
     * structured degradation report.
     */
    export: ExportApi;
    /**
     * History operations (undo/redo) scoped to the active editor instance.
     * Session-scoped: reflects the runtime undo/redo stack, not persistent state.
     */
    history: HistoryApi;
    /**
     * Document-level protection state and editing restriction operations.
     */
    protection: ProtectionApi;
    /**
     * Permission range exception operations for protected documents.
     */
    permissionRanges: PermissionRangesApi;
    /**
     * Custom XML Data Storage Part operations (ECMA-376 §15.2.5, §15.2.6).
     * Read and write raw custom XML parts in the OOXML package.
     */
    customXml: CustomXmlApi;
    /**
     * Anchored metadata — attach a JSON payload to a span of text and read
     * it back across DOCX round-trips. Backed by hidden inline content
     * controls and namespaced Custom XML Data Storage Parts; consumers see
     * one operation set.
     */
    metadata: AnchoredMetadataApi;
    /**
     * Runtime capability introspection.
     *
     * Callable directly (`capabilities()`) or via `.get()`.
     */
    capabilities: CapabilitiesApi;
    /**
     * Dynamically dispatch any operation by its operation ID.
     *
     * For TypeScript consumers, the return type narrows based on the operationId.
     * For dynamic callers (AI agents, automation), accepts {@link DynamicInvokeRequest}
     * with `unknown` input. Invalid inputs produce adapter-level errors.
     *
     * @param request - Operation envelope with operationId, input, and optional options.
     * @returns The operation-specific result payload from the dispatched handler.
     * @throws {Error} When operationId is unknown.
     */
    invoke<T extends OperationId>(request: InvokeRequest<T>): InvokeResult<T>;
    invoke(request: DynamicInvokeRequest): unknown;
}
export interface DocumentApiAdapters {
    get: GetAdapter;
    find: FindAdapter;
    getNode: GetNodeAdapter;
    getText: GetTextAdapter;
    getMarkdown: GetMarkdownAdapter;
    getHtml: GetHtmlAdapter;
    projectHtml?: ProjectHtmlAdapter;
    projectMarkdown?: ProjectMarkdownAdapter;
    markdownToFragment: MarkdownToFragmentAdapter;
    htmlToFragment?: HtmlToFragmentAdapter;
    info: InfoAdapter;
    extract: ExtractAdapter;
    clearContent: ClearContentAdapter;
    capabilities: CapabilitiesAdapter;
    comments: CommentsAdapter;
    write: WriteAdapter;
    selectionMutation: SelectionMutationAdapter;
    styles: StylesAdapter;
    templates: TemplatesAdapter;
    trackChanges: TrackChangesAdapter;
    create: CreateAdapter;
    blocks: BlocksAdapter;
    lists: ListsAdapter;
    sections: SectionsAdapter;
    paragraphs: ParagraphsAdapter;
    tables: TablesAdapter;
    toc: TocAdapter;
    images: ImagesAdapter & CreateImageAdapter;
    hyperlinks: HyperlinksAdapter;
    headerFooters: HeaderFootersAdapter;
    contentControls: ContentControlsAdapter & ContentControlsCreateAdapter;
    bookmarks?: BookmarksAdapter;
    footnotes?: FootnotesAdapter;
    clipboard?: ClipboardAdapter;
    crossRefs?: CrossRefsAdapter;
    index?: IndexAdapter;
    captions?: CaptionsAdapter;
    fields?: FieldsAdapter;
    citations?: CitationsAdapter;
    authorities?: AuthoritiesAdapter;
    ranges: RangesAdapter;
    /**
     * Optional: when omitted, `editor.doc.selection.*` throws
     * `SELECTION_ADAPTER_UNAVAILABLE`. All first-party engines register one;
     * external consumers constructing an adapter bag manually should only
     * need this if they invoke selection operations.
     */
    selection?: SelectionAdapter;
    query: QueryAdapter;
    mutations: MutationsAdapter;
    diff: DiffAdapter;
    /** Modeful DOCX export. Optional; gated when the engine does not provide it. */
    export?: ExportAdapter;
    history: HistoryAdapter;
    protection: ProtectionAdapter;
    permissionRanges: PermissionRangesAdapter;
    /** Custom XML Data Storage Part operations. Optional; not all engines support custom XML. */
    customXml?: CustomXmlAdapter;
    /**
     * Anchored-metadata operations (metadata.*). Optional; not all engines
     * support attaching JSON metadata to anchored spans.
     */
    metadata?: AnchoredMetadataAdapter;
}
export declare function createDocumentApi(adapters: DocumentApiAdapters): DocumentApi;
