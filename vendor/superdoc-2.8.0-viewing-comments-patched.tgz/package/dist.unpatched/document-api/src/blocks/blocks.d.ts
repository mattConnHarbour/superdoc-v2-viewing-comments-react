import { MutationOptions } from '../write/write.js';
import { BlocksDeleteInput, BlocksDeleteResult, BlocksListInput, BlocksListResult, BlocksDeleteRangeInput, BlocksDeleteRangeResult, BlocksMergeInput, BlocksMergeResult, BlocksMoveInput, BlocksMoveResult, BlocksSplitInput, BlocksSplitResult } from '../types/blocks.types.js';
export interface BlocksApi {
    list(input?: BlocksListInput): BlocksListResult;
    delete(input: BlocksDeleteInput, options?: MutationOptions): BlocksDeleteResult;
    deleteRange(input: BlocksDeleteRangeInput, options?: MutationOptions): BlocksDeleteRangeResult;
    /** Split a paragraph at a visible-text offset. */
    split(input: BlocksSplitInput, options?: MutationOptions): BlocksSplitResult;
    /** Merge two adjacent paragraphs in the same story. */
    merge(input: BlocksMergeInput, options?: MutationOptions): BlocksMergeResult;
    /** Move a paragraph within the same story. */
    move(input: BlocksMoveInput, options?: MutationOptions): BlocksMoveResult;
}
export interface BlocksAdapter {
    list(input?: BlocksListInput): BlocksListResult;
    delete(input: BlocksDeleteInput, options?: MutationOptions): BlocksDeleteResult;
    deleteRange(input: BlocksDeleteRangeInput, options?: MutationOptions): BlocksDeleteRangeResult;
    /** Structural block operations. Engines that don't support them
     * may reject with CAPABILITY_UNAVAILABLE. */
    split?(input: BlocksSplitInput, options?: MutationOptions): BlocksSplitResult;
    merge?(input: BlocksMergeInput, options?: MutationOptions): BlocksMergeResult;
    move?(input: BlocksMoveInput, options?: MutationOptions): BlocksMoveResult;
}
export declare function executeBlocksList(adapter: BlocksAdapter, input?: BlocksListInput): BlocksListResult;
export declare function executeBlocksDelete(adapter: BlocksAdapter, input: BlocksDeleteInput, options?: MutationOptions): BlocksDeleteResult;
export declare function executeBlocksDeleteRange(adapter: BlocksAdapter, input: BlocksDeleteRangeInput, options?: MutationOptions): BlocksDeleteRangeResult;
export declare function executeBlocksSplit(adapter: BlocksAdapter, input: BlocksSplitInput, options?: MutationOptions): BlocksSplitResult;
export declare function executeBlocksMerge(adapter: BlocksAdapter, input: BlocksMergeInput, options?: MutationOptions): BlocksMergeResult;
export declare function executeBlocksMove(adapter: BlocksAdapter, input: BlocksMoveInput, options?: MutationOptions): BlocksMoveResult;
