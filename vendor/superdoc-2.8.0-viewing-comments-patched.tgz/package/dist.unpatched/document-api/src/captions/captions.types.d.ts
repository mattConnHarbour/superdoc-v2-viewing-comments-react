import { BlockNodeAddress } from '../types/base.js';
import { AdapterMutationFailure } from '../types/adapter-result.js';
import { DiscoveryOutput } from '../types/discovery.js';
export interface CaptionAddress {
    kind: 'block';
    nodeType: 'paragraph';
    nodeId: string;
}
export interface CaptionListInput {
    label?: string;
    limit?: number;
    offset?: number;
}
export interface CaptionGetInput {
    target: CaptionAddress;
}
export interface CaptionInsertInput {
    adjacentTo: BlockNodeAddress;
    position: 'above' | 'below';
    label: string;
    text?: string;
}
export interface CaptionUpdateInput {
    target: CaptionAddress;
    patch: {
        text?: string;
    };
}
export interface CaptionRemoveInput {
    target: CaptionAddress;
}
export interface CaptionConfigureInput {
    label: string;
    format?: 'decimal' | 'lowerRoman' | 'upperRoman' | 'lowerLetter' | 'upperLetter';
    includeChapter?: boolean;
    chapterStyle?: string;
}
export interface CaptionInfo {
    address: CaptionAddress;
    label: string;
    number: number;
    text: string;
    instruction: string;
}
export interface CaptionDomain {
    address: CaptionAddress;
    label: string;
    number: number;
    text: string;
    instruction: string;
}
export interface CaptionMutationSuccess {
    success: true;
    caption: CaptionAddress;
}
export type CaptionMutationResult = CaptionMutationSuccess | AdapterMutationFailure;
export interface CaptionConfigSuccess {
    success: true;
}
export type CaptionConfigResult = CaptionConfigSuccess | AdapterMutationFailure;
export type CaptionsListResult = DiscoveryOutput<CaptionDomain>;
