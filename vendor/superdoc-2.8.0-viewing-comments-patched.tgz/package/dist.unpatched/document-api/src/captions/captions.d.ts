import { MutationOptions } from '../write/write.js';
import { CaptionListInput, CaptionsListResult, CaptionGetInput, CaptionInfo, CaptionInsertInput, CaptionUpdateInput, CaptionRemoveInput, CaptionMutationResult, CaptionConfigureInput, CaptionConfigResult } from './captions.types.js';
export interface CaptionsApi {
    list(input?: CaptionListInput): CaptionsListResult;
    get(input: CaptionGetInput): CaptionInfo;
    insert(input: CaptionInsertInput, options?: MutationOptions): CaptionMutationResult;
    update(input: CaptionUpdateInput, options?: MutationOptions): CaptionMutationResult;
    remove(input: CaptionRemoveInput, options?: MutationOptions): CaptionMutationResult;
    configure(input: CaptionConfigureInput, options?: MutationOptions): CaptionConfigResult;
}
export type CaptionsAdapter = CaptionsApi;
export declare function executeCaptionsList(adapter: CaptionsAdapter, input?: CaptionListInput): CaptionsListResult;
export declare function executeCaptionsGet(adapter: CaptionsAdapter, input: CaptionGetInput): CaptionInfo;
export declare function executeCaptionsInsert(adapter: CaptionsAdapter, input: CaptionInsertInput, options?: MutationOptions): CaptionMutationResult;
export declare function executeCaptionsUpdate(adapter: CaptionsAdapter, input: CaptionUpdateInput, options?: MutationOptions): CaptionMutationResult;
export declare function executeCaptionsRemove(adapter: CaptionsAdapter, input: CaptionRemoveInput, options?: MutationOptions): CaptionMutationResult;
export declare function executeCaptionsConfigure(adapter: CaptionsAdapter, input: CaptionConfigureInput, options?: MutationOptions): CaptionConfigResult;
