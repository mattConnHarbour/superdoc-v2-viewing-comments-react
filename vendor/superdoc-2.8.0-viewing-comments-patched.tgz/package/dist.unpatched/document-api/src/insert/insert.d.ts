import { RichContentMutationOptions, WriteAdapter } from '../write/write.js';
import { SelectionTarget, TargetLocator, SDMutationReceipt } from '../types/index.js';
import { SDInsertInput } from '../types/structural-input.js';
import { StoryLocator } from '../types/story.types.js';
import { BlockNodeAddress } from '../types/base.js';
import { Placement } from '../types/placement.js';
import { SelectionMutationAdapter } from '../selection-mutation.js';
/** Content format for the text insert operation payload. */
export type InsertContentType = 'text' | 'markdown' | 'html';
type OptionalInsertLocator = TargetLocator | {
    target?: undefined;
    ref?: undefined;
};
/** Text-based input for the insert operation. */
export type TextInsertInput = OptionalInsertLocator & {
    /** Optional insertion target (SelectionTarget). When omitted, inserts at the end of the document. */
    target?: SelectionTarget;
    /** Optional mutation ref returned by a prior find/query. Mutually exclusive with target. */
    ref?: string;
    /** The content to insert. Interpreted according to {@link TextInsertInput.type}. */
    value: string;
    /** Content format. Defaults to `'text'` when omitted. */
    type?: InsertContentType;
    /** Target a specific document story (body, header, footer, footnote, endnote). */
    in?: StoryLocator;
};
/**
 * Type-safe input for markdown/html inserts with block-level positioning.
 * Accepts BlockNodeAddress targets and placement (routed through the structural insert path).
 */
export type RichContentInsertInput = {
    target?: SelectionTarget | BlockNodeAddress;
    ref?: string;
    value: string;
    type: 'markdown' | 'html';
    placement?: Placement;
    in?: StoryLocator;
};
/** @deprecated Use {@link TextInsertInput} instead. */
export type LegacyInsertInput = TextInsertInput;
/**
 * Input payload for the `doc.insert` operation.
 *
 * Discrimination: presence of `content` (structural) vs `value` (text string).
 * These are mutually exclusive: providing both is an error.
 */
export type InsertInput = TextInsertInput | RichContentInsertInput | SDInsertInput;
export declare function isRichContentInsertInput(input: InsertInput): input is RichContentInsertInput;
/** Returns true when the input uses the structural SDFragment shape. */
export declare function isStructuralInsertInput(input: InsertInput): input is SDInsertInput;
/**
 * Validates InsertInput as either text or structural shape.
 *
 * Validation order:
 * 0. Input shape guard (must be non-null plain object)
 * 1. Union conflict detection (mutually exclusive discriminants)
 * 2. Shape-specific field and type validation
 */
export declare function validateInsertInput(input: unknown): asserts input is InsertInput;
/**
 * Executes an insert operation, routing to the appropriate adapter path.
 *
 * - Text inserts with `target` or `ref` route through the SelectionMutationAdapter.
 * - Structural inserts (SDFragment) and non-text content types route through WriteAdapter.
 * - Text inserts without a locator append at the document end via WriteAdapter.
 *
 * @param selectionAdapter - Adapter for target/ref-based text mutations.
 * @param writeAdapter - Adapter for structural and untargeted writes.
 * @param input - Insert payload (text string or structural SDFragment).
 * @param options - Optional mutation options (changeMode, dryRun, expectedRevision).
 * @returns Receipt indicating success/failure and mutation metadata.
 */
export declare function executeInsert(selectionAdapter: SelectionMutationAdapter, writeAdapter: WriteAdapter, input: InsertInput, options?: RichContentMutationOptions): SDMutationReceipt;
export {};
