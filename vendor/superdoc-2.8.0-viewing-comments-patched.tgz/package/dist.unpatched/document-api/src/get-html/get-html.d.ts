import { SDProjectionReadInput } from '../types/content-projection.js';
export interface GetHtmlInput extends SDProjectionReadInput {
    /**
     * Accepted for compatibility and ignored by V2. V2 always emits canonical
     * nested semantic lists.
     *
     * @deprecated replaceWith=canonical nested V2 output compat-indefinitely=existing callers may keep passing the option
     */
    unflattenLists?: boolean;
}
/**
 * Engine-specific adapter that the getHtml API delegates to.
 */
export interface GetHtmlAdapter {
    /**
     * Return the full document content as an HTML string.
     */
    getHtml(input: GetHtmlInput): string;
}
/**
 * Execute a getHtml operation via the provided adapter.
 *
 * @param adapter - Engine-specific getHtml adapter.
 * @param input - Canonical getHtml input object.
 * @returns The full document content as an HTML string.
 */
export declare function executeGetHtml(adapter: GetHtmlAdapter, input: GetHtmlInput): string;
