import { MutationOptions } from '../write/write.js';
import { BookmarkGetInput, BookmarkInfo, BookmarkInsertInput, BookmarkRenameInput, BookmarkRemoveInput, BookmarkMutationResult, BookmarkListInput, BookmarksListResult } from './bookmarks.types.js';
export interface BookmarksApi {
    list(query?: BookmarkListInput): BookmarksListResult;
    get(input: BookmarkGetInput): BookmarkInfo;
    insert(input: BookmarkInsertInput, options?: MutationOptions): BookmarkMutationResult;
    rename(input: BookmarkRenameInput, options?: MutationOptions): BookmarkMutationResult;
    remove(input: BookmarkRemoveInput, options?: MutationOptions): BookmarkMutationResult;
}
export type BookmarksAdapter = BookmarksApi;
export declare function executeBookmarksList(adapter: BookmarksAdapter, query?: BookmarkListInput): BookmarksListResult;
export declare function executeBookmarksGet(adapter: BookmarksAdapter, input: BookmarkGetInput): BookmarkInfo;
export declare function executeBookmarksInsert(adapter: BookmarksAdapter, input: BookmarkInsertInput, options?: MutationOptions): BookmarkMutationResult;
export declare function executeBookmarksRename(adapter: BookmarksAdapter, input: BookmarkRenameInput, options?: MutationOptions): BookmarkMutationResult;
export declare function executeBookmarksRemove(adapter: BookmarksAdapter, input: BookmarkRemoveInput, options?: MutationOptions): BookmarkMutationResult;
