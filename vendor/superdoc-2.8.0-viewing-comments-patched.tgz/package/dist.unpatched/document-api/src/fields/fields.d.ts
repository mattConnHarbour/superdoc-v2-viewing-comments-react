import { MutationOptions } from '../write/write.js';
import { FieldGetInput, FieldInfo, FieldInsertInput, FieldRebuildInput, FieldRemoveInput, FieldMutationResult, FieldListInput, FieldsListResult } from './fields.types.js';
export interface FieldsApi {
    list(query?: FieldListInput): FieldsListResult;
    get(input: FieldGetInput): FieldInfo;
    insert(input: FieldInsertInput, options?: MutationOptions): FieldMutationResult;
    rebuild(input: FieldRebuildInput, options?: MutationOptions): FieldMutationResult;
    remove(input: FieldRemoveInput, options?: MutationOptions): FieldMutationResult;
}
export type FieldsAdapter = FieldsApi;
export declare function executeFieldsList(adapter: FieldsAdapter, query?: FieldListInput): FieldsListResult;
export declare function executeFieldsGet(adapter: FieldsAdapter, input: FieldGetInput): FieldInfo;
export declare function executeFieldsInsert(adapter: FieldsAdapter, input: FieldInsertInput, options?: MutationOptions): FieldMutationResult;
export declare function executeFieldsRebuild(adapter: FieldsAdapter, input: FieldRebuildInput, options?: MutationOptions): FieldMutationResult;
export declare function executeFieldsRemove(adapter: FieldsAdapter, input: FieldRemoveInput, options?: MutationOptions): FieldMutationResult;
