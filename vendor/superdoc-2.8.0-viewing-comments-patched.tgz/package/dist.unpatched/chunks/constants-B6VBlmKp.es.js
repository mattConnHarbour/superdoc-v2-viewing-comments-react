//#region src/core/pdf/helpers/constants.js
var PDF_TO_CSS_UNITS = 96 / 72;
//#endregion
export { PDF_TO_CSS_UNITS as t };
