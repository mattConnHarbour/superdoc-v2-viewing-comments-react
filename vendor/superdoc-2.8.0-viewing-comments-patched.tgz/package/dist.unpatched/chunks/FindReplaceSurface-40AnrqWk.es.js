import { t as _plugin_vue_export_helper_default } from "./_plugin-vue_export-helper-BOaGB7Aw.es.js";
import { computed, createCommentVNode, createElementBlock, createElementVNode, normalizeClass, onMounted, openBlock, ref, toDisplayString, withKeys, withModifiers } from "vue";
//#region src/components/surfaces/FindReplaceSurface.vue
var _hoisted_1 = ["onKeydown"];
var _hoisted_2 = { class: "sd-find-replace__row" };
var _hoisted_3 = [
	"title",
	"aria-label",
	"aria-expanded"
];
var _hoisted_4 = [
	"value",
	"placeholder",
	"aria-label"
];
var _hoisted_5 = {
	key: 0,
	class: "sd-find-replace__count"
};
var _hoisted_6 = [
	"title",
	"aria-label",
	"aria-pressed"
];
var _hoisted_7 = [
	"title",
	"aria-label",
	"aria-pressed"
];
var _hoisted_8 = [
	"title",
	"aria-label",
	"aria-pressed"
];
var _hoisted_9 = { class: "sd-find-replace__nav" };
var _hoisted_10 = [
	"disabled",
	"title",
	"aria-label"
];
var _hoisted_11 = [
	"disabled",
	"title",
	"aria-label"
];
var _hoisted_12 = ["title", "aria-label"];
var _hoisted_13 = {
	key: 0,
	class: "sd-find-replace__row"
};
var _hoisted_14 = { class: "sd-find-replace__field" };
var _hoisted_15 = [
	"value",
	"placeholder",
	"aria-label"
];
var _hoisted_16 = { class: "sd-find-replace__nav sd-find-replace__nav--actions" };
var _hoisted_17 = ["disabled", "title"];
var _hoisted_18 = ["disabled", "title"];
var _hoisted_19 = {
	key: 1,
	class: "sd-find-replace__error",
	role: "alert"
};
var _hoisted_20 = {
	key: 0,
	class: "sd-find-replace__row-indent",
	"aria-hidden": "true"
};
var _hoisted_21 = { class: "sd-find-replace__error-text" };
var FindReplaceSurface_default = /*#__PURE__*/ _plugin_vue_export_helper_default({
	__name: "FindReplaceSurface",
	props: {
		surfaceId: {
			type: String,
			default: ""
		},
		mode: {
			type: String,
			default: "floating"
		},
		request: {
			type: Object,
			default: () => ({})
		},
		resolve: {
			type: Function,
			default: () => {}
		},
		close: {
			type: Function,
			default: () => {}
		},
		findReplace: {
			type: Object,
			required: true
		}
	},
	setup(__props) {
		const props = __props;
		const findInputRef = ref(null);
		const replaceDisabled = computed(() => {
			const fr = props.findReplace;
			if (!fr.hasMatches?.value) return true;
			if (fr.replacePending?.value === true) return true;
			if (fr.canReplace && fr.canReplace.value === false) return true;
			return false;
		});
		const showIgnoreDiacritics = computed(() => props.findReplace.ignoreDiacriticsSupported?.value !== false);
		const showReplaceControls = computed(() => props.findReplace.replaceEnabled && props.findReplace.replaceCanMutate?.value !== false);
		const showRegexToggle = computed(() => props.findReplace.regexSupported?.value === true);
		const searchErrorText = computed(() => props.findReplace.searchError?.value ?? null);
		function handleFindKeydown(e) {
			if (e.key === "Enter" && !e.shiftKey) {
				e.preventDefault();
				handleGoNext();
			} else if (e.key === "Enter" && e.shiftKey) {
				e.preventDefault();
				handleGoPrev();
			}
		}
		function handleGoNext() {
			props.findReplace.goNext();
			focusFindInput();
		}
		function handleGoPrev() {
			props.findReplace.goPrev();
			focusFindInput();
		}
		function handleClose() {
			props.findReplace.close("user-closed");
		}
		function collectScrollableAncestors(element) {
			const result = [];
			let cur = element?.parentElement ?? null;
			while (cur) {
				const style = cur.ownerDocument?.defaultView?.getComputedStyle?.(cur);
				if (style) {
					const overflow = `${style.overflowY} ${style.overflowX}`;
					if (overflow.includes("auto") || overflow.includes("scroll")) result.push(cur);
				}
				cur = cur.parentElement;
			}
			const root = element?.ownerDocument?.scrollingElement;
			if (root && !result.includes(root)) result.push(root);
			return result;
		}
		function focusFindInput() {
			const input = findInputRef.value;
			if (!input) return;
			const saved = collectScrollableAncestors(input).map((el) => ({
				el,
				top: el.scrollTop,
				left: el.scrollLeft
			}));
			input.focus({ preventScroll: true });
			for (const { el, top, left } of saved) {
				if (el.scrollTop !== top) el.scrollTop = top;
				if (el.scrollLeft !== left) el.scrollLeft = left;
			}
		}
		onMounted(() => {
			props.findReplace.registerFocusFn(focusFindInput);
		});
		return (_ctx, _cache) => {
			return openBlock(), createElementBlock("div", {
				class: "sd-find-replace",
				onKeydown: withKeys(withModifiers(handleClose, ["stop"]), ["esc"])
			}, [
				createElementVNode("div", _hoisted_2, [
					showReplaceControls.value ? (openBlock(), createElementBlock("button", {
						key: 0,
						type: "button",
						class: normalizeClass(["sd-find-replace__btn sd-find-replace__btn--expander", { "sd-find-replace__btn--expander-open": __props.findReplace.showReplace.value }]),
						title: __props.findReplace.texts.toggleReplaceLabel,
						"aria-label": __props.findReplace.texts.toggleReplaceAriaLabel,
						"aria-expanded": __props.findReplace.showReplace.value ? "true" : "false",
						onClick: _cache[0] || (_cache[0] = ($event) => __props.findReplace.showReplace.value = !__props.findReplace.showReplace.value)
					}, [..._cache[14] || (_cache[14] = [createElementVNode("svg", {
						viewBox: "0 0 16 16",
						width: "14",
						height: "14",
						"aria-hidden": "true"
					}, [createElementVNode("path", {
						d: "M6 3.5 10.5 8 6 12.5",
						fill: "none",
						stroke: "currentColor",
						"stroke-width": "1.5",
						"stroke-linecap": "round",
						"stroke-linejoin": "round"
					})], -1)])], 10, _hoisted_3)) : createCommentVNode("", true),
					createElementVNode("div", { class: normalizeClass(["sd-find-replace__field", { "sd-find-replace__field--error": searchErrorText.value }]) }, [
						_cache[15] || (_cache[15] = createElementVNode("svg", {
							class: "sd-find-replace__search-icon",
							viewBox: "0 0 16 16",
							width: "15",
							height: "15",
							"aria-hidden": "true"
						}, [createElementVNode("path", {
							d: "M7 1a6 6 0 1 0 3.7 10.7l3.3 3.3 1-1-3.3-3.3A6 6 0 0 0 7 1Zm0 1.5a4.5 4.5 0 1 1 0 9 4.5 4.5 0 0 1 0-9Z",
							fill: "currentColor"
						})], -1)),
						createElementVNode("input", {
							ref_key: "findInputRef",
							ref: findInputRef,
							value: __props.findReplace.findQuery.value,
							onInput: _cache[1] || (_cache[1] = ($event) => __props.findReplace.findQuery.value = $event.target.value),
							type: "text",
							class: "sd-find-replace__input sd-find-replace__input--search",
							"data-sd-autofocus": "",
							placeholder: __props.findReplace.texts.findPlaceholder,
							"aria-label": __props.findReplace.texts.findAriaLabel,
							onKeydown: handleFindKeydown
						}, null, 40, _hoisted_4),
						__props.findReplace.findQuery.value && !searchErrorText.value ? (openBlock(), createElementBlock("span", _hoisted_5, toDisplayString(__props.findReplace.matchLabel.value), 1)) : createCommentVNode("", true),
						createElementVNode("button", {
							type: "button",
							class: normalizeClass(["sd-find-replace__btn sd-find-replace__btn--toggle", { "sd-find-replace__btn--active": __props.findReplace.caseSensitive.value }]),
							title: __props.findReplace.texts.matchCaseAriaLabel,
							"aria-label": __props.findReplace.texts.matchCaseAriaLabel,
							"aria-pressed": __props.findReplace.caseSensitive.value ? "true" : "false",
							onMousedown: _cache[2] || (_cache[2] = withModifiers(() => {}, ["prevent"])),
							onClick: _cache[3] || (_cache[3] = ($event) => __props.findReplace.caseSensitive.value = !__props.findReplace.caseSensitive.value)
						}, toDisplayString(__props.findReplace.texts.matchCaseLabel), 43, _hoisted_6),
						showIgnoreDiacritics.value ? (openBlock(), createElementBlock("button", {
							key: 1,
							type: "button",
							class: normalizeClass(["sd-find-replace__btn sd-find-replace__btn--toggle", { "sd-find-replace__btn--active": __props.findReplace.ignoreDiacritics.value }]),
							title: __props.findReplace.texts.ignoreDiacriticsAriaLabel,
							"aria-label": __props.findReplace.texts.ignoreDiacriticsAriaLabel,
							"aria-pressed": __props.findReplace.ignoreDiacritics.value ? "true" : "false",
							onMousedown: _cache[4] || (_cache[4] = withModifiers(() => {}, ["prevent"])),
							onClick: _cache[5] || (_cache[5] = ($event) => __props.findReplace.ignoreDiacritics.value = !__props.findReplace.ignoreDiacritics.value)
						}, toDisplayString(__props.findReplace.texts.ignoreDiacriticsLabel), 43, _hoisted_7)) : createCommentVNode("", true),
						showRegexToggle.value ? (openBlock(), createElementBlock("button", {
							key: 2,
							type: "button",
							class: normalizeClass(["sd-find-replace__btn sd-find-replace__btn--toggle", { "sd-find-replace__btn--active": __props.findReplace.regex.value }]),
							title: __props.findReplace.texts.regexAriaLabel,
							"aria-label": __props.findReplace.texts.regexAriaLabel,
							"aria-pressed": __props.findReplace.regex.value ? "true" : "false",
							onMousedown: _cache[6] || (_cache[6] = withModifiers(() => {}, ["prevent"])),
							onClick: _cache[7] || (_cache[7] = ($event) => __props.findReplace.regex.value = !__props.findReplace.regex.value)
						}, toDisplayString(__props.findReplace.texts.regexLabel), 43, _hoisted_8)) : createCommentVNode("", true)
					], 2),
					createElementVNode("div", _hoisted_9, [
						createElementVNode("button", {
							type: "button",
							class: "sd-find-replace__btn sd-find-replace__btn--icon",
							disabled: !__props.findReplace.hasMatches.value,
							title: __props.findReplace.texts.previousMatchLabel,
							"aria-label": __props.findReplace.texts.previousMatchAriaLabel,
							onClick: _cache[8] || (_cache[8] = ($event) => handleGoPrev())
						}, [..._cache[16] || (_cache[16] = [createElementVNode("svg", {
							viewBox: "0 0 16 16",
							width: "16",
							height: "16",
							"aria-hidden": "true"
						}, [createElementVNode("path", {
							d: "M10 3.5 5.5 8 10 12.5",
							fill: "none",
							stroke: "currentColor",
							"stroke-width": "1.5",
							"stroke-linecap": "round",
							"stroke-linejoin": "round"
						})], -1)])], 8, _hoisted_10),
						createElementVNode("button", {
							type: "button",
							class: "sd-find-replace__btn sd-find-replace__btn--icon",
							disabled: !__props.findReplace.hasMatches.value,
							title: __props.findReplace.texts.nextMatchLabel,
							"aria-label": __props.findReplace.texts.nextMatchAriaLabel,
							onClick: _cache[9] || (_cache[9] = ($event) => handleGoNext())
						}, [..._cache[17] || (_cache[17] = [createElementVNode("svg", {
							viewBox: "0 0 16 16",
							width: "16",
							height: "16",
							"aria-hidden": "true"
						}, [createElementVNode("path", {
							d: "M6 3.5 10.5 8 6 12.5",
							fill: "none",
							stroke: "currentColor",
							"stroke-width": "1.5",
							"stroke-linecap": "round",
							"stroke-linejoin": "round"
						})], -1)])], 8, _hoisted_11),
						_cache[19] || (_cache[19] = createElementVNode("span", {
							class: "sd-find-replace__divider",
							"aria-hidden": "true"
						}, null, -1)),
						createElementVNode("button", {
							type: "button",
							class: "sd-find-replace__btn sd-find-replace__btn--icon",
							title: __props.findReplace.texts.closeLabel,
							"aria-label": __props.findReplace.texts.closeAriaLabel,
							onClick: handleClose
						}, [..._cache[18] || (_cache[18] = [createElementVNode("svg", {
							viewBox: "0 0 16 16",
							width: "16",
							height: "16",
							"aria-hidden": "true"
						}, [createElementVNode("path", {
							d: "m4.5 4.5 7 7m0-7-7 7",
							fill: "none",
							stroke: "currentColor",
							"stroke-width": "1.5",
							"stroke-linecap": "round"
						})], -1)])], 8, _hoisted_12)
					])
				]),
				__props.findReplace.showReplace.value && showReplaceControls.value ? (openBlock(), createElementBlock("div", _hoisted_13, [
					_cache[20] || (_cache[20] = createElementVNode("span", {
						class: "sd-find-replace__row-indent",
						"aria-hidden": "true"
					}, null, -1)),
					createElementVNode("div", _hoisted_14, [createElementVNode("input", {
						value: __props.findReplace.replaceText.value,
						onInput: _cache[10] || (_cache[10] = ($event) => __props.findReplace.replaceText.value = $event.target.value),
						type: "text",
						class: "sd-find-replace__input",
						placeholder: __props.findReplace.texts.replacePlaceholder,
						"aria-label": __props.findReplace.texts.replaceAriaLabel,
						onKeydown: _cache[11] || (_cache[11] = withKeys(withModifiers(($event) => __props.findReplace.replaceCurrent(), ["prevent"]), ["enter"]))
					}, null, 40, _hoisted_15)]),
					createElementVNode("div", _hoisted_16, [createElementVNode("button", {
						type: "button",
						class: "sd-find-replace__btn sd-find-replace__btn--action",
						disabled: replaceDisabled.value,
						title: __props.findReplace.texts.replaceLabel,
						onClick: _cache[12] || (_cache[12] = ($event) => __props.findReplace.replaceCurrent())
					}, toDisplayString(__props.findReplace.texts.replaceLabel), 9, _hoisted_17), createElementVNode("button", {
						type: "button",
						class: "sd-find-replace__btn sd-find-replace__btn--action",
						disabled: replaceDisabled.value,
						title: __props.findReplace.texts.replaceAllLabel,
						onClick: _cache[13] || (_cache[13] = ($event) => __props.findReplace.replaceAll())
					}, toDisplayString(__props.findReplace.texts.replaceAllLabel), 9, _hoisted_18)])
				])) : createCommentVNode("", true),
				searchErrorText.value ? (openBlock(), createElementBlock("div", _hoisted_19, [showReplaceControls.value ? (openBlock(), createElementBlock("span", _hoisted_20)) : createCommentVNode("", true), createElementVNode("span", _hoisted_21, toDisplayString(searchErrorText.value), 1)])) : createCommentVNode("", true)
			], 40, _hoisted_1);
		};
	}
}, [["__scopeId", "data-v-41f37c29"]]);
//#endregion
export { FindReplaceSurface_default as default };
