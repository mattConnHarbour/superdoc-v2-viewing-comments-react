//#region src/core/pdf/helpers/constants.js
var PDF_TO_CSS_UNITS = 96 / 72;
//#endregion
Object.defineProperty(exports, "PDF_TO_CSS_UNITS", {
	enumerable: true,
	get: function() {
		return PDF_TO_CSS_UNITS;
	}
});
