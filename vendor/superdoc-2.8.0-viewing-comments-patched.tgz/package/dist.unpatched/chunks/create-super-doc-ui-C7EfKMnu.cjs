//#region ../layout-engine/dom-contract/src/class-names.ts
/**
* DOM Contract: Class Names
*
* CSS class names stamped on rendered document elements by the DOM painter.
* These names form a public contract read by the painter (emitter) and by
* editor-side DOM observation code (reader).
*
* Changing a value here is a breaking change for both systems.
*/
var DOM_CLASS_NAMES = {
	/** Top-level page container element. */
	PAGE: "superdoc-page",
	/** Fragment container (paragraph, table, image block, etc.). */
	FRAGMENT: "superdoc-fragment",
	/** Non-flowing fragment whose visual position must not define body flow geometry. */
	FLOATING_FRAGMENT: "superdoc-floating-fragment",
	/** Line container within a fragment. */
	LINE: "superdoc-line",
	/**
	* Inline structured-content (SDT) wrapper.
	*
	* Carries `data-pm-start` / `data-pm-end` for selection highlighting.
	* Should be EXCLUDED from click-to-position mapping — child spans are
	* the character-level targets.
	*/
	INLINE_SDT_WRAPPER: "superdoc-structured-content-inline",
	/** Inline structured-content label chrome. */
	INLINE_SDT_LABEL: "superdoc-structured-content-inline__label",
	/** Block-level structured-content container. */
	BLOCK_SDT: "superdoc-structured-content-block",
	/** Block-level structured-content label chrome. */
	BLOCK_SDT_LABEL: "superdoc-structured-content__label",
	/** Table fragment container (resize overlay and click-mapping target). */
	TABLE_FRAGMENT: "superdoc-table-fragment",
	/** Document section container. */
	DOCUMENT_SECTION: "superdoc-document-section",
	/**
	* Grouped hover highlight applied to all fragments of the same block SDT.
	* Set by document-runtime hover coordination via event delegation.
	*/
	SDT_GROUP_HOVER: "sdt-group-hover",
	/** Paragraph fragment rendered as a Table of Contents entry. */
	TOC_ENTRY: "superdoc-toc-entry",
	/** TOC analogue of `SDT_GROUP_HOVER`, applied to every fragment sharing a `data-toc-id`. */
	TOC_GROUP_HOVER: "toc-group-hover",
	/** Block-level image fragment (ImageBlock). */
	IMAGE_FRAGMENT: "superdoc-image-fragment",
	/** Inline image element (ImageRun inside a paragraph). */
	INLINE_IMAGE: "superdoc-inline-image",
	/** Wrapper around a paragraph's list marker (bullet glyph or ordered number). */
	LIST_MARKER: "superdoc-list-marker",
	/** Clip wrapper around a cropped inline image. */
	INLINE_IMAGE_CLIP_WRAPPER: "superdoc-inline-image-clip-wrapper",
	/** Field annotation outer wrapper. */
	ANNOTATION: "annotation",
	/** Field annotation inner content wrapper. */
	ANNOTATION_CONTENT: "annotation-content",
	/** Hidden caret anchor span appended after field annotation content. */
	ANNOTATION_CARET_ANCHOR: "annotation-caret-anchor"
};
DOM_CLASS_NAMES.INLINE_SDT_LABEL, DOM_CLASS_NAMES.BLOCK_SDT_LABEL;
//#endregion
//#region ../layout-engine/dom-contract/src/data-attrs.ts
/**
* DOM Contract: Data Attributes
*
* Named constants for `data-*` attributes stamped on rendered DOM elements.
* These attributes are read by editor-side DOM observers, click-to-position
* mapping, and bridge compatibility code.
*
* Each constant stores the full attribute name (e.g. `"data-pm-start"`) as it
* appears in `getAttribute()` / `setAttribute()` calls and CSS selectors.
*
* The `DATASET_KEYS` mirror provides the camelCase equivalents used with
* `element.dataset.*` access.
*
* Editor-neutral (prep-001) attributes live alongside the legacy `data-pm-*`
* attributes; both surfaces are emitted so that v1 consumers continue to work
* unmodified while future editor-neutral consumers (hit-test / range mapping)
* can address rendered output without consulting ProseMirror positions.
*/
/**
* Full attribute names for use with `getAttribute` / `setAttribute` / CSS selectors.
*/
var DATA_ATTRS = {
	/** ProseMirror start position of the element's content range. */
	PM_START: "data-pm-start",
	/** ProseMirror end position of the element's content range. */
	PM_END: "data-pm-end",
	/** Layout epoch stamp — incremented on each layout pass. */
	LAYOUT_EPOCH: "data-layout-epoch",
	/** JSON-encoded table boundary metadata for resize overlays. */
	TABLE_BOUNDARIES: "data-table-boundaries",
	/** SDT unique identifier. */
	SDT_ID: "data-sdt-id",
	/** SDT type (fieldAnnotation, structuredContent, documentSection, etc.). */
	SDT_TYPE: "data-sdt-type",
	/** Field annotation field identifier. */
	FIELD_ID: "data-field-id",
	/** Field annotation field type (signer, text, checkbox, etc.). */
	FIELD_TYPE: "data-field-type",
	/** Marks an element as draggable by the editor. */
	DRAGGABLE: "data-draggable",
	/** Display label text for drag toast / accessibility. */
	DISPLAY_LABEL: "data-display-label",
	/** Field annotation variant (text, image, signature, checkbox, html, link). */
	VARIANT: "data-variant",
	/** Element type discriminator (annotation variant, etc.). */
	TYPE: "data-type",
	/** Schema version for the editor-neutral layout boundary attributes. */
	LAYOUT_BOUNDARY_SCHEMA: "data-layout-boundary-schema",
	/** Stable opaque id of the rendered fragment (see `LayoutFragmentId`). */
	LAYOUT_FRAGMENT_ID: "data-layout-fragment-id",
	/** Encoded story locator (e.g. `body`, `header:rId4`, `footer:rId7`). */
	LAYOUT_STORY: "data-layout-story",
	/** Source block reference (today: producer's `blockId`). */
	LAYOUT_BLOCK_REF: "data-layout-block-ref"
};
/**
* Decode the dataset string back into a `LayoutStoryLocator`-shaped object.
*
* Used by editor-side DOM observers. Unknown kinds fall back to
* `{ kind: 'unknown' }` so downstream code can treat the value as a
* diagnostic, not as a default body.
*/
var decodeLayoutStoryDataset = (raw) => {
	if (!raw) return { kind: "unknown" };
	if (raw === "body") return { kind: "body" };
	const idx = raw.indexOf(":");
	const kind = idx === -1 ? raw : raw.slice(0, idx);
	const id = idx === -1 ? void 0 : raw.slice(idx + 1);
	switch (kind) {
		case "body":
		case "header":
		case "footer":
		case "footnote":
		case "endnote":
		case "textbox": return id ? {
			kind,
			id
		} : { kind };
		default: return { kind: "unknown" };
	}
};
`${DOM_CLASS_NAMES.BLOCK_SDT}${DATA_ATTRS.SDT_ID}`;
`${DATA_ATTRS.DRAGGABLE}`;
//#endregion
//#region ../layout-engine/contracts/src/direction-context.ts
/**
* Read a paragraph's inline base direction from its attributes.
*
* Prefers the resolved {@link ParagraphDirectionContext} (SD-2776) when
* present. Falls back to `paragraphProperties.rightToLeft` for PM-node /
* editor paths that store direction on the raw OOXML properties rather
* than the typed direction context.
*
* Consumers should call this instead of inspecting attrs ad hoc so the
* direction source check stays in one place.
*/
function getParagraphInlineDirection(attrs) {
	const fromContext = attrs?.directionContext?.inlineDirection;
	if (fromContext != null) return fromContext;
	const ppRtl = attrs?.paragraphProperties?.rightToLeft;
	if (ppRtl === true) return "rtl";
	if (ppRtl === false) return "ltr";
}
//#endregion
//#region ../layout-engine/contracts/src/drawing-taxonomy.ts
/**
* Frozen canonical diagnostic codes for drawing rendering.
*
* New extractor/adapter diagnostics MUST use these exact strings. Family-
* specific codes are required — do not collapse everything to
* `render.unsupported-inline-ooxml` (plan §4).
*/
var DRAWING_DIAGNOSTIC_CODES = {
	/** External image relationship (`r:link` / `TargetMode="External"`). Not fetched. */
	externalImageDeferred: "render.media.external-image-deferred",
	/** Drawing references a relationship id that does not exist on the owner part. */
	missingRelationship: "render.drawing.missing-relationship",
	/** Relationship resolves but the target media part bytes are missing/empty. */
	missingMediaPart: "render.media.missing-part",
	/** Relationship exists but is not an image relationship type. */
	unsupportedRelationshipType: "render.drawing.unsupported-relationship-type",
	/** Media MIME is not in the supported allowlist. */
	unsupportedMime: "render.media.unsupported-mime",
	/** Media part exceeds the host byte-size policy before bytes are materialized. */
	imageTooLarge: "render.media.image-too-large",
	/** SVG content rejected by the SVG safety policy. */
	unsafeSvg: "render.media.unsafe-svg",
	/** Metafile / TIFF (EMF, WMF, TIFF) with no approved conversion path. */
	unsupportedFormat: "render.media.unsupported-format",
	/** OLE / ActiveX / embedded package object. */
	embeddedObjectNotSupported: "render.embedded-object-not-supported",
	/** SmartArt / diagram / unknown external graphic-data object. */
	unsupportedObject: "render.drawing.unsupported-object",
	/** VML structure outside any supported image-like subset. */
	vmlUnsupported: "render.drawing.vml-unsupported",
	/** VML image-like content that could not be promoted to a supported image. */
	vmlImageUnsupported: "render.drawing.vml-image-unsupported",
	/** Custom geometry command the extractor does not implement (e.g. `arcTo`). */
	unsupportedGeometryCommand: "render.drawing.unsupported-geometry-command",
	/** Anchor fields required for honest placement are unsupported. */
	anchorUnsupported: "render.drawing.anchor-unsupported",
	/** Wrap fields required for honest placement are unsupported. */
	wrapUnsupported: "render.drawing.wrap-unsupported",
	/** `mc:AlternateContent` had no supported choice and no usable fallback. */
	altContentNoSupportedChoice: "render.drawing.altcontent-no-supported-choice",
	/** A child of an otherwise-supported group is unsupported. */
	groupChildUnsupported: "render.drawing.group-child-unsupported"
};
DRAWING_DIAGNOSTIC_CODES.missingRelationship, DRAWING_DIAGNOSTIC_CODES.unsupportedRelationshipType, DRAWING_DIAGNOSTIC_CODES.unsupportedRelationshipType, DRAWING_DIAGNOSTIC_CODES.imageTooLarge, DRAWING_DIAGNOSTIC_CODES.missingMediaPart, DRAWING_DIAGNOSTIC_CODES.unsupportedObject, DRAWING_DIAGNOSTIC_CODES.vmlUnsupported;
/**
* The frozen drawing support taxonomy.
*
* Invariants (enforced by `drawing-taxonomy.test.ts`):
* - every `supported` family has a real contract target (`!== 'none'`);
* - every `DrawingBlock`-targeted family declares a `drawingKind`;
* - every `fail-closed` family declares a canonical `diagnostic`;
* - every canonical diagnostic code is referenced by at least one fail-closed
*   family;
* - `deferred` families make no support claim (`contract: 'none'`, no
*   diagnostic).
*/
var DRAWING_SUPPORT_TAXONOMY = {
	inlineBitmap: {
		family: "inlineBitmap",
		support: "supported",
		description: "wp:inline pic:pic with internal media and browser-safe MIME (PNG/JPEG; WebP/SVG once the host media resolver lands).",
		contract: "ImageRun"
	},
	anchoredBitmap: {
		family: "anchoredBitmap",
		support: "supported",
		description: "wp:anchor bitmap with anchor/wrap expressible by ImageAnchor/ImageWrap. Never silently inlined.",
		contract: "ImageBlock"
	},
	imageChildInGroup: {
		family: "imageChildInGroup",
		support: "supported",
		description: "Bitmap child of a supported DrawingML group/drawing wrapper. Supported only when the parent is.",
		contract: "ImageDrawing"
	},
	vectorShape: {
		family: "vectorShape",
		support: "supported",
		description: "Block/floating DrawingML preset/custom shape with the supported geometry/style subset.",
		contract: "DrawingBlock",
		drawingKind: "vectorShape"
	},
	shapeGroup: {
		family: "shapeGroup",
		support: "supported",
		description: "DrawingML group whose rendered children are supported vector/image children.",
		contract: "DrawingBlock",
		drawingKind: "shapeGroup"
	},
	chart: {
		family: "chart",
		support: "supported",
		description: "DrawingML chart projected into a ChartDrawing with parsed cached chart XML data. Complete Word chart fidelity remains deferred to chartFidelity.",
		contract: "DrawingBlock",
		drawingKind: "chart"
	},
	alternateContent: {
		family: "alternateContent",
		support: "supported",
		description: "mc:AlternateContent traversal/select policy. Selected Choice/Fallback maps to its family contract; unselected branches preserved for save/reopen.",
		contract: "selected-choice"
	},
	externalImage: {
		family: "externalImage",
		support: "fail-closed",
		description: "External image relationship (r:link / TargetMode=\"External\"). Not fetched.",
		contract: "none",
		diagnostic: DRAWING_DIAGNOSTIC_CODES.externalImageDeferred
	},
	missingRelationship: {
		family: "missingRelationship",
		support: "fail-closed",
		description: "Drawing references a relationship id absent from the owner part .rels.",
		contract: "none",
		diagnostic: DRAWING_DIAGNOSTIC_CODES.missingRelationship
	},
	missingMediaPart: {
		family: "missingMediaPart",
		support: "fail-closed",
		description: "Relationship resolves but the target media part bytes are missing or empty.",
		contract: "none",
		diagnostic: DRAWING_DIAGNOSTIC_CODES.missingMediaPart
	},
	wrongRelationshipType: {
		family: "wrongRelationshipType",
		support: "fail-closed",
		description: "Relationship exists but is not an image relationship type.",
		contract: "none",
		diagnostic: DRAWING_DIAGNOSTIC_CODES.unsupportedRelationshipType
	},
	unsupportedMime: {
		family: "unsupportedMime",
		support: "fail-closed",
		description: "Media MIME outside the supported allowlist (incl. GIF/BMP/ICO).",
		contract: "none",
		diagnostic: DRAWING_DIAGNOSTIC_CODES.unsupportedMime
	},
	oversizedMediaPart: {
		family: "oversizedMediaPart",
		support: "fail-closed",
		description: "Media part exceeds the host byte-size policy before bytes are materialized.",
		contract: "none",
		diagnostic: DRAWING_DIAGNOSTIC_CODES.imageTooLarge
	},
	unsafeSvg: {
		family: "unsafeSvg",
		support: "fail-closed",
		description: "SVG content rejected by the SVG safety policy.",
		contract: "none",
		diagnostic: DRAWING_DIAGNOSTIC_CODES.unsafeSvg
	},
	metafileOrTiff: {
		family: "metafileOrTiff",
		support: "fail-closed",
		description: "EMF/WMF/TIFF and other non-browser-native formats with no approved conversion path.",
		contract: "none",
		diagnostic: DRAWING_DIAGNOSTIC_CODES.unsupportedFormat
	},
	embeddedObject: {
		family: "embeddedObject",
		support: "fail-closed",
		description: "OLE / ActiveX / embedded package object.",
		contract: "none",
		diagnostic: DRAWING_DIAGNOSTIC_CODES.embeddedObjectNotSupported
	},
	smartArtOrDiagram: {
		family: "smartArtOrDiagram",
		support: "fail-closed",
		description: "SmartArt / diagram / unknown external graphic-data object.",
		contract: "none",
		diagnostic: DRAWING_DIAGNOSTIC_CODES.unsupportedObject
	},
	vml: {
		family: "vml",
		support: "fail-closed",
		description: "VML structure outside any supported image-like subset (default fail-closed policy).",
		contract: "none",
		diagnostic: DRAWING_DIAGNOSTIC_CODES.vmlUnsupported
	},
	vmlImageLike: {
		family: "vmlImageLike",
		support: "fail-closed",
		description: "Simple VML image references (v:imagedata) / watermark image metadata. Fail-closed unless a later change promotes a named subset with deterministic fixtures and exact oracles.",
		contract: "none",
		diagnostic: DRAWING_DIAGNOSTIC_CODES.vmlImageUnsupported
	},
	unsupportedGeometryCommand: {
		family: "unsupportedGeometryCommand",
		support: "fail-closed",
		description: "Custom geometry command the extractor does not implement, e.g. arcTo.",
		contract: "none",
		diagnostic: DRAWING_DIAGNOSTIC_CODES.unsupportedGeometryCommand
	},
	unsupportedAnchorFields: {
		family: "unsupportedAnchorFields",
		support: "fail-closed",
		description: "Anchor fields required for honest placement are unsupported (char-relative, alignment modes, etc.).",
		contract: "none",
		diagnostic: DRAWING_DIAGNOSTIC_CODES.anchorUnsupported
	},
	unsupportedWrapFields: {
		family: "unsupportedWrapFields",
		support: "fail-closed",
		description: "Wrap fields required for honest placement are unsupported (arbitrary wrap polygons, etc.).",
		contract: "none",
		diagnostic: DRAWING_DIAGNOSTIC_CODES.wrapUnsupported
	},
	alternateContentNoSupportedChoice: {
		family: "alternateContentNoSupportedChoice",
		support: "fail-closed",
		description: "mc:AlternateContent with no supported choice and no usable fallback.",
		contract: "none",
		diagnostic: DRAWING_DIAGNOSTIC_CODES.altContentNoSupportedChoice
	},
	groupChildUnsupported: {
		family: "groupChildUnsupported",
		support: "fail-closed",
		description: "Unsupported child inside an otherwise-supported group. Supported siblings are not dropped.",
		contract: "none",
		diagnostic: DRAWING_DIAGNOSTIC_CODES.groupChildUnsupported
	},
	objectEditing: {
		family: "objectEditing",
		support: "deferred",
		description: "Editing/mutation of anchored/vector objects.",
		contract: "none"
	},
	customWrapPolygon: {
		family: "customWrapPolygon",
		support: "deferred",
		description: "Full Word-compatible text wrapping for arbitrary custom wrap polygons.",
		contract: "none"
	},
	chartFidelity: {
		family: "chartFidelity",
		support: "deferred",
		description: "Complete chart fidelity (a dedicated chart effort owns the parsed subset).",
		contract: "none"
	},
	vmlFidelity: {
		family: "vmlFidelity",
		support: "deferred",
		description: "Complete VML fidelity.",
		contract: "none"
	},
	decorativeAccessibilityUi: {
		family: "decorativeAccessibilityUi",
		support: "deferred",
		description: "Full accessibility UI for decorative image semantics beyond preserving source data.",
		contract: "none"
	}
};
Object.keys(DRAWING_SUPPORT_TAXONOMY);
Object.freeze([
	"multiple-sections",
	"furniture-page-tokens",
	"non-balanceable-multi-column-sections",
	"body-anchored-objects",
	"non-flowing-page-relative-body-anchors",
	"footnotes",
	"page-references",
	"keep-constraints",
	"tables",
	"furniture-anchored-objects"
]);
var INCREMENTAL_DEPENDENCY_CERTIFICATE_CLASSES = Object.freeze([
	"checkpoint-geometry",
	"section-numbering",
	"font-style-inputs",
	"notes",
	"furniture",
	"flowing-anchors",
	"non-flowing-page-anchors",
	"convergence",
	"source-topology"
]);
new Set(INCREMENTAL_DEPENDENCY_CERTIFICATE_CLASSES);
//#endregion
//#region src/helpers/v2-review-mutation-impact.js
/**
* Classify the tracked-change identities carried by a v2 mutation event.
*
* Receipt entities are the durable invalidation contract between the document
* kernel and derived review UI. Direct receipts carry entity refs; mutation
* plans carry the same identities through `trackedChanges` and per-step ids.
*/
function getV2TrackedChangeMutationImpact(event) {
	if (event?.type !== "mutation:committed") return null;
	const payload = event.origin === "history" ? event.result : event.receipt;
	if (!payload || typeof payload !== "object") return null;
	const upsertIds = /* @__PURE__ */ new Set();
	const removedIds = /* @__PURE__ */ new Set();
	/** @type {Array<{ from: string, to: string }>} */
	const remappedPairs = [];
	const collectEntity = (entry, into) => {
		if (entry?.kind !== "entity" || entry.entityType !== "trackedChange") return;
		if (typeof entry.entityId === "string" && entry.entityId.length > 0) into.add(entry.entityId);
	};
	const readEntityId = (entry) => {
		if (entry?.kind !== "entity" || entry.entityType !== "trackedChange") return null;
		return typeof entry.entityId === "string" && entry.entityId.length > 0 ? entry.entityId : null;
	};
	if (Array.isArray(payload.inserted)) payload.inserted.forEach((entry) => collectEntity(entry, upsertIds));
	if (Array.isArray(payload.updated)) payload.updated.forEach((entry) => collectEntity(entry, upsertIds));
	if (Array.isArray(payload.trackedChangeRefs)) payload.trackedChangeRefs.forEach((entry) => collectEntity(entry, upsertIds));
	if (Array.isArray(payload.trackedChanges)) payload.trackedChanges.forEach((entry) => collectEntity(entry, upsertIds));
	if (Array.isArray(payload.steps)) for (const step of payload.steps) {
		if (!Array.isArray(step?.trackedChangeIds)) continue;
		for (const id of step.trackedChangeIds) if (typeof id === "string" && id.length > 0) upsertIds.add(id);
	}
	if (Array.isArray(payload.removed)) payload.removed.forEach((entry) => collectEntity(entry, removedIds));
	if (Array.isArray(payload.invalidatedRefs)) payload.invalidatedRefs.forEach((entry) => collectEntity(entry, removedIds));
	if (Array.isArray(payload.remappedRefs)) for (const mapping of payload.remappedRefs) {
		const fromId = readEntityId(mapping?.from);
		const toId = readEntityId(mapping?.to);
		if (fromId) removedIds.add(fromId);
		if (toId) upsertIds.add(toId);
		if (fromId && toId && fromId !== toId) remappedPairs.push({
			from: fromId,
			to: toId
		});
	}
	for (const id of removedIds) upsertIds.delete(id);
	const allResolved = readAllResolvedFact(event, payload);
	if (upsertIds.size === 0 && removedIds.size === 0 && !allResolved) return null;
	return {
		upsertIds,
		removedIds,
		remappedPairs,
		reconcileMode: "targeted",
		...allResolved ? { allResolved } : {}
	};
}
function readAllResolvedFact(event, receipt) {
	const fact = event?.trackedChangeAllResolved;
	if (event?.origin === "history" || !fact || fact.schemaVersion !== 1 || fact.targetKind !== "all" || fact.decision !== "accept" && fact.decision !== "reject" || fact.remainingLogicalCount !== 0 || typeof fact.catalogRevision !== "string" || !fact.catalogRevision || typeof fact.sourceCoverageRevision !== "string" || !fact.sourceCoverageRevision || !Number.isSafeInteger(fact.logicalTargetCount) || fact.logicalTargetCount <= 0 || !Number.isSafeInteger(fact.physicalCarrierCount) || fact.physicalCarrierCount < fact.logicalTargetCount || typeof fact.txId !== "string" || fact.txId !== receipt.txId || typeof fact.documentEpoch !== "string" || !Number.isSafeInteger(fact.commitSequence) || typeof fact.packagePreviousRevision !== "string" || typeof fact.packageNextRevision !== "string" || fact.packagePreviousRevision === fact.packageNextRevision) return null;
	return fact;
}
//#endregion
//#region src/public/ui/reasons.ts
/**
* Stable public reason taxonomy for the v2-native `superdoc/ui` controller.
*
* These strings are the canonical, stable vocabulary the controller uses to
* explain WHY a command or workflow handle is disabled, unsupported, deferred,
* or otherwise fails closed. They are part of the public custom-UI contract:
* consumer toolbars/panels can branch on them and migration docs reference
* them. Once shipped, a value must not be repurposed — add a new member rather
* than changing the meaning of an existing one.
*
* The reasons distinguish the failure-mode families a custom UI must tell
* apart (see `plans/v2-custom-ui-toolbar-parity-plan-set.md`, Workstream 2):
*
*   - command unsupported by v2            → `command-unsupported`
*   - reserved recognized/deferred command → `command-deferred`
*   - editor / Document API not ready yet   → `not-ready`, `document-api-unavailable`
*   - blocked by viewing / read-only state  → `document-readonly`
*   - blocked by missing selection/context  → `selection-required`,
*     `range-selection-required`, `context-unavailable`, `target-unresolved`,
*     `target-not-visible`, `geometry-unavailable`
*   - operation / host capability missing   → `operation-unavailable`,
*     `host-capability-unavailable`, `bulk-decisions-disabled`
*
* Geometry results (`viewport.getRect`, `metadata.getRect`) carry a separate,
* geometry-local `reason` vocabulary (`not-mounted`, `unresolved`,
* `invalid-target`, `not-ready`, `unavailable`); see `ViewportRectResult`.
* That vocabulary predates this taxonomy and is intentionally narrower.
*/
var SUPERDOC_UI_REASONS = {
	/** The active editor is not mounted / ready yet. */
	notReady: "not-ready",
	/** The editor is ready but its Document API facade is not available or has not been published yet. */
	documentApiUnavailable: "document-api-unavailable",
	/** The document is in viewing / read-only mode, so mutating commands are blocked. */
	documentReadonly: "document-readonly",
	/** A selection is required and none is active. */
	selectionRequired: "selection-required",
	/** A non-empty (range) selection is required and the current selection is collapsed/empty. */
	rangeSelectionRequired: "range-selection-required",
	/** Required pointer / entity / document context could not be resolved. */
	contextUnavailable: "context-unavailable",
	/** Painted geometry for the target could not be resolved. */
	geometryUnavailable: "geometry-unavailable",
	/** A navigation / geometry target could not be resolved to a live document address. */
	targetUnresolved: "target-unresolved",
	/** A navigation target was resolved but could not be brought into the visible viewport. */
	targetNotVisible: "target-not-visible",
	/** The command is not supported by v2 at all. */
	commandUnsupported: "command-unsupported",
	/** Reserved migration reason for a recognized command that is intentionally deferred. */
	commandDeferred: "command-deferred",
	/**
	* The command is a real v2 operation, but its required document context
	* (the current table / row / column / cell) cannot be resolved from any
	* public custom-UI state: `selection.current` exposes only text block ids,
	* and no public operation resolves the table ancestry of a block. This is a
	* precise, named context-facade gap — distinct from `command-deferred` — for
	* the table cell-context command family.
	*/
	tableContextUnavailable: "table-context-unavailable",
	/** The backing Document API / SuperDoc operation is not present on this host. */
	operationUnavailable: "operation-unavailable",
	/** Bulk accept/reject decisions are disabled unless the host opts in. */
	bulkDecisionsDisabled: "bulk-decisions-disabled",
	/** A host-owned capability (geometry, hit-test, navigation) is unavailable. */
	hostCapabilityUnavailable: "host-capability-unavailable",
	/** Undo / redo cannot run because the host history stack has no matching entry. */
	historyEmpty: "history-empty",
	/**
	* The shared search/find surface is unavailable because the host does not
	* expose a search facade (e.g. a pre-ready editor, a worker-backed v2 host,
	* or a build without the search substrate). Search reads return empty and
	* search actions fail closed rather than fabricating matches.
	*/
	searchUnavailable: "search-unavailable",
	/** The search pattern is an invalid or unsafe regular expression. */
	searchInvalidPattern: "search-invalid-pattern",
	/**
	* Find-and-replace is intentionally out of the first v2 search parity tranche.
	* The shared search surface implements query / navigation only; replace and
	* replace-all fail closed with this reason until replace ships. This is an
	* explicit product posture, not a missing-capability accident.
	*/
	replaceUnsupported: "replace-unsupported",
	/**
	* The selection overlaps a content control (SDT) whose lock mode
	* (`contentLocked` / `sdtContentLocked`) forbids styling its content — Word
	* parity (SD-3274): the toolbar must not leave styling controls clickable
	* when the style change cannot apply. Alignment / paragraph-level commands
	* are never gated by this reason.
	*/
	contentControlLocked: "content-control-locked",
	/**
	* The current user is not allowed to run this command under the product
	* permissionResolver / role matrix (SD-3845). Distinct from document
	* read-only: the document is writable, this one action is not.
	*/
	permissionDenied: "permission-denied"
};
//#endregion
//#region src/public/ui/commands.ts
/**
* Built-in command catalog for the v2-native UI controller.
*
* This module is the SINGLE SOURCE OF TRUTH for the controller's built-in
* command ids, their aliases, how each one routes (public Document API
* operation, public SuperDoc-instance method, tracked-change decision, or no
* supported route yet), whether it mutates the document, how v1-style payloads
* are normalized, and the stable fail-closed reason a recognized-but-unrouted
* command reports. `create-super-doc-ui.ts` reads these descriptors; it no
* longer carries an ad hoc route map.
*
* Posture (migration-only): every v1 headless-toolbar command id is present
* here with an explicit disposition —
*
*   - `routed`      → backed by a public surface today (Document API operation,
*                     SuperDoc-instance method, or tracked-change decision) and
*                     browser-proven through `ui.commands.execute`;
*   - `context-gap` → a real v2 operation whose required document context (the
*                     current table / row / column / cell) cannot be resolved
*                     from public custom-UI state; reports the precise, named
*                     `table-context-unavailable` reason and fails closed;
*   - `unsupported` → no clear public v2 equivalent (product decision) or an
*                     unknown id; reports `command-unsupported` and fails closed.
*
* No routeable v1 toolbar command remains `command-deferred` (that disposition
* stays in the type for migration scaffolding but is unused by the catalog).
*
* No descriptor imports a v1 editor internal or a private v2 runtime package,
* and no routed command mutates while the document is read-only / viewing.
*
*/
/**
* The 14 canonical v2-native command ids. These are the historically stable
* `superdoc/ui` built-ins; the broader catalog below adds v1 headless-toolbar
* coverage. Kept as a named export because it is part of the public `superdoc/ui`
* surface (`verify-public-facade-emit.cjs`, consumer typechecks).
*/
var BUILT_IN_COMMAND_IDS = {
	bold: "bold",
	italic: "italic",
	underline: "underline",
	strikethrough: "strikethrough",
	fontFamily: "font-family",
	fontSize: "font-size",
	setFontFamily: "setFontFamily",
	setFontSize: "setFontSize",
	undo: "undo",
	redo: "redo",
	acceptChange: "acceptChange",
	rejectChange: "rejectChange",
	acceptAllChanges: "acceptAllChanges",
	rejectAllChanges: "rejectAllChanges",
	bulletList: "bullet-list",
	numberedList: "numbered-list"
};
/** Strip a trailing `pt` unit from v1-style font sizes (`"12pt"` → `"12"`). */
function normalizeFontSizePayload(payload) {
	const strip = (value) => typeof value === "string" ? value.replace(/\s*pt$/i, "").trim() : value;
	if (typeof payload === "string") return strip(payload);
	if (payload && typeof payload === "object" && "value" in payload) {
		const record = payload;
		return {
			...record,
			value: strip(record.value)
		};
	}
	return payload;
}
/**
* Normalize v1-style zoom payloads to the percentage `SuperDoc.setZoom`
* expects (`100 === 100%`). Accepts `150`, `"150%"`, `"1.5"`, or `1.5`.
* Percentages pass through as numbers; legacy fraction-style values in the
* `0..5` range are converted to percentages (`1.5` → `150`).
*/
function normalizeZoomPayload(payload) {
	const normalizeNumber = (value, percentLiteral) => {
		if (!percentLiteral && value > 0 && value <= 5) return value * 100;
		return value;
	};
	if (typeof payload === "string") {
		const isPercent = payload.includes("%");
		const parsed = Number.parseFloat(payload.replace("%", "").trim());
		if (!Number.isFinite(parsed)) return payload;
		return normalizeNumber(parsed, isPercent);
	}
	if (typeof payload === "number" && Number.isFinite(payload)) return normalizeNumber(payload, false);
	return payload;
}
/**
* Normalize a measurement-unit payload to the `'in'` / `'cm'` form
* `SuperDoc.setMeasurementUnit` expects. Accepts the canonical `'in'` / `'cm'`,
* a `{ value }` wrapper, or common long forms (`"inches"`, `"centimeters"`).
* An unrecognized value passes through so the instance method can reject it.
*/
function normalizeMeasurementUnitPayload(payload) {
	const raw = payload && typeof payload === "object" && "value" in payload ? payload.value : payload;
	if (raw === "in" || raw === "cm") return raw;
	if (typeof raw === "string") {
		const token = raw.trim().toLowerCase();
		if (token === "in" || token === "inch" || token === "inches") return "in";
		if (token === "cm" || token === "centimeter" || token === "centimeters" || token === "centimetre" || token === "centimetres") return "cm";
	}
	return raw;
}
/**
* Normalize a v1-style color payload to the `#RRGGBB` form the inline
* `format.color` / `format.highlight` operations expect. Accepts `"#RRGGBB"`,
* `"RRGGBB"`, or `{ value }`. `null` (clear) passes through unchanged; an
* unrecognized value is returned as-is so the operation can reject it.
*/
function normalizeColorPayload(payload) {
	const coerce = (value) => {
		if (value === null) return null;
		if (typeof value !== "string") return value;
		const trimmed = value.trim();
		if (trimmed === "") return value;
		if (/^#[0-9a-fA-F]{6}$/.test(trimmed)) return trimmed;
		if (/^[0-9a-fA-F]{6}$/.test(trimmed)) return `#${trimmed}`;
		return trimmed;
	};
	if (payload && typeof payload === "object" && "value" in payload) {
		const record = payload;
		return {
			...record,
			value: coerce(record.value)
		};
	}
	return coerce(payload);
}
/** Unwrap a `{ value }` / `{ alignment } ` / `{ styleId }` wrapper to its scalar. */
function unwrapScalar(payload, keys) {
	if (payload && typeof payload === "object") {
		const record = payload;
		for (const key of keys) if (key in record) return record[key];
	}
	return payload;
}
/** Normalize a v1 alignment payload (`"left"`, `{ value }`, `"justified"`) to a `ParagraphAlignment`. */
function normalizeAlignmentPayload(payload) {
	const raw = unwrapScalar(payload, ["alignment", "value"]);
	if (typeof raw !== "string") return raw;
	const v = raw.trim().toLowerCase();
	if (v === "justified" || v === "both") return "justify";
	return v;
}
/**
* Normalize a v1 line-height payload to OOXML auto line spacing (240ths of a
* line: 240 = single, 360 = 1.5×, 480 = double). A multiplier in the `0..10`
* range is converted (`1.5` → `360`); a larger raw value passes through.
*/
function normalizeLineHeightPayload(payload) {
	const raw = unwrapScalar(payload, [
		"line",
		"lineHeight",
		"value"
	]);
	const num = typeof raw === "number" ? raw : typeof raw === "string" ? Number.parseFloat(raw.trim()) : NaN;
	if (!Number.isFinite(num) || num <= 0) return raw;
	return num <= 10 ? Math.round(num * 240) : Math.round(num);
}
/** Preserve semantic style intent; normalize legacy linked-style payloads to a concrete ID. */
function normalizeStyleIdPayload(payload) {
	if (payload && typeof payload === "object" && "role" in payload) return payload;
	const raw = unwrapScalar(payload, [
		"styleId",
		"value",
		"style"
	]);
	return typeof raw === "string" ? raw.trim() : raw;
}
/** Resolve a document-mode payload (`"viewing"` or `{ mode }`) to the mode string. */
function normalizeDocumentModePayload(payload) {
	if (typeof payload === "string") return payload;
	if (payload && typeof payload === "object") {
		const mode = payload.mode;
		if (typeof mode === "string") return mode;
	}
	return payload;
}
var UNSUPPORTED = SUPERDOC_UI_REASONS.commandUnsupported;
var TABLE_CONTEXT = SUPERDOC_UI_REASONS.tableContextUnavailable;
/**
* The built-in command catalog. Order is documentation-only. Every v1
* headless-toolbar id appears here with an explicit disposition; the 14
* canonical v2 ids route today, the kebab track-change selection ids and the
* zoom / document-mode ids are newly routed in this unit, and the remaining v1
* workflows are deferred or marked product-unsupported with a stable reason.
*/
var COMMAND_CATALOG = [
	{
		id: "bold",
		family: "inline marks",
		disposition: "routed",
		mutates: true,
		docRoute: "format.bold",
		activeMark: "bold",
		inline: {
			key: "bold",
			kind: "toggle"
		}
	},
	{
		id: "italic",
		family: "inline marks",
		disposition: "routed",
		mutates: true,
		docRoute: "format.italic",
		activeMark: "italic",
		inline: {
			key: "italic",
			kind: "toggle"
		}
	},
	{
		id: "underline",
		family: "inline marks",
		disposition: "routed",
		mutates: true,
		docRoute: "format.underline",
		activeMark: "underline",
		inline: {
			key: "underline",
			kind: "toggle"
		}
	},
	{
		id: "strikethrough",
		family: "inline marks",
		disposition: "routed",
		mutates: true,
		docRoute: "format.strikethrough",
		activeMark: "strikethrough",
		inline: {
			key: "strike",
			kind: "toggle"
		}
	},
	{
		id: "font-family",
		family: "fonts",
		disposition: "routed",
		mutates: true,
		docRoute: "format.fontFamily",
		aliases: ["setFontFamily"],
		inline: {
			key: "fontFamily",
			kind: "value-string"
		}
	},
	{
		id: "font-size",
		family: "fonts",
		disposition: "routed",
		mutates: true,
		docRoute: "format.fontSize",
		aliases: ["setFontSize"],
		normalizePayload: normalizeFontSizePayload,
		inline: {
			key: "fontSize",
			kind: "value-number"
		}
	},
	{
		id: "setFontFamily",
		family: "fonts",
		disposition: "routed",
		mutates: true,
		docRoute: "format.fontFamily",
		aliasOf: "font-family",
		inline: {
			key: "fontFamily",
			kind: "value-string"
		}
	},
	{
		id: "setFontSize",
		family: "fonts",
		disposition: "routed",
		mutates: true,
		docRoute: "format.fontSize",
		aliasOf: "font-size",
		normalizePayload: normalizeFontSizePayload,
		inline: {
			key: "fontSize",
			kind: "value-number"
		}
	},
	{
		id: "undo",
		family: "history",
		disposition: "routed",
		mutates: true,
		docRoute: "history.undo"
	},
	{
		id: "redo",
		family: "history",
		disposition: "routed",
		mutates: true,
		docRoute: "history.redo"
	},
	{
		id: "acceptChange",
		family: "tracked changes",
		disposition: "routed",
		mutates: true,
		trackDecision: {
			kind: "accept",
			scope: "id"
		},
		aliases: ["track-changes-accept-selection"]
	},
	{
		id: "rejectChange",
		family: "tracked changes",
		disposition: "routed",
		mutates: true,
		trackDecision: {
			kind: "reject",
			scope: "id"
		},
		aliases: ["track-changes-reject-selection"]
	},
	{
		id: "acceptAllChanges",
		family: "tracked changes (bulk)",
		disposition: "routed",
		mutates: true,
		trackDecision: {
			kind: "accept",
			scope: "all"
		}
	},
	{
		id: "rejectAllChanges",
		family: "tracked changes (bulk)",
		disposition: "routed",
		mutates: true,
		trackDecision: {
			kind: "reject",
			scope: "all"
		}
	},
	{
		id: "track-changes-accept-selection",
		family: "tracked changes",
		disposition: "routed",
		mutates: true,
		trackDecision: {
			kind: "accept",
			scope: "id"
		},
		aliasOf: "acceptChange"
	},
	{
		id: "track-changes-reject-selection",
		family: "tracked changes",
		disposition: "routed",
		mutates: true,
		trackDecision: {
			kind: "reject",
			scope: "id"
		},
		aliasOf: "rejectChange"
	},
	{
		id: "zoom",
		family: "zoom",
		disposition: "routed",
		mutates: false,
		instanceRoute: "setZoom",
		valueFrom: "zoom",
		normalizePayload: normalizeZoomPayload
	},
	{
		id: "zoom-fit-width",
		family: "zoom",
		disposition: "routed",
		mutates: false,
		instanceRoute: "setZoomMode",
		fixedArg: "fit-width",
		valueFrom: "zoom"
	},
	{
		id: "document-mode",
		family: "document",
		disposition: "routed",
		mutates: false,
		instanceRoute: "setDocumentMode",
		valueFrom: "documentMode",
		normalizePayload: normalizeDocumentModePayload
	},
	{
		id: "measurement-unit",
		family: "measurement",
		disposition: "routed",
		mutates: false,
		instanceRoute: "setMeasurementUnit",
		valueFrom: "measurementUnit",
		normalizePayload: normalizeMeasurementUnitPayload
	},
	{
		id: "text-color",
		family: "color",
		disposition: "routed",
		mutates: true,
		docRoute: "format.color",
		inline: {
			key: "color",
			kind: "value-string"
		},
		normalizePayload: normalizeColorPayload
	},
	{
		id: "highlight-color",
		family: "color",
		disposition: "routed",
		mutates: true,
		docRoute: "format.highlight",
		inline: {
			key: "highlight",
			kind: "value-string"
		},
		normalizePayload: normalizeColorPayload
	},
	{
		id: "link",
		family: "links",
		disposition: "routed",
		mutates: true,
		docRoute: "hyperlinks.wrap",
		activeMark: "link",
		link: { kind: "link" }
	},
	{
		id: "text-align",
		family: "paragraph",
		disposition: "routed",
		mutates: true,
		docRoute: "format.paragraph.setAlignment",
		blockParagraph: { kind: "alignment" },
		normalizePayload: normalizeAlignmentPayload
	},
	{
		id: "line-height",
		family: "paragraph",
		disposition: "routed",
		mutates: true,
		docRoute: "format.paragraph.setSpacing",
		blockParagraph: { kind: "spacing-line" },
		normalizePayload: normalizeLineHeightPayload
	},
	{
		id: "linked-style",
		family: "paragraph",
		disposition: "routed",
		mutates: true,
		docRoute: "styles.paragraph.setStyle",
		blockParagraph: { kind: "style" },
		normalizePayload: normalizeStyleIdPayload
	},
	{
		id: "bullet-list",
		family: "lists",
		disposition: "routed",
		mutates: true,
		docRoute: "lists.apply",
		list: {
			mode: "toggle-seed",
			seed: "bullet"
		}
	},
	{
		id: "numbered-list",
		family: "lists",
		disposition: "routed",
		mutates: true,
		docRoute: "lists.apply",
		list: {
			mode: "toggle-seed",
			seed: "ordered"
		}
	},
	{
		id: "indent-increase",
		family: "lists/indent",
		disposition: "routed",
		mutates: true,
		docRoute: "lists.indent",
		list: { mode: "indent" }
	},
	{
		id: "indent-decrease",
		family: "lists/indent",
		disposition: "routed",
		mutates: true,
		docRoute: "lists.outdent",
		list: { mode: "outdent" }
	},
	{
		id: "direction-ltr",
		family: "direction",
		disposition: "routed",
		mutates: true,
		docRoute: "format.paragraph.setDirection",
		blockParagraph: {
			kind: "direction",
			fixedValue: "ltr"
		}
	},
	{
		id: "direction-rtl",
		family: "direction",
		disposition: "routed",
		mutates: true,
		docRoute: "format.paragraph.setDirection",
		blockParagraph: {
			kind: "direction",
			fixedValue: "rtl"
		}
	},
	{
		id: "clear-formatting",
		family: "formatting",
		disposition: "routed",
		mutates: true,
		docRoute: "format.apply",
		inline: {
			key: "*",
			kind: "clear"
		}
	},
	{
		id: "image",
		family: "media",
		disposition: "routed",
		mutates: true,
		docRoute: "create.image",
		create: { kind: "image" }
	},
	{
		id: "table-of-contents-insert",
		family: "TOC",
		disposition: "routed",
		mutates: true,
		docRoute: "create.tableOfContents",
		create: { kind: "toc" }
	},
	{
		id: "table-insert",
		family: "tables",
		disposition: "routed",
		mutates: true,
		docRoute: "create.table",
		create: { kind: "table" }
	},
	{
		id: "table-add-row-before",
		family: "tables",
		disposition: "routed",
		mutates: true,
		docRoute: "tables.insertRow",
		table: {
			action: "insert-row-before",
			op: "insertRow"
		},
		reason: TABLE_CONTEXT
	},
	{
		id: "table-add-row-after",
		family: "tables",
		disposition: "routed",
		mutates: true,
		docRoute: "tables.insertRow",
		table: {
			action: "insert-row-after",
			op: "insertRow"
		},
		reason: TABLE_CONTEXT
	},
	{
		id: "table-delete-row",
		family: "tables",
		disposition: "routed",
		mutates: true,
		docRoute: "tables.deleteRow",
		table: {
			action: "delete-row",
			op: "deleteRow"
		},
		reason: TABLE_CONTEXT
	},
	{
		id: "table-add-column-before",
		family: "tables",
		disposition: "routed",
		mutates: true,
		docRoute: "tables.insertColumn",
		table: {
			action: "insert-column-before",
			op: "insertColumn"
		},
		reason: TABLE_CONTEXT
	},
	{
		id: "table-add-column-after",
		family: "tables",
		disposition: "routed",
		mutates: true,
		docRoute: "tables.insertColumn",
		table: {
			action: "insert-column-after",
			op: "insertColumn"
		},
		reason: TABLE_CONTEXT
	},
	{
		id: "table-delete-column",
		family: "tables",
		disposition: "routed",
		mutates: true,
		docRoute: "tables.deleteColumn",
		table: {
			action: "delete-column",
			op: "deleteColumn"
		},
		reason: TABLE_CONTEXT
	},
	{
		id: "table-delete",
		family: "tables",
		disposition: "routed",
		mutates: true,
		docRoute: "tables.delete",
		table: {
			action: "delete-table",
			op: "delete"
		},
		reason: TABLE_CONTEXT
	},
	{
		id: "table-merge-cells",
		family: "tables",
		disposition: "routed",
		mutates: true,
		docRoute: "tables.mergeCells",
		table: {
			action: "merge-cells",
			op: "mergeCells"
		},
		reason: TABLE_CONTEXT
	},
	{
		id: "table-split-cell",
		family: "tables",
		disposition: "routed",
		mutates: true,
		docRoute: "tables.splitCell",
		table: {
			action: "split-cell",
			op: "splitCell",
			requiresCell: true
		},
		reason: TABLE_CONTEXT
	},
	{
		id: "table-remove-borders",
		family: "tables",
		disposition: "routed",
		mutates: true,
		docRoute: "tables.setBorders",
		table: {
			action: "remove-borders",
			op: "setBorders"
		},
		reason: TABLE_CONTEXT
	},
	{
		id: "ruler",
		family: "UI chrome",
		disposition: "routed",
		mutates: false,
		instanceRoute: "toggleRuler",
		valueFrom: "ruler"
	},
	{
		id: "formatting-marks",
		family: "UI chrome",
		disposition: "routed",
		mutates: false,
		instanceRoute: "toggleFormattingMarks",
		valueFrom: "formattingMarks"
	},
	{
		id: "copy-format",
		family: "formatting",
		disposition: "routed",
		mutates: false
	},
	{
		id: "table-fix",
		family: "tables",
		disposition: "unsupported",
		mutates: true,
		reason: UNSUPPORTED
	}
];
var CATALOG_BY_ID = new Map(COMMAND_CATALOG.map((descriptor) => [descriptor.id, descriptor]));
/** All built-in command ids known to the controller (routed + deferred + unsupported). */
var ALL_BUILT_IN_COMMAND_IDS = COMMAND_CATALOG.map((d) => d.id);
/** Resolve a command descriptor by id, or `null` when the id is unknown. */
function getCommandDescriptor(id) {
	return CATALOG_BY_ID.get(id) ?? null;
}
//#endregion
//#region src/public/ui/equality.ts
/**
* Shallow equality used by the controller to suppress redundant slice
* notifications. v2-native, dependency-free.
*/
/**
* Returns `true` when `a` and `b` are the same reference, or are objects with
* the same own-enumerable keys and `Object.is`-equal values one level deep.
* Arrays compare by index. Primitives compare with `Object.is`.
*/
function shallowEqual(a, b) {
	if (Object.is(a, b)) return true;
	if (typeof a !== "object" || a === null || typeof b !== "object" || b === null) return false;
	if (Array.isArray(a) !== Array.isArray(b)) return false;
	const aKeys = Object.keys(a);
	const bKeys = Object.keys(b);
	if (aKeys.length !== bKeys.length) return false;
	for (const key of aKeys) {
		if (!Object.prototype.hasOwnProperty.call(b, key)) return false;
		if (!Object.is(a[key], b[key])) return false;
	}
	return true;
}
//#endregion
//#region src/public/ui/format-painter-helpers.js
/**
* Maps SDRunProps field names to InlineRunPatch field names.
* SDRunProps (read-side) and InlineRunPatch (write-side) use different keys
* for the same properties; direct assignment between them is forbidden.
*
* @param {Record<string, unknown>} props - SDRunProps object from doc.getNodeById
* @returns {Record<string, unknown>} InlineRunPatch ready for doc.format.apply
*/
function sdRunPropsToInlineRunPatch(props) {
	if (!props || typeof props !== "object") return {};
	const patch = {};
	if (props.fonts) patch.rFonts = {
		ascii: props.fonts.ascii,
		hAnsi: props.fonts.hAnsi,
		eastAsia: props.fonts.eastAsia,
		cs: props.fonts.cs,
		asciiTheme: props.fonts.asciiTheme,
		hAnsiTheme: props.fonts.hAnsiTheme,
		eastAsiaTheme: props.fonts.eastAsiaTheme,
		csTheme: props.fonts.csTheme,
		hint: props.fonts.hint
	};
	if (props.fontFamily != null) patch.fontFamily = props.fontFamily;
	if (props.lang) patch.lang = {
		val: props.lang.val,
		eastAsia: props.lang.eastAsia,
		bidi: props.lang.bidi
	};
	if (props.fontSize != null) patch.fontSize = props.fontSize;
	if (props.fontSizeCs != null) patch.fontSizeCs = props.fontSizeCs;
	const color = projectColorRefToInlineColor(props.color);
	if (color != null) patch.color = color;
	if (props.highlight != null) patch.highlight = props.highlight;
	const shading = projectShadingToInlinePatch(props.shading);
	if (shading) patch.shading = shading;
	if (props.cs != null) patch.cs = props.cs;
	if (props.rtl != null) patch.rtl = props.rtl;
	if (props.bold != null) patch.bold = props.bold;
	if (props.boldCs != null) patch.bCs = props.boldCs;
	if (props.italic != null) patch.italic = props.italic;
	if (props.italicCs != null) patch.iCs = props.italicCs;
	const underline = projectUnderlineToInlinePatch(props.underline);
	if (underline !== void 0) patch.underline = underline;
	if (props.strikethrough != null) patch.strike = props.strikethrough;
	if (props.doubleStrikethrough != null) patch.dstrike = props.doubleStrikethrough;
	if (props.caps != null) patch.caps = props.caps;
	if (props.smallCaps != null) patch.smallCaps = props.smallCaps;
	if (props.outline != null) patch.outline = props.outline;
	if (props.shadow != null) patch.shadow = props.shadow;
	if (props.emboss != null) patch.emboss = props.emboss;
	if (props.imprint != null) patch.imprint = props.imprint;
	if (props.verticalAlign != null) patch.vertAlign = props.verticalAlign;
	if (props.characterSpacing != null) patch.letterSpacing = props.characterSpacing;
	if (props.characterScale != null) patch.charScale = props.characterScale;
	if (props.kern != null) patch.kerning = props.kern;
	if (props.baselineShift != null) patch.position = props.baselineShift;
	if (props.fitTextWidth != null) patch.fitText = { val: props.fitTextWidth };
	if (props.vanish != null) patch.vanish = props.vanish;
	if (props.webHidden != null) patch.webHidden = props.webHidden;
	if (props.specVanish != null) patch.specVanish = props.specVanish;
	const border = projectBorderToInlinePatch(props.border);
	if (border) patch.border = border;
	return patch;
}
function projectColorRefToInlineColor(color) {
	if (!color) return void 0;
	if (typeof color === "string") return color;
	if (color.model === "rgb") return color.value;
	if (color.model === "auto") return "auto";
}
function projectUnderlineToInlinePatch(underline) {
	if (underline == null) return void 0;
	const patch = {};
	if (underline.style != null) patch.style = underline.style;
	if (underline.color?.model === "rgb") patch.color = underline.color.value;
	if (underline.color?.model === "theme") patch.themeColor = underline.color.theme;
	return Object.keys(patch).length > 0 ? patch : true;
}
function projectShadingToInlinePatch(shading) {
	if (!shading) return void 0;
	const patch = {};
	const fill = projectColorRefToInlineColor(shading.fill);
	if (fill != null) patch.fill = fill;
	const color = projectColorRefToInlineColor(shading.color);
	if (color != null) patch.color = color;
	if (shading.pattern != null) patch.val = shading.pattern;
	return Object.keys(patch).length > 0 ? patch : void 0;
}
function projectBorderToInlinePatch(border) {
	if (!border) return void 0;
	const patch = {};
	if (border.style != null) patch.val = border.style;
	if (border.width != null) patch.sz = border.width;
	if (border.space != null) patch.space = border.space;
	const color = projectColorRefToInlineColor(border.color);
	if (color != null) patch.color = color;
	return Object.keys(patch).length > 0 ? patch : void 0;
}
/**
* Serializes a selection to a stable string key used to detect whether
* the target selection is the same as the source (skip apply in that case).
*
* Falls back to the plain text target when the host has not populated an
* explicit `selectionTarget` yet.
*
* @param {{ selectionTarget?: unknown; target?: unknown } | null | undefined} selection
* @returns {string}
*/
function selectionKey(selection) {
	const target = selection?.selectionTarget ?? selection?.target;
	if (!selection || !target) return "";
	try {
		return JSON.stringify(target);
	} catch {
		return String(target);
	}
}
//#endregion
//#region src/helpers/v2-typing-mutation-event.js
/**
* Command kinds whose committed mutations belong to the sustained typing
* cadence class (insert / replace / plain paste / Backspace / Delete).
*
* The SuperDoc shell debounces per-keystroke review-row hydration for these
* kinds instead of refreshing comments + tracked changes on every commit —
* hydrating immediately per keystroke was a measured worker-read storm during
* typing and backspace bursts. The `text.*` aliases cover integrations that
* forward Document API style command ids rather than editable-input kinds.
*/
var V2_TYPING_COMMAND_KINDS = /* @__PURE__ */ new Set([
	"insert-text",
	"replace-text",
	"plain-text-paste",
	"delete-backward",
	"delete-forward",
	"text.insert",
	"text.replace",
	"text.pastePlain",
	"text.deleteBackward",
	"text.deleteForward",
	"structural.enter",
	"structural:enter-split-paragraph",
	"structural:enter-insert-paragraph-before",
	"structural:enter-insert-paragraph-after",
	"structural:shift-enter-line-break",
	"structural:backspace-boundary-merge-with-previous",
	"structural:delete-boundary-merge-with-next",
	"backspace:boundary-merge-with-previous",
	"backspace:list-remove",
	"backspace:list-outdent"
]);
/**
* True when a forwarded v2 host event is a committed editable-input mutation
* of the sustained-typing class, i.e. review-row hydration for it should be
* debounced rather than fired immediately.
*
* Events without a forwarded `editableCommandKind` (programmatic Document API
* mutations, history commits, unclassified structural commands) return false
* so they keep hydrating immediately.
*
* @param {{ type?: string, origin?: string, editableCommandKind?: string } | null | undefined} event
* @returns {boolean}
*/
var isV2EditableTextMutationEvent = (event) => {
	if (event?.type !== "mutation:committed" || event.origin !== "command") return false;
	return V2_TYPING_COMMAND_KINDS.has(event.editableCommandKind);
};
//#endregion
//#region src/public/ui/entity-at.ts
function parseCommaSeparatedIds(value) {
	return value.split(",").map((id) => id.trim()).filter(Boolean);
}
/**
* Collect every public-id candidate a painted run can carry for a tracked
* change, deduped, in priority order: the canonical
* `data-track-change-preferred-target-id` first (when the painter stamps one),
* then the `data-track-change-ids` list, then the singular
* `data-track-change-id`. The caller validates these against the live
* tracked-changes slice and keeps whichever is the public id, so it does not
* matter which attribute carries it — an imported/raw alias on one attribute
* never hides the public id on another (a union, not a prefer-one-attribute).
*/
function getTrackChangeIds(node) {
	const out = [];
	const add = (id) => {
		if (id && !out.includes(id)) out.push(id);
	};
	add(node.getAttribute("data-track-change-preferred-target-id"));
	const list = node.getAttribute("data-track-change-ids");
	if (list) for (const id of parseCommaSeparatedIds(list)) add(id);
	add(node.getAttribute("data-track-change-id"));
	return out;
}
/**
* Read painted entities off `el` and every ancestor up to the document root, or
* up to and INCLUDING `stopAt` when given. Innermost-first ordering: a tracked
* change inside a comment highlight returns `[{ trackedChange }, { comment }]`,
* matching what a switch on `hits[0]` expects when picking the most specific
* entity.
*
* `stopAt` bounds the walk to the visible host: its own attributes are read, but
* the walk never climbs into an app wrapper ABOVE it, so wrapper data-* cannot
* leak into the hits. Omitting it keeps the original walk-to-document-root.
*
* Returns `[]` for null / non-Element starts. Uses duck-typed `getAttribute`
* access so it works under any DOM implementation (happy-dom, jsdom, real
* browser) without an `instanceof` check that could fail across realms.
*/
function collectEntityHitsFromChain(start, stopAt) {
	if (!start || typeof start.getAttribute !== "function") return [];
	const hits = [];
	const seen = /* @__PURE__ */ new Set();
	let pendingStory = [];
	let el = start;
	while (el) {
		const node = el;
		const trackChangeIds = getTrackChangeIds(node);
		const storyKey = trackChangeIds.length > 0 ? node.getAttribute("data-story-key") : null;
		for (const trackChangeId of trackChangeIds) {
			const key = `trackedChange:${trackChangeId}`;
			if (!seen.has(key)) {
				seen.add(key);
				const hit = {
					type: "trackedChange",
					id: trackChangeId
				};
				if (storyKey) hit.storyKey = storyKey;
				hits.push(hit);
				pendingStory.push(hit);
			}
		}
		const layoutStory = node.getAttribute("data-layout-story");
		if (layoutStory && pendingStory.length > 0) {
			for (const hit of pendingStory) hit.story = layoutStory;
			pendingStory = [];
		}
		const citationId = node.getAttribute("data-citation-id");
		if (citationId) {
			const key = `citation:${citationId}`;
			if (!seen.has(key)) {
				seen.add(key);
				hits.push({
					type: "citation",
					id: citationId
				});
			}
		}
		const commentIds = node.getAttribute("data-comment-ids");
		if (commentIds) for (const id of parseCommaSeparatedIds(commentIds)) {
			const key = `comment:${id}`;
			if (!seen.has(key)) {
				seen.add(key);
				hits.push({
					type: "comment",
					id
				});
			}
		}
		const sdtType = node.getAttribute("data-sdt-type");
		const sdtId = node.getAttribute("data-sdt-id");
		if (sdtId && sdtType === "structuredContent") {
			const key = `contentControl:${sdtId}`;
			if (!seen.has(key)) {
				seen.add(key);
				const scopeAttr = node.getAttribute("data-sdt-scope");
				const tag = node.getAttribute("data-sdt-tag");
				const hit = {
					type: "contentControl",
					id: sdtId
				};
				if (scopeAttr === "block" || scopeAttr === "inline") hit.scope = scopeAttr;
				if (tag) hit.tag = tag;
				hits.push(hit);
			}
		}
		if (stopAt && el === stopAt) break;
		el = el.parentElement;
	}
	return hits;
}
//#endregion
//#region ../document-api/src/format/inline-run-patch.ts
var schemaBooleanOrNull = () => ({ oneOf: [{ type: "boolean" }, { type: "null" }] });
var schemaStringOrNull = () => ({ oneOf: [{
	type: "string",
	minLength: 1
}, { type: "null" }] });
var schemaNumberOrNull = () => ({ oneOf: [{ type: "number" }, { type: "null" }] });
var schemaObjectOrNull = (properties) => ({ oneOf: [{
	type: "object",
	properties,
	additionalProperties: false,
	minProperties: 1
}, { type: "null" }] });
var UNDERLINE_OBJECT_SCHEMA = {
	type: "object",
	properties: {
		style: { oneOf: [{
			type: "string",
			minLength: 1
		}, { type: "null" }] },
		color: { oneOf: [{
			type: "string",
			minLength: 1
		}, { type: "null" }] },
		themeColor: { oneOf: [{
			type: "string",
			minLength: 1
		}, { type: "null" }] }
	},
	additionalProperties: false,
	minProperties: 1
};
var STYLISTIC_SET_ITEM_SCHEMA = {
	type: "object",
	properties: {
		id: { type: "number" },
		val: { type: "boolean" }
	},
	required: ["id"],
	additionalProperties: false
};
var schemaUnderlinePatch = () => ({ oneOf: [
	{ type: "boolean" },
	{ type: "null" },
	UNDERLINE_OBJECT_SCHEMA
] });
var schemaStylisticSets = () => ({ oneOf: [{
	type: "array",
	items: STYLISTIC_SET_ITEM_SCHEMA,
	minItems: 1
}, { type: "null" }] });
function markCarrier(markName, textStyleAttr) {
	return {
		storage: "mark",
		markName,
		textStyleAttr
	};
}
function runAttributeCarrier(runPropertyKey) {
	return {
		storage: "runAttribute",
		nodeName: "run",
		runPropertyKey
	};
}
var markBoolean = (key, ooxmlElement, markName) => ({
	key,
	type: "boolean",
	ooxmlElement,
	storage: "mark",
	tracked: true,
	carrier: markCarrier(markName),
	schema: schemaBooleanOrNull()
});
var markTextStyleValue = (key, type, ooxmlElement, schema, textStyleAttr) => ({
	key,
	type,
	ooxmlElement,
	storage: "mark",
	tracked: true,
	carrier: markCarrier("textStyle", textStyleAttr ?? key),
	schema
});
var runAttribute = (key, type, ooxmlElement, schema, runPropertyKey) => ({
	key,
	type,
	ooxmlElement,
	storage: "runAttribute",
	tracked: false,
	carrier: runAttributeCarrier(runPropertyKey ?? key),
	schema
});
var INLINE_PROPERTY_REGISTRY = [
	markBoolean("bold", "w:b", "bold"),
	markBoolean("italic", "w:i", "italic"),
	markBoolean("strike", "w:strike", "strike"),
	{
		key: "underline",
		type: "object",
		ooxmlElement: "w:u",
		storage: "mark",
		tracked: true,
		carrier: markCarrier("underline"),
		schema: schemaUnderlinePatch()
	},
	{
		key: "highlight",
		type: "string",
		ooxmlElement: "w:highlight",
		storage: "mark",
		tracked: true,
		carrier: markCarrier("highlight"),
		schema: schemaStringOrNull()
	},
	markTextStyleValue("color", "string", "w:color", schemaStringOrNull()),
	markTextStyleValue("fontSize", "number", "w:sz", schemaNumberOrNull()),
	markTextStyleValue("fontFamily", "string", "w:rFonts", schemaStringOrNull()),
	markTextStyleValue("letterSpacing", "number", "w:spacing", schemaNumberOrNull()),
	markTextStyleValue("vertAlign", "string", "w:vertAlign", { oneOf: [{ enum: [
		"superscript",
		"subscript",
		"baseline"
	] }, { type: "null" }] }),
	markTextStyleValue("position", "number", "w:position", schemaNumberOrNull()),
	runAttribute("dstrike", "boolean", "w:dstrike", schemaBooleanOrNull()),
	runAttribute("smallCaps", "boolean", "w:smallCaps", schemaBooleanOrNull()),
	markTextStyleValue("caps", "boolean", "w:caps", schemaBooleanOrNull(), "textTransform"),
	runAttribute("shading", "object", "w:shd", schemaObjectOrNull({
		fill: { oneOf: [{
			type: "string",
			minLength: 1
		}, { type: "null" }] },
		color: { oneOf: [{
			type: "string",
			minLength: 1
		}, { type: "null" }] },
		val: { oneOf: [{
			type: "string",
			minLength: 1
		}, { type: "null" }] }
	})),
	runAttribute("border", "object", "w:bdr", schemaObjectOrNull({
		val: { oneOf: [{
			type: "string",
			minLength: 1
		}, { type: "null" }] },
		sz: { oneOf: [{ type: "number" }, { type: "null" }] },
		color: { oneOf: [{
			type: "string",
			minLength: 1
		}, { type: "null" }] },
		space: { oneOf: [{ type: "number" }, { type: "null" }] }
	}), "borders"),
	runAttribute("outline", "boolean", "w:outline", schemaBooleanOrNull()),
	runAttribute("shadow", "boolean", "w:shadow", schemaBooleanOrNull()),
	runAttribute("emboss", "boolean", "w:emboss", schemaBooleanOrNull()),
	runAttribute("imprint", "boolean", "w:imprint", schemaBooleanOrNull()),
	runAttribute("charScale", "number", "w:w", schemaNumberOrNull(), "w"),
	runAttribute("kerning", "number", "w:kern", schemaNumberOrNull(), "kern"),
	runAttribute("vanish", "boolean", "w:vanish", schemaBooleanOrNull()),
	runAttribute("webHidden", "boolean", "w:webHidden", schemaBooleanOrNull()),
	runAttribute("specVanish", "boolean", "w:specVanish", schemaBooleanOrNull()),
	runAttribute("rtl", "boolean", "w:rtl", schemaBooleanOrNull()),
	runAttribute("cs", "boolean", "w:cs", schemaBooleanOrNull()),
	runAttribute("bCs", "boolean", "w:bCs", schemaBooleanOrNull(), "boldCs"),
	runAttribute("iCs", "boolean", "w:iCs", schemaBooleanOrNull(), "italicCs"),
	runAttribute("eastAsianLayout", "object", "w:eastAsianLayout", schemaObjectOrNull({
		id: { oneOf: [{
			type: "string",
			minLength: 1
		}, { type: "null" }] },
		combine: { oneOf: [{ type: "boolean" }, { type: "null" }] },
		combineBrackets: { oneOf: [{
			type: "string",
			minLength: 1
		}, { type: "null" }] },
		vert: { oneOf: [{ type: "boolean" }, { type: "null" }] },
		vertCompress: { oneOf: [{ type: "boolean" }, { type: "null" }] }
	})),
	runAttribute("em", "string", "w:em", schemaStringOrNull()),
	runAttribute("fitText", "object", "w:fitText", schemaObjectOrNull({
		val: { oneOf: [{ type: "number" }, { type: "null" }] },
		id: { oneOf: [{
			type: "string",
			minLength: 1
		}, { type: "null" }] }
	})),
	runAttribute("snapToGrid", "boolean", "w:snapToGrid", schemaBooleanOrNull()),
	runAttribute("lang", "object", "w:lang", schemaObjectOrNull({
		val: { oneOf: [{
			type: "string",
			minLength: 1
		}, { type: "null" }] },
		eastAsia: { oneOf: [{
			type: "string",
			minLength: 1
		}, { type: "null" }] },
		bidi: { oneOf: [{
			type: "string",
			minLength: 1
		}, { type: "null" }] }
	})),
	runAttribute("oMath", "boolean", "w:oMath", schemaBooleanOrNull()),
	runAttribute("rStyle", "string", "w:rStyle", schemaStringOrNull(), "styleId"),
	runAttribute("rFonts", "object", "w:rFonts", schemaObjectOrNull({
		ascii: { oneOf: [{
			type: "string",
			minLength: 1
		}, { type: "null" }] },
		hAnsi: { oneOf: [{
			type: "string",
			minLength: 1
		}, { type: "null" }] },
		eastAsia: { oneOf: [{
			type: "string",
			minLength: 1
		}, { type: "null" }] },
		cs: { oneOf: [{
			type: "string",
			minLength: 1
		}, { type: "null" }] },
		asciiTheme: { oneOf: [{
			type: "string",
			minLength: 1
		}, { type: "null" }] },
		hAnsiTheme: { oneOf: [{
			type: "string",
			minLength: 1
		}, { type: "null" }] },
		eastAsiaTheme: { oneOf: [{
			type: "string",
			minLength: 1
		}, { type: "null" }] },
		csTheme: { oneOf: [{
			type: "string",
			minLength: 1
		}, { type: "null" }] },
		hint: { oneOf: [{
			type: "string",
			minLength: 1
		}, { type: "null" }] }
	}), "fontFamily"),
	runAttribute("fontSizeCs", "number", "w:szCs", schemaNumberOrNull()),
	runAttribute("ligatures", "string", "w14:ligatures", schemaStringOrNull()),
	runAttribute("numForm", "string", "w14:numForm", schemaStringOrNull()),
	runAttribute("numSpacing", "string", "w14:numSpacing", schemaStringOrNull()),
	runAttribute("stylisticSets", "array", "w14:stylisticSets", schemaStylisticSets()),
	runAttribute("contextualAlternates", "boolean", "w14:cntxtAlts", schemaBooleanOrNull())
];
new Set(INLINE_PROPERTY_REGISTRY.map((entry) => entry.key));
var INLINE_PROPERTY_BY_KEY = Object.fromEntries(INLINE_PROPERTY_REGISTRY.map((entry) => [entry.key, entry]));
INLINE_PROPERTY_REGISTRY.filter((entry) => entry.storage === "mark").map((entry) => entry.key), INLINE_PROPERTY_REGISTRY.filter((entry) => entry.storage === "runAttribute").map((entry) => entry.key);
//#endregion
//#region src/public/ui/create-super-doc-ui.ts
/**
* v2-native `createSuperDocUI` controller.
*
* A small, truthful layer over the public v2 active-editor facade
* (`superdoc.activeEditor`), its read-only-guarded Document API
* (`activeEditor.doc`), and SuperDoc lifecycle events. No v1 editor imports,
* no private v2 runtime imports. In browser mode the underlying Document API
* facade is async-capable, so the controller normalizes it into live slices
* plus promise-capable workflow helpers. Every document read/mutation is
* attempted through the public Document API and degrades to a stable noop /
* `false` when the surface is unavailable (view mode, a pre-ready editor, or a
* host that has not exposed a Document API facade) rather than throwing.
*/
function uiBenchNowMs() {
	return typeof performance !== "undefined" && typeof performance.now === "function" ? performance.now() : Date.now();
}
function readUiBenchRuntime() {
	const benchGlobal = globalThis;
	return {
		sink: typeof benchGlobal.__superdocV2BenchPipelineTiming === "function" ? benchGlobal.__superdocV2BenchPipelineTiming : null,
		workerContext: benchGlobal.__superdocV2BenchWorkerMessageContext ?? null
	};
}
function emitUiBenchTiming(event) {
	const { sink } = readUiBenchRuntime();
	if (!sink) return;
	try {
		sink(event);
	} catch {}
}
var sharedUiTrackedChangesCatalogByHost = /* @__PURE__ */ new WeakMap();
function acquireSharedUiTrackedChangesCatalog(host) {
	let state = sharedUiTrackedChangesCatalogByHost.get(host);
	if (!state) {
		state = {
			refCount: 0,
			generation: 0,
			abortController: new AbortController(),
			inFlight: null,
			activeMutationTokens: /* @__PURE__ */ new Set()
		};
		sharedUiTrackedChangesCatalogByHost.set(host, state);
	}
	state.refCount += 1;
	return state;
}
function releaseSharedUiTrackedChangesCatalog(host, state) {
	state.refCount = Math.max(0, state.refCount - 1);
	if (state.refCount > 0) return;
	state.abortController.abort("ui-controller-destroyed");
	state.inFlight = null;
	state.activeMutationTokens.clear();
	sharedUiTrackedChangesCatalogByHost.delete(host);
}
var SUPERDOC_UI_REASON_VALUES = new Set(Object.values(SUPERDOC_UI_REASONS));
function coerceSuperDocUIReason(reason, fallback) {
	return typeof reason === "string" && SUPERDOC_UI_REASON_VALUES.has(reason) ? reason : fallback;
}
/**
* Normalize the host selection apply helper's return value for
* `selection.apply` / `selection.restore`: host `{ ok: false, reason }`
* results pass through (unknown reasons coerce to `target-unresolved`);
* anything else — including legacy void/boolean returns — counts as success.
*/
function normalizeHostSelectionApplyResult(result) {
	if (result && typeof result === "object") {
		if (result.ok === false) {
			const reason = result.reason;
			if (reason === "host-not-ready" || reason === "host-disposed" || reason === "editing-mount-required") return {
				ok: false,
				reason: SUPERDOC_UI_REASONS.notReady
			};
			return {
				ok: false,
				reason: coerceSuperDocUIReason(reason, SUPERDOC_UI_REASONS.targetUnresolved)
			};
		}
	}
	return { ok: true };
}
/** Lifecycle events the controller subscribes to. */
var HOST_EVENTS = [
	"document-replaced",
	"editorCreate",
	"active-editor-change",
	"document-mode-change",
	"zoomChange",
	"measurement-unit-change",
	"viewport-change",
	"fonts-changed"
];
/**
* row-862 — list toolbar ids routed through the v2 editor host edit-command
* surface (`activeEditor.editCommands.lists.apply`) rather than a raw one-off
* `doc.lists.apply` mutation, so readiness / mount / selection / read-only
* gating and command state stay coherent with the rest of the editor chrome.
*/
var LIST_TOGGLE_KINDS = {
	[BUILT_IN_COMMAND_IDS.bulletList]: "bullet",
	[BUILT_IN_COMMAND_IDS.numberedList]: "ordered"
};
function listToggleKind(id) {
	return LIST_TOGGLE_KINDS[id] ?? null;
}
/**
* SD-3571 — the built-in toolbar's bullet/numbered style dropdowns emit a bare
* toolbar style-key string (e.g. `'upper-roman'`, `'decimal-paren'`) as the
* command argument. Map each to the Document API `ListPresetId` so the chosen
* glyph/number format actually applies instead of being dropped to the default
* decimal/disc list. Keys mirror `internal/toolbar/built-in/list-style-buttons.js`
* (asserted by a coverage test); the public command surface also still accepts
* an options object with an explicit `preset`.
*/
var TOOLBAR_LIST_STYLE_PRESETS = {
	disc: "disc",
	circle: "circle",
	square: "square",
	decimal: "decimal",
	"decimal-paren": "decimalParenthesis",
	"upper-roman": "upperRoman",
	"lower-roman": "lowerRoman",
	"upper-alpha": "upperLetter",
	"upper-alpha-paren": "upperLetterParenthesis",
	"lower-alpha": "lowerLetter",
	"lower-alpha-paren": "lowerLetterParenthesis"
};
function presetFromToolbarStyleKey(styleKey) {
	const preset = TOOLBAR_LIST_STYLE_PRESETS[styleKey];
	return preset ? {
		preset,
		behavior: "toggleStyle"
	} : {};
}
var EMPTY_SELECTION = {
	status: "ready",
	empty: true,
	target: null,
	selectionTarget: null,
	activeMarks: [],
	activeCommentIds: [],
	activeChangeIds: [],
	quotedText: ""
};
var HEAVY_DOC_READ_POLICY = [
	{
		key: "contentControls",
		match: "exact",
		note: "full-document SDT catalog parse (the measured during-load cliff)"
	},
	{
		key: "contentControls:inRange:",
		match: "prefix",
		note: "same adapter load() as the catalog, issued per settled selection"
	},
	{
		key: "hyperlinks:",
		match: "prefix",
		note: "per-block hyperlink list over the loading story"
	},
	{
		key: "styles:catalog:",
		match: "prefix",
		note: "WordStyleModel recompile from package bytes"
	},
	{
		key: "comments",
		match: "exact",
		note: "audited: full comments list; stale-served during load"
	},
	{
		key: "trackChanges",
		match: "exact",
		note: "audited: shared all-story tracked-changes catalog; stale-served during load"
	},
	{
		key: "trackChanges:all",
		match: "exact",
		note: "audited: current-token validation over the shared all-story catalog; consumers fail closed on non-ready"
	},
	{
		key: "tables",
		match: "exact",
		note: "reserved: full tables catalog"
	},
	{
		key: "sections",
		match: "exact",
		note: "reserved: full sections list"
	}
];
var COMMENTS_CATALOG_PART_URIS = /* @__PURE__ */ new Set([
	"/word/comments.xml",
	"/word/commentsExtended.xml",
	"/word/commentsIds.xml"
]);
/** Whether a coordinator cache key falls under the heavy-read policy. */
function isHeavyDocReadKey(key) {
	return HEAVY_DOC_READ_POLICY.some((entry) => entry.match === "exact" ? entry.key === key : key.startsWith(entry.key));
}
/** Status precedence: a combined status is as "unsettled" as its worst part. */
var STATUS_RANK = {
	ready: 0,
	stale: 1,
	pending: 2
};
/** Combine read statuses; `pending` (no data yet) dominates `stale`, which dominates `ready`. */
function combineStatus(...statuses) {
	let worst = "ready";
	for (const status of statuses) if (STATUS_RANK[status] > STATUS_RANK[worst]) worst = status;
	return worst;
}
function safeCall(fn, fallback) {
	if (typeof fn !== "function") return fallback;
	try {
		const result = fn();
		return result === void 0 ? fallback : result;
	} catch {
		return fallback;
	}
}
function isPromiseLike(value) {
	return Boolean(value) && (typeof value === "object" || typeof value === "function") && typeof value.then === "function";
}
/** Resolve a dotted path (e.g. `format.bold`) to a callable on the doc facade. */
function resolveDocOperation(doc, path) {
	if (!doc) return null;
	const parts = path.split(".");
	let cursor = doc;
	for (const part of parts) {
		if (cursor == null) return null;
		cursor = cursor[part];
	}
	return typeof cursor === "function" ? cursor : null;
}
function failedReceipt(message, code = "CAPABILITY_UNAVAILABLE") {
	return {
		success: false,
		failure: {
			code,
			message
		}
	};
}
function partialLinkEditFailure(hyperlinkResult, textResult) {
	return {
		success: false,
		failure: {
			code: "PARTIAL_LINK_EDIT",
			message: "Hyperlink target was updated, but display text replacement failed."
		},
		applied: {
			href: true,
			text: false
		},
		hyperlinkResult,
		textResult
	};
}
/** Read a stable public `target` off a doc-api entity row. */
function readEntityTarget(row) {
	if (!row || typeof row !== "object") return null;
	const target = row.target;
	return target && typeof target === "object" ? target : null;
}
function isHostGeometryTarget(target) {
	if (!target || typeof target !== "object") return false;
	const record = target;
	const isTextPoint = (point) => {
		if (!point || typeof point !== "object") return false;
		const candidate = point;
		return candidate.kind === "text" && typeof candidate.blockId === "string" && typeof candidate.offset === "number";
	};
	const isTextSegment = (segment) => {
		if (!segment || typeof segment !== "object") return false;
		const candidate = segment;
		const range = candidate.range;
		return typeof candidate.blockId === "string" && typeof range?.start === "number" && typeof range.end === "number";
	};
	if (Array.isArray(record.segments)) {
		const first = record.segments[0];
		const last = record.segments[record.segments.length - 1];
		return isTextSegment(first) && isTextSegment(last);
	}
	if (record.kind === "selection") return isTextPoint(record.start) && isTextPoint(record.end);
	if (record.kind !== "text" || typeof record.blockId !== "string") return false;
	const range = record.range;
	return typeof range?.start === "number" && typeof range.end === "number";
}
/**
* Convert the tracked-change catalog's document-stable block address into the
* text address accepted by the host geometry surface. Keeping the entity
* address lets the host prefer the exact painted review carrier after the
* containing block has been materialized.
*/
function readTrackedChangeNavigationTarget(row, options) {
	if (!row || typeof row !== "object") return null;
	const target = readEntityTarget(row);
	const record = row;
	const navigationTarget = record.navigationTarget && typeof record.navigationTarget === "object" ? record.navigationTarget : null;
	if (navigationTarget?.kind === "block" && typeof navigationTarget.blockId === "string" && navigationTarget.blockId.length > 0) {
		const stableBlockTarget = {
			kind: "text",
			blockId: navigationTarget.blockId,
			range: {
				start: 0,
				end: 0
			},
			...navigationTarget.story && typeof navigationTarget.story === "object" ? { story: navigationTarget.story } : {},
			...record.address && typeof record.address === "object" ? { address: record.address } : {}
		};
		if (options?.preferStableBlock || !isHostGeometryTarget(target)) return stableBlockTarget;
	}
	return target;
}
function storyLocatorSignature(story) {
	if (!story || typeof story !== "object") return "story:body";
	const record = story;
	const storyType = typeof record.storyType === "string" ? record.storyType : "body";
	switch (storyType) {
		case "body": return "story:body";
		case "headerFooterPart": return `story:headerFooterPart:${typeof record.refId === "string" ? record.refId : ""}`;
		case "headerFooterSlot": return JSON.stringify({
			storyType,
			section: record.section ?? null,
			headerFooterKind: record.headerFooterKind ?? null,
			variant: record.variant ?? null,
			resolution: record.resolution ?? "effective",
			onWrite: record.onWrite ?? "materializeIfInherited"
		});
		case "footnote": return `story:footnote:${typeof record.noteId === "string" ? record.noteId : ""}`;
		case "endnote": return `story:endnote:${typeof record.noteId === "string" ? record.noteId : ""}`;
		case "textbox": return `story:textbox:${typeof record.textboxId === "string" ? record.textboxId : ""}`;
		default: return JSON.stringify(record);
	}
}
function readEntityStory(row) {
	if (!row || typeof row !== "object") return null;
	const record = row;
	const address = record.address && typeof record.address === "object" ? record.address : null;
	if (address?.story && typeof address.story === "object") return address.story;
	if (record.storyLocator && typeof record.storyLocator === "object") return record.storyLocator;
	if (record.trackedChangeStory && typeof record.trackedChangeStory === "object") return record.trackedChangeStory;
	const target = readEntityTarget(row);
	if (!target || typeof target !== "object") return null;
	const targetRecord = target;
	if (targetRecord.story && typeof targetRecord.story === "object") return targetRecord.story;
	const targetAddress = targetRecord.address && typeof targetRecord.address === "object" ? targetRecord.address : null;
	return targetAddress?.story && typeof targetAddress.story === "object" ? targetAddress.story : null;
}
function entityRowMatchesRequest(row, id, story) {
	if (readEntityId(row) !== id) return false;
	if (!story) return true;
	return storyLocatorSignature(readEntityStory(row)) === storyLocatorSignature(story);
}
/**
* Story to thread through a navigation / scroll request for a loaded list row:
* the row's own non-body story, or `undefined` for body / story-less rows.
* Mirrors `getAt`, which omits body stories from its hits, so body-only
* documents keep their id-only matching byte-for-byte unchanged while a
* non-body row (footnote / endnote / header / footer) pins target and carrier
* resolution to its own story — an id repeated across stories can no longer
* resolve to another story's occurrence (IT-1250).
*/
function readEntityRequestStory(row) {
	const story = readEntityStory(row);
	if (!story || storyLocatorSignature(story) === storyLocatorSignature(null)) return void 0;
	return story;
}
/**
* Bridge a painter `data-layout-story` value to the public Document API
* {@link StoryLocator} shape the controller's story-aware matchers speak.
*
* The painter encodes the layout story as `"body"` or `"<kind>:<id>"`;
* `decodeLayoutStoryDataset` turns that back into `{ kind, id }`. Tracked-change
* rows, however, carry a Document API `StoryLocator` (`{ kind: 'story',
* storyType, noteId | refId }`), and `storyLocatorSignature` keys on
* `storyType`, so the two forms must be reconciled before they can be compared.
* Body, unknown, and id-less stories all return `undefined` so callers fall back
* to id-only matching and never stamp a story onto the public hit — that keeps
* body-only documents byte-for-byte unchanged. Story disambiguation only kicks
* in for the non-body stories (footnote, endnote, header/footer) that can repeat
* a tracked-change id across stories.
*/
function layoutStoryDatasetToStoryLocator(raw) {
	if (typeof raw !== "string" || raw.length === 0) return void 0;
	const decoded = decodeLayoutStoryDataset(raw);
	switch (decoded.kind) {
		case "body": return;
		case "footnote": return decoded.id ? {
			kind: "story",
			storyType: "footnote",
			noteId: decoded.id
		} : void 0;
		case "endnote": return decoded.id ? {
			kind: "story",
			storyType: "endnote",
			noteId: decoded.id
		} : void 0;
		case "header":
		case "footer": return decoded.id ? {
			kind: "story",
			storyType: "headerFooterPart",
			refId: decoded.id
		} : void 0;
		default: return;
	}
}
/**
* Bridge a painter `data-story-key` value to the public Document API
* {@link StoryLocator} shape. PREFERRED over {@link layoutStoryDatasetToStoryLocator}
* for tracked changes: the run/marker element carries the real owning story in
* `data-story-key` (`'body'`, `'fn:<noteId>'`, `'en:<noteId>'`,
* `'hf:part:<refId>'`), while the layout fragment's `data-layout-story` falls
* back to `'body'` for the footnote/endnote band — so reading only the layout
* story loses the story identity needed to disambiguate repeated source ids.
*
* Split on the FIRST delimiter group only: the `fn:`/`en:` id and the `hf:part:`
* refId are taken verbatim after their prefix, so an id that itself contains a
* colon survives intact. The resulting shapes match what `storyLocatorSignature`
* keys on and what the all-story `list({ in: 'all' })` rows carry. Body, empty,
* and unknown keys return `undefined` so callers fall back to id-only matching
* and body-only documents stay byte-for-byte unchanged.
*/
function storyKeyToStoryLocator(raw) {
	if (typeof raw !== "string" || raw.length === 0 || raw === "body") return void 0;
	if (raw.startsWith("hf:part:")) {
		const refId = raw.slice(8);
		return refId ? {
			kind: "story",
			storyType: "headerFooterPart",
			refId
		} : void 0;
	}
	if (raw.startsWith("fn:")) {
		const noteId = raw.slice(3);
		return noteId ? {
			kind: "story",
			storyType: "footnote",
			noteId
		} : void 0;
	}
	if (raw.startsWith("en:")) {
		const noteId = raw.slice(3);
		return noteId ? {
			kind: "story",
			storyType: "endnote",
			noteId
		} : void 0;
	}
}
/** Read a public `selectionTarget` off a content-control row when available. */
function readSelectionTarget(row) {
	if (!row || typeof row !== "object") return null;
	const target = row.selectionTarget;
	return target && typeof target === "object" ? target : null;
}
function readContentControlRequestId(input) {
	if (!input || typeof input !== "object") return null;
	const id = input.id;
	return typeof id === "string" && id.length > 0 ? id : null;
}
function collapseSelectionTargetToCaret(target) {
	if (!target || typeof target !== "object") return null;
	const record = target;
	if (record.kind !== "selection") return target;
	const start = record.start;
	if (!start || typeof start !== "object") return null;
	return {
		...record,
		end: start
	};
}
/** Read a stable public row id from discovery/list/detail shapes. */
function readEntityId(row) {
	if (!row || typeof row !== "object") return null;
	const record = row;
	const id = record.id ?? record.commentId ?? record.changeId;
	return typeof id === "string" && id.length > 0 ? id : null;
}
function identityText(value) {
	return typeof value === "string" ? value.trim() : "";
}
/** Same id/email-first OWN rule as editor-core `classifyOwnership`. */
function trackedChangeOwnedByCurrentUser(change, currentUser) {
	const user = currentUser ?? {};
	const currentId = identityText(user.id).toLowerCase();
	const authorId = identityText(change.authorId).toLowerCase();
	if (currentId && authorId) return currentId === authorId;
	const currentEmail = identityText(user.email).toLowerCase();
	const authorEmail = identityText(change.authorEmail).toLowerCase();
	if (currentEmail && authorEmail) return currentEmail === authorEmail;
	if (currentId || currentEmail || authorId || authorEmail) return false;
	const authorName = identityText(change.author).replace(/\s+/g, " ").toLowerCase();
	if (!authorName) return true;
	const currentName = identityText(user.name).replace(/\s+/g, " ").toLowerCase();
	return Boolean(currentName && currentName === authorName);
}
/**
* Read the tracked-change carrier shared by both ends of a collapsed host
* selection. Unlike the public sync seed, this painted caret metadata is
* available without a worker read and proves that the caret still belongs to
* the same review carrier.
*/
function readCollapsedHostTrackChangeId(snapshot) {
	if (!snapshot || typeof snapshot !== "object") return null;
	const record = snapshot;
	const anchor = record.anchor;
	const focus = record.focus;
	const anchorVisual = anchor?.visualCaret;
	const focusVisual = focus?.visualCaret;
	const anchorId = anchorVisual?.trackChangeId;
	const focusId = focusVisual?.trackChangeId;
	return typeof anchorId === "string" && anchorId.length > 0 && anchorId === focusId ? anchorId : null;
}
var trackedChangeIdContextCache = /* @__PURE__ */ new WeakMap();
/**
* Collect the raw source-provenance ids a tracked-change list item exposes,
* reading from both the top-level row and its nested `change` payload (the
* public projection surfaces provenance on either shape).
*/
function readTrackChangeProvenanceIds(item) {
	const out = [];
	const push = (value) => {
		if (typeof value === "string" && value.length > 0 && !out.includes(value)) out.push(value);
	};
	const scan = (rec) => {
		if (!rec || typeof rec !== "object") return;
		const record = rec;
		const sourceIds = record.sourceIds;
		if (sourceIds && typeof sourceIds === "object") {
			push(sourceIds.wordIdInsert);
			push(sourceIds.wordIdDelete);
			if (Array.isArray(sourceIds.wordIdOther)) for (const w of sourceIds.wordIdOther) push(w);
		}
		const wordRevisionIds = record.wordRevisionIds;
		if (wordRevisionIds && typeof wordRevisionIds === "object") {
			push(wordRevisionIds.insert);
			push(wordRevisionIds.delete);
			push(wordRevisionIds.format);
		}
		const replacement = record.replacement;
		if (replacement && typeof replacement === "object") {
			for (const side of [replacement.inserted, replacement.deleted]) if (side && typeof side === "object") {
				push(side.id);
				push(side.wordId);
			}
		}
		const move = record.move;
		if (move && typeof move === "object") {
			for (const side of [move.source, move.destination]) if (side && typeof side === "object") {
				push(side.id);
				push(side.wordId);
			}
		}
	};
	scan(item);
	const change = item?.change;
	if (change && change !== item) scan(change);
	return out;
}
/** Build (or reuse) the alias↔canonical context for a tracked-change list slice. */
function buildTrackedChangeIdContext(items) {
	const cached = trackedChangeIdContextCache.get(items);
	if (cached) return cached;
	const itemIds = /* @__PURE__ */ new Set();
	const canonicalByAlias = /* @__PURE__ */ new Map();
	for (const item of items) {
		const publicId = readEntityId(item);
		if (!publicId) continue;
		itemIds.add(publicId);
		for (const raw of readTrackChangeProvenanceIds(item)) {
			if (!canonicalByAlias.has(raw)) canonicalByAlias.set(raw, publicId);
			const prefixed = `imported:${raw}`;
			if (!canonicalByAlias.has(prefixed)) canonicalByAlias.set(prefixed, publicId);
		}
	}
	const context = {
		toPublicId(rawId) {
			if (itemIds.has(rawId)) return rawId;
			const canonical = canonicalByAlias.get(rawId);
			return canonical != null && itemIds.has(canonical) ? canonical : null;
		},
		aliasesFor(publicId) {
			const out = [publicId];
			for (const [alias, canonical] of canonicalByAlias) if (canonical === publicId && !out.includes(alias)) out.push(alias);
			return out;
		}
	};
	trackedChangeIdContextCache.set(items, context);
	return context;
}
var storyScopedTrackedChangeIdContextCache = /* @__PURE__ */ new WeakMap();
var declaredBodyItemsCache = /* @__PURE__ */ new WeakMap();
/**
* Alias↔canonical context scoped to the rows in a single `story`.
*
* {@link buildTrackedChangeIdContext} keys aliases purely on the raw Word
* `w:id` / `imported:<id>` painter form, so when body / footnote / header
* changes reuse the same `w:id`, the first row inserted wins the alias for
* EVERY story. A click in a later story would then map through
* `toPublicId` to the first story's public id and get dropped by the
* subsequent `entityRowMatchesRequest(..., story)` check (or focus the wrong
* same-story split). Restricting the alias map to same-story candidates keeps
* each story's ids independent so the reconciliation resolves within the
* painted story. Falls back to id-only when the row carries no comparable story.
*/
function buildStoryScopedTrackedChangeIdContext(items, story) {
	const signature = storyLocatorSignature(story);
	let byStory = storyScopedTrackedChangeIdContextCache.get(items);
	if (!byStory) {
		byStory = /* @__PURE__ */ new Map();
		storyScopedTrackedChangeIdContextCache.set(items, byStory);
	}
	const cached = byStory.get(signature);
	if (cached) return cached;
	const context = buildTrackedChangeIdContext(items.filter((item) => storyLocatorSignature(readEntityStory(item)) === signature));
	byStory.set(signature, context);
	return context;
}
function isTextboxStory(story) {
	return !!story && typeof story === "object" && story.storyType === "textbox";
}
/**
* Resolve a textbox selection against rows that carry no story locator.
*
* Textbox rows arrive from the v2 adapter without a comparable locator, but body
* rows omit theirs too (body is the documented default). A missing story is
* therefore not proof of textbox ownership: when a textbox change and a body
* change reuse one Word revision id, live selection can supply both canonical
* ids, and taking the first story-less match would publish whichever the catalog
* happened to list first.
*
* The signal is a shared revision id, not a count. A selection spanning several
* independent changes in one textbox is ordinary — those ids describe different
* revisions and the first is the right active one. Two ids tracing back to the
* same revision id are the ambiguous case, and that fails closed.
*/
function resolveStorylessCanonicalTrackedChangeId(items, selectionIds) {
	const storyless = selectionIds.filter((id) => items.some((item) => readEntityId(item) === id && readEntityStory(item) == null));
	if (storyless.length === 0) return null;
	if (storyless.length === 1) return storyless[0];
	const seen = /* @__PURE__ */ new Set();
	for (const id of storyless) {
		const row = items.find((item) => readEntityId(item) === id);
		if (!row) continue;
		for (const raw of readTrackChangeProvenanceIds(row)) {
			if (seen.has(raw)) return null;
			seen.add(raw);
		}
	}
	return storyless[0];
}
/**
* Keep only rows that explicitly declare a story locator.
*
* A missing locator is not the same claim as `{ storyType: 'body' }`, but both
* share the body story signature. Filtering the undeclared rows out keeps a body
* selection from aliasing onto one of them.
*/
function declaredBodyItems(items) {
	const cached = declaredBodyItemsCache.get(items);
	if (cached) return cached;
	const declared = items.filter((item) => readEntityStory(item) != null);
	const result = declared.length === items.length ? items : declared;
	declaredBodyItemsCache.set(items, result);
	return result;
}
/**
* Map `selection.activeChangeIds` to a public tracked-change id for
* `TrackChangesSlice.activeId`.
*
* Prefer the live selection's story against the all-story catalog so a
* footnote/header/footer alias that reuses a Word revision id cannot resolve
* to a colliding body change. Unscoped body mapping is only for body
* selection. While the all-story catalog is unsettled for a non-body
* selection, keep activeId null rather than publishing an unvalidated raw
* painter alias or canonical-looking id.
*/
function resolveSelectionActiveChangeId(options) {
	const { selectionIds, publicIds, selection, bodyItems, allStoryItems } = options;
	if (selectionIds.length === 0) return null;
	const mapIds = (context) => {
		for (const id of selectionIds) {
			const publicId = context.toPublicId(id);
			if (publicId) return publicId;
		}
		return null;
	};
	const story = selectionStory(selection);
	const isBodySelection = storyLocatorSignature(story) === storyLocatorSignature(null);
	if (allStoryItems) {
		const scopedItems = isBodySelection ? declaredBodyItems(allStoryItems) : allStoryItems;
		const fromStory = mapIds(buildStoryScopedTrackedChangeIdContext(scopedItems, story));
		if (fromStory) return fromStory;
		const fromPublic = publicIds?.find((id) => scopedItems.some((item) => entityRowMatchesRequest(item, id, story)));
		if (fromPublic) return fromPublic;
		if (!isBodySelection) return isTextboxStory(story) ? resolveStorylessCanonicalTrackedChangeId(allStoryItems, selectionIds) : null;
		return mapIds(buildTrackedChangeIdContext(bodyItems));
	}
	if (isBodySelection) return mapIds(buildTrackedChangeIdContext(bodyItems)) ?? selectionIds[0] ?? null;
	return null;
}
/**
* Resolve a requested comment activation id to its thread's canonical active
* id. Accepts a bare `id`, the `importedId` v2 minted when it had to repair
* a malformed/duplicated source comment id on import, or a reply's id - all
* resolve to the same thread-root comment, matching main's accepted aliases
* for `ui.comments.setActive`. Returns `null` when `commentId` matches no
* currently loaded comment under either alias.
*/
function resolveActiveCommentId(items, commentId) {
	const item = items.find((candidate) => readEntityId(candidate) === commentId || candidate.importedId === commentId);
	if (!item) return null;
	return item.rootCommentId ?? item.parentCommentId ?? readEntityId(item) ?? commentId;
}
/** Derive a `{ startBlockId, endBlockId }` block range from a selection slice. */
function selectionBlockRange(selection) {
	const sel = selection.selectionTarget;
	if (sel) {
		const start = sel.start;
		const end = sel.end;
		const startBlockId = typeof start?.blockId === "string" ? start.blockId : void 0;
		const endBlockId = typeof end?.blockId === "string" ? end.blockId : startBlockId;
		if (startBlockId) return {
			startBlockId,
			endBlockId: endBlockId ?? startBlockId
		};
	}
	const target = selection.target;
	const segments = target && Array.isArray(target.segments) ? target.segments : [];
	const first = segments[0]?.blockId;
	const last = segments[segments.length - 1]?.blockId;
	if (typeof first === "string") return {
		startBlockId: first,
		endBlockId: typeof last === "string" ? last : first
	};
	return null;
}
/**
* Distinct block ids the selection covers, in document order. In the v2 adapter
* the selection's `blockId` is the same identifier the public block operations
* accept as `nodeId` (both resolve to the OOXML `paraId`), so these are valid
* `nodeId`s for `format.paragraph.*` / `styles.paragraph.*` / `lists.*`.
*
* A collapsed caret still yields its containing block id (the v2
* `selection.current` returns a zero-length text segment), so paragraph/list
* commands work from a caret — they do not require a range selection.
*/
function selectionBlockIds(selection) {
	const ids = [];
	const push = (id) => {
		if (typeof id === "string" && id.length > 0 && !ids.includes(id)) ids.push(id);
	};
	const target = selection.target;
	const segments = target && Array.isArray(target.segments) ? target.segments : [];
	for (const segment of segments) push(segment?.blockId);
	const sel = selection.selectionTarget;
	if (sel) {
		push(sel.start?.blockId);
		push(sel.end?.blockId);
	}
	return ids;
}
var MAX_REACTIVE_SELECTION_BLOCK_READS = 64;
function canProbeEverySelectedBlock(blockIds) {
	return blockIds.length <= MAX_REACTIVE_SELECTION_BLOCK_READS;
}
/** Resolve the selection's story, defaulting to the main body story. */
function selectionStory(selection) {
	const target = selection.target;
	const explicit = selection.selectionTarget;
	const start = explicit?.start;
	const end = explicit?.end;
	const story = target?.story ?? explicit?.story ?? start?.story ?? end?.story;
	return story && typeof story === "object" ? story : {
		kind: "story",
		storyType: "body"
	};
}
/** Build a `ParagraphTarget` ( `format.paragraph.*` / `styles.paragraph.*` ). */
function paragraphTarget(blockId, story) {
	return {
		kind: "block",
		nodeType: "paragraph",
		nodeId: blockId,
		...story && typeof story === "object" ? { story } : {}
	};
}
/** Build a `ListsBlockTarget` ( `lists.apply` / `lists.remove` / `lists.getState` ). */
function listsBlockTarget(blockId) {
	return {
		kind: "block",
		nodeType: "paragraph",
		nodeId: blockId
	};
}
/** Build a `ListItemAddress` ( `lists.indent` / `lists.outdent` / `lists.applyStyle` ). */
function listItemTarget(blockId, story) {
	return {
		kind: "block",
		nodeType: "listItem",
		nodeId: blockId,
		...story && typeof story === "object" ? { story } : {}
	};
}
var PARAGRAPH_INDENT_STEP_TWIPS = 720;
function pointsToTwips(value) {
	return Math.round(value * 20);
}
function isFiniteNumber(value) {
	return typeof value === "number" && Number.isFinite(value);
}
function readParagraphIndentationFromResult(result) {
	if (!result || typeof result !== "object") return null;
	const node = result.node;
	if (!node || typeof node !== "object") return null;
	const paragraphPayload = node.kind === "heading" ? node.heading ?? null : node.kind === "paragraph" ? node.paragraph ?? null : null;
	if (!paragraphPayload) return null;
	const resolved = paragraphPayload.resolved;
	const props = paragraphPayload.props;
	const indent = resolved?.indent ?? props?.indent;
	if (!indent || typeof indent !== "object") return null;
	const left = isFiniteNumber(indent.left) ? pointsToTwips(indent.left) : isFiniteNumber(indent.start) ? pointsToTwips(indent.start) : void 0;
	const right = isFiniteNumber(indent.right) ? pointsToTwips(indent.right) : isFiniteNumber(indent.end) ? pointsToTwips(indent.end) : void 0;
	const firstLine = isFiniteNumber(indent.firstLine) ? pointsToTwips(indent.firstLine) : void 0;
	const hanging = isFiniteNumber(indent.hanging) ? pointsToTwips(indent.hanging) : void 0;
	if (left == null && right == null && firstLine == null && hanging == null) return null;
	return {
		...left != null ? { left } : {},
		...right != null ? { right } : {},
		...firstLine != null ? { firstLine } : {},
		...hanging != null ? { hanging } : {}
	};
}
/** Build one `TextAddress` per covered text segment for `hyperlinks.wrap`. */
function selectionTextAddresses(selection) {
	const target = selection.target;
	const segments = target && Array.isArray(target.segments) ? target.segments : [];
	const story = target?.story;
	const addresses = [];
	for (const segment of segments) {
		if (!segment || typeof segment.blockId !== "string") continue;
		const range = segment.range;
		if (!range || typeof range.start !== "number" || typeof range.end !== "number" || range.start === range.end) continue;
		addresses.push({
			kind: "text",
			blockId: segment.blockId,
			range: {
				start: range.start,
				end: range.end
			},
			...story ? { story } : {}
		});
	}
	return addresses;
}
function textAddressesFromTarget(target) {
	if (!target || typeof target !== "object") return [];
	const record = target;
	const story = record.story;
	const addresses = [];
	if (record.kind === "text" && record.range && typeof record.blockId === "string") {
		const range = record.range;
		if (typeof range.start === "number" && typeof range.end === "number" && range.start !== range.end) addresses.push({
			kind: "text",
			blockId: record.blockId,
			range: {
				start: Math.min(range.start, range.end),
				end: Math.max(range.start, range.end)
			},
			...story ? { story } : {}
		});
		return addresses;
	}
	if (record.kind === "text" && Array.isArray(record.segments)) {
		for (const segment of record.segments) {
			const range = segment?.range;
			if (typeof segment?.blockId === "string" && typeof range?.start === "number" && typeof range?.end === "number" && range.start !== range.end) addresses.push({
				kind: "text",
				blockId: segment.blockId,
				range: {
					start: Math.min(range.start, range.end),
					end: Math.max(range.start, range.end)
				},
				...story ? { story } : {}
			});
		}
		return addresses;
	}
	if (record.kind === "selection") {
		const start = record.start;
		const end = record.end;
		const blockId = typeof start?.blockId === "string" && end?.blockId === start.blockId ? start.blockId : null;
		if (start?.kind === "text" && end?.kind === "text" && blockId && typeof start.offset === "number" && typeof end.offset === "number" && start.offset !== end.offset) addresses.push({
			kind: "text",
			blockId,
			range: {
				start: Math.min(start.offset, end.offset),
				end: Math.max(start.offset, end.offset)
			},
			...record.story ?? start.story ? { story: record.story ?? start.story } : {}
		});
	}
	return addresses;
}
function collapsedTextAddressFromTarget(target) {
	if (!target || typeof target !== "object") return null;
	const record = target;
	const story = record.story;
	if (record.kind === "text" && record.range && typeof record.blockId === "string") {
		const range = record.range;
		if (typeof range.start === "number" && typeof range.end === "number" && range.start === range.end) return {
			kind: "text",
			blockId: record.blockId,
			range: {
				start: range.start,
				end: range.end
			},
			...story ? { story } : {}
		};
	}
	if (record.kind === "text" && Array.isArray(record.segments)) {
		const segment = record.segments[0];
		const range = segment?.range;
		if (typeof segment?.blockId === "string" && typeof range?.start === "number" && typeof range?.end === "number" && range.start === range.end) return {
			kind: "text",
			blockId: segment.blockId,
			range: {
				start: range.start,
				end: range.end
			},
			...story ? { story } : {}
		};
	}
	if (record.kind === "selection") {
		const start = record.start;
		const end = record.end;
		const blockId = typeof start?.blockId === "string" && end?.blockId === start.blockId ? start.blockId : null;
		if (start?.kind === "text" && end?.kind === "text" && blockId && typeof start.offset === "number" && typeof end.offset === "number" && start.offset === end.offset) return {
			kind: "text",
			blockId,
			range: {
				start: start.offset,
				end: start.offset
			},
			...record.story ?? start.story ? { story: record.story ?? start.story } : {}
		};
	}
	return null;
}
function collapsedTextAddressFromSelection(selection) {
	return collapsedTextAddressFromTarget(selection.target) ?? collapsedTextAddressFromTarget(selection.selectionTarget);
}
var PROJECTED_INLINE_SELECTION_VALUE_KEYS = [
	"fontFamily",
	"fontSize",
	"color",
	"highlight"
];
var MIRRORED_EDIT_COMMAND_IDS = {
	undo: "history.undo",
	redo: "history.redo"
};
var EFFECTIVE_MARK_KEYS = [
	"bold",
	"italic",
	"underline",
	"strikethrough"
];
function isProjectedInlineSelectionValueKey(value) {
	return PROJECTED_INLINE_SELECTION_VALUE_KEYS.includes(value);
}
function selectionTextSegments(selection) {
	const target = selection.target;
	const segments = target && Array.isArray(target.segments) ? target.segments : [];
	const out = [];
	const push = (blockId, start, end) => {
		if (typeof blockId !== "string" || typeof start !== "number" || typeof end !== "number") return;
		out.push({
			blockId,
			start: Math.min(start, end),
			end: Math.max(start, end)
		});
	};
	for (const segment of segments) {
		const range = segment?.range;
		push(segment?.blockId, range?.start, range?.end);
	}
	if (out.length > 0) return out;
	const explicit = selection.selectionTarget;
	const start = explicit?.start;
	const end = explicit?.end;
	if (!start || !end) return out;
	if (start.blockId !== end.blockId) return out;
	push(start.blockId, start.offset, end.offset);
	return out;
}
function selectionStoryLocator(selection) {
	const target = selection.target;
	const explicit = selection.selectionTarget;
	const start = explicit?.start;
	const end = explicit?.end;
	const story = target?.story ?? explicit?.story ?? start?.story ?? end?.story;
	return story && typeof story === "object" ? story : void 0;
}
function selectionInlineValueStorySignature(selection) {
	const story = selectionStoryLocator(selection);
	if (!story || typeof story !== "object") return "body";
	const record = story;
	return JSON.stringify({
		storyType: typeof record.storyType === "string" ? record.storyType : "body",
		refId: typeof record.refId === "string" ? record.refId : null,
		noteId: typeof record.noteId === "string" ? record.noteId : null,
		textboxId: typeof record.textboxId === "string" ? record.textboxId : null
	});
}
function selectionInlineValueSignature(selection) {
	const segments = selectionTextSegments(selection);
	if (segments.length === 0) return null;
	return [selectionInlineValueStorySignature(selection), ...segments.map((segment) => `${segment.blockId}:${segment.start}-${segment.end}`)].join("|");
}
/**
* The effective-uniformity worker operation accepts the durable
* `selectionTarget`, not the expanded segment list. Whole-story segment lists
* grow as source coverage arrives, so using them as this cache key restarts the
* same worker read indefinitely while the document is loading.
*/
function selectionEffectiveUniformitySignature(selection) {
	const target = selection.selectionTarget;
	if (!target || typeof target !== "object") return null;
	return selectionKey({ selectionTarget: target });
}
function normalizeOptimisticInlineSelectionValue(key, value) {
	if (key === "fontSize") {
		const numeric = typeof value === "number" ? value : Number(value);
		return Number.isFinite(numeric) && numeric > 0 ? String(numeric) : null;
	}
	if (typeof value !== "string") return null;
	const trimmed = value.trim();
	if (trimmed.length === 0) return null;
	if (key === "color" || key === "highlight") return trimmed.toUpperCase();
	return trimmed;
}
function rangesOverlap(left, right) {
	return Math.max(left.start, right.start) < Math.min(left.end, right.end);
}
function queryMatchItemSegments(item) {
	if (!item) return [];
	const blocks = Array.isArray(item.blocks) ? item.blocks : [];
	const out = [];
	for (const block of blocks) {
		const range = block?.range;
		const blockId = block?.blockId;
		if (typeof blockId !== "string" || typeof range?.start !== "number" || typeof range?.end !== "number") continue;
		out.push({
			blockId,
			start: Math.min(range.start, range.end),
			end: Math.max(range.start, range.end)
		});
	}
	return out;
}
function sameSelectionTextSegments(left, right) {
	if (left.length !== right.length) return false;
	return left.every((segment, index) => {
		const candidate = right[index];
		return candidate?.blockId === segment.blockId && candidate?.start === segment.start && candidate?.end === segment.end;
	});
}
/**
* Pick the `query.match` result item that best covers the selection. Pure over
* a settled query result so the controller's async read coordinator owns the
* (promise-capable) `query.match` call and this stays a synchronous projection.
*/
function pickSelectionTextQueryItem(result, selection) {
	const segments = selectionTextSegments(selection);
	if (segments.length === 0) return null;
	const items = result && Array.isArray(result.items) ? result.items : [];
	if (items.length === 0) return null;
	const exact = items.find((item) => sameSelectionTextSegments(segments, queryMatchItemSegments(item)));
	if (exact) return exact;
	if (segments.length === 1) {
		const singleBlock = items.find((item) => {
			const address = item?.address;
			return address?.kind === "block" && address.nodeId === segments[0].blockId;
		});
		if (singleBlock) return singleBlock;
	}
	return items[0] ?? null;
}
function readProjectedInlineStyleValue(styles, key) {
	const raw = key === "fontSize" ? styles?.fontSizePt ?? styles?.fontSize : key === "highlight" ? styles?.highlight ?? styles?.backgroundColor : styles?.[key];
	if (typeof raw === "number") return Number.isFinite(raw) ? String(raw) : void 0;
	if (typeof raw !== "string") return void 0;
	const trimmed = raw.trim();
	if (trimmed.length === 0) return void 0;
	if (key === "color" || key === "highlight") return trimmed.toUpperCase();
	return trimmed;
}
/** Primary named family from a resolved CSS font stack, dropping generic fallbacks (SD-3652). */
function normalizeLayoutFontFamily(value) {
	if (typeof value !== "string") return void 0;
	const first = value.split(",")[0]?.trim().replace(/^['"]+|['"]+$/g, "").trim();
	if (!first) return void 0;
	const lower = first.toLowerCase();
	if (lower === "serif" || lower === "sans-serif" || lower === "monospace" || lower === "cursive" || lower === "fantasy") return;
	return first;
}
/** Convert a resolved run font size in CSS px to the toolbar's point value (SD-3652). */
function normalizeLayoutFontSizePt(value) {
	if (typeof value !== "number" || !Number.isFinite(value) || value <= 0) return void 0;
	const pt = Math.round(value * .75 * 2) / 2;
	if (pt <= 0) return void 0;
	return String(pt);
}
function normalizeProjectedInlineStyleValueKey(key, value) {
	if (key === "fontFamily") return value.toLowerCase();
	if (key === "color" || key === "highlight") return value.toUpperCase();
	return value;
}
function projectInlineValuesFromQueryItem(item, selection) {
	if (!item) return {};
	const selectionSegmentsByBlock = /* @__PURE__ */ new Map();
	for (const segment of selectionTextSegments(selection)) {
		const ranges = selectionSegmentsByBlock.get(segment.blockId) ?? [];
		ranges.push({
			start: segment.start,
			end: segment.end
		});
		selectionSegmentsByBlock.set(segment.blockId, ranges);
	}
	if (selectionSegmentsByBlock.size === 0) return {};
	const blocks = Array.isArray(item.blocks) ? item.blocks : [];
	const projection = {};
	for (const key of PROJECTED_INLINE_SELECTION_VALUE_KEYS) {
		const seenValues = /* @__PURE__ */ new Map();
		let sawOverlap = false;
		let sawMissingValue = false;
		for (const block of blocks) {
			const blockId = typeof block?.blockId === "string" ? block.blockId : null;
			if (!blockId) continue;
			const selectionRanges = selectionSegmentsByBlock.get(blockId);
			if (!selectionRanges?.length) continue;
			const runs = Array.isArray(block?.runs) ? block.runs : [];
			for (const run of runs) {
				const range = run?.range;
				const start = typeof range?.start === "number" ? range.start : null;
				const end = typeof range?.end === "number" ? range.end : null;
				if (start == null || end == null) continue;
				if (!selectionRanges.some((selectionRange) => rangesOverlap(selectionRange, {
					start,
					end
				}))) continue;
				sawOverlap = true;
				const value = readProjectedInlineStyleValue(run?.styles, key);
				if (value === void 0) {
					sawMissingValue = true;
					continue;
				}
				const normalized = normalizeProjectedInlineStyleValueKey(key, value);
				if (!seenValues.has(normalized)) seenValues.set(normalized, value);
				if (seenValues.size > 1) break;
			}
			if (seenValues.size > 1) break;
		}
		if (sawOverlap && !sawMissingValue && seenValues.size === 1) projection[key] = [...seenValues.values()][0];
	}
	return projection;
}
/** A create-location `at` derived from the current block, or `documentEnd`. */
function createLocationAt(selection, mode) {
	const blockId = selectionBlockIds(selection)[0];
	if (!blockId) return { kind: "documentEnd" };
	return mode === "nodeId" ? {
		kind: "after",
		nodeId: blockId
	} : {
		kind: "after",
		target: paragraphTarget(blockId)
	};
}
function normalizeCommandState(state, source) {
	const supported = state.supported ?? source !== "unsupported";
	const enabled = state.enabled ?? (state.disabled !== void 0 ? !state.disabled : supported);
	return {
		enabled,
		disabled: !enabled,
		active: state.active ?? false,
		supported,
		value: state.value,
		source,
		reason: enabled ? void 0 : state.reason
	};
}
function projectTrackChangesItem(item) {
	if (!item || typeof item !== "object") return null;
	const row = item;
	const nested = row.change;
	const change = nested && typeof nested === "object" ? nested : row;
	return {
		...row,
		id: row.id ?? change.id,
		change
	};
}
function trackChangesItemPayload(item) {
	const row = item;
	const change = row.change;
	return change && typeof change === "object" ? change : row;
}
function commandResultFromOperationResult(result) {
	if (isPromiseLike(result)) return true;
	if (result === false) return false;
	if (result === true || result == null) return true;
	if (typeof result !== "object") return true;
	const record = result;
	if ("success" in record || "failure" in record || "effects" in record) return result;
	if (record.status === "rejected") return false;
	return true;
}
function isSuccessfulReceipt(result) {
	return Boolean(result) && typeof result === "object" && result.success === true;
}
function commandResultSucceeded(result) {
	if (result === false) return false;
	if (result && typeof result === "object" && result.success === false) return false;
	return true;
}
function isLooseObject(value) {
	return Boolean(value && typeof value === "object" && !Array.isArray(value));
}
/**
* Flatten mounted projection blocks into text-bearing blocks (those with a
* `runs` array), descending into table rows/cells so table-cell content is
* reachable (SD-3652). A block carries either `runs` (paragraph) or `rows`
* (table); nested tables recurse.
*/
function collectProjectionTextBlocks(blocks) {
	const out = [];
	const visit = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		if (Array.isArray(record.runs)) out.push(record);
		if (Array.isArray(record.rows)) for (const row of record.rows) {
			const cells = row?.cells;
			if (!Array.isArray(cells)) continue;
			for (const cell of cells) {
				const cellRecord = cell;
				if (Array.isArray(cellRecord?.blocks)) for (const nested of cellRecord.blocks) visit(nested);
				if (cellRecord?.paragraph) visit(cellRecord.paragraph);
			}
		}
	};
	if (Array.isArray(blocks)) for (const block of blocks) visit(block);
	return out;
}
/** A projection block matches a selection block id by `sourceAnchor.sourceNodeId` or `block.id`. */
function projectionBlockMatchesId(block, id) {
	if (block.sourceAnchor?.sourceNodeId === id) return true;
	return block.id === id;
}
/**
* Length of a painted run in the Document API selection-offset space.
*
* Review mode paints deleted revision text, but that text is not part of the
* editable selection stream. Counting its painted characters shifts every
* later selection onto the wrong projected run (and therefore the wrong
* effective formatting). Insertions remain selectable and keep their length.
*/
function projectionRunSelectionLength(run) {
	if (run.trackedChange?.kind === "delete") return 0;
	return typeof run.text === "string" ? run.text.length : 0;
}
function combineCommandResults(results) {
	let last = false;
	let firstFailure = null;
	let lastRouted = null;
	let lastReceipt = null;
	for (const result of results) {
		last = result;
		if (!commandResultSucceeded(result) && firstFailure === null) firstFailure = result;
		if (isSuccessfulReceipt(result)) lastReceipt = result;
		if (result !== false) lastRouted = result;
	}
	return firstFailure ?? lastReceipt ?? lastRouted ?? last;
}
function hyperlinkAddressToSelectionTarget(address) {
	const anchor = address?.anchor;
	const start = anchor?.start;
	const end = anchor?.end;
	if (typeof start?.blockId !== "string" || typeof end?.blockId !== "string") return null;
	if (start.blockId !== end.blockId) return null;
	if (typeof start.offset !== "number" || typeof end.offset !== "number") return null;
	return {
		kind: "selection",
		start: {
			kind: "text",
			blockId: start.blockId,
			offset: start.offset
		},
		end: {
			kind: "text",
			blockId: end.blockId,
			offset: end.offset
		}
	};
}
function hyperlinkTargetFromHref(href) {
	if (href.startsWith("#")) return {
		kind: "anchor",
		anchor: href.slice(1)
	};
	return {
		kind: "external",
		url: href
	};
}
/** Tracked-change decision spec for a command id, from the descriptor catalog. */
function trackDecisionCommand(id) {
	return getCommandDescriptor(id)?.trackDecision ?? null;
}
function rectResult(rects) {
	return {
		found: rects.length > 0,
		success: rects.length > 0,
		rects,
		rect: rects[0]
	};
}
/** Fail-closed empty geometry result carrying a stable reason. */
function rectFailure(reason) {
	return {
		found: false,
		success: false,
		rects: [],
		reason
	};
}
/** Offset client-space rects so they are relative to `relativeTo`, when given. */
function relativizeRects(result, relativeTo) {
	if (!relativeTo || typeof relativeTo.getBoundingClientRect !== "function" || result.rects.length === 0) return result;
	let origin;
	try {
		const box = relativeTo.getBoundingClientRect();
		origin = {
			left: box.left,
			top: box.top
		};
	} catch {
		return result;
	}
	const rects = result.rects.map((rect) => ({
		...rect,
		left: rect.left - origin.left,
		right: rect.right - origin.left,
		top: rect.top - origin.top,
		bottom: rect.bottom - origin.top
	}));
	return {
		...result,
		rects,
		rect: rects[0]
	};
}
/**
* Whether a text-target segment carries the addressable shape AND the value
* invariants the derived selection target relies on (`blockId` string plus a
* `range` of valid integer bounds, `start >= 0` and `start <= end` — the
* documented `TextTarget` contract). Captures can be stale or deserialized from
* a host store, so entries are validated instead of trusted: a segment that is
* malformed (missing `range`) or out of bounds (negative, non-integer, or
* inverted) makes the caller return `null` (fail closed) rather than throw
* mid-derivation or restore a clamped, different range than was captured.
*/
function isAddressableSegment(segment) {
	if (!segment || typeof segment !== "object") return false;
	const candidate = segment;
	if (typeof candidate.blockId !== "string" || !candidate.range || typeof candidate.range !== "object") return false;
	const range = candidate.range;
	return Number.isInteger(range.start) && Number.isInteger(range.end) && range.start >= 0 && range.start <= range.end;
}
function selectionTargetFromTextTarget(target) {
	if (!target || target.kind !== "text" || !Array.isArray(target.segments) || target.segments.length === 0) return null;
	const segments = Array.from(target.segments);
	if (!segments.every(isAddressableSegment)) return null;
	const first = segments[0];
	const last = segments[segments.length - 1];
	const story = target.story;
	return {
		kind: "selection",
		start: {
			kind: "text",
			blockId: first.blockId,
			offset: first.range.start,
			...story ? { story } : {}
		},
		end: {
			kind: "text",
			blockId: last.blockId,
			offset: last.range.end,
			...story ? { story } : {}
		},
		...story ? { story } : {}
	};
}
function selectionTargetForRestore(capture) {
	if (capture.selectionTarget) return capture.selectionTarget;
	return selectionTargetFromTextTarget(capture.target);
}
/**
* Resolve the live selection slice to a `SelectionTarget` the inline
* `format.*` operations accept. Returns the explicit `selectionTarget` when the
* source provides one, otherwise derives a same-story selection target from the
* resolved text target's first/last covered segments. Returns `null` when the
* selection is empty or has no resolvable range — the inline command then fails closed with
* `range-selection-required` rather than calling `format.*` with a missing
* target (which the public Document API rejects with `INVALID_INPUT`).
*/
function resolveInlineSelectionTarget(selection) {
	if (selection.empty) return null;
	if (selection.selectionTarget) return selection.selectionTarget;
	const fallback = selectionTargetFromTextTarget(selection.target);
	if (fallback && fallback.start.kind === "text" && fallback.end.kind === "text" && fallback.start.blockId !== fallback.end.blockId) return null;
	return fallback;
}
/**
* The `format.*` method name a stored inline mark is keyed by (SD-3654). The
* host store and the toggle command both address a mark by its Document API
* method (`docRoute` minus the `format.` prefix), which differs from the inline
* `key` for strikethrough (`key: 'strike'` vs `docRoute: 'format.strikethrough'`).
*/
function inlineFormatMethod(descriptor) {
	if (!descriptor.inline || typeof descriptor.docRoute !== "string") return null;
	return descriptor.docRoute.startsWith("format.") ? descriptor.docRoute.slice(7) : null;
}
/** Inline run-property keys cleared by `clear-formatting` via `format.apply`. */
var CLEAR_INLINE_PATCH = {
	bold: null,
	italic: null,
	underline: null,
	strike: null,
	color: null,
	highlight: null,
	fontFamily: null,
	fontSize: null,
	vertAlign: null,
	smallCaps: null,
	caps: null,
	letterSpacing: null,
	dstrike: null
};
/**
* Subset of `CLEAR_INLINE_PATCH` whose registry entry supports tracked
* changes. Tracked `format.apply` rejects the whole patch with
* `CAPABILITY_UNAVAILABLE` if any key isn't `tracked: true` (e.g. `smallCaps`,
* `dstrike`), regardless of whether the selection actually carries them, so
* suggesting mode must send this filtered patch instead of the full one.
*/
var TRACKED_CLEAR_INLINE_PATCH = Object.fromEntries(Object.entries(CLEAR_INLINE_PATCH).filter(([key]) => INLINE_PROPERTY_BY_KEY[key]?.tracked === true));
/**
* Build the public Document API input for an inline-format command from the
* resolved selection target, the normalized payload, and the command's live
* active state. Boolean mark commands can also receive an explicit boolean/null
* payload, which is useful for hosts that know the desired state themselves.
* Returns `null` when the payload is invalid for the spec (so the controller
* fails closed instead of forwarding a malformed value).
*/
function buildInlineFormatInput(spec, target, payload, active) {
	switch (spec.kind) {
		case "toggle": {
			const value = typeof payload === "object" && payload !== null && "value" in payload ? payload.value : payload;
			if (typeof value === "boolean" || value === null) return {
				target,
				value
			};
			return {
				target,
				value: !active
			};
		}
		case "value-string": {
			const value = typeof payload === "object" && payload !== null && "value" in payload ? payload.value : payload;
			if (value === null) return {
				target,
				value: null
			};
			if (typeof value !== "string" || value.trim() === "") return null;
			return {
				target,
				value
			};
		}
		case "value-number": {
			const raw = typeof payload === "object" && payload !== null && "value" in payload ? payload.value : payload;
			const value = typeof raw === "number" ? raw : Number(raw);
			if (!Number.isFinite(value) || value <= 0) return null;
			return {
				target,
				value
			};
		}
		case "clear": return {
			target,
			inline: { ...CLEAR_INLINE_PATCH }
		};
		default: return null;
	}
}
/** Read a `{ start, end }` cell-range from the host snapshot, when well-formed. */
function readMergeRange(range) {
	const point = (value) => {
		if (!value || typeof value !== "object") return null;
		const record = value;
		const rowIndex = record.rowIndex;
		const columnIndex = record.columnIndex;
		if (typeof rowIndex !== "number" || !Number.isInteger(rowIndex)) return null;
		if (typeof columnIndex !== "number" || !Number.isInteger(columnIndex)) return null;
		return {
			rowIndex,
			columnIndex
		};
	};
	if (!range) return null;
	const start = point(range.start);
	const end = point(range.end);
	if (!start || !end) return null;
	return {
		start,
		end
	};
}
/**
* Build the public `tables.*` input for a table cell-context command from the
* resolved table context. Returns `null` when the action's required context is
* missing (e.g. split with no resolved cell), so the controller fails closed
* with `table-context-unavailable` rather than calling with a malformed locator.
*/
function buildTableCommandInput(action, context) {
	const { tableNodeId: nodeId, rowIndex, columnIndex, cellNodeId, mergeRange } = context;
	switch (action) {
		case "insert-row-before": return {
			nodeId,
			rowIndex,
			position: "above"
		};
		case "insert-row-after": return {
			nodeId,
			rowIndex,
			position: "below"
		};
		case "delete-row": return {
			nodeId,
			rowIndex
		};
		case "insert-column-before": return {
			nodeId,
			columnIndex,
			position: "left"
		};
		case "insert-column-after": return {
			nodeId,
			columnIndex,
			position: "right"
		};
		case "delete-column": return {
			nodeId,
			columnIndex
		};
		case "delete-table": return { nodeId };
		case "merge-cells": {
			const range = mergeRange ?? {
				start: {
					rowIndex,
					columnIndex
				},
				end: {
					rowIndex,
					columnIndex
				}
			};
			return {
				nodeId,
				start: range.start,
				end: range.end
			};
		}
		case "split-cell": return cellNodeId ? {
			nodeId: cellNodeId,
			rows: 1,
			columns: 2
		} : null;
		case "remove-borders": return {
			nodeId,
			mode: "applyTo",
			applyTo: "all",
			border: null
		};
		default: return null;
	}
}
function createSuperDocUI(options) {
	const superdoc = options.superdoc;
	const optimisticInlineValues = /* @__PURE__ */ new Map();
	const optimisticInlineToggles = /* @__PURE__ */ new Map();
	let optimisticParagraphAlignment = null;
	let optimisticParagraphAlignmentGeneration = 0;
	const pendingInlineToggleMutations = [];
	let lastOptimisticInlineSelectionSignature = null;
	let optimisticInlineToggleGeneration = 0;
	let inlineToggleMutationActive = false;
	let inlineToggleMutationIdle = Promise.resolve();
	let resolveInlineToggleMutationIdle = null;
	let painter = {
		mode: "idle",
		snapshot: null,
		sourceSelectionKey: null,
		lastClickAt: 0,
		pointerSelecting: false,
		keyboardSelecting: false
	};
	let painterCaptureEpoch = 0;
	const painterModeListeners = /* @__PURE__ */ new Set();
	let frozenProjectedValues = {};
	let frozenProjectedValuesKey = "";
	let heldSettledInlineValues = null;
	/** Read the live active editor (or null). */
	const getEditor = () => {
		const editor = superdoc?.activeEditor;
		return editor && typeof editor === "object" ? editor : null;
	};
	/** Read the live browser Document API facade (or null). */
	const getDoc = () => {
		const doc = getEditor()?.doc;
		return doc && typeof doc === "object" ? doc : null;
	};
	/** Read the live v2 tracked-change facade, when exposed. */
	const getV2TrackedChanges = () => {
		const trackedChanges = getEditor()?.v2TrackedChanges;
		return trackedChanges && typeof trackedChanges === "object" ? trackedChanges : null;
	};
	/** Read the committed V2 page-window review feed (never a document catalog). */
	const getV2ReviewWindowSource = () => {
		const editor = getEditor();
		if (editor?.editorVersion !== 2) return null;
		const reviewWindow = editor.reviewWindow;
		return reviewWindow && typeof reviewWindow === "object" ? reviewWindow : null;
	};
	const getV2ReviewWindowSnapshot = () => {
		const source = getV2ReviewWindowSource();
		if (!source || typeof source.getSnapshot !== "function") return null;
		return safeCall(() => source.getSnapshot(), null);
	};
	const hasV2ReviewWindowFeed = () => typeof getV2ReviewWindowSource()?.getSnapshot === "function";
	const reviewWindowSliceStatus = (snapshot) => {
		const status = snapshot?.status;
		return status === "ready" || status === "stale" ? status : "pending";
	};
	/** Read the live v2 editor host (inline mode only), when exposed. */
	const getHost = () => {
		const host = getEditor()?.host;
		return host && typeof host === "object" ? host : null;
	};
	const resolveActiveHeaderFooterSlot = (story) => {
		if (story.storyType !== "headerFooterPart" || typeof story.refId !== "string") return null;
		const editor = getEditor();
		const host = getHost();
		const pageLayout = editor?.pageLayout ?? host?.pageLayout;
		if (!pageLayout || typeof pageLayout !== "object") return null;
		const getActiveRulerContext = pageLayout.getActiveRulerContext;
		const resolveEditTarget = host?.resolveHeaderFooterEditTarget;
		if (typeof getActiveRulerContext !== "function" || typeof resolveEditTarget !== "function") return null;
		const active = safeCall(() => getActiveRulerContext.call(pageLayout), null);
		if (!active || typeof active.pageIndex !== "number") return null;
		for (const headerFooterKind of ["header", "footer"]) {
			const resolved = safeCall(() => resolveEditTarget.call(host, {
				pageIndex: active.pageIndex,
				kind: headerFooterKind
			}), null);
			if (resolved?.status !== "ready" || resolved.refId !== story.refId || typeof resolved.sectionId !== "string" || ![
				"default",
				"first",
				"even"
			].includes(String(resolved.slotVariant))) continue;
			return {
				kind: "story",
				storyType: "headerFooterSlot",
				section: {
					kind: "section",
					sectionId: resolved.sectionId
				},
				headerFooterKind,
				variant: resolved.slotVariant
			};
		}
		return null;
	};
	/** Read the host's stored inline marks (SD-3654/SD-3652), when any pending. */
	const readPendingInlineFormat = () => {
		const host = getHost();
		const fn = host?.getPendingInlineFormat;
		if (typeof fn !== "function") return null;
		const pending = safeCall(() => fn.call(host), null);
		return pending && typeof pending === "object" ? pending : null;
	};
	/**
	* Active state contributed by a stored inline mark for this command, or null
	* when nothing is pending for it (SD-3654). Only meaningful for a collapsed
	* caret; the store is cleared on any selection move, so a range never has one.
	*/
	const pendingInlineActive = (descriptor) => {
		const method = inlineFormatMethod(descriptor);
		if (!method) return null;
		const pending = readPendingInlineFormat();
		if (!pending || !(method in pending)) return null;
		const value = pending[method];
		if (descriptor.inline?.kind === "toggle") return value === true;
		return value != null && value !== "";
	};
	/** The pending caret font/size value for this command's `format.*` method, if any (SD-3652). */
	const pendingInlineValueFor = (descriptor) => {
		const method = inlineFormatMethod(descriptor);
		if (!method) return void 0;
		const pending = readPendingInlineFormat();
		if (!pending || !(method in pending)) return void 0;
		const value = pending[method];
		if (typeof value === "string" && value !== "") return value;
		if (typeof value === "number" && Number.isFinite(value)) return String(value);
	};
	/** Record / clear the stored inline mark for a collapsed-caret pick (SD-3654/SD-3652). */
	const setPendingInlineFormatOnHost = (method, value) => {
		const host = getHost();
		const fn = host?.setPendingInlineFormat;
		if (typeof fn === "function") safeCall(() => fn.call(host, method, value), void 0);
	};
	const clearPendingInlineFormatOnHost = (method) => {
		const host = getHost();
		const fn = host?.clearPendingInlineFormat;
		if (typeof fn === "function") safeCall(() => fn.call(host, method), void 0);
	};
	/** Inline `format.*` methods whose active state is a boolean mark (name === method). */
	const BOOLEAN_INLINE_FORMAT_METHODS = /* @__PURE__ */ new Set([
		"bold",
		"italic",
		"underline",
		"strikethrough"
	]);
	/**
	* Retire a stored inline mark (SD-3654/SD-3652) once the selection's own
	* formatting has caught up to it: a boolean mark when the live activeMarks
	* match, a font/size when the projection matches. Runs each recompute so the
	* toolbar hands off from "pending" to the real marks/value without a gap.
	*/
	const reconcilePendingInlineFormat = (selection) => {
		const pending = readPendingInlineFormat();
		if (!pending) return;
		const activeMarks = Array.isArray(selection.activeMarks) ? selection.activeMarks : [];
		let projected = null;
		for (const method of Object.keys(pending)) {
			const value = pending[method];
			let matched;
			if (BOOLEAN_INLINE_FORMAT_METHODS.has(method)) matched = activeMarks.includes(method) === (value === true);
			else if (isProjectedInlineSelectionValueKey(method)) {
				if (value == null) continue;
				if (!projected) projected = projectSelectionInlineValues(selection);
				matched = projected[method] === value;
			} else matched = false;
			if (matched) clearPendingInlineFormatOnHost(method);
		}
	};
	/** Read the live v2 edit-command adapters (`activeEditor.editCommands`), when exposed. */
	const getEditCommands = () => {
		const editCommands = getEditor()?.editCommands;
		return editCommands && typeof editCommands === "object" ? editCommands : null;
	};
	/** Read one edit-command snapshot entry (`activeEditor.editCommands.getSnapshot().commands[id]`). */
	const readEditCommandStateEntry = (commandId) => {
		const editCommands = getEditCommands();
		if (!editCommands || typeof editCommands.getSnapshot !== "function") return null;
		const entry = (safeCall(() => editCommands.getSnapshot(), null)?.commands)?.[commandId];
		return entry && typeof entry === "object" ? entry : null;
	};
	/** Read the `lists.apply` command state surfaced by the v2 edit-command snapshot. */
	const readListApplyStateEntry = () => {
		return readEditCommandStateEntry("lists.apply");
	};
	/** Read the additive list active state surfaced by the edit-command snapshot. */
	const readListActiveSeed = (entry) => {
		const seed = (entry?.value)?.seed;
		return seed === "bullet" || seed === "ordered" ? seed : null;
	};
	/** Read the lower host-state entry mirrored into the public `undo` / `redo` ids. */
	const readMirroredEditCommandStateEntry = (commandId) => {
		const mirrored = MIRRORED_EDIT_COMMAND_IDS[commandId];
		return mirrored ? readEditCommandStateEntry(mirrored) : null;
	};
	/**
	* Shared table-context resolution. Reads the V2 host table-context facade
	* (`host.getTableContext()`) — the single public surface that resolves the
	* current selection's enclosing table without private editor internals — and
	* normalizes it to the locator inputs the `tables.*` operations need. Returns
	* `null` when the caret is not inside a table, the host does not expose the
	* facade, or the snapshot is missing the table node id / indices. Both the
	* built-in toolbar authority and custom UIs consume this same resolution.
	*/
	const readHostTableContext = () => {
		const host = getHost();
		if (!host || typeof host.getTableContext !== "function") return null;
		const snapshot = safeCall(() => host.getTableContext(), null);
		return snapshot && typeof snapshot === "object" ? snapshot : null;
	};
	const resolveTableContext = () => {
		const snapshot = readHostTableContext();
		if (!snapshot || snapshot.inTable !== true) return null;
		const table = snapshot.table;
		const tableNodeId = typeof table?.nodeId === "string" && table.nodeId.length > 0 ? table.nodeId : null;
		if (!tableNodeId) return null;
		const row = snapshot.row;
		const column = snapshot.column;
		const cell = snapshot.cell;
		const rowIndex = typeof row?.index === "number" && Number.isInteger(row.index) ? row.index : null;
		const columnIndex = typeof column?.index === "number" && Number.isInteger(column.index) ? column.index : null;
		if (rowIndex == null || columnIndex == null) return null;
		const cellNodeId = typeof cell?.nodeId === "string" && cell.nodeId.length > 0 ? cell.nodeId : null;
		const range = snapshot.cellRange;
		return {
			tableNodeId,
			rowIndex,
			columnIndex,
			cellNodeId,
			mergeRange: readMergeRange(range)
		};
	};
	const customCommands = /* @__PURE__ */ new Map();
	let explicitActiveCommentId = null;
	let explicitActiveChange = null;
	let explicitActiveChangeRevision = 0;
	let queuedTrackChangeNavigationInvalidation = 0;
	let trackChangeRevealInvalidation = 0;
	const pendingTrackChangeRevealFocuses = /* @__PURE__ */ new Set();
	const explicitActiveChangesEqual = (left, right) => {
		if (left === right) return true;
		if (!left || !right) return false;
		return left.id === right.id && left.paintedEntityId === right.paintedEntityId && storyLocatorSignature(left.story) === storyLocatorSignature(right.story);
	};
	const hasPendingTrackChangeRevealFocus = (focus) => Array.from(pendingTrackChangeRevealFocuses).some((pendingFocus) => explicitActiveChangesEqual(pendingFocus, focus));
	const mirrorTrackedChangeFocusToHost = (next) => {
		const host = getHost();
		if (typeof host?.getHandles !== "function") return;
		const handles = safeCall(() => host.getHandles(), null);
		const review = handles?.review;
		if (!review) return;
		if (next) {
			if (typeof review.setActiveReviewTarget !== "function") return;
			const layout = handles?.layout;
			safeCall(() => review.setActiveReviewTarget({
				entityType: "trackedChange",
				entityId: next.id,
				...next.paintedEntityId ? { paintedEntityId: next.paintedEntityId } : {},
				origin: "panel",
				layoutEpoch: typeof layout?.generation === "number" ? layout.generation : 0,
				story: next.story ?? {
					kind: "story",
					storyType: "body"
				}
			}), null);
			return;
		}
		if (typeof review.getActiveReviewTarget !== "function" || typeof review.clearActiveReviewTarget !== "function") return;
		if (safeCall(() => review.getActiveReviewTarget(), null)?.entityType === "trackedChange") safeCall(() => review.clearActiveReviewTarget(), void 0);
	};
	const setExplicitActiveChange = (next, options) => {
		explicitActiveChange = next;
		explicitActiveChangeRevision += 1;
		trackChangeRevealInvalidation += 1;
		if (options?.invalidateQueuedNavigation !== false) queuedTrackChangeNavigationInvalidation += 1;
	};
	const listeners = /* @__PURE__ */ new Set();
	let state;
	let disposed = false;
	let controllerRef = null;
	const asyncReads = /* @__PURE__ */ new Map();
	const coldAsyncReadDeferrals = /* @__PURE__ */ new Set();
	let lastEffectiveInlineReadKey = null;
	let pendingEffectiveInlineRead = null;
	let asyncRefreshScheduled = false;
	let asyncReadFailureRetryTimer = null;
	let asyncReadFailureRetryAtMs = 0;
	let foregroundAsyncRetryTimer = null;
	let pendingSelectionSeedValidationToken = null;
	let typingContentInvalidationTimer = null;
	const pendingAsyncReadSettlements = [];
	const scheduleAsyncRefresh = () => {
		if (asyncRefreshScheduled || disposed) return;
		asyncRefreshScheduled = true;
		const run = () => {
			asyncRefreshScheduled = false;
			if (!disposed) recompute("async-read-settled");
		};
		if (typeof queueMicrotask === "function") queueMicrotask(run);
		else Promise.resolve().then(run);
	};
	const ASYNC_READ_FAILURE_RETRY_BASE_MS = 250;
	const ASYNC_READ_FAILURE_RETRY_MAX_MS = 5e3;
	const scheduleAsyncReadFailureRetry = (retryAtMs) => {
		if (disposed) return;
		if (asyncReadFailureRetryTimer && asyncReadFailureRetryAtMs <= retryAtMs) return;
		if (asyncReadFailureRetryTimer) clearTimeout(asyncReadFailureRetryTimer);
		asyncReadFailureRetryAtMs = retryAtMs;
		asyncReadFailureRetryTimer = setTimeout(() => {
			asyncReadFailureRetryTimer = null;
			asyncReadFailureRetryAtMs = 0;
			if (!disposed) recompute();
		}, Math.max(0, retryAtMs - Date.now()));
	};
	const editorIdentityIds = /* @__PURE__ */ new WeakMap();
	let editorIdentityCounter = 0;
	const editorIdentityId = (editor) => {
		if (!editor) return "none";
		let id = editorIdentityIds.get(editor);
		if (id == null) {
			id = editorIdentityCounter += 1;
			editorIdentityIds.set(editor, id);
		}
		return `e${id}`;
	};
	let documentMutationRevision = 0;
	const uiTrackedChangesCatalogHost = options.superdoc;
	const uiTrackedChangesCatalogState = acquireSharedUiTrackedChangesCatalog(uiTrackedChangesCatalogHost);
	const supersedeUiTrackedChangesCatalogRead = () => {
		uiTrackedChangesCatalogState.abortController.abort("review-mutation-started");
		uiTrackedChangesCatalogState.inFlight = null;
	};
	const renewUiTrackedChangesCatalogRead = () => {
		uiTrackedChangesCatalogState.generation += 1;
		uiTrackedChangesCatalogState.abortController = new AbortController();
		uiTrackedChangesCatalogState.inFlight = null;
	};
	const beginUiReviewMutation = (token) => {
		const activeTokens = uiTrackedChangesCatalogState.activeMutationTokens;
		if (typeof token !== "string" || token.length === 0 || activeTokens.has(token)) return;
		const firstToken = activeTokens.size === 0;
		activeTokens.add(token);
		if (firstToken) supersedeUiTrackedChangesCatalogRead();
	};
	const settleUiReviewMutation = (token) => {
		const activeTokens = uiTrackedChangesCatalogState.activeMutationTokens;
		if (typeof token !== "string" || !activeTokens.delete(token)) return;
		if (activeTokens.size === 0) renewUiTrackedChangesCatalogRead();
	};
	const runUiTrackedChangesCatalogRead = (fallback) => {
		const v2TrackedChanges = getV2TrackedChanges();
		const listTrackedChanges = v2TrackedChanges?.listTrackedChanges;
		if (typeof listTrackedChanges !== "function") {
			if (getEditor()?.editorVersion === 2) return Promise.reject(/* @__PURE__ */ new Error("v2-tracked-changes-bridge-pending"));
			return fallback();
		}
		if (uiTrackedChangesCatalogState.activeMutationTokens.size > 0) return Promise.reject(/* @__PURE__ */ new Error("ui-review-catalog-superseded"));
		const generation = uiTrackedChangesCatalogState.generation;
		const existing = uiTrackedChangesCatalogState.inFlight;
		if (existing?.generation === generation) return existing.promise;
		const signal = uiTrackedChangesCatalogState.abortController.signal;
		const validateResult = (result) => {
			if (signal.aborted || generation !== uiTrackedChangesCatalogState.generation || result?.reason === "review-hydration-superseded") throw new Error("ui-review-catalog-superseded");
			return result;
		};
		const rawResult = listTrackedChanges.call(v2TrackedChanges, {
			blocking: false,
			signal
		});
		if (!isPromiseLike(rawResult)) return validateResult(rawResult);
		const promise = Promise.resolve(rawResult).then(validateResult);
		uiTrackedChangesCatalogState.inFlight = {
			generation,
			promise
		};
		promise.then(() => {
			if (uiTrackedChangesCatalogState.inFlight?.promise === promise) uiTrackedChangesCatalogState.inFlight = null;
		}, () => {
			if (uiTrackedChangesCatalogState.inFlight?.promise === promise) uiTrackedChangesCatalogState.inFlight = null;
		});
		return promise;
	};
	let postDecisionTrackChangesToken = null;
	let postDecisionTrackChangeIds = /* @__PURE__ */ new Set();
	let allTrackedChangesResolvedToken = null;
	let selectionEpoch = 0;
	let lastCoordinatorEditor = null;
	/** Token shared by document-content reads (editor identity + mutation revision). */
	const contentToken = () => `${editorIdentityId(getEditor())}|m${documentMutationRevision}`;
	const clearPostDecisionTrackChanges = () => {
		postDecisionTrackChangesToken = null;
		postDecisionTrackChangeIds = /* @__PURE__ */ new Set();
	};
	const applyPostDecisionTrackChangesToCache = (ids) => {
		for (const key of ["trackChanges", "trackChanges:all"]) {
			const entry = asyncReads.get(key);
			if (!entry?.hasSettled || !Array.isArray(entry.value)) continue;
			const nextValue = entry.value.filter((item) => {
				const id = readEntityId(item);
				return !id || !ids.has(id);
			});
			if (nextValue.length === entry.value.length) continue;
			asyncReads.set(key, {
				...entry,
				value: nextValue
			});
		}
	};
	const notifyPostDecisionTrackChanges = (receipt) => {
		const notify = () => {
			if (disposed) return;
			for (const listener of [...listeners]) listener(state);
		};
		const record = isLooseObject(receipt) ? receipt : null;
		const readiness = getEditor()?.documentMutationReadiness;
		const waitForPostPaintTask = () => {
			const requestFrame = globalThis.requestAnimationFrame;
			if (typeof requestFrame !== "function") return Promise.resolve();
			return new Promise((resolve) => {
				let settled = false;
				const finish = () => {
					if (settled) return;
					settled = true;
					clearTimeout(fallback);
					resolve();
				};
				const fallback = setTimeout(finish, 250);
				requestFrame(() => requestFrame(() => setTimeout(finish, 0)));
			});
		};
		if (record?.success === true && typeof record.txId === "string" && record.txId.length > 0 && typeof readiness?.whenPainted === "function") try {
			Promise.resolve(readiness.whenPainted.call(readiness, record)).then(waitForPostPaintTask, () => void 0).then(notify, notify);
			return;
		} catch {}
		notify();
	};
	const publishPostDecisionTrackChanges = (ids, receipt) => {
		const previous = state.trackChanges;
		const items = previous.items.filter((item) => {
			const id = readEntityId(item);
			return !id || !ids.has(id);
		});
		if (items.length === previous.items.length) return;
		if (explicitActiveChange && ids.has(explicitActiveChange.id)) setExplicitActiveChange(null);
		const authors = /* @__PURE__ */ new Set();
		for (const item of items) {
			const change = trackChangesItemPayload(item);
			const row = item;
			const author = change.author ?? change.authorEmail ?? row.author ?? row.authorEmail;
			if (typeof author === "string") authors.add(author);
		}
		const removedCount = previous.items.length - items.length;
		state = {
			...state,
			trackChanges: {
				...previous,
				items,
				total: Math.max(items.length, previous.total - removedCount),
				activeId: previous.activeId && ids.has(previous.activeId) ? null : previous.activeId,
				authors: [...authors]
			}
		};
		notifyPostDecisionTrackChanges(receipt);
	};
	/**
	* Publish the exact empty catalog proved by an all-resolved receipt.
	* Reject All does not carry one removed ref per logical change, so the
	* ordinary identity-pruning path cannot clear selection-derived focus or
	* the slice total. Keep this proof scoped to the current content token: the
	* next independent document mutation advances the token and resumes normal
	* catalog/selection reads.
	*/
	const publishAllTrackedChangesResolved = (receipt) => {
		const previous = state.trackChanges;
		const changed = previous.items.length > 0 || previous.total !== 0 || previous.activeId !== null || previous.authors.length > 0;
		allTrackedChangesResolvedToken = contentToken();
		if (explicitActiveChange !== null) setExplicitActiveChange(null);
		state = {
			...state,
			trackChanges: {
				...previous,
				items: [],
				total: 0,
				activeId: null,
				authors: []
			}
		};
		if (changed) notifyPostDecisionTrackChanges(receipt);
	};
	const markPostDecisionTrackChanges = (ids, receipt) => {
		if (ids.size === 0) return;
		const token = contentToken();
		const alreadyRemoved = postDecisionTrackChangesToken === token ? postDecisionTrackChangeIds : /* @__PURE__ */ new Set();
		const newlyRemoved = new Set([...ids].filter((id) => !alreadyRemoved.has(id)));
		if (newlyRemoved.size === 0) return;
		postDecisionTrackChangesToken = token;
		postDecisionTrackChangeIds = /* @__PURE__ */ new Set([...alreadyRemoved, ...newlyRemoved]);
		applyPostDecisionTrackChangesToCache(postDecisionTrackChangeIds);
		publishPostDecisionTrackChanges(newlyRemoved, receipt);
	};
	const postDecisionTrackChangeIdsForToken = (token) => postDecisionTrackChangesToken === token && postDecisionTrackChangeIds.size > 0 ? postDecisionTrackChangeIds : null;
	const replaceTrackedChangeItemsInCache = (items) => {
		const token = contentToken();
		const suppressedIds = postDecisionTrackChangeIdsForToken(token);
		const projected = items.map(projectTrackChangesItem).filter((item) => {
			if (item == null) return false;
			const id = readEntityId(item);
			return id != null && !suppressedIds?.has(id);
		});
		for (const key of ["trackChanges", "trackChanges:all"]) asyncReads.set(key, {
			token,
			value: [...projected],
			hasSettled: true,
			inflightToken: null
		});
	};
	/** Token for the live selection read, including the mode that controls its public projection. */
	const selectionReadToken = () => `${contentToken()}|m${readDocumentMode()}|s${selectionEpoch}`;
	/** Stable signature of a settled selection, used to key selection-scoped reads. */
	const selectionSignature = (selection) => JSON.stringify({
		t: selection.target ?? null,
		s: selection.selectionTarget ?? null
	});
	const SELECTION_SCOPED_ASYNC_READ_PREFIXES = [
		"contentControls:inRange:",
		"query:",
		"effInline:"
	];
	const FOREGROUND_ASYNC_RETRY_MS = 120;
	const COLD_ASYNC_READ_START_DELAY_MS = 180;
	/** Tri-state host source-load phase derived from the loading snapshot seam. */
	const hostSourceLoadPhase = () => {
		const host = getHost();
		const read = host?.getDocumentLoadingSnapshot;
		if (typeof read !== "function") return "unknown";
		const stage = safeCall(() => read.call(host), null)?.sourceStage;
		if (stage === "opening" || stage === "bootstrap-ready" || stage === "source-loading") return "loading";
		if (stage === "source-complete" || stage === "source-failed" || stage === "source-cancelled") return "complete";
		return "unknown";
	};
	const demandedHeavyReads = /* @__PURE__ */ new Map();
	const incompleteTrackChangesDirectoryReadTokens = /* @__PURE__ */ new Map();
	const postSourceCompletionRefreshTokens = /* @__PURE__ */ new Map();
	let sourceCompletionObservedToken = null;
	let commentsDirectoryLeaseCount = 0;
	let trackChangesDirectoryLeaseCount = 0;
	const demandHeavyDocRead = (key) => {
		const token = contentToken();
		if (demandedHeavyReads.get(key) === token) return;
		demandedHeavyReads.set(key, token);
		scheduleAsyncRefresh();
	};
	const commentsCatalogMayHaveRows = () => {
		const entry = asyncReads.get("comments");
		if (!entry?.hasSettled) return entry?.inflightToken != null;
		return Array.isArray(entry.value) && entry.value.length > 0;
	};
	const heavyReadDemandActive = (key, token) => demandedHeavyReads.get(key) === token;
	const refreshIncompleteTrackChangesDirectories = () => {
		const token = contentToken();
		let invalidated = false;
		for (const [key, incompleteToken] of incompleteTrackChangesDirectoryReadTokens) {
			if (incompleteToken !== token) {
				incompleteTrackChangesDirectoryReadTokens.delete(key);
				continue;
			}
			if (postSourceCompletionRefreshTokens.get(key) === token) continue;
			const entry = asyncReads.get(key);
			if (!entry?.hasSettled || entry.token !== token || entry.inflightToken != null) continue;
			asyncReads.set(key, {
				...entry,
				token: null,
				inflightToken: null
			});
			postSourceCompletionRefreshTokens.set(key, token);
			invalidated = true;
		}
		if (invalidated) scheduleAsyncRefresh();
	};
	const acquireDirectoryLease = (family) => {
		if (family === "comments") commentsDirectoryLeaseCount += 1;
		else trackChangesDirectoryLeaseCount += 1;
		demandHeavyDocRead(family);
		let released = false;
		return () => {
			if (released) return;
			released = true;
			if (family === "comments") commentsDirectoryLeaseCount = Math.max(0, commentsDirectoryLeaseCount - 1);
			else trackChangesDirectoryLeaseCount = Math.max(0, trackChangesDirectoryLeaseCount - 1);
			if ((family === "comments" ? commentsDirectoryLeaseCount : trackChangesDirectoryLeaseCount) === 0 && demandedHeavyReads.get(family) === contentToken()) demandedHeavyReads.delete(family);
			scheduleAsyncRefresh();
		};
	};
	/**
	* Demand-driven route for the content-controls catalog (panel / API use).
	* Explicit demand bypasses both active-loading and post-complete idle holds.
	*/
	const ensureContentControlsCatalog = (_reason) => {
		demandHeavyDocRead("contentControls");
	};
	/** Demand-driven route for an explicitly consumed tracked-change list. */
	const ensureTrackChangesCatalog = () => {
		const entry = asyncReads.get("trackChanges");
		if (entry?.hasSettled || entry?.inflightToken != null) return;
		demandHeavyDocRead("trackChanges");
	};
	/** Demand-driven route for an explicitly consumed comments list. */
	const ensureCommentsCatalog = () => {
		const entry = asyncReads.get("comments");
		if (entry?.hasSettled || entry?.inflightToken != null) return;
		demandHeavyDocRead("comments");
	};
	const HEAVY_READ_IDLE_MS = 6500;
	const HEAVY_READ_IDLE_POLL_MS = 250;
	let lastEditableMutationAtMs = 0;
	/**
	* Last burst-class mutation: a local typing command or a remote apply whose
	* originating operation is unavailable. Drives the steady-phase heavy-read
	* hold while one-off local programmatic mutations keep refreshing promptly.
	*/
	let lastTypingMutationAtMs = 0;
	/**
	* True from the first deferred heavy read until the input-idle release runs.
	* Held reads stay deferred even after source-complete so a typing-driven
	* recompute cannot bypass the idle gate.
	*/
	let heavyReadsHeldUntilIdle = false;
	let heavyReadCompletionRecomputeTimer = null;
	const scheduleHeavyReadCompletionRecompute = () => {
		if (disposed || heavyReadCompletionRecomputeTimer) return;
		const attempt = () => {
			heavyReadCompletionRecomputeTimer = null;
			if (disposed) return;
			const idleForMs = Date.now() - lastEditableMutationAtMs;
			if (foregroundMutationActive() || idleForMs < HEAVY_READ_IDLE_MS) {
				heavyReadCompletionRecomputeTimer = setTimeout(attempt, HEAVY_READ_IDLE_POLL_MS);
				return;
			}
			heavyReadsHeldUntilIdle = false;
			recompute();
		};
		heavyReadCompletionRecomputeTimer = setTimeout(attempt, 0);
	};
	let sourceLoadingSubscriptionHost = null;
	let detachSourceLoading = null;
	const armSourceLoadCompletionRecompute = () => {
		const host = getHost();
		if (!host || sourceLoadingSubscriptionHost === host) return;
		if (detachSourceLoading) {
			detachSourceLoading();
			detachSourceLoading = null;
		}
		sourceLoadingSubscriptionHost = host;
		const subscribe = host.subscribeDocumentLoading;
		if (typeof subscribe !== "function") {
			sourceLoadingSubscriptionHost = null;
			scheduleForegroundAsyncRetry(HEAVY_READ_IDLE_MS);
			return;
		}
		try {
			const handleLoadingSnapshot = (snapshot) => {
				const stage = snapshot?.sourceStage;
				if (stage === "source-complete" || stage === "source-failed" || stage === "source-cancelled") {
					sourceCompletionObservedToken = contentToken();
					refreshIncompleteTrackChangesDirectories();
					lastEditableMutationAtMs = Math.max(lastEditableMutationAtMs, Date.now());
					scheduleHeavyReadCompletionRecompute();
				}
			};
			const off = subscribe.call(host, handleLoadingSnapshot);
			if (typeof off === "function") detachSourceLoading = off;
			const read = host.getDocumentLoadingSnapshot;
			if (typeof read === "function") handleLoadingSnapshot(safeCall(() => read.call(host), null));
		} catch {
			sourceLoadingSubscriptionHost = null;
			scheduleForegroundAsyncRetry(HEAVY_READ_IDLE_MS);
		}
	};
	const foregroundMutationState = () => {
		const host = getEditor()?.host;
		const read = host?.getForegroundMutationState;
		if (typeof read !== "function") return null;
		const state = safeCall(() => read.call(host), null);
		return {
			active: typeof state?.active === "number" ? state.active : 0,
			pending: typeof state?.pending === "number" ? state.pending : 0
		};
	};
	const foregroundMutationActive = () => {
		const state = foregroundMutationState();
		return Boolean(state && (state.active > 0 || state.pending > 0));
	};
	const scheduleForegroundAsyncRetry = (delayMs = FOREGROUND_ASYNC_RETRY_MS) => {
		if (disposed || foregroundAsyncRetryTimer) return;
		foregroundAsyncRetryTimer = setTimeout(() => {
			foregroundAsyncRetryTimer = null;
			if (disposed) return;
			if (pendingSelectionSeedValidationToken && foregroundMutationActive()) {
				scheduleForegroundAsyncRetry();
				recompute();
				return;
			}
			const validationToken = pendingSelectionSeedValidationToken;
			pendingSelectionSeedValidationToken = null;
			if (validationToken === selectionReadToken()) issueAsyncRead("selection", validationToken, selectionCurrentRun, normalizeSelectionInfo);
			recompute();
		}, delayMs);
	};
	const shouldDeferColdAsyncRead = (key, token) => {
		if (!foregroundMutationState()) return false;
		const deferralKey = `${key}\u0000${token}`;
		if (coldAsyncReadDeferrals.has(deferralKey)) return false;
		coldAsyncReadDeferrals.add(deferralKey);
		scheduleForegroundAsyncRetry(COLD_ASYNC_READ_START_DELAY_MS);
		return true;
	};
	/**
	* A large-selection uniformity read walks every covered paragraph. The first
	* settled selection reads immediately; later distinct selection keys debounce
	* so pointer-drag/autoscroll updates supersede one another before worker work
	* starts. Refreshes of the same selection stay immediate.
	*/
	const shouldDeferEffectiveInlineRead = (key) => {
		if (lastEffectiveInlineReadKey == null || key === lastEffectiveInlineReadKey) {
			if (pendingEffectiveInlineRead?.timer) clearTimeout(pendingEffectiveInlineRead.timer);
			pendingEffectiveInlineRead = null;
			lastEffectiveInlineReadKey = key;
			return false;
		}
		if (pendingEffectiveInlineRead?.key === key) {
			if (!pendingEffectiveInlineRead.ready) return true;
			pendingEffectiveInlineRead = null;
			lastEffectiveInlineReadKey = key;
			return false;
		}
		if (pendingEffectiveInlineRead?.timer) clearTimeout(pendingEffectiveInlineRead.timer);
		const pending = {
			key,
			ready: false,
			timer: null
		};
		pending.timer = setTimeout(() => {
			if (disposed || pendingEffectiveInlineRead !== pending) return;
			pending.timer = null;
			pending.ready = true;
			recompute();
		}, COLD_ASYNC_READ_START_DELAY_MS);
		pendingEffectiveInlineRead = pending;
		return true;
	};
	const isEditableTextMutationEvent = (event) => {
		return isV2EditableTextMutationEvent(event);
	};
	const invalidateDocumentContentAndRecompute = () => {
		invalidateDocumentContent();
		recompute();
	};
	let pendingPostPaintContentRefresh = null;
	let postPaintContentRefreshRunning = false;
	let postPaintContentRefreshDrainToken = 0;
	const resetPostPaintContentRefresh = () => {
		pendingPostPaintContentRefresh = null;
		postPaintContentRefreshRunning = false;
		postPaintContentRefreshDrainToken += 1;
	};
	const schedulePostPaintContentRefresh = () => {
		const editor = getEditor();
		const readiness = editor?.documentMutationReadiness;
		if (!editor || typeof readiness?.whenPainted !== "function") return;
		pendingPostPaintContentRefresh = {
			editor,
			readiness,
			afterEpoch: typeof readiness.getRenderEpoch === "function" ? safeCall(() => readiness.getRenderEpoch.call(readiness), null) : null
		};
		if (postPaintContentRefreshRunning) return;
		postPaintContentRefreshRunning = true;
		const drainToken = postPaintContentRefreshDrainToken;
		const drain = async () => {
			while (!disposed && drainToken === postPaintContentRefreshDrainToken) {
				const request = pendingPostPaintContentRefresh;
				pendingPostPaintContentRefresh = null;
				if (!request) {
					postPaintContentRefreshRunning = false;
					return;
				}
				let paintCompleted = false;
				try {
					await request.readiness.whenPainted.call(request.readiness, typeof request.afterEpoch === "number" ? { afterEpoch: request.afterEpoch } : void 0);
					paintCompleted = true;
				} catch {}
				if (disposed || drainToken !== postPaintContentRefreshDrainToken) return;
				if (getEditor() !== request.editor) {
					resetPostPaintContentRefresh();
					return;
				}
				if (paintCompleted) invalidateDocumentContentAndRecompute();
			}
		};
		drain();
	};
	const scheduleTypingDocumentContentInvalidation = () => {
		if (typingContentInvalidationTimer) clearTimeout(typingContentInvalidationTimer);
		typingContentInvalidationTimer = setTimeout(() => {
			typingContentInvalidationTimer = null;
			if (!disposed) invalidateDocumentContentAndRecompute();
		}, 500);
	};
	const issueAsyncRead = (key, token, run, normalize) => {
		let raw;
		try {
			raw = run();
		} catch {
			raw = void 0;
		}
		if (!isPromiseLike(raw)) {
			const settled = {
				token,
				value: normalize(raw),
				hasSettled: true,
				inflightToken: null,
				failedToken: null,
				failureCount: 0,
				retryAtMs: 0
			};
			asyncReads.set(key, settled);
			return settled;
		}
		const prev = asyncReads.get(key);
		const retryingSameToken = prev?.failedToken === token;
		asyncReads.set(key, {
			token: prev?.token ?? null,
			value: prev?.value ?? null,
			hasSettled: prev?.hasSettled ?? false,
			inflightToken: token,
			failedToken: retryingSameToken ? token : null,
			failureCount: retryingSameToken ? prev.failureCount ?? 0 : 0,
			retryAtMs: 0
		});
		Promise.resolve(raw).then((resolved) => {
			const entry = asyncReads.get(key);
			if (!entry || entry.inflightToken !== token) return;
			asyncReads.set(key, {
				token,
				value: normalize(resolved),
				hasSettled: true,
				inflightToken: null,
				failedToken: null,
				failureCount: 0,
				retryAtMs: 0
			});
			const { sink, workerContext } = readUiBenchRuntime();
			if (sink) {
				const settledAtMs = uiBenchNowMs();
				pendingAsyncReadSettlements.push({
					key,
					settledAtMs,
					commandId: workerContext?.commandId ?? null,
					commandKind: workerContext?.commandKind ?? null
				});
				emitUiBenchTiming({
					stage: "superdoc-ui-async-read-settled",
					atMs: settledAtMs,
					key,
					settledAtMs,
					commandId: workerContext?.commandId ?? null,
					commandKind: workerContext?.commandKind ?? null
				});
			}
			scheduleAsyncRefresh();
		}, () => {
			const entry = asyncReads.get(key);
			if (!entry || entry.inflightToken !== token) return;
			const failureCount = entry.failedToken === token ? (entry.failureCount ?? 0) + 1 : 1;
			const retryDelayMs = Math.min(ASYNC_READ_FAILURE_RETRY_MAX_MS, ASYNC_READ_FAILURE_RETRY_BASE_MS * 2 ** Math.min(failureCount - 1, 8));
			const retryAtMs = Date.now() + retryDelayMs;
			asyncReads.set(key, {
				...entry,
				inflightToken: null,
				failedToken: token,
				failureCount,
				retryAtMs
			});
			scheduleAsyncReadFailureRetry(retryAtMs);
		});
		return null;
	};
	/**
	* Read a doc value through the settled cache. Returns the best-known value
	* plus a {@link SliceStatus}: `ready` (settled for this token), `stale`
	* (older settled value while a refresh runs), or `pending` (nothing settled
	* yet). Never returns or surfaces a promise.
	*/
	const readAsync = (key, token, run, normalize) => {
		const entry = asyncReads.get(key);
		if (entry && entry.token === token && entry.hasSettled) return {
			value: entry.value,
			status: "ready"
		};
		if (isHeavyDocReadKey(key) && !heavyReadDemandActive(key, token)) {
			if (hostSourceLoadPhase() === "loading") {
				heavyReadsHeldUntilIdle = true;
				armSourceLoadCompletionRecompute();
				if (entry?.hasSettled) return {
					value: entry.value,
					status: "stale"
				};
				return {
					value: null,
					status: "pending"
				};
			}
			if (heavyReadsHeldUntilIdle) {
				scheduleHeavyReadCompletionRecompute();
				if (entry?.hasSettled) return {
					value: entry.value,
					status: "stale"
				};
				return {
					value: null,
					status: "pending"
				};
			}
			if (Date.now() - lastTypingMutationAtMs < HEAVY_READ_IDLE_MS) {
				heavyReadsHeldUntilIdle = true;
				scheduleHeavyReadCompletionRecompute();
				if (entry?.hasSettled) return {
					value: entry.value,
					status: "stale"
				};
				return {
					value: null,
					status: "pending"
				};
			}
		}
		if (foregroundMutationActive()) {
			scheduleForegroundAsyncRetry();
			if (entry?.hasSettled) return {
				value: entry.value,
				status: "stale"
			};
			return {
				value: null,
				status: "pending"
			};
		}
		if (entry?.failedToken === token && entry.inflightToken == null && (entry.retryAtMs ?? 0) > Date.now()) {
			scheduleAsyncReadFailureRetry(entry.retryAtMs);
			if (entry.hasSettled) return {
				value: entry.value,
				status: "stale"
			};
			return {
				value: null,
				status: "pending"
			};
		}
		if (!entry && key.startsWith("effInline:") && shouldDeferEffectiveInlineRead(key)) return {
			value: null,
			status: "pending"
		};
		if (!entry && shouldDeferColdAsyncRead(key, token)) return {
			value: null,
			status: "pending"
		};
		if (!entry || entry.inflightToken !== token) {
			const completed = issueAsyncRead(key, token, run, normalize);
			if (completed) return {
				value: completed.value,
				status: "ready"
			};
		}
		const current = asyncReads.get(key);
		if (current?.hasSettled) return {
			value: current.value,
			status: "stale"
		};
		return {
			value: null,
			status: "pending"
		};
	};
	const clearAsyncReadKeys = (predicate) => {
		for (const key of asyncReads.keys()) if (predicate(key)) asyncReads.delete(key);
	};
	const selectionScopedAsyncReadKeys = (selection) => {
		const signature = selectionSignature(selection);
		const effectiveUniformitySignature = selectionEffectiveUniformitySignature(selection);
		return /* @__PURE__ */ new Set([
			`contentControls:inRange:${signature}`,
			`query:${signature}`,
			...effectiveUniformitySignature ? [`effInline:${effectiveUniformitySignature}`] : []
		]);
	};
	const pruneSelectionScopedAsyncReads = (selection) => {
		const retained = selectionScopedAsyncReadKeys(selection);
		clearAsyncReadKeys((key) => SELECTION_SCOPED_ASYNC_READ_PREFIXES.some((prefix) => key.startsWith(prefix)) && !retained.has(key));
		for (const key of coldAsyncReadDeferrals) {
			const readKey = key.split("\0", 1)[0];
			if (SELECTION_SCOPED_ASYNC_READ_PREFIXES.some((prefix) => readKey.startsWith(prefix)) && !retained.has(readKey)) coldAsyncReadDeferrals.delete(key);
		}
	};
	/** Drop cached reads when the active editor identity changes (avoids cross-editor leakage). */
	const syncCoordinatorEditor = () => {
		const editor = getEditor();
		if (editor === lastCoordinatorEditor) return;
		resetPostPaintContentRefresh();
		lastCoordinatorEditor = editor;
		asyncReads.clear();
		if (asyncReadFailureRetryTimer) clearTimeout(asyncReadFailureRetryTimer);
		asyncReadFailureRetryTimer = null;
		asyncReadFailureRetryAtMs = 0;
		if (pendingEffectiveInlineRead?.timer) clearTimeout(pendingEffectiveInlineRead.timer);
		pendingEffectiveInlineRead = null;
		lastEffectiveInlineReadKey = null;
		heldSettledInlineValues = null;
		optimisticParagraphAlignment = null;
		pendingSelectionSeedValidationToken = null;
		coldAsyncReadDeferrals.clear();
		demandedHeavyReads.clear();
		incompleteTrackChangesDirectoryReadTokens.clear();
		postSourceCompletionRefreshTokens.clear();
		sourceCompletionObservedToken = null;
		heavyReadsHeldUntilIdle = false;
		if (detachSourceLoading) detachSourceLoading();
		detachSourceLoading = null;
		sourceLoadingSubscriptionHost = null;
		clearPostDecisionTrackChanges();
		allTrackedChangesResolvedToken = null;
	};
	/** Bump the document-mutation revision so content reads re-fetch on the next compute. */
	const invalidateDocumentContent = () => {
		documentMutationRevision += 1;
		incompleteTrackChangesDirectoryReadTokens.clear();
		postSourceCompletionRefreshTokens.clear();
		sourceCompletionObservedToken = null;
		clearPostDecisionTrackChanges();
	};
	/**
	* Refresh command-derived document slices without discarding an exact
	* all-resolved catalog received while the async command was settling. Host
	* mutation events arrive before the command promise resolves; a generic
	* invalidation at that later boundary would otherwise advance the cache
	* token and immediately re-list the catalog we already know is empty.
	*/
	const invalidateAfterCommandSettlement = () => {
		const carryAllResolvedCatalog = allTrackedChangesResolvedToken === contentToken();
		invalidateDocumentContent();
		if (carryAllResolvedCatalog) {
			replaceTrackedChangeItemsInCache([]);
			allTrackedChangesResolvedToken = contentToken();
		}
		recompute();
	};
	/**
	* Insert plain text through the public Document API. The narrow built-in /
	* custom insertion helper exposed on the custom-command callback context.
	* Fails closed (failure receipt) in viewing mode or when `doc.insert` is
	* unavailable — never reaching into `activeEditor.commands`.
	*/
	const insertText = (text) => {
		if (typeof text !== "string" || text.length === 0) return failedReceipt("insertText requires a non-empty string.", "INVALID_INPUT");
		if (readDocumentMode() === "viewing") return failedReceipt("The document is read-only.", "DOCUMENT_READONLY");
		const doc = getDoc();
		const op = doc?.insert;
		if (!doc || typeof op !== "function") return failedReceipt("insert is unavailable.");
		const currentSelection = doc.selection?.current;
		if (typeof currentSelection !== "function") return failedReceipt("selection.current is unavailable.");
		const insertAtLiveSelection = (selection) => {
			const record = selection && typeof selection === "object" ? selection : null;
			const target = record?.selectionTarget ?? record?.target ?? null;
			if (!target || typeof target !== "object") return failedReceipt("insertText requires a live selection target.", "PRECONDITION_FAILED");
			return safeCall(() => settleWorkflowReceipt(op.call(doc, {
				type: "text",
				value: text,
				target
			}), failedReceipt("insert failed.")), failedReceipt("insert failed."));
		};
		let selection;
		try {
			selection = currentSelection.call(doc.selection);
		} catch {
			return failedReceipt("insertText could not resolve the live selection.", "PRECONDITION_FAILED");
		}
		if (isPromiseLike(selection)) return Promise.resolve(selection).then(insertAtLiveSelection, () => failedReceipt("insertText could not resolve the live selection.", "PRECONDITION_FAILED"));
		return insertAtLiveSelection(selection);
	};
	/** Build the shared V2-truthful callback context for a custom command / button. */
	const buildCustomCommandContext = (payload, context) => ({
		payload,
		state,
		editor: getEditor(),
		superdoc,
		context,
		ui: controllerRef,
		execute: (commandId, commandPayload) => executeCommand(commandId, commandPayload),
		executeAsync: (commandId, commandPayload) => executeCommandAsync(commandId, commandPayload),
		doc: getDoc(),
		selection: state.selection,
		documentMode: readDocumentMode(),
		insertText
	});
	const normalizeDocumentMode = (value) => {
		return value === "editing" || value === "suggesting" || value === "viewing" ? value : null;
	};
	const readDocumentMode = () => {
		const editor = getEditor();
		const superdocRecord = superdoc && typeof superdoc === "object" ? superdoc : null;
		const fromConfig = normalizeDocumentMode((superdocRecord?.config)?.documentMode);
		const runtimeSnapshot = safeCall(typeof superdocRecord?.getActiveRuntime === "function" ? () => {
			const runtime = superdocRecord.getActiveRuntime();
			return typeof runtime?.getSnapshot === "function" ? runtime.getSnapshot() : null;
		} : void 0, null);
		const fromRuntime = normalizeDocumentMode(runtimeSnapshot?.documentMode);
		const fromOptions = normalizeDocumentMode((editor?.options)?.documentMode);
		if (fromConfig && fromRuntime && fromConfig !== fromRuntime) return fromConfig;
		return fromRuntime ?? fromConfig ?? fromOptions;
	};
	const commentsReadOnlyForReview = () => {
		const superdocRecord = superdoc && typeof superdoc === "object" ? superdoc : null;
		const resolved = (superdocRecord?.interactionConfig)?.comments;
		if (resolved && typeof resolved.readOnly === "boolean") return resolved.readOnly === true;
		const comments = ((superdocRecord?.config)?.modules)?.comments;
		return !!comments && typeof comments === "object" && comments.readOnly === true;
	};
	/**
	* Whether `interaction.comments.allowResolve` forbids changing a thread's
	* resolved state. Same precedence as `readOnly`: the resolved policy first,
	* the legacy block only when it is absent.
	*/
	const resolveIsForbidden = () => {
		const superdocRecord = superdoc && typeof superdoc === "object" ? superdoc : null;
		const resolved = (superdocRecord?.interactionConfig)?.comments;
		if (resolved && typeof resolved.allowResolve === "boolean") return resolved.allowResolve === false;
		const comments = ((superdocRecord?.config)?.modules)?.comments;
		return !!comments && typeof comments === "object" && comments.allowResolve === false;
	};
	const reviewMutationsAreReadOnly = () => readDocumentMode() === "viewing" || commentsReadOnlyForReview();
	const normalizeSelectionInfo = (raw) => raw && typeof raw === "object" ? raw : null;
	const selectionSliceFromInfo = (info, status) => {
		if (!info) return {
			...EMPTY_SELECTION,
			status
		};
		const target = info.target ?? null;
		const quotedText = typeof info.text === "string" ? info.text : "";
		return {
			status,
			empty: info.empty === true,
			target,
			selectionTarget: info.selectionTarget ?? null,
			activeMarks: Array.isArray(info.activeMarks) ? info.activeMarks : [],
			activeCommentIds: Array.isArray(info.activeCommentIds) ? info.activeCommentIds : [],
			activeChangeIds: Array.isArray(info.activeChangeIds) ? info.activeChangeIds : [],
			quotedText
		};
	};
	const readSelectionInfoLive = () => {
		const selectionApi = getDoc()?.selection;
		return readAsync("selection", selectionReadToken(), () => selectionApi?.current ? selectionApi.current({ includeText: true }) : void 0, normalizeSelectionInfo);
	};
	const computeSelection = () => {
		const { value: info, status } = readSelectionInfoLive();
		return selectionSliceFromInfo(info, status);
	};
	const selectionCurrentRun = () => {
		const selectionApi = getDoc()?.selection;
		return selectionApi?.current ? selectionApi.current({ includeText: true }) : void 0;
	};
	/** True when a host sync snapshot is a resolved collapsed caret (not a range). */
	const isCollapsedCaretSnapshot = (info) => {
		if (info.empty !== true) return false;
		const target = info.selectionTarget;
		const start = target?.start;
		const end = target?.end;
		return start?.kind === "text" && end?.kind === "text" && typeof start.blockId === "string" && start.blockId === end.blockId && typeof start.offset === "number" && start.offset === end.offset;
	};
	/**
	* On a caret move, seed the `selection` read cache synchronously from the
	* host's local snapshot so the toolbar reflects the NEW caret's block (and the
	* effective font resolved from it) on the next recompute, instead of serving
	* the previous selection until the worker `selection.current` round-trip lands
	* (SD-3652). Only a resolvable COLLAPSED CARET is seeded - a range's snapshot
	* cannot be resolved synchronously in worker mode, so ranges defer to the async
	* read (seeding an empty value would wrongly disable range-only commands). The
	* authoritative async read still overwrites marks/text/review overlap, but
	* foreground typing defers and coalesces that worker hop through the shared
	* retry gate. Previous marks are carried forward for toolbar continuity. A
	* tracked-change id is carried only when the host's painted caret proves the
	* same carrier, or while an active typing dispatch advances the same caret by
	* one code point. Pending work alone never carries review command context.
	*/
	const seedCaretSelectionFromHost = (hostSelectionSnapshot) => {
		const host = getHost();
		const read = host?.readLiveSelectionSyncSnapshot;
		if (typeof read !== "function") return;
		const seed = normalizeSelectionInfo(safeCall(() => read.call(host), null));
		if (!seed || !isCollapsedCaretSnapshot(seed)) return;
		const token = selectionReadToken();
		const foreground = foregroundMutationState();
		const deferAuthoritativeRead = Boolean(foreground && (foreground.active > 0 || foreground.pending > 0));
		if (!deferAuthoritativeRead) {
			pendingSelectionSeedValidationToken = null;
			if (issueAsyncRead("selection", token, selectionCurrentRun, normalizeSelectionInfo)) return;
		} else {
			pendingSelectionSeedValidationToken = token;
			scheduleForegroundAsyncRetry();
		}
		const prev = asyncReads.get("selection");
		const seedMarks = Array.isArray(seed.activeMarks) && seed.activeMarks.length > 0 ? seed.activeMarks : Array.isArray(state.selection.activeMarks) ? state.selection.activeMarks : [];
		const seedCommentIds = Array.isArray(seed.activeCommentIds) ? seed.activeCommentIds : [];
		const paintedTrackChangeId = readCollapsedHostTrackChangeId(hostSelectionSnapshot);
		const previousCaret = collapsedTextAddressFromSelection(state.selection);
		const nextCaret = collapsedTextAddressFromTarget(seed.selectionTarget) ?? collapsedTextAddressFromTarget(seed.target);
		const previousRange = previousCaret?.range;
		const nextRange = nextCaret?.range;
		const sameActiveTypingCaret = Boolean(foreground && foreground.active > 0 && previousCaret && nextCaret && previousCaret.blockId === nextCaret.blockId && storyLocatorSignature(previousCaret.story) === storyLocatorSignature(nextCaret.story) && typeof previousRange?.start === "number" && typeof nextRange?.start === "number" && Math.abs(nextRange.start - previousRange.start) <= 2);
		const carriedChangeIds = paintedTrackChangeId != null || sameActiveTypingCaret ? state.selection.activeChangeIds.filter((id) => paintedTrackChangeId == null || buildTrackedChangeIdContext(state.trackChanges.items).aliasesFor(id).includes(paintedTrackChangeId)) : [];
		const seedChangeIds = Array.isArray(seed.activeChangeIds) && seed.activeChangeIds.length > 0 ? seed.activeChangeIds : carriedChangeIds;
		asyncReads.set("selection", {
			token,
			value: {
				...seed,
				activeMarks: seedMarks,
				activeCommentIds: seedCommentIds,
				activeChangeIds: seedChangeIds
			},
			hasSettled: true,
			inflightToken: deferAuthoritativeRead ? null : prev?.inflightToken ?? null
		});
	};
	const readSelectionInfoFresh = async (attempt = 0) => {
		const selectionApi = getDoc()?.selection;
		const current = selectionApi?.current;
		const token = selectionReadToken();
		if (typeof current !== "function") {
			asyncReads.set("selection", {
				token,
				value: null,
				hasSettled: true,
				inflightToken: null
			});
			recompute();
			return state.selection;
		}
		let raw;
		try {
			raw = current.call(selectionApi, { includeText: true });
			if (isPromiseLike(raw)) raw = await Promise.resolve(raw);
		} catch {
			raw = null;
		}
		if (disposed) return selectionSliceFromInfo(null, "pending");
		if (selectionReadToken() !== token) return attempt < 1 ? readSelectionInfoFresh(attempt + 1) : state.selection;
		asyncReads.set("selection", {
			token,
			value: normalizeSelectionInfo(raw),
			hasSettled: true,
			inflightToken: null
		});
		recompute();
		return state.selection;
	};
	const readCommentsDirectory = () => {
		const commentsApi = getDoc()?.comments;
		return readAsync("comments", contentToken(), () => commentsApi?.list ? commentsApi.list() : void 0, (raw) => raw && Array.isArray(raw.items) ? raw.items : []);
	};
	const readTrackChangesDirectory = (key = "trackChanges") => {
		const token = contentToken();
		const tcApi = getDoc()?.trackChanges;
		const v2TrackedChanges = getV2TrackedChanges();
		const listTrackedChanges = typeof v2TrackedChanges?.listTrackedChanges === "function" ? v2TrackedChanges.listTrackedChanges : null;
		const read = readAsync(key, token, () => {
			if (listTrackedChanges) return runUiTrackedChangesCatalogRead(() => tcApi?.list?.({ in: "all" }));
			return tcApi?.list ? tcApi.list({ in: "all" }) : void 0;
		}, (raw) => {
			const result = raw && typeof raw === "object" ? raw : null;
			if (result?.complete === false || result?.sourceCoverageComplete === false) {
				incompleteTrackChangesDirectoryReadTokens.set(key, token);
				armSourceLoadCompletionRecompute();
				if (sourceCompletionObservedToken === token || hostSourceLoadPhase() === "complete") {
					const refresh = () => {
						if (!disposed) refreshIncompleteTrackChangesDirectories();
					};
					if (typeof queueMicrotask === "function") queueMicrotask(refresh);
					else Promise.resolve().then(refresh);
				}
			} else if (incompleteTrackChangesDirectoryReadTokens.get(key) === token) incompleteTrackChangesDirectoryReadTokens.delete(key);
			return result && Array.isArray(result.items) ? result.items : [];
		});
		return incompleteTrackChangesDirectoryReadTokens.get(key) === token && read.status === "ready" ? {
			...read,
			status: "stale"
		} : read;
	};
	const computeComments = (selection) => {
		const reviewWindow = getV2ReviewWindowSnapshot();
		const hasWindowFeed = hasV2ReviewWindowFeed();
		const catalog = !hasWindowFeed ? readCommentsDirectory() : null;
		const windowItems = hasWindowFeed && Array.isArray(reviewWindow?.commentItems) ? reviewWindow.commentItems : null;
		const value = hasWindowFeed ? windowItems : catalog.value;
		const listStatus = hasWindowFeed ? reviewWindowSliceStatus(reviewWindow) : catalog.status;
		const items = value ?? [];
		const activeIds = selection.activeCommentIds;
		const directory = asyncReads.get("comments");
		const directoryItems = directory?.token === contentToken() && directory.hasSettled && Array.isArray(directory.value) ? directory.value : null;
		const activeValidationItems = commentsDirectoryLeaseCount > 0 ? directoryItems : items;
		if (explicitActiveCommentId && activeValidationItems && !activeValidationItems.some((item) => readEntityId(item) === explicitActiveCommentId)) explicitActiveCommentId = null;
		const activeId = explicitActiveCommentId ?? activeIds[0] ?? null;
		return {
			status: combineStatus(listStatus, selection.status),
			listStatus,
			items,
			total: items.length,
			activeIds,
			activeId
		};
	};
	const projectedTrackChangesCache = /* @__PURE__ */ new WeakMap();
	const projectTrackChangesItems = (source) => {
		const cached = projectedTrackChangesCache.get(source);
		if (cached) return cached;
		const projected = source.map(projectTrackChangesItem).filter((item) => item != null);
		projectedTrackChangesCache.set(source, projected);
		return projected;
	};
	const filteredTrackChangesCache = /* @__PURE__ */ new WeakMap();
	const filterPostDecisionTrackChanges = (source, suppressedIds) => {
		const cached = filteredTrackChangesCache.get(source);
		if (cached?.suppressedIds === suppressedIds) return cached.value;
		const filtered = suppressedIds ? source.filter((item) => {
			const id = readEntityId(item);
			return !id || !suppressedIds.has(id);
		}) : source;
		filteredTrackChangesCache.set(source, {
			suppressedIds,
			value: filtered
		});
		return filtered;
	};
	const trackChangeAuthorsCache = /* @__PURE__ */ new WeakMap();
	const trackChangeAuthors = (items) => {
		const cached = trackChangeAuthorsCache.get(items);
		if (cached) return cached;
		const authors = /* @__PURE__ */ new Set();
		for (const item of items) {
			const change = trackChangesItemPayload(item);
			const row = item;
			const author = change.author ?? change.authorEmail ?? row.author ?? row.authorEmail;
			if (typeof author === "string") authors.add(author);
		}
		const value = [...authors];
		trackChangeAuthorsCache.set(items, value);
		return value;
	};
	const readAllStoryTrackChanges = () => {
		const token = contentToken();
		if (hasV2ReviewWindowFeed()) {
			const directory = asyncReads.get("trackChanges");
			const source = directory?.token === token && directory.hasSettled && Array.isArray(directory.value) ? directory.value : getV2ReviewWindowSnapshot()?.trackedChangeItems;
			if (!Array.isArray(source)) return null;
			return projectTrackChangesItems(source);
		}
		const { value, status } = readTrackChangesDirectory("trackChanges:all");
		return status === "ready" ? projectTrackChangesItems(value ?? []) : null;
	};
	const computeTrackChanges = (selection) => {
		const token = contentToken();
		const postDecisionIds = postDecisionTrackChangeIdsForToken(token);
		const reviewWindow = getV2ReviewWindowSnapshot();
		const hasWindowFeed = hasV2ReviewWindowFeed();
		const catalog = !hasWindowFeed ? readTrackChangesDirectory() : null;
		const windowItems = hasWindowFeed && Array.isArray(reviewWindow?.trackedChangeItems) ? reviewWindow.trackedChangeItems : null;
		const value = hasWindowFeed ? windowItems : catalog.value;
		const listStatus = hasWindowFeed ? reviewWindowSliceStatus(reviewWindow) : catalog.status;
		const items = filterPostDecisionTrackChanges(projectTrackChangesItems(value ?? []), postDecisionIds);
		const allStoryItems = readAllStoryTrackChanges();
		const active = explicitActiveChange;
		if (active && !pendingTrackChangeRevealFocuses.has(active)) {
			const directory = asyncReads.get("trackChanges");
			const directoryItems = directory?.token === token && directory.hasSettled && Array.isArray(directory.value) ? filterPostDecisionTrackChanges(projectTrackChangesItems(directory.value), postDecisionIds) : null;
			const activeValidationItems = trackChangesDirectoryLeaseCount > 0 ? directoryItems : active.story ? allStoryItems : items;
			if (activeValidationItems && !activeValidationItems.some((row) => entityRowMatchesRequest(row, active.id, active.story))) setExplicitActiveChange(null);
		}
		const publicIdItems = allStoryItems ?? items;
		const selectionIdContext = buildStoryScopedTrackedChangeIdContext(publicIdItems, selectionStory(selection));
		const selectionActiveChangeIds = allTrackedChangesResolvedToken === token ? [] : postDecisionIds ? selection.activeChangeIds.filter((id) => !postDecisionIds.has(id)) : selection.activeChangeIds;
		const selectionPublicChangeIds = selectionActiveChangeIds.map((id) => selectionIdContext.toPublicId(id) ?? id);
		const explicitActiveIdContext = explicitActiveChange?.story ? buildStoryScopedTrackedChangeIdContext(publicIdItems, explicitActiveChange.story) : buildTrackedChangeIdContext(publicIdItems);
		const explicitActiveId = explicitActiveChange ? explicitActiveIdContext.toPublicId(explicitActiveChange.id) ?? explicitActiveChange.id : null;
		const selectionActiveId = resolveSelectionActiveChangeId({
			selectionIds: selectionActiveChangeIds,
			publicIds: selectionPublicChangeIds,
			selection,
			bodyItems: items,
			allStoryItems
		});
		const activeId = explicitActiveId ?? selectionActiveId;
		return {
			status: combineStatus(listStatus, selection.status),
			items,
			total: items.length,
			activeId,
			authors: trackChangeAuthors(items)
		};
	};
	const computeCommentsDirectorySnapshot = (selection, windowSnapshot) => {
		if (!hasV2ReviewWindowFeed()) return windowSnapshot;
		demandHeavyDocRead("comments");
		const directory = readCommentsDirectory();
		const items = directory.value ?? windowSnapshot.items;
		return {
			status: combineStatus(directory.status, selection.status),
			listStatus: directory.status,
			items,
			total: items.length,
			activeIds: selection.activeCommentIds,
			activeId: explicitActiveCommentId ?? selection.activeCommentIds[0] ?? null
		};
	};
	const computeTrackChangesDirectorySnapshot = (selection, windowSnapshot) => {
		if (!hasV2ReviewWindowFeed()) return windowSnapshot;
		demandHeavyDocRead("trackChanges");
		const directory = readTrackChangesDirectory();
		const postDecisionIds = postDecisionTrackChangeIdsForToken(contentToken());
		const items = filterPostDecisionTrackChanges(projectTrackChangesItems(directory.value ?? windowSnapshot.items), postDecisionIds);
		const explicitIdContext = explicitActiveChange?.story ? buildStoryScopedTrackedChangeIdContext(items, explicitActiveChange.story) : buildTrackedChangeIdContext(items);
		const activeId = explicitActiveChange ? explicitIdContext.toPublicId(explicitActiveChange.id) ?? explicitActiveChange.id : windowSnapshot.activeId;
		return {
			status: combineStatus(directory.status, selection.status),
			items,
			total: items.length,
			activeId,
			authors: trackChangeAuthors(items)
		};
	};
	const computeContentControls = (selection) => {
		const ccApi = getDoc()?.contentControls;
		const { value, status: listStatus } = readAsync("contentControls", contentToken(), () => ccApi?.list ? ccApi.list() : void 0, (raw) => raw && Array.isArray(raw.items) ? raw.items : []);
		const items = value ?? [];
		const { ids: activeIds, status: rangeStatus } = computeActiveContentControlIds(ccApi, selection);
		return {
			status: combineStatus(listStatus, rangeStatus, selection.status),
			items,
			total: items.length,
			activeId: activeIds[0] ?? null,
			activeIds
		};
	};
	/**
	* Lock mode of every content control overlapping the current selection's
	* block range, keyed by control id. Powers `contentControlLockReason` so the
	* toolbar can disable styling controls when the selection touches a
	* `contentLocked`/`sdtContentLocked` control (SD-3274) — block-range scoped,
	* same precision as `computeActiveContentControlIds` below.
	*/
	const computeActiveContentControlLockModes = (ccApi, selection) => {
		if (!ccApi || typeof ccApi.listInRange !== "function") return {
			lockModesById: /* @__PURE__ */ new Map(),
			status: "ready"
		};
		const range = selectionBlockRange(selection);
		if (!range) return {
			lockModesById: /* @__PURE__ */ new Map(),
			status: "ready"
		};
		const { value, status } = readAsync(`contentControls:inRange:${selectionSignature(selection)}`, contentToken(), () => ccApi.listInRange(range), (raw) => raw && Array.isArray(raw.items) ? raw.items : []);
		const rows = value ?? [];
		const lockModesById = /* @__PURE__ */ new Map();
		for (const row of rows) if (typeof row?.id === "string") lockModesById.set(row.id, typeof row.lockMode === "string" ? row.lockMode : "unlocked");
		return {
			lockModesById,
			status
		};
	};
	const computeActiveContentControlIds = (ccApi, selection) => {
		const { lockModesById, status } = computeActiveContentControlLockModes(ccApi, selection);
		return {
			ids: [...lockModesById.keys()],
			status
		};
	};
	const computeFonts = () => {
		const fontsApi = superdoc?.fonts;
		return {
			options: composeFontFamilyOptions(normalizeDocumentFontOptions(safeCall(fontsApi?.getDocumentFontOptions ? () => fontsApi.getDocumentFontOptions() : void 0, [])), normalizePickerFontOptions(safeCall(fontsApi?.getFontFamilyOptions ? () => fontsApi.getFontFamilyOptions() : void 0, []))),
			sizeOptions: DEFAULT_FONT_SIZE_OPTIONS
		};
	};
	const computeZoom = () => {
		const state = safeCall(superdoc?.getZoomState ? () => superdoc.getZoomState() : void 0, null);
		const value = typeof state?.value === "number" ? state.value : 100;
		const rawMode = state?.mode;
		return {
			mode: rawMode === "manual" || rawMode === "fit-width" ? rawMode : rawMode === "fixed" ? "manual" : null,
			value,
			min: typeof state?.min === "number" ? state.min : 10,
			max: typeof state?.max === "number" ? state.max : 100
		};
	};
	const readMeasurementUnit = () => {
		return safeCall(superdoc?.getMeasurementUnit ? () => superdoc.getMeasurementUnit() : void 0, "in") === "cm" ? "cm" : "in";
	};
	const computeDocument = () => {
		const editor = getEditor();
		return {
			ready: editor != null,
			mode: readDocumentMode(),
			dirty: editor ? Boolean(editor.isDirty) : false
		};
	};
	/**
	* Resolve the `query.match` row covering the current selection through the
	* async read coordinator. The promise-capable browser `query.match` is read
	* via the cache (keyed by selection signature + content revision), so inline
	* value projection no longer collapses to empty when the read is async.
	*/
	const selectionTextQueryRequest = (selection) => {
		const pattern = selection.quotedText;
		if (typeof pattern !== "string" || pattern.length === 0) return null;
		const segments = selectionTextSegments(selection);
		if (segments.length === 0 || !canProbeEverySelectedBlock(segments.map((segment) => segment.blockId))) return null;
		const target = selection.target;
		const within = segments.length === 1 ? paragraphTarget(segments[0].blockId, target?.story) : void 0;
		return {
			select: {
				type: "text",
				pattern,
				mode: "contains",
				caseSensitive: true
			},
			...within ? { within } : {},
			require: "any"
		};
	};
	const resolveSelectionTextQueryItem = (selection) => {
		const query = getDoc()?.query;
		if (typeof query?.match !== "function") return null;
		const request = selectionTextQueryRequest(selection);
		if (!request) return null;
		const { value } = readAsync(`query:${selectionSignature(selection)}`, contentToken(), () => query.match(request), (raw) => raw && typeof raw === "object" ? raw : null);
		return pickSelectionTextQueryItem(value, selection);
	};
	/**
	* Effective (cascade-resolved) font family / size for the selection, read from
	* the mounted layout and matched by source node id (SD-3652). The Document API
	* query surfaces only DIRECT run properties, so inherited fonts have no
	* projected value; the layout has already resolved them for painting.
	*/
	const resolveEffectiveInlineValuesFromLayout = (selection) => {
		const host = getHost();
		const blockIds = new Set(selectionBlockIds(selection));
		if (blockIds.size === 0) return {};
		const readByIds = host?.readMountedProjectionBlocksByIds;
		const readAll = host?.readMountedProjectionBlocks;
		if (typeof readByIds !== "function" && typeof readAll !== "function") return {};
		const blocks = safeCall(() => {
			if (typeof readByIds !== "function") return readAll.call(host);
			const story = selectionStoryLocator(selection);
			return story ? readByIds.call(host, [...blockIds], story) : readByIds.call(host, [...blockIds]);
		}, null);
		if (!Array.isArray(blocks)) return {};
		const flatBlocks = collectProjectionTextBlocks(blocks);
		const runFontValues = (run) => {
			const out = {};
			const family = normalizeLayoutFontFamily(run.fontFamily);
			if (family) out.fontFamily = family;
			const size = normalizeLayoutFontSizePt(run.fontSize);
			if (size) out.fontSize = size;
			if (typeof run.color === "string" && run.color.trim() !== "") out.color = run.color.trim().toUpperCase();
			if (typeof run.highlight === "string" && run.highlight.trim() !== "") out.highlight = run.highlight.trim().toUpperCase();
			return out;
		};
		const caret = collapsedTextAddressFromSelection(selection);
		const caretOffset = caret && typeof caret.range?.start === "number" ? caret.range.start : null;
		if (caret && caretOffset !== null && blockIds.has(caret.blockId)) {
			const block = flatBlocks.find((b) => projectionBlockMatchesId(b, caret.blockId));
			const runs = block && Array.isArray(block.runs) ? block.runs : null;
			if (runs && runs.length > 0 && runs.every((r) => r?.kind === "text" || r?.kind === "tab")) {
				let acc = 0;
				let chosen = null;
				for (const run of runs) {
					const len = projectionRunSelectionLength(run);
					if (caretOffset >= acc && caretOffset < acc + len) {
						chosen = run;
						break;
					}
					acc += len;
				}
				if (!chosen) {
					for (let i = runs.length - 1; i >= 0 && !chosen; i -= 1) if (runs[i]?.kind === "text") chosen = runs[i];
					chosen ??= runs[runs.length - 1] ?? null;
				}
				if (!chosen) return {};
				return runFontValues(chosen);
			}
		}
		const segments = selectionTextSegments(selection);
		if (segments.length > 0) {
			const rangeFamilies = /* @__PURE__ */ new Set();
			const rangeSizes = /* @__PURE__ */ new Set();
			let rangeSawRun = false;
			let offsetSafe = true;
			for (const seg of segments) {
				const block = flatBlocks.find((b) => projectionBlockMatchesId(b, seg.blockId));
				if (!block) return {};
				const runs = Array.isArray(block.runs) ? block.runs : [];
				if (runs.length === 0) continue;
				if (!runs.every((r) => r?.kind === "text" || r?.kind === "tab")) {
					offsetSafe = false;
					break;
				}
				let acc = 0;
				for (const run of runs) {
					const len = projectionRunSelectionLength(run);
					const runStart = acc;
					const runEnd = acc + len;
					if (runStart < seg.end && runEnd > seg.start) {
						rangeSawRun = true;
						const values = runFontValues(run);
						if (values.fontFamily) rangeFamilies.add(values.fontFamily);
						if (values.fontSize) rangeSizes.add(values.fontSize);
					}
					acc = runEnd;
				}
			}
			if (offsetSafe && rangeSawRun) {
				const projection = {};
				if (rangeFamilies.size === 1) projection.fontFamily = [...rangeFamilies][0];
				if (rangeSizes.size === 1) projection.fontSize = [...rangeSizes][0];
				return projection;
			}
		}
		const families = /* @__PURE__ */ new Set();
		const sizes = /* @__PURE__ */ new Set();
		let sawRun = false;
		for (const block of flatBlocks) {
			if (![...blockIds].some((id) => projectionBlockMatchesId(block, id))) continue;
			const runs = Array.isArray(block.runs) ? block.runs : [];
			for (const run of runs) {
				if (run?.kind !== "text") continue;
				sawRun = true;
				const values = runFontValues(run);
				if (values.fontFamily) families.add(values.fontFamily);
				if (values.fontSize) sizes.add(values.fontSize);
			}
		}
		if (!sawRun) return {};
		const projection = {};
		if (families.size === 1) projection.fontFamily = [...families][0];
		if (sizes.size === 1) projection.fontSize = [...sizes][0];
		return projection;
	};
	/**
	* Effective (cascade-resolved) toggle-mark state read from the mounted
	* projection (SD-3860). `run.bold`/`run.italic`/`run.strike`/`run.underline`
	* on a projected run are already the FINAL merged value (style cascade +
	* any direct rPr override) — the same values `DomPainter` paints with — so
	* unlike the raw-rPr-only `selection.activeMarks` scan, this correctly
	* reports `false` for an explicit `<w:b w:val="0"/>` override even when a
	* paragraph/table style says bold. A key is left `undefined` when the
	* covered runs disagree (genuine mixed selection) or nothing could be read,
	* so the caller falls through to the worker-side uniformity read rather
	* than guessing. Mounted-projection `underline` is an object (`{}` /
	* `{ style: 'single' }`) when active, never a bare `true` — check presence.
	*/
	const resolveEffectiveMarkValuesFromLayout = (selection) => {
		const host = getHost();
		const blockIds = new Set(selectionBlockIds(selection));
		if (blockIds.size === 0) return {};
		const readByIds = host?.readMountedProjectionBlocksByIds;
		const readAll = host?.readMountedProjectionBlocks;
		if (typeof readByIds !== "function" && typeof readAll !== "function") return {};
		const blocks = safeCall(() => {
			if (typeof readByIds !== "function") return readAll.call(host);
			const story = selectionStoryLocator(selection);
			return story ? readByIds.call(host, [...blockIds], story) : readByIds.call(host, [...blockIds]);
		}, null);
		if (!Array.isArray(blocks)) return {};
		const flatBlocks = collectProjectionTextBlocks(blocks);
		const runMarkValues = (run) => ({
			bold: run.bold === true,
			italic: run.italic === true,
			underline: run.underline != null,
			strikethrough: run.strike === true
		});
		const collapseMarkSets = (sets) => {
			const out = {};
			for (const key of EFFECTIVE_MARK_KEYS) {
				const set = sets[key];
				if (set.size === 1) out[key] = [...set][0];
			}
			return out;
		};
		const caret = collapsedTextAddressFromSelection(selection);
		const caretOffset = caret && typeof caret.range?.start === "number" ? caret.range.start : null;
		if (caret && caretOffset !== null && blockIds.has(caret.blockId)) {
			const block = flatBlocks.find((b) => projectionBlockMatchesId(b, caret.blockId));
			const runs = block && Array.isArray(block.runs) ? block.runs : null;
			if (runs && runs.length > 0 && runs.every((r) => r?.kind === "text" || r?.kind === "tab")) {
				let acc = 0;
				let chosen = null;
				for (const run of runs) {
					const len = projectionRunSelectionLength(run);
					if (caretOffset >= acc && caretOffset < acc + len) {
						chosen = run;
						break;
					}
					acc += len;
				}
				if (!chosen) {
					for (let i = runs.length - 1; i >= 0 && !chosen; i -= 1) if (runs[i]?.kind === "text") chosen = runs[i];
					chosen ??= runs[runs.length - 1] ?? null;
				}
				if (!chosen) return {};
				return runMarkValues(chosen);
			}
		}
		const segments = selectionTextSegments(selection);
		if (segments.length > 0) {
			const rangeSets = {
				bold: /* @__PURE__ */ new Set(),
				italic: /* @__PURE__ */ new Set(),
				underline: /* @__PURE__ */ new Set(),
				strikethrough: /* @__PURE__ */ new Set()
			};
			let rangeSawRun = false;
			let offsetSafe = true;
			for (const seg of segments) {
				const block = flatBlocks.find((b) => projectionBlockMatchesId(b, seg.blockId));
				if (!block) return {};
				const runs = Array.isArray(block.runs) ? block.runs : [];
				if (runs.length === 0) continue;
				if (!runs.every((r) => r?.kind === "text" || r?.kind === "tab")) {
					offsetSafe = false;
					break;
				}
				let acc = 0;
				for (const run of runs) {
					const len = projectionRunSelectionLength(run);
					const runStart = acc;
					const runEnd = acc + len;
					if (runStart < seg.end && runEnd > seg.start) {
						rangeSawRun = true;
						const values = runMarkValues(run);
						for (const key of EFFECTIVE_MARK_KEYS) rangeSets[key].add(values[key]);
					}
					acc = runEnd;
				}
			}
			if (offsetSafe && rangeSawRun) return collapseMarkSets(rangeSets);
		}
		const wholeSets = {
			bold: /* @__PURE__ */ new Set(),
			italic: /* @__PURE__ */ new Set(),
			underline: /* @__PURE__ */ new Set(),
			strikethrough: /* @__PURE__ */ new Set()
		};
		let sawWholeRun = false;
		for (const block of flatBlocks) {
			if (![...blockIds].some((id) => projectionBlockMatchesId(block, id))) continue;
			const runs = Array.isArray(block.runs) ? block.runs : [];
			for (const run of runs) {
				if (run?.kind !== "text") continue;
				sawWholeRun = true;
				const values = runMarkValues(run);
				for (const key of EFFECTIVE_MARK_KEYS) wholeSets[key].add(values[key]);
			}
		}
		if (!sawWholeRun) return {};
		return collapseMarkSets(wholeSets);
	};
	const completeProjectedInlineValues = (selection, direct) => {
		if (direct.fontFamily !== void 0 && direct.fontSize !== void 0 && direct.color !== void 0 && direct.highlight !== void 0) return {
			values: direct,
			effectiveUniformityStatus: "ready"
		};
		const resolved = resolveEffectiveInlineValuesFromLayout(selection);
		const combined = {
			...resolved.fontFamily !== void 0 ? { fontFamily: resolved.fontFamily } : {},
			...resolved.fontSize !== void 0 ? { fontSize: resolved.fontSize } : {},
			...resolved.color !== void 0 ? { color: resolved.color } : {},
			...resolved.highlight !== void 0 ? { highlight: resolved.highlight } : {},
			...direct
		};
		if (!selection.empty && (combined.fontFamily === void 0 || combined.fontSize === void 0)) {
			const uniformity = resolveEffectiveInlineUniformityValues(selection);
			if (uniformity.values) {
				if (combined.fontFamily === void 0 && uniformity.values.fontFamily !== void 0) combined.fontFamily = uniformity.values.fontFamily;
				if (combined.fontSize === void 0 && uniformity.values.fontSize !== void 0) combined.fontSize = uniformity.values.fontSize;
			}
			return {
				values: combined,
				effectiveUniformityStatus: uniformity.status
			};
		}
		return {
			values: combined,
			effectiveUniformityStatus: "ready"
		};
	};
	/**
	* Cached async access to the INTERNAL `format.readEffectiveInlineUniformity`
	* read (duck-typed; absent on hosts that do not provide it). Returns only
	* settled UNIFORM values - mixed and unresolvable keys stay undefined so the
	* toolbar renders its mixed/blank state, and a pending read serves nothing
	* (the held-value logic covers the transition).
	*/
	const EFFECTIVE_INLINE_UNIFORMITY_KEYS = [
		"fontFamily",
		"fontSize",
		"bold",
		"italic",
		"underline",
		"strikethrough"
	];
	const readEffectiveInlineUniformityCached = (selection) => {
		const target = selection.selectionTarget;
		if (!target) return {
			value: null,
			status: "ready"
		};
		const op = resolveDocOperation(getDoc(), "format.readEffectiveInlineUniformity");
		if (!op) return {
			value: null,
			status: "ready"
		};
		const signature = selectionEffectiveUniformitySignature(selection) ?? selectionSignature(selection);
		return readAsync(`effInline:${signature}`, contentToken(), () => op({
			target,
			offsetSpace: "selection",
			keys: EFFECTIVE_INLINE_UNIFORMITY_KEYS
		}), (raw) => raw && typeof raw === "object" ? raw : null);
	};
	const resolveEffectiveInlineUniformityValues = (selection) => {
		const { value, status } = readEffectiveInlineUniformityCached(selection);
		if (!value || value.success !== true) return {
			values: null,
			status
		};
		const states = value.values;
		const uniform = (key) => {
			const entry = states?.[key];
			if (!entry || entry.state !== "uniform" || typeof entry.value !== "string") return void 0;
			return key === "fontFamily" ? normalizeLayoutFontFamily(entry.value) : entry.value;
		};
		return {
			values: {
				fontFamily: uniform("fontFamily"),
				fontSize: uniform("fontSize")
			},
			status
		};
	};
	/** Worker-side cascade-resolved mark uniformity, for selections whose tail isn't mounted (SD-3860). */
	const resolveEffectiveMarkUniformityValues = (selection) => {
		const { value, status } = readEffectiveInlineUniformityCached(selection);
		if (!value || value.success !== true) return {
			values: null,
			status
		};
		const states = value.values;
		const values = {};
		for (const key of EFFECTIVE_MARK_KEYS) {
			const entry = states?.[key];
			if (entry?.state === "uniform" && (entry.value === "true" || entry.value === "false")) values[key] = entry.value === "true";
		}
		return {
			values,
			status
		};
	};
	/**
	* Effective active state for a toggle-mark command (bold/italic/underline/
	* strikethrough), SD-3860: the mounted-layout read is tried first (fast,
	* synchronous), then the worker uniformity read for unmounted content.
	* Returns `null` (no opinion) only when neither source has resolved yet,
	* in which case the caller falls back to the raw direct-only check.
	*/
	const effectiveMarkActiveState = (descriptor, selection) => {
		const mark = descriptor.activeMark;
		if (!mark || !EFFECTIVE_MARK_KEYS.includes(mark)) return null;
		const key = mark;
		const fromLayout = resolveEffectiveMarkValuesFromLayout(selection)[key];
		if (fromLayout !== void 0) return fromLayout;
		const { values } = resolveEffectiveMarkUniformityValues(selection);
		const fromWorker = values?.[key];
		return fromWorker !== void 0 ? fromWorker : null;
	};
	const readEffectiveInlineUniformityNow = async (selection) => {
		const target = selection.selectionTarget;
		if (!target) return null;
		const op = resolveDocOperation(getDoc(), "format.readEffectiveInlineUniformity");
		if (!op) return null;
		try {
			const raw = await Promise.resolve(op({
				target,
				offsetSpace: "selection"
			}));
			return raw && typeof raw === "object" && raw.success === true ? raw : null;
		} catch {
			return null;
		}
	};
	const applyEffectiveInlineUniformity = (projected, direct, result) => {
		const states = result.values;
		for (const key of ["fontFamily", "fontSize"]) {
			if (direct[key] !== void 0) continue;
			const entry = states?.[key];
			if (entry?.state === "uniform" && typeof entry.value === "string") projected[key] = key === "fontFamily" ? normalizeLayoutFontFamily(entry.value) : entry.value;
			else delete projected[key];
		}
	};
	const projectSelectionInlineValuesWithStatus = (selection) => completeProjectedInlineValues(selection, projectInlineValuesFromQueryItem(resolveSelectionTextQueryItem(selection), selection));
	const projectSelectionInlineValues = (selection) => projectSelectionInlineValuesWithStatus(selection).values;
	/**
	* Read command-critical inline values for format-painter capture. Reactive
	* command state intentionally serves stale values while its worker read is
	* refreshing, but arming the painter must snapshot the mutation that just
	* settled. A direct, bounded query here makes the async capture authoritative
	* without changing the non-blocking toolbar snapshot policy.
	*/
	const readFormatPainterInlineValues = async (selection) => {
		const query = getDoc()?.query;
		const request = selectionTextQueryRequest(selection);
		if (typeof query?.match !== "function" || !request) return projectSelectionInlineValues(selection);
		try {
			const raw = await Promise.resolve(query.match(request));
			const direct = projectInlineValuesFromQueryItem(pickSelectionTextQueryItem(raw && typeof raw === "object" ? raw : null, selection), selection);
			const completed = completeProjectedInlineValues(selection, direct);
			if (completed.effectiveUniformityStatus !== "ready" && (direct.fontFamily === void 0 || direct.fontSize === void 0)) {
				const effective = await readEffectiveInlineUniformityNow(selection);
				if (effective) applyEffectiveInlineUniformity(completed.values, direct, effective);
			}
			return completed.values;
		} catch {
			return projectSelectionInlineValues(selection);
		}
	};
	const readBlockNode = async (address) => {
		const doc = getDoc();
		if (!doc) return void 0;
		if (typeof doc.getNode === "function") return await Promise.resolve(doc.getNode(address));
		return await Promise.resolve(doc.getNodeById?.({
			nodeId: address["nodeId"],
			nodeType: address["nodeType"]
		}));
	};
	/**
	* Returns the settled status of the query.match read backing the current
	* selection's inline-value projection. Called after resolveSelectionTextQueryItem
	* so readAsync always finds an existing cache entry — this is a status-only lookup.
	*/
	const selectionQueryStatus = (selection) => {
		const query = getDoc()?.query;
		if (typeof query?.match !== "function") return "ready";
		const request = selectionTextQueryRequest(selection);
		if (!request) return "ready";
		const { status } = readAsync(`query:${selectionSignature(selection)}`, contentToken(), () => query.match(request), (raw) => raw && typeof raw === "object" ? raw : null);
		return status;
	};
	/**
	* Last fully-settled inline projection, keyed by the selection's inline
	* signature (content-token-free: the SAME selection across content
	* revisions keeps its key). While a refresh of the same selection is
	* pending/stale, settled values fill keys the in-flight projection has not
	* resolved yet, so the toolbar font field does not flicker blank mid-edit.
	* A NEW selection never reads a previous selection's held values, and a
	* SETTLED mixed selection overwrites the hold (blank is then correct).
	*/
	const projectInlineValuesWithSettledHold = (selection) => {
		const projection = projectSelectionInlineValuesWithStatus(selection);
		const projected = projection.values;
		if (selection.empty) return projection;
		const signature = selectionInlineValueSignature(selection);
		if (!signature) return projection;
		if (selection.status === "ready" && selectionQueryStatus(selection) === "ready" && projection.effectiveUniformityStatus === "ready") {
			heldSettledInlineValues = {
				key: signature,
				values: projected
			};
			return projection;
		}
		if (heldSettledInlineValues && heldSettledInlineValues.key === signature) return {
			...projection,
			values: {
				...heldSettledInlineValues.values,
				...projected
			}
		};
		return projection;
	};
	const computeCommandStates = (selection) => {
		const doc = getDoc();
		const projectedInlineRead = projectInlineValuesWithSettledHold(selection);
		const projectedInlineValues = projectedInlineRead.values;
		if (selection.status === "ready" && !selection.empty && selectionQueryStatus(selection) === "ready" && projectedInlineRead.effectiveUniformityStatus === "ready") {
			frozenProjectedValues = projectedInlineValues;
			frozenProjectedValuesKey = `${selectionKey(selection)}:${contentToken()}`;
		}
		const ccApi = doc?.contentControls;
		const { lockModesById } = computeActiveContentControlLockModes(ccApi, selection);
		const states = {};
		for (const id of allCommandIds()) states[id] = computeCommandState(id, doc, selection, projectedInlineValues, lockModesById);
		return states;
	};
	/** Stable reason a routed command cannot reach its Document API operation. */
	const unavailableRouteReason = (doc) => {
		if (doc) return SUPERDOC_UI_REASONS.operationUnavailable;
		return getEditor() ? SUPERDOC_UI_REASONS.documentApiUnavailable : SUPERDOC_UI_REASONS.notReady;
	};
	/**
	* Lock modes that block run-level styling mutations (bold/italic/font/etc.),
	* mirroring the content-mutation axis the content-controls adapter's
	* `guardContentUnlocked` enforces server-side (`contentLocked` /
	* `sdtContentLocked`). `sdtLocked` protects only the wrapper, not styling.
	*/
	const blocksContentStyling = (lockMode) => lockMode === "contentLocked" || lockMode === "sdtContentLocked";
	/**
	* Stable reason an inline (run-level) styling command is disabled because the
	* selection overlaps a content control whose lock forbids styling it — Word
	* parity (SD-3274): SuperDoc must not leave styling controls clickable when
	* the mutation cannot apply. Block-range scoped (same precision as
	* `computeActiveContentControlLockModes`), so this can over-disable when an
	* unrelated selection shares a block with a locked control — accepted for
	* now; alignment/paragraph-level commands are never gated here.
	*/
	const contentControlLockReason = (lockModesById) => {
		for (const lockMode of lockModesById.values()) if (blocksContentStyling(lockMode)) return SUPERDOC_UI_REASONS.contentControlLocked;
	};
	/** Stable reason a tracked-change decision command is disabled, or undefined when enabled. */
	const trackDecisionReason = (command, supported, readonly, selection, doc) => {
		if (!supported) return command.scope === "all" ? SUPERDOC_UI_REASONS.bulkDecisionsDisabled : unavailableRouteReason(doc);
		if (readonly) return SUPERDOC_UI_REASONS.documentReadonly;
		if (command.scope !== "all" && selection.activeChangeIds.length === 0) return SUPERDOC_UI_REASONS.selectionRequired;
	};
	const findTrackChangeForPermission = (id) => {
		const fromSlice = state?.trackChanges?.items?.find((item) => readEntityId(item) === id);
		if (fromSlice) return trackChangesItemPayload(fromSlice);
		const listed = safeCall(() => (getDoc()?.trackChanges)?.list?.(), null);
		if (!listed || typeof listed !== "object" || typeof listed.then === "function") return null;
		const items = listed.items;
		if (!Array.isArray(items)) return null;
		const row = items.find((item) => readEntityId(item) === id);
		if (!row) return null;
		const projected = projectTrackChangesItem(row);
		return projected ? trackChangesItemPayload(projected) : row;
	};
	const trackedChangeDecisionPermissionReason = (kind, ids) => {
		const canPerform = superdoc.canPerformPermission;
		if (typeof canPerform !== "function" || ids.length === 0) return void 0;
		const currentUser = superdoc.config && typeof superdoc.config === "object" ? superdoc.config.user : null;
		for (const id of ids) {
			const trackedChange = findTrackChangeForPermission(id) ?? { id };
			const isOwn = trackedChangeOwnedByCurrentUser(trackedChange, currentUser);
			const permission = kind === "accept" ? isOwn ? "RESOLVE_OWN" : "RESOLVE_OTHER" : isOwn ? "REJECT_OWN" : "REJECT_OTHER";
			let allowed;
			try {
				allowed = canPerform.call(superdoc, {
					permission,
					trackedChange,
					comment: null
				});
			} catch {
				return;
			}
			if (allowed === false) return SUPERDOC_UI_REASONS.permissionDenied;
		}
	};
	const hostCommandSupport = (command) => {
		const host = getHost();
		const commands = safeCall(typeof host?.getCapabilities === "function" ? () => host.getCapabilities() : void 0, null)?.editableSubset?.commands;
		if (Array.isArray(commands)) return commands.find((entry) => entry?.command === command || entry?.id === command) ?? null;
		if (commands && typeof commands === "object") {
			const record = commands[command];
			return record && typeof record === "object" ? record : null;
		}
		return null;
	};
	const bulkTrackDecisionBlockedReason = (command, tcApi) => {
		if (command.scope !== "all") return void 0;
		if (typeof tcApi?.[`${command.kind}All`] === "function") return void 0;
		const support = hostCommandSupport(`trackedChanges.${command.kind}All`);
		if (support && (support.status === "supported" || support.enabled === true)) return void 0;
		return SUPERDOC_UI_REASONS.bulkDecisionsDisabled;
	};
	const computeCommandState = (id, doc, selection, projectedInlineValues, lockModesById = /* @__PURE__ */ new Map()) => {
		if (customCommands.has(id)) return normalizeCommandState({
			supported: true,
			enabled: true,
			...safeCall(customCommands.get(id).getState ? () => customCommands.get(id).getState(buildCustomCommandContext(void 0)) : void 0, {})
		}, "custom");
		const readonly = readDocumentMode() === "viewing";
		const listKind = listToggleKind(id);
		if (listKind) {
			if (typeof (getEditCommands()?.lists)?.apply === "function") {
				const entry = readListApplyStateEntry();
				const shippedStatus = typeof entry?.shippedStatus === "string" ? entry.shippedStatus : null;
				const supported = shippedStatus !== "not-shipped" && shippedStatus !== "disabled";
				const enabled = supported && (typeof entry?.enabled === "boolean" ? entry.enabled : true);
				const activeSeed = supported ? readListActiveSeed(entry) : null;
				if (readonly) return normalizeCommandState({
					enabled: false,
					active: activeSeed === listKind,
					supported,
					value: entry?.value,
					reason: SUPERDOC_UI_REASONS.documentReadonly
				}, "builtin");
				return normalizeCommandState({
					enabled,
					active: activeSeed === listKind,
					supported,
					value: entry?.value
				}, "builtin");
			}
		}
		const trackCommand = trackDecisionCommand(id);
		if (trackCommand) {
			const tcApi = doc?.trackChanges;
			const supportsSingle = typeof tcApi?.decide === "function" || typeof tcApi?.[trackCommand.kind] === "function";
			const supportsAll = typeof tcApi?.decide === "function" || typeof tcApi?.[`${trackCommand.kind}All`] === "function";
			const supported = trackCommand.scope === "all" ? supportsAll : supportsSingle;
			const reason = bulkTrackDecisionBlockedReason(trackCommand, tcApi) ?? trackDecisionReason(trackCommand, supported, reviewMutationsAreReadOnly(), selection, doc) ?? (trackCommand.scope === "all" ? void 0 : trackedChangeDecisionPermissionReason(trackCommand.kind, selection.activeChangeIds));
			return normalizeCommandState({
				enabled: reason == null,
				active: false,
				supported,
				reason
			}, "builtin");
		}
		if (id === "copy-format") {
			if (readDocumentMode() === "viewing") return normalizeCommandState({
				supported: true,
				enabled: false,
				active: false
			}, "builtin");
			if (!getEditor()) return normalizeCommandState({
				supported: true,
				enabled: false,
				active: false,
				reason: SUPERDOC_UI_REASONS.notReady
			}, "builtin");
			return normalizeCommandState({
				supported: true,
				enabled: true,
				active: painter.mode !== "idle"
			}, "builtin");
		}
		const descriptor = getCommandDescriptor(id);
		if (!descriptor) return normalizeCommandState({
			enabled: false,
			active: false,
			supported: false,
			reason: SUPERDOC_UI_REASONS.commandUnsupported
		}, "unsupported");
		if (descriptor.disposition !== "routed") return normalizeCommandState({
			enabled: false,
			active: false,
			supported: false,
			reason: descriptor.reason ?? SUPERDOC_UI_REASONS.commandUnsupported
		}, descriptor.disposition === "unsupported" ? "unsupported" : "builtin");
		if (descriptor.instanceRoute) return computeInstanceCommandState(descriptor);
		if (descriptor.table) return computeTableCommandState(descriptor, doc, readonly);
		if (descriptor.inline?.kind === "clear") {
			if (descriptor.mutates && readonly) return normalizeCommandState({
				enabled: false,
				active: false,
				supported: true,
				reason: SUPERDOC_UI_REASONS.documentReadonly
			}, "builtin");
			const lockReason = contentControlLockReason(lockModesById);
			if (lockReason) return normalizeCommandState({
				enabled: false,
				active: false,
				supported: true,
				reason: lockReason
			}, "builtin");
			const enabled = selectionBlockIds(selection).length > 0 || resolveInlineSelectionTarget(selection) != null;
			return normalizeCommandState({
				enabled,
				active: false,
				supported: true,
				reason: enabled ? void 0 : SUPERDOC_UI_REASONS.selectionRequired
			}, "builtin");
		}
		const route = descriptor.docRoute;
		if (!route) return normalizeCommandState({
			enabled: false,
			active: false,
			supported: false,
			reason: SUPERDOC_UI_REASONS.commandUnsupported
		}, "unsupported");
		if (resolveDocOperation(doc, route) == null) return normalizeCommandState({
			enabled: false,
			active: false,
			supported: false,
			reason: unavailableRouteReason(doc)
		}, "builtin");
		const mirroredEditCommandState = readMirroredEditCommandStateEntry(id);
		if (mirroredEditCommandState) {
			const shippedStatus = mirroredEditCommandState.shippedStatus;
			const supported = shippedStatus !== "not-shipped" && shippedStatus !== "disabled";
			const mirroredEnabled = typeof mirroredEditCommandState.enabled === "boolean" ? mirroredEditCommandState.enabled : true;
			const isHistoryCommand = id === "undo" || id === "redo";
			const historyUnread = isHistoryCommand && mirroredEditCommandState.historyResolved === false;
			const isEmptyHistoryStack = isHistoryCommand && supported && mirroredEnabled === false && mirroredEditCommandState.reason === null && !historyUnread;
			const reason = mirroredEditCommandState.reason === void 0 ? void 0 : isEmptyHistoryStack ? SUPERDOC_UI_REASONS.historyEmpty : historyUnread ? SUPERDOC_UI_REASONS.notReady : coerceSuperDocUIReason(mirroredEditCommandState.reason, SUPERDOC_UI_REASONS.commandUnsupported);
			if (descriptor.mutates && readonly) return normalizeCommandState({
				enabled: false,
				active: false,
				supported,
				reason: SUPERDOC_UI_REASONS.documentReadonly
			}, "builtin");
			return normalizeCommandState({
				enabled: supported && mirroredEnabled,
				active: false,
				supported,
				reason
			}, "builtin");
		}
		const active = commandActiveState(descriptor, doc, selection);
		const value = routedCommandValue(descriptor, doc, selection, projectedInlineValues);
		if (descriptor.list?.mode === "indent" || descriptor.list?.mode === "outdent") return computeHybridIndentCommandState(descriptor, doc, readonly, selection, active, value);
		if (descriptor.list?.mode === "toggle-seed") return computeListToggleCommandState(descriptor, doc, readonly, selection, active, value);
		if (descriptor.mutates && readonly) return normalizeCommandState({
			enabled: false,
			active,
			supported: true,
			value,
			reason: SUPERDOC_UI_REASONS.documentReadonly
		}, "builtin");
		if (descriptor.inline && !resolveInlineSelectionTarget(selection)) {
			const lockReason = contentControlLockReason(lockModesById);
			if (lockReason) return normalizeCommandState({
				enabled: false,
				active,
				supported: true,
				value,
				reason: lockReason
			}, "builtin");
			return normalizeCommandState(selectionBlockIds(selection).length > 0 && typeof getHost()?.setPendingInlineFormat === "function" ? {
				enabled: true,
				active,
				supported: true,
				value
			} : {
				enabled: false,
				active,
				supported: true,
				value,
				reason: SUPERDOC_UI_REASONS.rangeSelectionRequired
			}, "builtin");
		}
		if ((descriptor.blockParagraph || descriptor.list) && selectionBlockIds(selection).length === 0) return normalizeCommandState({
			enabled: false,
			active,
			supported: true,
			value,
			reason: SUPERDOC_UI_REASONS.selectionRequired
		}, "builtin");
		if (descriptor.link && !active && selectionTextAddresses(selection).length === 0 && !collapsedTextAddressFromSelection(selection)) return normalizeCommandState({
			enabled: false,
			active,
			supported: true,
			reason: SUPERDOC_UI_REASONS.rangeSelectionRequired
		}, "builtin");
		if (descriptor.inline) {
			const lockReason = contentControlLockReason(lockModesById);
			if (lockReason) return normalizeCommandState({
				enabled: false,
				active,
				supported: true,
				value,
				reason: lockReason
			}, "builtin");
		}
		return normalizeCommandState({
			enabled: true,
			active,
			supported: true,
			value
		}, "builtin");
	};
	function hyperlinkOverlapsSelection(link, selection) {
		const anchor = link.address?.anchor;
		const start = anchor?.start;
		const end = anchor?.end;
		const linkBlockId = typeof start?.blockId === "string" ? start.blockId : null;
		const linkEndBlockId = typeof end?.blockId === "string" ? end.blockId : null;
		if (!linkBlockId || !linkEndBlockId) return false;
		const linkStart = typeof start?.offset === "number" ? start.offset : null;
		const linkEnd = typeof end?.offset === "number" ? end.offset : null;
		if (linkStart == null || linkEnd == null) return false;
		const target = selection.target;
		const segments = target && Array.isArray(target.segments) ? target.segments : [];
		for (const segment of segments) {
			const segmentBlockId = typeof segment?.blockId === "string" ? segment.blockId : null;
			if (!segmentBlockId) continue;
			const range = segment.range;
			const rangeStart = typeof range?.start === "number" ? range.start : null;
			const rangeEnd = typeof range?.end === "number" ? range.end : null;
			if (rangeStart == null || rangeEnd == null) continue;
			if (linkBlockId !== linkEndBlockId) {
				if (segmentBlockId === linkBlockId && rangeEnd > linkStart) return true;
				if (segmentBlockId === linkEndBlockId && rangeStart < linkEnd) return true;
				continue;
			}
			if (segmentBlockId !== linkBlockId) continue;
			if (rangeStart === rangeEnd) {
				if (rangeStart >= linkStart && rangeStart <= linkEnd) return true;
				continue;
			}
			if (Math.max(rangeStart, linkStart) < Math.min(rangeEnd, linkEnd)) return true;
		}
		return false;
	}
	/**
	* Resolve the hyperlink overlapping the current selection/caret via
	* `hyperlinks.list({ within })` scoped to the selection's covered blocks.
	* Returns the first overlapping list row (`{ address, properties }`) or null.
	*/
	const resolveCurrentHyperlink = (doc, selection) => {
		const linksApi = doc?.hyperlinks;
		if (!linksApi || typeof linksApi.list !== "function") return null;
		const blockIds = selectionBlockIds(selection);
		if (!canProbeEverySelectedBlock(blockIds)) return null;
		for (const blockId of blockIds) {
			const within = {
				kind: "block",
				nodeType: "paragraph",
				nodeId: blockId
			};
			const { value: result } = readAsync(`hyperlinks:${blockId}`, contentToken(), () => linksApi.list({ within }), (raw) => raw && typeof raw === "object" ? raw : null);
			const hit = (result && Array.isArray(result.items) ? result.items : []).find((item) => hyperlinkOverlapsSelection(item, selection));
			if (hit) return hit;
		}
		return null;
	};
	/**
	* Active state for a routed command. Links resolve by public hyperlink
	* address overlap; list commands read the current block's list state and
	* match the seeded kind. Other inline marks use the selection mark set when
	* the host exposes it.
	*/
	const commandActiveState = (descriptor, doc, selection) => {
		if (descriptor.link) return resolveCurrentHyperlink(doc, selection) != null;
		if (descriptor.list?.mode === "toggle-seed" && descriptor.list.seed) return readListSeed(doc, selection) === descriptor.list.seed;
		const pending = pendingInlineActive(descriptor);
		if (pending !== null) return pending;
		const optimistic = optimisticInlineToggles.get(descriptor.id);
		const selectionSignature = selectionInlineValueSignature(selection);
		if (selectionSignature && optimistic?.selectionSignature === selectionSignature) return optimistic.active;
		const effective = effectiveMarkActiveState(descriptor, selection);
		if (effective !== null) return effective;
		return commandIsActive(descriptor, selection);
	};
	/** Live `value` for a routed command, when modeled (current paragraph style / link href). */
	const routedCommandValue = (descriptor, doc, selection, projectedInlineValues) => {
		if (descriptor.inline && isProjectedInlineSelectionValueKey(descriptor.inline.key)) {
			const pending = pendingInlineValueFor(descriptor);
			if (pending !== void 0) return pending;
			const projected = projectedInlineValues[descriptor.inline.key];
			if (projected !== void 0) return projected;
			const signature = selectionInlineValueSignature(selection);
			const cached = signature ? optimisticInlineValues.get(descriptor.inline.key) : void 0;
			if (signature && cached?.selectionSignature === signature) return cached.value;
		}
		if (descriptor.id === "linked-style") {
			const { style: active } = computeActiveParagraphStyle(selection, getStyleCatalog().cache);
			if (!active.styleId || active.mixed) return void 0;
			return {
				styleId: active.styleId,
				styleName: active.styleName
			};
		}
		if (descriptor.id === "text-align") return readToolbarParagraphAlignment(doc, selection);
		if (descriptor.id === "link") return readActiveLinkHref(doc, selection) ?? void 0;
	};
	/** Read one block's list state and cache status through the selected story's list-state seam. */
	const readListStateSnapshotForBlock = (doc, blockId, story) => {
		const listsApi = doc?.lists;
		if (!listsApi) return {
			value: null,
			status: "ready"
		};
		const isBodyStory = story.storyType === "body";
		const readState = typeof listsApi.getStateInStory === "function" ? () => listsApi.getStateInStory({
			target: listsBlockTarget(blockId),
			story
		}) : isBodyStory && typeof listsApi.getState === "function" ? () => listsApi.getState({ target: listsBlockTarget(blockId) }) : null;
		if (!readState) return {
			value: null,
			status: "ready"
		};
		const { value: result, status } = readAsync(`lists:${storyLocatorSignature(story)}:${blockId}`, contentToken(), readState, (raw) => raw && typeof raw === "object" ? raw : null);
		return {
			value: result?.success === true ? result : null,
			status
		};
	};
	/** Read one block's settled list state through the selected story's list-state seam. */
	const readListStateForBlock = (doc, blockId, story) => {
		return readListStateSnapshotForBlock(doc, blockId, story).value;
	};
	/** Read one block's list seed (`'bullet'` / `'ordered'`) in the selected story. */
	const readListSeedForBlock = (doc, blockId, story) => {
		const result = readListStateForBlock(doc, blockId, story);
		if (!result || result.isListItem !== true) return null;
		return result.seed === "bullet" || result.seed === "ordered" ? result.seed : null;
	};
	/**
	* Read whether a block is a list item. `null` means the authoritative state is
	* unavailable or has not settled yet; it must never be interpreted as a plain
	* paragraph. A list item may legitimately have no bullet/ordered seed (for
	* example, a linked Word numbering definition).
	*/
	const readListMembershipSnapshotForBlock = (doc, blockId, story) => {
		const snapshot = readListStateSnapshotForBlock(doc, blockId, story);
		const result = snapshot.value;
		return {
			value: result && typeof result.isListItem === "boolean" ? result.isListItem : null,
			status: snapshot.status
		};
	};
	/** Read a uniform list seed across the covered blocks, or null when mixed / non-list. */
	const readListSeed = (doc, selection) => {
		const blockIds = selectionBlockIds(selection);
		if (blockIds.length === 0 || !canProbeEverySelectedBlock(blockIds)) return null;
		const story = selectionStory(selection);
		const firstSeed = readListSeedForBlock(doc, blockIds[0], story);
		if (firstSeed !== "bullet" && firstSeed !== "ordered") return null;
		for (const blockId of blockIds.slice(1)) if (readListSeedForBlock(doc, blockId, story) !== firstSeed) return null;
		return firstSeed;
	};
	/** Read a paragraph node in its story through the async read coordinator. */
	const readNodeById = (doc, blockId, story) => {
		if (!doc) return {
			value: null,
			status: "ready",
			refreshing: false
		};
		const storySignature = storyLocatorSignature(story);
		const isBodyStory = storySignature === "story:body";
		if (isBodyStory && typeof doc.getNodeById !== "function") return {
			value: null,
			status: "ready",
			refreshing: false
		};
		if (!isBodyStory && typeof doc.getNode !== "function") return {
			value: null,
			status: "ready",
			refreshing: false
		};
		const key = `node:${storySignature}:${blockId}`;
		const token = contentToken();
		const read = readAsync(key, token, () => isBodyStory ? doc.getNodeById({
			nodeId: blockId,
			nodeType: "paragraph"
		}) : doc.getNode(paragraphTarget(blockId, story)), (raw) => raw && typeof raw === "object" ? raw : null);
		const entry = asyncReads.get(key);
		return {
			...read,
			refreshing: read.status === "stale" && entry?.inflightToken === token && entry.failedToken !== token
		};
	};
	const normalizeParagraphAlignment = (value) => {
		return value === "left" || value === "center" || value === "right" || value === "justify" ? value : void 0;
	};
	const isProjectionResolvedParagraphAlignment = (value) => {
		return value === "start" || value === "end" || value === "distributed" || value === "numTab" || value === "lowKashida" || value === "mediumKashida" || value === "highKashida" || value === "thaiDistribute";
	};
	/** Read effective paragraph alignments from the mounted, style-resolved layout. */
	const readEffectiveParagraphAlignments = (selection, blockIds) => {
		const host = getHost();
		const readByIds = host?.readMountedProjectionBlocksByIds;
		if (typeof readByIds !== "function") return null;
		const story = selectionStoryLocator(selection);
		const blocks = safeCall(() => story ? readByIds.call(host, [...blockIds], story) : readByIds.call(host, [...blockIds]), null);
		if (!Array.isArray(blocks)) return /* @__PURE__ */ new Map();
		const projectionBlocks = collectProjectionTextBlocks(blocks);
		const alignments = /* @__PURE__ */ new Map();
		for (const blockId of blockIds) {
			const block = projectionBlocks.find((candidate) => projectionBlockMatchesId(candidate, blockId));
			if (!block) continue;
			const attrs = block.attrs;
			const alignment = normalizeParagraphAlignment(attrs?.alignment);
			const inlineDirection = getParagraphInlineDirection(attrs);
			alignments.set(blockId, alignment ?? (inlineDirection === "rtl" ? "right" : "left"));
		}
		return alignments;
	};
	/** Read public paragraph alignment, then fall back to the resolved projection. */
	const readParagraphAlignment = (doc, blockId, story, effectiveAlignments) => {
		const { value: result, status, refreshing } = readNodeById(doc, blockId, story);
		const effective = effectiveAlignments?.get(blockId);
		if (status === "pending") return effective ? {
			status: "uniform",
			value: effective
		} : { status: "pending" };
		if (status === "stale" && !refreshing) return { status: "pending" };
		if (status === "stale" && effective) return {
			status: "uniform",
			value: effective
		};
		if (status === "stale" && effectiveAlignments && !effective) return { status: "unavailable" };
		if (!result) return { status: "unavailable" };
		const node = result.node;
		if (!node) return { status: "unavailable" };
		const kind = node.kind;
		if (kind !== "paragraph" && kind !== "heading") return { status: "unavailable" };
		const payload = node[kind];
		if (!payload || typeof payload !== "object") return { status: "unavailable" };
		const directAlignment = payload.props?.alignment;
		if (directAlignment == null) return effective ? {
			status: "uniform",
			value: effective
		} : { status: "unavailable" };
		const alignment = normalizeParagraphAlignment(directAlignment);
		if (alignment) return {
			status: "uniform",
			value: alignment
		};
		if (isProjectionResolvedParagraphAlignment(directAlignment) && effective) return {
			status: "uniform",
			value: effective
		};
		return { status: "unavailable" };
	};
	/** Resolve a uniform effective alignment across every selected paragraph. */
	const readUniformParagraphAlignment = (doc, selection) => {
		const blockIds = selectionBlockIds(selection);
		if (blockIds.length === 0 || !canProbeEverySelectedBlock(blockIds)) return { status: "unavailable" };
		const story = selectionStory(selection);
		const effectiveAlignments = readEffectiveParagraphAlignments(selection, blockIds);
		const first = readParagraphAlignment(doc, blockIds[0], story, effectiveAlignments);
		if (first.status !== "uniform") return first;
		for (const blockId of blockIds.slice(1)) {
			const next = readParagraphAlignment(doc, blockId, story, effectiveAlignments);
			if (next.status !== "uniform") return next;
			if (next.value !== first.value) return { status: "mixed" };
		}
		return first;
	};
	const paragraphAlignmentSelectionSignature = (selection) => {
		const blockIds = selectionBlockIds(selection);
		if (blockIds.length === 0) return null;
		return `${storyLocatorSignature(selectionStory(selection))}:${blockIds.join(",")}`;
	};
	/** Keep a toolbar pick stable until its painted paragraph state is readable. */
	const readToolbarParagraphAlignment = (doc, selection) => {
		const resolution = readUniformParagraphAlignment(doc, selection);
		const resolved = resolution.status === "uniform" ? resolution.value : void 0;
		const optimistic = optimisticParagraphAlignment;
		if (!optimistic) return resolved;
		const selectionSignature = paragraphAlignmentSelectionSignature(selection);
		if (selectionSignature && selectionSignature !== optimistic.selectionSignature) {
			optimisticParagraphAlignment = null;
			return resolved;
		}
		if (!selectionSignature) return optimistic.value;
		if (!optimistic.settled) return optimistic.value;
		if (resolution.status !== "pending") {
			optimisticParagraphAlignment = null;
			return resolved;
		}
		return optimistic.value;
	};
	const armOptimisticParagraphAlignment = (selection, payload) => {
		const alignment = normalizeParagraphAlignment(payload);
		const selectionSignature = paragraphAlignmentSelectionSignature(selection);
		const blockIds = selectionBlockIds(selection);
		if (!alignment || !selectionSignature || blockIds.length === 0) return null;
		const generation = ++optimisticParagraphAlignmentGeneration;
		optimisticParagraphAlignment = {
			selectionSignature,
			value: alignment,
			generation,
			settled: false,
			canReconcile: canProbeEverySelectedBlock(blockIds)
		};
		recompute();
		return generation;
	};
	const settleOptimisticParagraphAlignment = (generation, result) => {
		if (generation == null) return;
		const optimistic = optimisticParagraphAlignment;
		if (!optimistic || optimistic.generation !== generation) return;
		if (!commandResultSucceeded(result)) {
			optimisticParagraphAlignment = null;
			return;
		}
		if (!optimistic.canReconcile) {
			optimisticParagraphAlignment = null;
			return;
		}
		optimistic.settled = true;
	};
	/**
	* Await a block's list membership authoritatively. Membership comes from
	* `isListItem`, not `seed`: linked/custom Word numbering can be a valid list
	* item while returning `seed: null`. Command execution must also fail closed
	* when membership cannot be resolved instead of assuming a plain paragraph.
	*
	* The read resolves directly instead of peeking at the async cache. Only the
	* first selected block is warmed by the command-state snapshot, so command
	* execution cannot depend on that cache being warm (SD-3659).
	*/
	const resolveListMembershipForBlockAsync = async (doc, blockId, story) => {
		const listsApi = doc?.lists;
		if (!listsApi) return null;
		try {
			const isBodyStory = story.storyType === "body";
			const raw = typeof listsApi.getStateInStory === "function" ? await listsApi.getStateInStory({
				target: listsBlockTarget(blockId),
				story
			}) : isBodyStory && typeof listsApi.getState === "function" ? await listsApi.getState({ target: listsBlockTarget(blockId) }) : null;
			const result = raw && typeof raw === "object" ? raw : null;
			if (!result || result.success !== true || typeof result.isListItem !== "boolean") return null;
			return result.isListItem;
		} catch {
			return null;
		}
	};
	/** Read a list seed directly for mutation planning instead of trusting the reactive cache. */
	const resolveListSeedForBlock = (doc, blockId, story) => {
		const unavailable = {
			resolved: false,
			seed: null
		};
		const listsApi = doc?.lists;
		if (!listsApi) return unavailable;
		const isBodyStory = story.storyType === "body";
		const readState = typeof listsApi.getStateInStory === "function" ? () => listsApi.getStateInStory({
			target: listsBlockTarget(blockId),
			story
		}) : isBodyStory && typeof listsApi.getState === "function" ? () => listsApi.getState({ target: listsBlockTarget(blockId) }) : null;
		if (!readState) return unavailable;
		const normalize = (raw) => {
			const result = raw && typeof raw === "object" ? raw : null;
			if (!result || result.success !== true || typeof result.isListItem !== "boolean") return unavailable;
			return {
				resolved: true,
				seed: result.isListItem === true && (result.seed === "bullet" || result.seed === "ordered") ? result.seed : null
			};
		};
		try {
			const raw = readState();
			return isPromiseLike(raw) ? Promise.resolve(raw).then(normalize, () => unavailable) : normalize(raw);
		} catch {
			return unavailable;
		}
	};
	/** Await a block's current paragraph indentation authoritatively. */
	const resolveParagraphIndentationForBlockAsync = async (doc, blockId, story) => {
		if (!doc) return null;
		try {
			const isBodyStory = !story || story.storyType === "body";
			const raw = story && typeof doc.getNode === "function" ? await doc.getNode(paragraphTarget(blockId, story)) : isBodyStory && typeof doc.getNodeById === "function" ? await doc.getNodeById({
				nodeId: blockId,
				nodeType: "paragraph"
			}) : null;
			return readParagraphIndentationFromResult(raw && typeof raw === "object" ? raw : null);
		} catch {
			return null;
		}
	};
	const computeHybridIndentCommandState = (descriptor, doc, readonly, selection, active, value) => {
		if (descriptor.mutates && readonly) return normalizeCommandState({
			enabled: false,
			active,
			supported: true,
			value,
			reason: SUPERDOC_UI_REASONS.documentReadonly
		}, "builtin");
		const blockIds = selectionBlockIds(selection);
		if (blockIds.length === 0) return normalizeCommandState({
			enabled: false,
			active,
			supported: true,
			value,
			reason: SUPERDOC_UI_REASONS.selectionRequired
		}, "builtin");
		const listOp = descriptor.docRoute ? resolveDocOperation(doc, descriptor.docRoute) : null;
		const paragraphSetIndent = resolveDocOperation(doc, "format.paragraph.setIndentation");
		const paragraphClearIndent = resolveDocOperation(doc, "format.paragraph.clearIndentation");
		const mode = descriptor.list?.mode;
		const paragraphOpAvailable = mode === "indent" ? paragraphSetIndent != null : paragraphSetIndent != null || paragraphClearIndent != null;
		const story = selectionStory(selection);
		let listMembership = null;
		if (story.storyType !== "body") {
			listMembership = [];
			for (const blockId of blockIds) {
				const { value: isListItem, status } = readListMembershipSnapshotForBlock(doc, blockId, story);
				if (isListItem === null) {
					if (status !== "ready" && (listOp != null || paragraphOpAvailable)) return normalizeCommandState({
						enabled: true,
						active,
						supported: true,
						value
					}, "builtin");
					return normalizeCommandState({
						enabled: false,
						active,
						supported: false,
						value,
						reason: unavailableRouteReason(doc)
					}, "builtin");
				}
				listMembership.push(isListItem);
			}
		}
		if (listMembership?.some((isListItem) => isListItem === true)) {
			const rangeRoute = mode === "indent" ? "lists.indentRange" : "lists.outdentRange";
			const canUseRange = readDocumentMode() !== "suggesting" && listMembership.every((isListItem) => isListItem === true) && resolveDocOperation(doc, rangeRoute) != null;
			const canUseStoryOutdent = mode === "outdent" && resolveDocOperation(doc, "lists.outdentInStory") != null;
			if (!canUseRange && !canUseStoryOutdent) return normalizeCommandState({
				enabled: false,
				active,
				supported: false,
				value,
				reason: unavailableRouteReason(doc)
			}, "builtin");
		}
		for (const [index, blockId] of blockIds.entries()) {
			const membership = listMembership ? {
				value: listMembership[index] ?? null,
				status: "ready"
			} : readListMembershipSnapshotForBlock(doc, blockId, story);
			const isListItem = membership.value;
			if (isListItem === true) {
				if (listOp != null) return normalizeCommandState({
					enabled: true,
					active,
					supported: true,
					value
				}, "builtin");
				continue;
			}
			if (isListItem === false && paragraphOpAvailable) {
				if (story.storyType !== "body" && typeof doc?.getNode !== "function") continue;
				return normalizeCommandState({
					enabled: true,
					active,
					supported: true,
					value
				}, "builtin");
			}
			if (isListItem === null) {
				if (membership.status !== "ready" && (listOp != null || paragraphOpAvailable)) return normalizeCommandState({
					enabled: true,
					active,
					supported: true,
					value
				}, "builtin");
				return normalizeCommandState({
					enabled: false,
					active,
					supported: false,
					value,
					reason: unavailableRouteReason(doc)
				}, "builtin");
			}
		}
		return normalizeCommandState({
			enabled: false,
			active,
			supported: false,
			value,
			reason: unavailableRouteReason(doc)
		}, "builtin");
	};
	const computeListToggleCommandState = (descriptor, doc, readonly, selection, active, value) => {
		if (descriptor.mutates && readonly) return normalizeCommandState({
			enabled: false,
			active,
			supported: true,
			value,
			reason: SUPERDOC_UI_REASONS.documentReadonly
		}, "builtin");
		const blockIds = selectionBlockIds(selection);
		if (blockIds.length === 0) return normalizeCommandState({
			enabled: false,
			active,
			supported: true,
			value,
			reason: SUPERDOC_UI_REASONS.selectionRequired
		}, "builtin");
		const story = selectionStory(selection);
		const listsApi = doc?.lists;
		if (!(typeof listsApi?.getStateInStory === "function" || story.storyType === "body" && typeof listsApi?.getState === "function")) return normalizeCommandState({
			enabled: false,
			active,
			supported: false,
			value,
			reason: SUPERDOC_UI_REASONS.operationUnavailable
		}, "builtin");
		if (!canProbeEverySelectedBlock(blockIds)) return normalizeCommandState(story.storyType === "body" && resolveDocOperation(doc, "lists.remove") != null ? {
			enabled: true,
			active,
			supported: true,
			value
		} : {
			enabled: false,
			active,
			supported: false,
			value,
			reason: SUPERDOC_UI_REASONS.operationUnavailable
		}, "builtin");
		const snapshots = blockIds.map((blockId) => readListStateSnapshotForBlock(doc, blockId, story));
		if (snapshots.some(({ status }) => status !== "ready")) return normalizeCommandState({
			enabled: true,
			active,
			supported: true,
			value
		}, "builtin");
		if (snapshots.some(({ value: state }) => state === null)) return normalizeCommandState({
			enabled: false,
			active,
			supported: false,
			value,
			reason: SUPERDOC_UI_REASONS.operationUnavailable
		}, "builtin");
		const seed = descriptor.list?.seed;
		const shouldRemove = snapshots.every(({ value: state }) => state?.isListItem === true && state.seed === seed);
		if (story.storyType === "body") return normalizeCommandState(!shouldRemove || resolveDocOperation(doc, "lists.remove") != null ? {
			enabled: true,
			active,
			supported: true,
			value
		} : {
			enabled: false,
			active,
			supported: false,
			value,
			reason: SUPERDOC_UI_REASONS.operationUnavailable
		}, "builtin");
		const removeInStory = resolveDocOperation(doc, "lists.removeInStory");
		if (shouldRemove && removeInStory) return normalizeCommandState({
			enabled: true,
			active,
			supported: true,
			value
		}, "builtin");
		return normalizeCommandState({
			enabled: false,
			active,
			supported: false,
			value,
			reason: SUPERDOC_UI_REASONS.operationUnavailable
		}, "builtin");
	};
	/** Read the active hyperlink's href overlapping the selection, when present. */
	const readActiveLinkHref = (doc, selection) => {
		const href = (resolveCurrentHyperlink(doc, selection)?.properties)?.href;
		return typeof href === "string" ? href : null;
	};
	/** State for a command routed through a public SuperDoc-instance method. */
	const computeInstanceCommandState = (descriptor) => {
		if (!getEditor()) return normalizeCommandState({
			enabled: false,
			active: false,
			supported: false,
			reason: SUPERDOC_UI_REASONS.notReady
		}, "builtin");
		const method = descriptor.instanceRoute;
		if (!(typeof superdoc?.[method] === "function")) return normalizeCommandState({
			enabled: false,
			active: false,
			supported: false,
			reason: SUPERDOC_UI_REASONS.operationUnavailable
		}, "builtin");
		return normalizeCommandState({
			enabled: true,
			active: chromeActiveState(descriptor),
			supported: true,
			value: descriptorValue(descriptor)
		}, "builtin");
	};
	/** Live active state for a host-owned chrome control (`ruler`, `formatting-marks`). */
	const chromeActiveState = (descriptor) => {
		const config = superdoc?.config ?? void 0;
		if (descriptor.valueFrom === "ruler") return Boolean(config?.rulers);
		if (descriptor.valueFrom === "formattingMarks") return Boolean((config?.layoutEngineOptions)?.showFormattingMarks);
		return false;
	};
	/** State for a table cell-context command routed through `tables.*`. */
	const computeTableCommandState = (descriptor, doc, readonly) => {
		if (readonly) return normalizeCommandState({
			enabled: false,
			active: false,
			supported: true,
			reason: SUPERDOC_UI_REASONS.documentReadonly
		}, "builtin");
		const context = resolveTableContext();
		if (!(context != null && (!descriptor.table.requiresCell || context.cellNodeId != null))) return normalizeCommandState({
			enabled: false,
			active: false,
			supported: true,
			reason: SUPERDOC_UI_REASONS.tableContextUnavailable
		}, "builtin");
		if ((descriptor.docRoute ? resolveDocOperation(doc, descriptor.docRoute) : null) == null) return normalizeCommandState({
			enabled: false,
			active: false,
			supported: false,
			reason: unavailableRouteReason(doc)
		}, "builtin");
		return normalizeCommandState({
			enabled: true,
			active: false,
			supported: true
		}, "builtin");
	};
	/** Resolve a descriptor's live `value` from public controller state, when modeled. */
	const descriptorValue = (descriptor) => {
		if (descriptor.valueFrom === "zoom") return computeZoom().value;
		if (descriptor.valueFrom === "documentMode") return readDocumentMode();
		if (descriptor.valueFrom === "measurementUnit") return readMeasurementUnit();
		if (descriptor.valueFrom === "ruler" || descriptor.valueFrom === "formattingMarks") return chromeActiveState(descriptor);
	};
	/** Validate normalized payloads before invoking public SuperDoc-instance methods. */
	const instanceCommandPayloadIsValid = (descriptor, payload) => {
		if (descriptor.id === "zoom") return typeof payload === "number" && Number.isFinite(payload) && payload > 0;
		if (descriptor.id === "document-mode") return payload === "editing" || payload === "suggesting" || payload === "viewing";
		if (descriptor.id === "measurement-unit") return payload === "in" || payload === "cm";
		return true;
	};
	const allCommandIds = () => {
		return [.../* @__PURE__ */ new Set([...ALL_BUILT_IN_COMMAND_IDS, ...customCommands.keys()])];
	};
	const DEFAULT_PARAGRAPH_STYLE_ID = "Normal";
	const EMPTY_STYLES_SLICE = {
		ready: false,
		status: "ready",
		catalogRevision: null,
		quickGallery: [],
		activeParagraphStyleId: null,
		activeParagraphStyleName: null,
		mixedSelection: false,
		sourceStatus: null,
		diagnostics: []
	};
	/**
	* Read the public Document API style catalogue (`doc.styles.getCatalog`)
	* through the async read coordinator. A promise-returning browser read
	* settles into the cache (keyed by content revision) instead of collapsing
	* the catalogue to `null`. `value` is `null` when the styles surface is
	* unreachable (worker-backed `doc` is null or the operation is missing); the
	* accompanying {@link SliceStatus} reports pending/stale/ready.
	*/
	const readStyleCatalogLive = (input) => {
		const stylesApi = getDoc()?.styles;
		if (!stylesApi || typeof stylesApi.getCatalog !== "function") return {
			value: null,
			status: "ready"
		};
		return readAsync(`styles:catalog:${JSON.stringify(input ?? {})}`, contentToken(), () => stylesApi.getCatalog(input), (raw) => raw && typeof raw === "object" ? raw : null);
	};
	/** Resolve the catalogue (coordinator-cached by content revision) plus its readiness. */
	const getStyleCatalog = () => {
		const full = readStyleCatalogLive({ includePreview: true });
		if (!full.value) return {
			cache: null,
			status: full.status
		};
		const quickResult = readStyleCatalogLive({
			view: "quickGallery",
			includePreview: true
		});
		const quickGallery = quickResult.value ? quickResult.value.items : full.value.styles.filter((item) => item.visibility.quickGallery);
		const byId = /* @__PURE__ */ new Map();
		for (const item of full.value.styles) byId.set(item.id, item);
		return {
			cache: {
				full: full.value,
				quickGallery,
				byId
			},
			status: combineStatus(full.status, quickResult.status)
		};
	};
	/**
	* Read one block's paragraph `styleRef` through the public `getNodeById`
	* read. `ok` distinguishes a successful read (styleRef may be null when the
	* paragraph has no explicit style) from an unavailable read (no operation, a
	* promise in worker mode, or a missing node) so active-style resolution can
	* fail closed precisely.
	*/
	const readBlockStyleRef = (doc, blockId, story) => {
		const { value: result, status } = readNodeById(doc, blockId, story);
		if (!result) return {
			ok: false,
			styleRef: null,
			status
		};
		const node = result.node;
		if (!node || typeof node !== "object") return {
			ok: false,
			styleRef: null,
			status
		};
		const kind = node.kind;
		const payload = typeof kind === "string" ? node[kind] : void 0;
		const raw = payload && typeof payload === "object" ? payload.styleRef : void 0;
		return {
			ok: true,
			styleRef: typeof raw === "string" && raw.length > 0 ? raw : null,
			status
		};
	};
	/**
	* Resolve the active paragraph style from the current selection. Handles the
	* uniform, default (no explicit style → document default paragraph style),
	* and mixed cases, and fails closed with diagnostics when block reads are
	* unavailable.
	*/
	const computeActiveParagraphStyle = (selection, catalog) => {
		const diagnostics = [];
		const doc = getDoc();
		if (!doc) {
			diagnostics.push({
				severity: "warning",
				code: "active-style-unavailable",
				message: "Active paragraph style is unavailable: the Document API is not reachable."
			});
			return {
				style: {
					styleId: null,
					styleName: null,
					mixed: false,
					diagnostics
				},
				status: "ready"
			};
		}
		const blockIds = selectionBlockIds(selection);
		if (blockIds.length === 0) {
			diagnostics.push({
				severity: "info",
				code: "active-style-no-selection",
				message: "No paragraph block is resolvable from the current selection; active paragraph style is unavailable."
			});
			return {
				style: {
					styleId: null,
					styleName: null,
					mixed: false,
					diagnostics
				},
				status: "ready"
			};
		}
		if (!canProbeEverySelectedBlock(blockIds)) {
			diagnostics.push({
				severity: "info",
				code: "active-style-selection-too-large",
				message: "Active paragraph style is unavailable for a large multi-paragraph selection."
			});
			return {
				style: {
					styleId: null,
					styleName: null,
					mixed: false,
					diagnostics
				},
				status: "ready"
			};
		}
		const defaultId = catalog?.full.defaults.paragraphStyleId ?? (catalog ? DEFAULT_PARAGRAPH_STYLE_ID : null);
		const resolvedIds = /* @__PURE__ */ new Set();
		let resolved = 0;
		let blockReadFailures = 0;
		let defaultReadFailures = 0;
		let readStatus = "ready";
		const story = selectionStory(selection);
		for (const blockId of blockIds) {
			const read = readBlockStyleRef(doc, blockId, story);
			readStatus = combineStatus(readStatus, read.status);
			if (!read.ok) {
				blockReadFailures += 1;
				continue;
			}
			if (!read.styleRef && !defaultId) {
				defaultReadFailures += 1;
				continue;
			}
			const styleId = read.styleRef ?? defaultId;
			if (!styleId) {
				defaultReadFailures += 1;
				continue;
			}
			resolved += 1;
			resolvedIds.add(styleId);
		}
		if (resolved === 0) {
			const onlyDefaultUnavailable = defaultReadFailures > 0 && blockReadFailures === 0;
			diagnostics.push({
				severity: "warning",
				code: onlyDefaultUnavailable ? "active-style-default-unavailable" : "active-style-read-failed",
				message: onlyDefaultUnavailable ? "Selected paragraphs have no explicit style and the style catalogue is unavailable, so the document default cannot be resolved." : "Could not read the paragraph style of any selected block; active paragraph style is unavailable."
			});
			return {
				style: {
					styleId: null,
					styleName: null,
					mixed: false,
					diagnostics
				},
				status: readStatus
			};
		}
		const unresolved = blockReadFailures + defaultReadFailures;
		if (unresolved > 0) {
			diagnostics.push({
				severity: "warning",
				code: "active-style-partial",
				message: `Active paragraph style resolved from ${resolved} of ${resolved + unresolved} selected blocks; ${unresolved} could not be read, so the active style is unavailable.`
			});
			return {
				style: {
					styleId: null,
					styleName: null,
					mixed: false,
					diagnostics
				},
				status: readStatus
			};
		}
		if (resolvedIds.size > 1) return {
			style: {
				styleId: null,
				styleName: null,
				mixed: true,
				diagnostics
			},
			status: readStatus
		};
		const styleId = [...resolvedIds][0];
		return {
			style: {
				styleId,
				styleName: catalog?.byId.get(styleId)?.name ?? null,
				mixed: false,
				diagnostics
			},
			status: readStatus
		};
	};
	const computeStyles = (selection) => {
		if (!getEditor()) return EMPTY_STYLES_SLICE;
		const { cache: catalog, status: catalogStatus } = getStyleCatalog();
		const { style: active, status: activeStatus } = computeActiveParagraphStyle(selection, catalog);
		let diagnostics;
		if (catalog) diagnostics = active.diagnostics.length === 0 ? catalog.full.diagnostics : [...catalog.full.diagnostics, ...active.diagnostics];
		else diagnostics = [{
			severity: "warning",
			code: "catalog-unavailable",
			message: "The style catalogue is unavailable: the Document API styles surface is not reachable (e.g. viewing mode or a worker-backed editor)."
		}, ...active.diagnostics];
		return {
			ready: true,
			status: combineStatus(catalogStatus, activeStatus, selection.status),
			catalogRevision: catalog?.full.revision ?? null,
			quickGallery: catalog?.quickGallery ?? [],
			activeParagraphStyleId: active.styleId,
			activeParagraphStyleName: active.styleName,
			mixedSelection: active.mixed,
			sourceStatus: catalog?.full.sourceStatus ?? null,
			diagnostics
		};
	};
	const computeState = (reason = "direct") => {
		const { sink } = readUiBenchRuntime();
		const startedAtMs = sink ? uiBenchNowMs() : 0;
		const phaseMs = {};
		const measure = (phase, run) => {
			if (!sink) return run();
			const phaseStartedAtMs = uiBenchNowMs();
			try {
				return run();
			} finally {
				phaseMs[phase] = uiBenchNowMs() - phaseStartedAtMs;
			}
		};
		const documentMode = measure("documentMode", readDocumentMode);
		const selection = measure("selection", computeSelection);
		if (selection.status === "ready") pruneSelectionScopedAsyncReads(selection);
		reconcilePendingInlineFormat(selection);
		const selectionSignature = selectionInlineValueSignature(selection);
		for (const [commandId, optimistic] of optimisticInlineToggles) if (!selectionSignature || optimistic.selectionSignature !== selectionSignature) optimisticInlineToggles.delete(commandId);
		else if (optimistic.settled && selection.status === "ready") optimisticInlineToggles.delete(commandId);
		const nextState = {
			ready: getEditor() != null,
			documentMode,
			document: measure("document", computeDocument),
			selection,
			toolbar: {
				context: documentMode,
				commands: measure("toolbarCommands", () => computeCommandStates(selection)),
				copyFormatActive: painter.mode !== "idle"
			},
			comments: measure("comments", () => computeComments(selection)),
			trackChanges: measure("trackChanges", () => computeTrackChanges(selection)),
			contentControls: measure("contentControls", () => computeContentControls(selection)),
			zoom: measure("zoom", computeZoom),
			fonts: measure("fonts", computeFonts),
			styles: measure("styles", () => computeStyles(selection))
		};
		if (sink) {
			const completedAtMs = uiBenchNowMs();
			emitUiBenchTiming({
				stage: "superdoc-ui-compute-state",
				atMs: completedAtMs,
				reason,
				startedAtMs,
				completedAtMs,
				durationMs: completedAtMs - startedAtMs,
				phaseMs,
				asyncReadSettlements: pendingAsyncReadSettlements.splice(0)
			});
		}
		return nextState;
	};
	const syncOptimisticInlineSelection = (selection) => {
		const nextSignature = selectionInlineValueSignature(selection);
		if (nextSignature && lastOptimisticInlineSelectionSignature && nextSignature !== lastOptimisticInlineSelectionSignature) {
			optimisticInlineValues.clear();
			optimisticInlineToggles.clear();
		}
		if (nextSignature) lastOptimisticInlineSelectionSignature = nextSignature;
	};
	let currentHostSelectionSource = null;
	let detachHostSelection = null;
	let currentEditCommandsSource = null;
	let detachEditCommands = null;
	let currentV2ReviewWindowSource = null;
	let detachV2ReviewWindow = null;
	let editCommandsRecomputeQueued = false;
	const requestEditCommandsRecompute = () => {
		if (disposed || editCommandsRecomputeQueued) return;
		editCommandsRecomputeQueued = true;
		const run = () => {
			if (!editCommandsRecomputeQueued) return;
			editCommandsRecomputeQueued = false;
			if (disposed) return;
			recompute();
		};
		if (typeof queueMicrotask === "function") queueMicrotask(run);
		else Promise.resolve().then(run);
	};
	const syncEditCommandsSubscription = () => {
		const next = getEditCommands();
		if (next === currentEditCommandsSource) return;
		if (detachEditCommands) {
			detachEditCommands();
			detachEditCommands = null;
		}
		currentEditCommandsSource = next;
		if (!next || typeof next.subscribe !== "function") return;
		try {
			const unsubscribe = next.subscribe(() => requestEditCommandsRecompute());
			if (typeof unsubscribe === "function") detachEditCommands = unsubscribe;
		} catch {
			currentEditCommandsSource = null;
		}
	};
	const syncV2ReviewWindowSubscription = () => {
		const next = getV2ReviewWindowSource();
		if (next === currentV2ReviewWindowSource) return;
		if (detachV2ReviewWindow) {
			detachV2ReviewWindow();
			detachV2ReviewWindow = null;
		}
		currentV2ReviewWindowSource = next;
		if (!next || typeof next.subscribe !== "function") return;
		try {
			const unsubscribe = next.subscribe(() => recompute());
			if (typeof unsubscribe === "function") detachV2ReviewWindow = unsubscribe;
		} catch {
			currentV2ReviewWindowSource = null;
		}
	};
	let currentHostReviewSource = null;
	let detachHostReview = null;
	let currentHostEventsSource = null;
	let detachHostEvents = null;
	let currentDocumentSelectionSource = null;
	let detachDocumentSelection = null;
	const readHostSelectionSource = () => {
		const host = getEditor()?.host;
		const selection = safeCall(host?.getHandles ? () => host.getHandles() : void 0, null)?.editing?.selection;
		return selection && typeof selection.subscribe === "function" ? selection : null;
	};
	const syncHostSelectionSubscription = () => {
		const next = readHostSelectionSource();
		if (next === currentHostSelectionSource) return;
		if (detachHostSelection) {
			detachHostSelection();
			detachHostSelection = null;
		}
		currentHostSelectionSource = next;
		if (!next) return;
		try {
			const unsubscribe = next.subscribe((snapshot) => {
				selectionEpoch += 1;
				seedCaretSelectionFromHost(snapshot);
				recompute("host-selection");
			});
			if (typeof unsubscribe === "function") detachHostSelection = unsubscribe;
		} catch {
			currentHostSelectionSource = null;
		}
	};
	const readHostReviewSource = () => {
		const host = getEditor()?.host;
		const review = safeCall(host?.getHandles ? () => host.getHandles() : void 0, null)?.review;
		return review && typeof review.subscribe === "function" ? review : null;
	};
	const readHostActiveReviewTarget = (review) => {
		if (!review) return null;
		if (typeof review.getActiveReviewTarget === "function") return safeCall(() => review.getActiveReviewTarget(), null);
		if (typeof review.getSnapshot === "function") return safeCall(() => review.getSnapshot(), null)?.activeReviewTarget ?? null;
		return null;
	};
	let trackedChangeNavigationInFlight = 0;
	const syncTrackedChangeFocusFromHostReviewTarget = (rawTarget, rawSnapshot) => {
		const rejection = (rawSnapshot && typeof rawSnapshot === "object" ? rawSnapshot : null)?.lastInteractionRejection;
		if (rawTarget == null && rejection && typeof rejection === "object" && rejection.code === "review-target-invalidated" && rejection.detail === "not-painted" && explicitActiveChange) return false;
		const target = rawTarget && typeof rawTarget === "object" ? rawTarget : null;
		let next = null;
		if (target?.entityType === "trackedChange" && typeof target.entityId === "string" && target.entityId.length > 0) {
			const targetStory = target.story && typeof target.story === "object" ? target.story : void 0;
			const story = targetStory && storyLocatorSignature(targetStory) !== storyLocatorSignature(null) ? targetStory : void 0;
			const rawPaintedEntityId = typeof target.paintedEntityId === "string" && target.paintedEntityId.length > 0 ? target.paintedEntityId : null;
			const lookupEntityId = rawPaintedEntityId ?? target.entityId;
			const publicId = (() => {
				if (story) {
					const allStoryItems = readAllStoryTrackChanges();
					const storyContext = allStoryItems ? buildStoryScopedTrackedChangeIdContext(allStoryItems, story) : null;
					return storyContext?.toPublicId(lookupEntityId) ?? storyContext?.toPublicId(target.entityId) ?? target.entityId;
				}
				const bodyContext = buildTrackedChangeIdContext(Array.isArray(state?.trackChanges.items) ? state.trackChanges.items : []);
				return bodyContext.toPublicId(lookupEntityId) ?? bodyContext.toPublicId(target.entityId) ?? target.entityId;
			})();
			const paintedEntityId = rawPaintedEntityId ?? (lookupEntityId !== publicId ? lookupEntityId : null);
			next = {
				id: publicId,
				...story ? { story } : {},
				...paintedEntityId && paintedEntityId !== publicId ? { paintedEntityId } : {}
			};
		}
		if (rawTarget == null && next == null && explicitActiveChange != null && hasPendingTrackChangeRevealFocus(explicitActiveChange)) return false;
		if (explicitActiveChangesEqual(explicitActiveChange, next)) return false;
		setExplicitActiveChange(next);
		return true;
	};
	const syncHostReviewSubscription = () => {
		const next = readHostReviewSource();
		if (next === currentHostReviewSource) return;
		if (detachHostReview) {
			detachHostReview();
			detachHostReview = null;
		}
		currentHostReviewSource = next;
		if (!next) {
			syncTrackedChangeFocusFromHostReviewTarget(null);
			return;
		}
		let attaching = true;
		try {
			const unsubscribe = next.subscribe((snapshot) => {
				const snapshotRecord = snapshot && typeof snapshot === "object" ? snapshot : null;
				const target = snapshotRecord && Object.prototype.hasOwnProperty.call(snapshotRecord, "activeReviewTarget") ? snapshotRecord.activeReviewTarget : readHostActiveReviewTarget(next);
				if (!syncTrackedChangeFocusFromHostReviewTarget(target, snapshot) || attaching) return;
				recompute();
			});
			if (typeof unsubscribe === "function") detachHostReview = unsubscribe;
			syncTrackedChangeFocusFromHostReviewTarget(readHostActiveReviewTarget(next));
		} catch {
			currentHostReviewSource = null;
		} finally {
			attaching = false;
		}
	};
	const readDocumentSelectionFallbackSource = () => {
		if (currentHostSelectionSource || readDocumentMode() !== "viewing") return null;
		const container = (getEditor()?.mount)?.container;
		const doc = (container && typeof container === "object" && "ownerDocument" in container ? container.ownerDocument ?? null : null) ?? globalThis.document ?? null;
		return doc && typeof doc.addEventListener === "function" ? doc : null;
	};
	const syncDocumentSelectionFallbackSubscription = () => {
		const next = readDocumentSelectionFallbackSource();
		if (next === currentDocumentSelectionSource) return;
		if (detachDocumentSelection) {
			detachDocumentSelection();
			detachDocumentSelection = null;
		}
		currentDocumentSelectionSource = next;
		if (!next) return;
		const handler = () => {
			selectionEpoch += 1;
			recompute();
		};
		next.addEventListener("selectionchange", handler);
		next.addEventListener("pointerup", handler, true);
		next.addEventListener("mouseup", handler, true);
		detachDocumentSelection = () => {
			next.removeEventListener("selectionchange", handler);
			next.removeEventListener("pointerup", handler, true);
			next.removeEventListener("mouseup", handler, true);
		};
	};
	syncCoordinatorEditor();
	syncTrackedChangeFocusFromHostReviewTarget(readHostActiveReviewTarget(readHostReviewSource()));
	state = computeState("initial");
	lastOptimisticInlineSelectionSignature = selectionInlineValueSignature(state.selection);
	const syncHostEventsSubscription = () => {
		const events = (getEditor()?.host)?.events;
		const next = events && typeof events.subscribe === "function" ? events : null;
		if (next === currentHostEventsSource) return;
		if (detachHostEvents) {
			detachHostEvents();
			detachHostEvents = null;
		}
		currentHostEventsSource = next;
		if (!next) return;
		try {
			const off = next.subscribe((event) => {
				const type = event?.type;
				if (type === "review-mutation:started") {
					beginUiReviewMutation(event.reviewMutation?.token);
					return;
				}
				if (type === "review-mutation:aborted") {
					settleUiReviewMutation(event.reviewMutation?.token);
					scheduleAsyncRefresh();
					return;
				}
				if (type === "mutation:rejected" && event.reviewMutation) {
					settleUiReviewMutation(event.reviewMutation.token);
					scheduleAsyncRefresh();
				}
				if (type === "mutation:committed" && event.reviewMutation) settleUiReviewMutation(event.reviewMutation.token);
				if (type === "source:complete" || type === "source:signals-complete") {
					sourceCompletionObservedToken = contentToken();
					refreshIncompleteTrackChangesDirectories();
					return;
				}
				if (type === "mutation:committed" || type === "collaboration:remote-changed") lastEditableMutationAtMs = Date.now();
				if (type === "mutation:committed" || type === "save:completed" || type === "collaboration:remote-changed") {
					const impact = type === "mutation:committed" ? getV2TrackedChangeMutationImpact(event) : null;
					if (impact?.allResolved) {
						replaceTrackedChangeItemsInCache([]);
						publishAllTrackedChangesResolved(event.receipt);
						return;
					}
					if (impact?.removedIds.size) markPostDecisionTrackChanges(new Set(impact.removedIds), event.receipt);
					const isTypingBurst = type === "mutation:committed" && isEditableTextMutationEvent(event) || type === "collaboration:remote-changed" && Array.isArray(event.changedStoryIds) && event.changedStoryIds.length > 0;
					if (isTypingBurst) lastTypingMutationAtMs = Date.now();
					if (type === "mutation:committed" && isTypingBurst) {
						scheduleTypingDocumentContentInvalidation();
						return;
					}
					if (impact?.removedIds.size && impact.upsertIds.size === 0) return;
					if (type === "collaboration:remote-changed" || type === "mutation:committed" && !isTypingBurst) schedulePostPaintContentRefresh();
					const remoteCommentsPartChanged = type === "collaboration:remote-changed" && Array.isArray(event.changedPartUris) && event.changedPartUris.some((partUri) => typeof partUri === "string" && COMMENTS_CATALOG_PART_URIS.has(partUri));
					const loadedCommentAnchorsMayHaveChanged = type === "collaboration:remote-changed" && Array.isArray(event.changedStoryIds) && event.changedStoryIds.length > 0 && commentsCatalogMayHaveRows();
					if (remoteCommentsPartChanged && !isTypingBurst) heavyReadsHeldUntilIdle = true;
					invalidateDocumentContent();
					if (remoteCommentsPartChanged && !isTypingBurst) demandHeavyDocRead("comments");
					else if (loadedCommentAnchorsMayHaveChanged) {
						heavyReadsHeldUntilIdle = true;
						scheduleHeavyReadCompletionRecompute();
					}
					recompute();
				}
			});
			if (typeof off === "function") detachHostEvents = off;
		} catch {
			currentHostEventsSource = null;
		}
	};
	const recompute = (reason = "unspecified") => {
		if (disposed) return;
		const { sink } = readUiBenchRuntime();
		const startedAtMs = sink ? uiBenchNowMs() : 0;
		editCommandsRecomputeQueued = false;
		syncCoordinatorEditor();
		syncHostSelectionSubscription();
		syncEditCommandsSubscription();
		syncV2ReviewWindowSubscription();
		syncHostReviewSubscription();
		syncDocumentSelectionFallbackSubscription();
		syncHostEventsSubscription();
		const nextState = computeState(reason);
		syncOptimisticInlineSelection(nextState.selection);
		state = nextState;
		let listenerTotalMs = 0;
		let listenerMaxMs = 0;
		for (const listener of [...listeners]) {
			if (!sink) {
				listener(state);
				continue;
			}
			const listenerStartedAtMs = uiBenchNowMs();
			listener(state);
			const listenerMs = uiBenchNowMs() - listenerStartedAtMs;
			listenerTotalMs += listenerMs;
			listenerMaxMs = Math.max(listenerMaxMs, listenerMs);
		}
		if (sink) {
			const completedAtMs = uiBenchNowMs();
			emitUiBenchTiming({
				stage: "superdoc-ui-recompute",
				atMs: completedAtMs,
				reason,
				startedAtMs,
				completedAtMs,
				durationMs: completedAtMs - startedAtMs,
				listenerCount: listeners.size,
				listenerTotalMs,
				listenerMaxMs
			});
		}
	};
	/**
	* Work that is bound to one specific active editor and cannot survive a swap.
	* Recomputing aggregate state is not enough for these: a geometry
	* subscription points at a DOM host that is going away, and an in-flight
	* async query would publish the old document's result into the new one.
	*
	* Populated by the viewport and search handles further down. The handler only
	* runs on a host event, which cannot happen during construction, so
	* registering later than `attach` is safe.
	*/
	const activeEditorResetHooks = [];
	/**
	* The subset bound to the DOCUMENT rather than to the editor.
	*
	* `replaceFile()` swaps content in place: the editor object and its host both
	* survive, so a geometry subscription is still attached to the thing now
	* rendering the replacement and must be left alone. Search state describes
	* content that is gone and must not be.
	*
	* Measured rather than assumed — after an in-place replace the geometry
	* subscription is never detached and keeps firing, while `search.total` still
	* reports the previous document's match count.
	*/
	const documentResetHooks = [];
	const runHooks = (hooks) => {
		for (const reset of hooks) try {
			reset();
		} catch {}
	};
	const runActiveEditorResetHooks = () => runHooks(activeEditorResetHooks);
	const runDocumentResetHooks = () => runHooks(documentResetHooks);
	const detachers = [];
	const attach = (source, events) => {
		if (!source || typeof source.on !== "function") return;
		for (const event of events) {
			const handler = event === "active-editor-change" ? () => {
				runActiveEditorResetHooks();
				runDocumentResetHooks();
				recompute();
			} : event === "document-replaced" ? (payload) => {
				const detail = payload && typeof payload === "object" ? payload : null;
				const replacedEditor = detail?.["editor"];
				const replacedHost = detail?.["host"];
				const matchesEditor = Boolean(replacedEditor) && replacedEditor === getEditor();
				const matchesHost = Boolean(replacedHost) && replacedHost === getHost();
				if (!matchesEditor && !matchesHost) return;
				runDocumentResetHooks();
				asyncReads.clear();
				invalidateDocumentContent();
				recompute();
			} : () => recompute();
			try {
				source.on(event, handler);
				detachers.push(() => {
					try {
						if (typeof source.off === "function") source.off(event, handler);
					} catch {}
				});
			} catch {}
		}
	};
	attach(superdoc, HOST_EVENTS);
	syncHostSelectionSubscription();
	syncEditCommandsSubscription();
	syncV2ReviewWindowSubscription();
	syncHostReviewSubscription();
	syncDocumentSelectionFallbackSubscription();
	syncHostEventsSubscription();
	const select = (selector, equality = shallowEqual) => {
		return {
			get: () => selector(state),
			subscribe: (cb) => {
				let last = selector(state);
				const listener = (next) => {
					const value = selector(next);
					if (!equality(last, value)) {
						last = value;
						cb(value);
					}
				};
				listeners.add(listener);
				return () => listeners.delete(listener);
			}
		};
	};
	const sliceHandle = (selector) => select(selector);
	/**
	* Wrap an underlying selector {@link Subscribable} (raw `get` + value
	* `subscribe`) in the main-compatible domain-handle subscription shape so
	* every customer-facing handle exposes the same contract main does:
	*
	*   - `getSnapshot()` reads the current slice;
	*   - `observe(listener)` emits the current value immediately, then on each
	*     change (the listener receives the snapshot directly);
	*   - `subscribe(listener)` is the `{ snapshot }`-shaped alias of `observe`,
	*     likewise emitting immediately then on change.
	*
	* The generic `select(...)` substrate stays raw-value and unchanged; only the
	* domain handles are composed from this.
	*/
	const snapshotHandle = (sub) => {
		const observe = (listener) => {
			const safe = (snapshot) => {
				try {
					listener(snapshot);
				} catch {}
			};
			const unsubscribe = sub.subscribe(safe);
			safe(sub.get());
			return unsubscribe;
		};
		return {
			get: () => sub.get(),
			getSnapshot: () => sub.get(),
			observe,
			subscribe: (listener) => observe((snapshot) => listener({ snapshot }))
		};
	};
	const directorySnapshotHandle = (passiveSub, directorySub, family) => {
		const passive = snapshotHandle(passiveSub);
		const directory = snapshotHandle(directorySub);
		const observe = (listener) => {
			const release = acquireDirectoryLease(family);
			recompute();
			const unsubscribe = directory.observe(listener);
			return () => {
				unsubscribe();
				release();
			};
		};
		return {
			get: passive.get,
			getSnapshot: passive.getSnapshot,
			observe,
			subscribe: (listener) => observe((snapshot) => listener({ snapshot }))
		};
	};
	function readTrackDecisionTargetId(target) {
		return target && typeof target === "object" && typeof target.id === "string" ? String(target.id) : null;
	}
	function nonBodySelectionStoryLocator(selection) {
		const story = selectionStoryLocator(selection);
		return story && storyLocatorSignature(story) !== storyLocatorSignature(null) ? story : void 0;
	}
	function trackDecisionIdTarget(changeId, story) {
		return {
			kind: "id",
			id: changeId,
			...story ? { story } : {}
		};
	}
	/**
	* Build the Document API range target for a partial tracked-change decision.
	* The explicit selection target is authoritative and labels its coordinates:
	* ordinary/insertion selections are visible-space, while a selection that
	* reaches painted deleted text is projected in tracked space by the host.
	*
	* A cross-block or malformed selection fails closed. Its intermediate block
	* coverage cannot be reconstructed from two endpoints without guessing.
	*/
	function trackDecisionRangeFromSelection(selection) {
		if (selection.empty) return null;
		const explicit = selection.selectionTarget;
		const start = explicit?.start;
		const end = explicit?.end;
		if (explicit?.kind !== "selection" || start?.kind !== "text" || end?.kind !== "text" || typeof start.blockId !== "string" || start.blockId !== end.blockId || !Number.isInteger(start.offset) || !Number.isInteger(end.offset) || start.offset < 0 || end.offset < 0 || start.offset === end.offset) return null;
		const rangeStart = Math.min(start.offset, end.offset);
		const rangeEnd = Math.max(start.offset, end.offset);
		const story = selectionStoryLocator(selection);
		return {
			kind: "range",
			coordinateSpace: explicit.coordinateSpace === "tracked" ? "tracked" : "visible",
			range: {
				kind: "text",
				...story ? { story } : {},
				segments: [{
					blockId: start.blockId,
					range: {
						start: rangeStart,
						end: rangeEnd
					}
				}]
			}
		};
	}
	function readBodyTrackChangeForDecision(activeId, story) {
		if (storyLocatorSignature(story) !== storyLocatorSignature(null)) return void 0;
		const trackChanges = getDoc()?.trackChanges;
		const list = trackChanges?.list;
		if (typeof list !== "function") return void 0;
		const raw = safeCall(() => list.call(trackChanges), null);
		if (isPromiseLike(raw) || !raw || typeof raw !== "object") return void 0;
		const items = raw.items;
		if (!Array.isArray(items)) return void 0;
		return items.map(projectTrackChangesItem).find((item) => item != null && entityRowMatchesRequest(item, activeId, story));
	}
	function selectedTextCoversTrackChangeText(selection, item) {
		const selected = normalizeTrackDecisionText(selection.quotedText);
		if (!selected) return false;
		const payload = trackChangesItemPayload(item);
		return [
			payload.insertedText,
			payload.deletedText,
			payload.excerpt
		].some((value) => normalizeTrackDecisionText(value) === selected);
	}
	function normalizeTrackDecisionText(value) {
		return typeof value === "string" ? value.replace(/\s+/g, " ").trim() : "";
	}
	function activeChangePartialDecisionRoute() {
		const activeId = state.selection.activeChangeIds[0];
		if (!activeId) return "unavailable";
		const story = selectionStoryLocator(state.selection);
		const item = (state.trackChanges.status === "ready" ? state.trackChanges.items.find((candidate) => entityRowMatchesRequest(candidate, activeId, story)) : void 0) ?? readBodyTrackChangeForDecision(activeId, story) ?? readAllStoryTrackChanges()?.find((candidate) => entityRowMatchesRequest(candidate, activeId, story));
		if (!item) return "unavailable";
		const change = trackChangesItemPayload(item);
		const type = change.type;
		const grouping = change.grouping;
		if (selectedTextCoversTrackChangeText(state.selection, item)) return "id";
		if (type === "replacement" && grouping === "replacement-pair") return "range";
		return (type === "insertion" || type === "deletion" || type === "insert" || type === "delete") && grouping === "standalone" ? "range" : "id";
	}
	function executeTrackDecisionRangeWithIdFallback(kind, rangeTarget, changeId, story) {
		const fallback = () => callTrackDecisionTarget(kind, trackDecisionIdTarget(changeId, story), changeId, story);
		try {
			const result = callTrackDecisionTarget(kind, rangeTarget, changeId, story);
			if (isPromiseLike(result)) return settleCommandExecution(Promise.resolve(result).then((settled) => {
				return commandResultSucceeded(commandResultFromOperationResult(settled)) ? settled : fallback();
			}));
			const commandResult = commandResultFromOperationResult(result);
			return settleCommandExecution(commandResultSucceeded(commandResult) ? result : fallback());
		} catch {
			return false;
		}
	}
	function resolveTrackDecisionTarget(command, payload) {
		if (command.scope === "all") return {
			target: { kind: "all" },
			changeId: null
		};
		if (typeof payload === "string" && payload.length > 0) return {
			target: {
				kind: "id",
				id: payload
			},
			changeId: payload
		};
		if (payload && typeof payload === "object") {
			const record = payload;
			if (record.target && typeof record.target === "object") {
				const target = record.target;
				return {
					target,
					changeId: readTrackDecisionTargetId(target),
					story: target.story
				};
			}
			const id = typeof record.changeId === "string" ? record.changeId : record.id;
			if (typeof id === "string" && id.length > 0) return {
				target: trackDecisionIdTarget(id, record.story),
				changeId: id,
				story: record.story
			};
		}
		const selectedId = state.selection.activeChangeIds[0];
		const story = nonBodySelectionStoryLocator(state.selection);
		return selectedId ? {
			target: trackDecisionIdTarget(selectedId, story),
			changeId: selectedId,
			story
		} : null;
	}
	function executeTrackDecisionCommand(command, payload) {
		if (command.scope === "id" && payload == null) {
			if (state.selection.activeChangeIds.length > 1) return executeTrackDecisionTarget(command.kind, {
				kind: "ids",
				ids: state.selection.activeChangeIds
			}, null);
			if (state.selection.activeChangeIds.length === 1 && !state.selection.empty && state.selection.selectionTarget) {
				const route = activeChangePartialDecisionRoute();
				if (route === "unavailable") return false;
				if (route === "range") {
					const target = trackDecisionRangeFromSelection(state.selection);
					const story = nonBodySelectionStoryLocator(state.selection);
					return target ? executeTrackDecisionRangeWithIdFallback(command.kind, target, state.selection.activeChangeIds[0], story) : false;
				}
				if (route === "id") {
					const activeId = state.selection.activeChangeIds[0];
					const selectedStory = selectionStoryLocator(state.selection);
					const story = selectedStory && storyLocatorSignature(selectedStory) !== storyLocatorSignature(null) ? selectedStory : void 0;
					return executeTrackDecision(command.kind, story ? {
						id: activeId,
						story
					} : activeId);
				}
			}
		}
		const resolved = resolveTrackDecisionTarget(command, payload);
		if (!resolved) return false;
		return executeTrackDecisionTarget(command.kind, resolved.target, resolved.changeId, resolved.story);
	}
	function executeListToggleCommand(kind, payload) {
		const lists = getEditCommands()?.lists;
		const apply = lists?.apply;
		if (typeof apply !== "function") return false;
		const { behavior, preset, continuity } = typeof payload === "string" ? presetFromToolbarStyleKey(payload) : payload && typeof payload === "object" ? payload : {};
		const input = {
			kind,
			behavior: behavior ?? "toggle"
		};
		if (preset !== void 0) input.preset = preset;
		if (continuity !== void 0) input.continuity = continuity;
		try {
			return settleCommandExecution(apply.call(lists, input));
		} catch {
			return false;
		}
	}
	let lastCommandSettlement = Promise.resolve(false);
	let pendingCommandSettlement = null;
	let lastInlineToggleCommandSettlement = Promise.resolve(false);
	const awaitMutationReadiness = async (result) => {
		if (!isSuccessfulReceipt(result)) return result;
		const readiness = getEditor()?.documentMutationReadiness;
		const whenPainted = readiness?.whenPainted;
		if (typeof whenPainted !== "function") return result;
		const txId = typeof result.txId === "string" ? result.txId : void 0;
		try {
			await whenPainted.call(readiness, txId ? { txId } : void 0);
		} catch {}
		return result;
	};
	const settleOperationResult = (result) => {
		if (isPromiseLike(result)) {
			const operation = Promise.resolve(result);
			return {
				immediate: true,
				committed: operation.then((resolved) => commandResultFromOperationResult(resolved), () => false),
				settled: operation.then((resolved) => awaitMutationReadiness(commandResultFromOperationResult(resolved)), () => false)
			};
		}
		const immediate = commandResultFromOperationResult(result);
		return {
			immediate,
			committed: Promise.resolve(immediate),
			settled: awaitMutationReadiness(immediate)
		};
	};
	const releaseInlineToggleMutation = () => {
		const next = pendingInlineToggleMutations.shift();
		if (!next) {
			inlineToggleMutationActive = false;
			resolveInlineToggleMutationIdle?.();
			resolveInlineToggleMutationIdle = null;
			return;
		}
		try {
			next.resolve(disposed ? false : next.mutate());
		} catch {
			next.resolve(false);
		}
	};
	const releaseInlineToggleMutationOnce = () => {
		let released = false;
		return () => {
			if (released) return;
			released = true;
			releaseInlineToggleMutation();
		};
	};
	const scheduleInlineToggleMutation = (key, mutate) => {
		if (!inlineToggleMutationActive) {
			inlineToggleMutationActive = true;
			inlineToggleMutationIdle = new Promise((resolve) => {
				resolveInlineToggleMutationIdle = resolve;
			});
			try {
				return {
					result: mutate(),
					release: releaseInlineToggleMutationOnce()
				};
			} catch (error) {
				inlineToggleMutationActive = false;
				resolveInlineToggleMutationIdle?.();
				resolveInlineToggleMutationIdle = null;
				throw error;
			}
		}
		const pending = pendingInlineToggleMutations.find((mutation) => mutation.key === key);
		if (pending) {
			pending.mutate = mutate;
			return {
				result: pending.result,
				release: () => void 0
			};
		}
		let resolve;
		const result = new Promise((settle) => {
			resolve = settle;
		});
		pendingInlineToggleMutations.push({
			key,
			mutate,
			result,
			resolve
		});
		return {
			result,
			release: releaseInlineToggleMutationOnce()
		};
	};
	const UNSUPPORTED_TRACKED_UI_MUTATION_ROUTES = /* @__PURE__ */ new Set(["create.tableOfContents"]);
	const unsupportedTrackedMutationReceipt = (route) => failedReceipt(`Tracked authoring is not supported for ${route}.`);
	const editorMutationOptionsForRoute = (route) => {
		if (readDocumentMode() !== "suggesting") return void 0;
		if (UNSUPPORTED_TRACKED_UI_MUTATION_ROUTES.has(route)) return unsupportedTrackedMutationReceipt(route);
		return { changeMode: "tracked" };
	};
	/** Clear-patch to send for the current document mode (see TRACKED_CLEAR_INLINE_PATCH). */
	const clearInlinePatchForMode = () => readDocumentMode() === "suggesting" ? TRACKED_CLEAR_INLINE_PATCH : CLEAR_INLINE_PATCH;
	const callEditorMutation = (route, op, input) => {
		const options = editorMutationOptionsForRoute(route);
		if (options && options.success === false) return options;
		return options ? op(input, options) : op(input);
	};
	const captureOptimisticInlineValueResult = (descriptor, selection, input, result) => {
		const inline = descriptor.inline;
		if (!inline) return;
		const commandResult = commandResultFromOperationResult(result);
		if (commandResult === false) return;
		if (typeof commandResult === "object" && commandResult && commandResult.success === false) return;
		if (inline.kind === "clear") {
			optimisticInlineValues.clear();
			return;
		}
		if (inline.kind === "toggle" || !isProjectedInlineSelectionValueKey(inline.key)) return;
		const selectionSignature = selectionInlineValueSignature(selection);
		if (!selectionSignature) return;
		const value = normalizeOptimisticInlineSelectionValue(inline.key, input.value);
		if (value == null) {
			optimisticInlineValues.delete(inline.key);
			return;
		}
		optimisticInlineValues.set(inline.key, {
			selectionSignature,
			value
		});
	};
	const decorateInlineCommandResult = (descriptor, selection, input, result) => {
		if (!descriptor.inline || descriptor.inline.kind === "toggle") return result;
		if (isPromiseLike(result)) return Promise.resolve(result).then((resolved) => {
			captureOptimisticInlineValueResult(descriptor, selection, input, resolved);
			return resolved;
		});
		return result;
	};
	const captureOptimisticInlineToggle = (descriptor, selection, input, result) => {
		if (descriptor.inline?.kind !== "toggle") return null;
		if (!commandResultSucceeded(commandResultFromOperationResult(result))) return null;
		if (typeof input.value !== "boolean" && input.value !== null) return null;
		const selectionSignature = selectionInlineValueSignature(selection);
		if (!selectionSignature) return null;
		const generation = ++optimisticInlineToggleGeneration;
		optimisticInlineToggles.set(descriptor.id, {
			selectionSignature,
			active: input.value === true,
			generation,
			settled: false
		});
		recompute();
		return generation;
	};
	const settleOptimisticInlineToggle = (descriptor, generation, result) => {
		if (generation == null) return;
		const optimistic = optimisticInlineToggles.get(descriptor.id);
		if (!optimistic || optimistic.generation !== generation) return;
		if (!commandResultSucceeded(result)) {
			optimisticInlineToggles.delete(descriptor.id);
			return;
		}
		optimistic.settled = true;
	};
	const finalizeCommandSettlement = (promise, onSettled) => promise.then((settled) => {
		onSettled?.(settled);
		invalidateAfterCommandSettlement();
		return settled;
	}, () => {
		onSettled?.(false);
		invalidateAfterCommandSettlement();
		return false;
	});
	const settleCommandExecution = (result, onSettled) => {
		const pending = pendingCommandSettlement;
		pendingCommandSettlement = null;
		if (pending) {
			lastCommandSettlement = finalizeCommandSettlement(pending, onSettled);
			return commandResultFromOperationResult(result);
		}
		if (isPromiseLike(result)) {
			lastCommandSettlement = finalizeCommandSettlement(settleOperationResult(result).settled, onSettled);
			return true;
		}
		const settled = commandResultFromOperationResult(result);
		if (isSuccessfulReceipt(settled)) {
			if (typeof (getEditor()?.documentMutationReadiness)?.whenPainted === "function") {
				lastCommandSettlement = finalizeCommandSettlement(awaitMutationReadiness(settled), onSettled);
				return settled;
			}
		}
		onSettled?.(settled);
		lastCommandSettlement = Promise.resolve(settled);
		invalidateAfterCommandSettlement();
		return settled;
	};
	const normalizeWorkflowReceipt = (value, fallback) => {
		if (!value || typeof value !== "object") return fallback;
		return value;
	};
	const settleWorkflowReceipt = (receipt, fallback = failedReceipt("Document API operation failed.")) => {
		if (isPromiseLike(receipt)) return Promise.resolve(receipt).then((resolved) => settleWorkflowReceipt(resolved, fallback), () => fallback);
		const normalizedReceipt = normalizeWorkflowReceipt(receipt, fallback);
		invalidateDocumentContent();
		if (isSuccessfulReceipt(normalizedReceipt)) {
			if (typeof (getEditor()?.documentMutationReadiness)?.whenPainted === "function") {
				finalizeCommandSettlement(awaitMutationReadiness(normalizedReceipt));
				recompute();
				return normalizedReceipt;
			}
		}
		recompute();
		return normalizedReceipt;
	};
	/**
	* Apply a Document API operation once per covered block, building the input
	* from the block id. Returns the last success receipt (or `true`), else the
	* last result (or `false`). Recompute is the caller's responsibility.
	*/
	const applyPerBlock = (route, op, blockIds, buildInput) => {
		const immediateResults = [];
		const settledResults = [];
		for (const blockId of blockIds) {
			const input = buildInput(blockId);
			if (!input) continue;
			try {
				const result = settleOperationResult(callEditorMutation(route, op, input));
				immediateResults.push(result.immediate);
				settledResults.push(result.settled);
			} catch {
				immediateResults.push(false);
				settledResults.push(Promise.resolve(false));
			}
		}
		pendingCommandSettlement = settledResults.length ? Promise.all(settledResults).then((results) => combineCommandResults(results)) : null;
		return combineCommandResults(immediateResults);
	};
	/** Apply a Document API operation once per covered text segment. */
	const applyPerTextAddress = (route, op, targets, buildInput) => {
		const immediateResults = [];
		const settledResults = [];
		for (const target of targets) {
			const input = buildInput(target);
			if (!input) continue;
			try {
				const result = settleOperationResult(callEditorMutation(route, op, input));
				immediateResults.push(result.immediate);
				settledResults.push(result.settled);
			} catch {
				immediateResults.push(false);
				settledResults.push(Promise.resolve(false));
			}
		}
		pendingCommandSettlement = settledResults.length ? Promise.all(settledResults).then((results) => combineCommandResults(results)) : null;
		return combineCommandResults(immediateResults);
	};
	/**
	* Call an inline `format.*` operation against the live selection. Mirrors
	* `callEditorMutation` (suggesting mode adds `changeMode: 'tracked'`), and
	* when the target is the host's own editable `selectionTarget` it also
	* carries the PRIVATE V2 option `offsetSpace: 'selection'` (browser
	* selection offsets count an inline object as one caret position). The
	* option is not part of public `MutationOptions`; this is the same cast
	* pattern the delete/replace callers use.
	*/
	const callInlineFormatMutation = (route, op, input, selection = state.selection) => {
		const options = editorMutationOptionsForRoute(route);
		if (options && options.success === false) return options;
		if (!selection.selectionTarget) return options ? op(input, options) : op(input);
		return op(input, {
			...options,
			offsetSpace: "selection"
		});
	};
	/** Build the `format.paragraph.*` / `styles.paragraph.*` input for a block. */
	const buildBlockParagraphInput = (spec, blockId, payload, story) => {
		const target = paragraphTarget(blockId, story);
		switch (spec.kind) {
			case "alignment": {
				const alignment = payload;
				if (alignment !== "left" && alignment !== "center" && alignment !== "right" && alignment !== "justify") return null;
				return {
					target,
					alignment
				};
			}
			case "spacing-line": {
				const line = typeof payload === "number" ? payload : Number(payload);
				if (!Number.isFinite(line) || line <= 0) return null;
				return {
					target,
					line,
					lineRule: "auto"
				};
			}
			case "style":
				if (payload && typeof payload === "object") {
					const role = payload.role;
					if (role && typeof role === "object") return {
						target,
						role
					};
				}
				if (typeof payload !== "string" || payload.trim() === "") return null;
				return {
					target,
					styleId: payload
				};
			case "direction": {
				const direction = spec.fixedValue;
				if (direction !== "ltr" && direction !== "rtl") return null;
				return {
					target,
					direction
				};
			}
			default: return null;
		}
	};
	/**
	* Store a caret pick as a pending mark (SD-3654/SD-3652) so the next typed text
	* carries it. Mirrors ProseMirror `storedMarks`: a toggle flips the stored
	* value against the current active state; a value command (color/font/size)
	* stores the value or clears it on a null/empty ("None") payload; a clear
	* command drops all stored marks. The host applies the store to the created
	* span on the next insert; settleCommandExecution drives the recompute.
	*/
	const storePendingInlineFormat = (descriptor, payload) => {
		const spec = descriptor.inline;
		const method = inlineFormatMethod(descriptor);
		const host = getHost();
		if (!spec || typeof host?.setPendingInlineFormat !== "function") return false;
		if (spec.kind === "clear") {
			clearPendingInlineFormatOnHost();
			return true;
		}
		if (!method) return false;
		let value;
		if (spec.kind === "toggle") value = !commandActiveState(descriptor, getDoc(), state.selection);
		else {
			const raw = payload && typeof payload === "object" && "value" in payload ? payload.value : payload;
			if (spec.kind === "value-number") {
				const n = typeof raw === "number" ? raw : Number(raw);
				value = Number.isFinite(n) && n > 0 ? n : null;
			} else value = typeof raw === "string" && raw.trim() !== "" ? raw : null;
			if (value === null) {
				setPendingInlineFormatOnHost(method, null);
				return true;
			}
		}
		setPendingInlineFormatOnHost(method, value);
		return true;
	};
	const executeClearFormattingCommand = () => {
		const doc = getDoc();
		const { lockModesById } = computeActiveContentControlLockModes(doc?.contentControls, state.selection);
		if (contentControlLockReason(lockModesById)) return false;
		const immediateResults = [];
		const settledResults = [];
		const record = (result) => {
			const settled = settleOperationResult(result);
			immediateResults.push(settled.immediate);
			settledResults.push(settled.settled);
		};
		const run = (op, input, options) => {
			try {
				record(options ? op(input, options) : op(input));
			} catch {
				immediateResults.push(false);
				settledResults.push(Promise.resolve(false));
			}
		};
		const defaultStyleId = getStyleCatalog().cache?.full.defaults.paragraphStyleId ?? DEFAULT_PARAGRAPH_STYLE_ID;
		const rangeTarget = resolveInlineSelectionTarget(state.selection);
		if (rangeTarget) {
			const inlineOp = resolveDocOperation(doc, "format.apply");
			if (inlineOp) try {
				record(callInlineFormatMutation("format.apply", inlineOp, {
					target: rangeTarget,
					inline: { ...clearInlinePatchForMode() }
				}));
			} catch {
				immediateResults.push(false);
				settledResults.push(Promise.resolve(false));
			}
		}
		const resetOp = resolveDocOperation(doc, "format.paragraph.resetDirectFormatting");
		const setStyleRefOp = resolveDocOperation(doc, "styles.paragraph.setStyleRef");
		const story = selectionStoryLocator(state.selection);
		const isBodyStory = !story || story.storyType === "body";
		const listsRemoveOp = resolveDocOperation(doc, isBodyStory ? "lists.remove" : "lists.removeInStory");
		for (const blockId of selectionBlockIds(state.selection)) {
			const target = paragraphTarget(blockId, story);
			if (resetOp) run(resetOp, { target });
			if (listsRemoveOp) try {
				const listTarget = listsBlockTarget(blockId);
				const r = settleOperationResult(listsRemoveOp(isBodyStory ? { target: listTarget } : {
					target: listTarget,
					story
				}));
				settledResults.push(r.settled.then((s) => commandResultSucceeded(s) ? s : true));
			} catch {}
			if (setStyleRefOp) run(setStyleRefOp, {
				target,
				styleId: defaultStyleId
			});
		}
		if (!rangeTarget && readDocumentMode() !== "suggesting") {
			const setMarkRunPropsOp = resolveDocOperation(doc, "format.paragraph.setMarkRunProps");
			if (setMarkRunPropsOp) for (const blockId of selectionBlockIds(state.selection)) run(setMarkRunPropsOp, {
				target: paragraphTarget(blockId, story),
				markRunProps: {
					bold: false,
					italic: false,
					strikethrough: false,
					doubleStrikethrough: false,
					smallCaps: false,
					caps: false,
					verticalAlign: "baseline"
				}
			});
		}
		pendingCommandSettlement = settledResults.length ? Promise.all(settledResults).then((results) => combineCommandResults(results)) : null;
		return combineCommandResults(immediateResults.length ? immediateResults : [false]);
	};
	/** Route a block-level paragraph command (`format.paragraph.*` / `styles.paragraph.*`). */
	const executeBlockParagraph = (descriptor, op, payload) => {
		const blockIds = selectionBlockIds(state.selection);
		if (blockIds.length === 0) return false;
		const story = selectionStoryLocator(state.selection);
		return applyPerBlock(descriptor.docRoute, op, blockIds, (blockId) => buildBlockParagraphInput(descriptor.blockParagraph, blockId, payload, story));
	};
	const executeHybridIndentCommand = (descriptor, listOp, blockIds) => {
		const doc = getDoc();
		const paragraphSetIndent = resolveDocOperation(doc, "format.paragraph.setIndentation");
		const paragraphClearIndent = resolveDocOperation(doc, "format.paragraph.clearIndentation");
		const mode = descriptor.list?.mode;
		const story = selectionStory(state.selection);
		const targetStory = selectionStoryLocator(state.selection);
		const planBlock = async (blockId) => {
			const isListItem = await resolveListMembershipForBlockAsync(doc, blockId, story);
			if (isListItem === true) return {
				kind: "list",
				routeToCall: descriptor.docRoute,
				opToCall: listOp,
				input: { target: listItemTarget(blockId) }
			};
			if (isListItem === null) return null;
			if (targetStory && targetStory.storyType !== "body" && typeof doc?.getNode !== "function") return null;
			const current = await resolveParagraphIndentationForBlockAsync(doc, blockId, targetStory);
			const preserved = {};
			if (current?.right != null) preserved.right = current.right;
			if (current?.firstLine != null) preserved.firstLine = current.firstLine;
			if (current?.hanging != null) preserved.hanging = current.hanging;
			if (mode === "indent") {
				if (!paragraphSetIndent) return null;
				return {
					kind: "paragraph",
					routeToCall: "format.paragraph.setIndentation",
					opToCall: paragraphSetIndent,
					input: {
						target: paragraphTarget(blockId, targetStory),
						left: Math.max(0, current?.left ?? 0) + PARAGRAPH_INDENT_STEP_TWIPS,
						...preserved
					}
				};
			}
			const nextLeft = Math.max(0, (current?.left ?? 0) - PARAGRAPH_INDENT_STEP_TWIPS);
			if (nextLeft > 0) preserved.left = nextLeft;
			if (Object.keys(preserved).length === 0) {
				if (paragraphClearIndent) return {
					kind: "paragraph",
					routeToCall: "format.paragraph.clearIndentation",
					opToCall: paragraphClearIndent,
					input: { target: paragraphTarget(blockId, targetStory) }
				};
				if (paragraphSetIndent) return {
					kind: "paragraph",
					routeToCall: "format.paragraph.setIndentation",
					opToCall: paragraphSetIndent,
					input: {
						target: paragraphTarget(blockId, targetStory),
						left: 0
					}
				};
				return null;
			}
			if (paragraphSetIndent) return {
				kind: "paragraph",
				routeToCall: "format.paragraph.setIndentation",
				opToCall: paragraphSetIndent,
				input: {
					target: paragraphTarget(blockId, targetStory),
					...preserved
				}
			};
			return null;
		};
		pendingCommandSettlement = (async () => {
			const plans = await Promise.all(blockIds.map((blockId) => planBlock(blockId).catch(() => null)));
			if (plans.length === blockIds.length && plans.every((plan) => plan?.kind === "list") && readDocumentMode() !== "suggesting") {
				const rangeRoute = mode === "indent" ? "lists.indentRange" : "lists.outdentRange";
				const rangeOp = resolveDocOperation(doc, rangeRoute);
				if (rangeOp) try {
					return await settleOperationResult(callEditorMutation(rangeRoute, rangeOp, {
						paraIds: blockIds,
						story
					})).settled;
				} catch {
					return false;
				}
			}
			const nonBodyListPlans = story.storyType !== "body" && plans.some((plan) => plan?.kind === "list");
			const outdentInStory = nonBodyListPlans && mode === "outdent" ? resolveDocOperation(doc, "lists.outdentInStory") : null;
			if (nonBodyListPlans && !outdentInStory) return false;
			const settledResults = plans.map((plan) => {
				if (!plan) return Promise.resolve(false);
				try {
					if (plan.kind === "list" && outdentInStory) return settleOperationResult(callEditorMutation("lists.outdentInStory", outdentInStory, {
						target: plan.input.target,
						story
					})).settled;
					return settleOperationResult(callEditorMutation(plan.routeToCall, plan.opToCall, plan.input)).settled;
				} catch {
					return Promise.resolve(false);
				}
			});
			return combineCommandResults(await Promise.all(settledResults));
		})();
		return true;
	};
	/** Route a list command (`lists.apply` / `lists.remove` / list level changes). */
	const executeListCommand = (descriptor, op) => {
		const spec = descriptor.list;
		const doc = getDoc();
		const blockIds = selectionBlockIds(state.selection);
		if (blockIds.length === 0) return false;
		const story = selectionStory(state.selection);
		const isBodyStory = story.storyType === "body";
		if (spec.mode === "indent" || spec.mode === "outdent") return executeHybridIndentCommand(descriptor, op, blockIds);
		const seed = spec.seed;
		const executeResolved = (states) => {
			if (states.some((listState) => !listState.resolved)) return {
				immediate: false,
				settled: null
			};
			const shouldRemove = states.every((listState) => listState.seed === seed);
			if (!shouldRemove && !isBodyStory) return {
				immediate: false,
				settled: null
			};
			const route = shouldRemove ? isBodyStory ? "lists.remove" : "lists.removeInStory" : descriptor.docRoute;
			const operation = shouldRemove ? resolveDocOperation(doc, route) : op;
			if (!operation) return {
				immediate: false,
				settled: null
			};
			const immediateResults = [];
			const settledResults = [];
			blockIds.forEach((blockId, index) => {
				if (!shouldRemove && states[index]?.seed === seed) return;
				const input = shouldRemove ? {
					target: listsBlockTarget(blockId),
					...!isBodyStory ? { story } : {}
				} : {
					target: listsBlockTarget(blockId),
					seed
				};
				try {
					const result = settleOperationResult(callEditorMutation(route, operation, input));
					immediateResults.push(result.immediate);
					settledResults.push(result.settled);
				} catch {
					immediateResults.push(false);
					settledResults.push(Promise.resolve(false));
				}
			});
			return {
				immediate: combineCommandResults(immediateResults),
				settled: settledResults.length ? Promise.all(settledResults).then((results) => combineCommandResults(results)) : null
			};
		};
		const stateReads = blockIds.map((blockId) => resolveListSeedForBlock(doc, blockId, story));
		if (stateReads.some(isPromiseLike)) {
			pendingCommandSettlement = Promise.all(stateReads).then(async (states) => {
				const result = executeResolved(states);
				return result.settled ? await result.settled : result.immediate;
			});
			return true;
		}
		const result = executeResolved(stateReads);
		pendingCommandSettlement = result.settled;
		return result.immediate;
	};
	function readLinkPayloadRecord(payload) {
		return payload && typeof payload === "object" ? payload : {};
	}
	function readLinkPayloadHref(payload) {
		if (typeof payload === "string") return payload;
		const record = readLinkPayloadRecord(payload);
		if (Object.prototype.hasOwnProperty.call(record, "href")) return record.href;
		if (Object.prototype.hasOwnProperty.call(record, "value")) return record.value;
	}
	function readLinkPayloadText(payload, href) {
		const text = readLinkPayloadRecord(payload).text;
		return typeof text === "string" && text.trim() !== "" ? text : href;
	}
	function readLinkPayloadTarget(payload) {
		const record = readLinkPayloadRecord(payload);
		const capture = record.capture && typeof record.capture === "object" ? record.capture : null;
		return record.target ?? capture?.target ?? capture?.selectionTarget ?? record.selectionTarget ?? record.textTarget ?? null;
	}
	/** Route a link command (`hyperlinks.wrap` / `insert` / `patch` / `remove`). */
	const executeLinkCommand = (payload) => {
		const doc = getDoc();
		const linksApi = doc?.hyperlinks;
		if (!linksApi) return false;
		const record = readLinkPayloadRecord(payload);
		const href = readLinkPayloadHref(payload);
		const payloadTarget = readLinkPayloadTarget(payload);
		const text = typeof record.text === "string" ? record.text : void 0;
		const currentText = typeof record.currentText === "string" ? record.currentText : void 0;
		const requestedHyperlinkTarget = isLooseObject(record.hyperlinkTarget) ? record.hyperlinkTarget : null;
		const requestedTextTarget = isLooseObject(record.textTarget) ? record.textTarget : null;
		const existing = resolveCurrentHyperlink(doc, state.selection);
		const hasRequestedHyperlinkTarget = typeof requestedHyperlinkTarget?.storyId === "string" && typeof requestedHyperlinkTarget?.hyperlinkNodeId === "string";
		if (hasRequestedHyperlinkTarget && href === null) {
			const remove = linksApi.remove;
			if (typeof remove !== "function") return false;
			try {
				return callEditorMutation("hyperlinks.remove", remove, {
					storyId: requestedHyperlinkTarget.storyId,
					hyperlinkNodeId: requestedHyperlinkTarget.hyperlinkNodeId,
					keepText: true
				});
			} catch {
				return false;
			}
		}
		if (existing && href === null) {
			const remove = linksApi.remove;
			if (typeof remove !== "function") return false;
			try {
				return callEditorMutation("hyperlinks.remove", remove, {
					target: existing.address,
					mode: "unwrap"
				});
			} catch {
				return false;
			}
		}
		if ((existing || requestedHyperlinkTarget) && typeof href === "string" && href.trim() !== "") {
			const patch = linksApi.patch;
			const updateTarget = linksApi.updateTarget;
			if (!(!hasRequestedHyperlinkTarget && existing && typeof patch === "function") && !(hasRequestedHyperlinkTarget && typeof updateTarget === "function")) return false;
			const shouldReplaceText = typeof text === "string" && text !== (hasRequestedHyperlinkTarget ? currentText : existing?.text ?? currentText);
			const replace = (doc?.text)?.replace;
			const target = shouldReplaceText ? hasRequestedHyperlinkTarget ? requestedTextTarget : hyperlinkAddressToSelectionTarget(existing?.address) : null;
			const canReplaceText = shouldReplaceText && Boolean(target) && typeof replace === "function";
			if (shouldReplaceText && !canReplaceText) return false;
			const results = [];
			const settledResults = [];
			let hyperlinkResult = null;
			let committedHyperlinkResult = null;
			let settledHyperlinkResult = null;
			let hyperlinkWasDeferred = false;
			try {
				if (hasRequestedHyperlinkTarget) {
					if (typeof updateTarget !== "function") return false;
					const operationResult = callEditorMutation("hyperlinks.updateTarget", updateTarget, {
						storyId: requestedHyperlinkTarget.storyId,
						hyperlinkNodeId: requestedHyperlinkTarget.hyperlinkNodeId,
						newTarget: hyperlinkTargetFromHref(href)
					});
					hyperlinkWasDeferred = isPromiseLike(operationResult);
					const result = settleOperationResult(operationResult);
					if (!commandResultSucceeded(result.immediate)) return false;
					results.push(result.immediate);
					settledResults.push(result.settled);
					hyperlinkResult = result.immediate;
					committedHyperlinkResult = result.committed;
					settledHyperlinkResult = result.settled;
				} else if (existing) {
					if (typeof patch !== "function") return false;
					const operationResult = callEditorMutation("hyperlinks.patch", patch, {
						target: existing.address,
						patch: { href }
					});
					hyperlinkWasDeferred = isPromiseLike(operationResult);
					const result = settleOperationResult(operationResult);
					if (!commandResultSucceeded(result.immediate)) return false;
					results.push(result.immediate);
					settledResults.push(result.settled);
					hyperlinkResult = result.immediate;
					committedHyperlinkResult = result.committed;
					settledHyperlinkResult = result.settled;
				}
			} catch {
				return false;
			}
			if (canReplaceText) {
				const combineSettledLinkEdit = (finalHyperlinkResult, finalTextResult) => {
					if (!commandResultSucceeded(finalTextResult)) return commandResultSucceeded(finalHyperlinkResult) ? partialLinkEditFailure(finalHyperlinkResult, finalTextResult) : finalTextResult;
					return combineCommandResults([finalHyperlinkResult, finalTextResult]);
				};
				const replaceTextAfterHyperlinkCommit = (finalHyperlinkResult) => {
					if (!commandResultSucceeded(finalHyperlinkResult)) return finalHyperlinkResult;
					try {
						const result = settleOperationResult(callEditorMutation("text.replace", replace, {
							target,
							text
						}));
						if (!commandResultSucceeded(result.immediate)) return partialLinkEditFailure(finalHyperlinkResult, result.immediate);
						return Promise.all([settledHyperlinkResult ?? Promise.resolve(finalHyperlinkResult), result.settled]).then(([settledHyperlink, finalTextResult]) => combineSettledLinkEdit(settledHyperlink, finalTextResult));
					} catch {
						return partialLinkEditFailure(finalHyperlinkResult, false);
					}
				};
				if (hyperlinkWasDeferred) {
					pendingCommandSettlement = (committedHyperlinkResult ?? Promise.resolve(hyperlinkResult ?? false)).then(replaceTextAfterHyperlinkCommit);
					return combineCommandResults(results);
				}
				try {
					const result = settleOperationResult(callEditorMutation("text.replace", replace, {
						target,
						text
					}));
					if (!commandResultSucceeded(result.immediate)) return hyperlinkResult ? partialLinkEditFailure(hyperlinkResult, result.immediate) : result.immediate;
					results.push(result.immediate);
					settledResults.push(result.settled);
					pendingCommandSettlement = Promise.all([settledHyperlinkResult ?? Promise.resolve(hyperlinkResult ?? false), result.settled]).then(([finalHyperlinkResult, finalTextResult]) => {
						return combineSettledLinkEdit(finalHyperlinkResult, finalTextResult);
					});
				} catch {
					return hyperlinkResult ? partialLinkEditFailure(hyperlinkResult, false) : false;
				}
			}
			if (!canReplaceText && settledResults.length > 0) pendingCommandSettlement = Promise.all(settledResults).then((settled) => combineCommandResults(settled));
			return combineCommandResults(results);
		}
		if (typeof href === "string" && href.trim() !== "") {
			const normalizedHref = href.trim();
			const wrap = linksApi.wrap;
			const textTargets = textAddressesFromTarget(payloadTarget);
			const wrapTargets = textTargets.length > 0 ? textTargets : selectionTextAddresses(state.selection);
			if (wrapTargets.length > 0) {
				if (typeof wrap !== "function") return false;
				try {
					return applyPerTextAddress("hyperlinks.wrap", wrap, wrapTargets, (target) => ({
						target,
						link: { destination: { href: normalizedHref } }
					}));
				} catch {
					return false;
				}
			}
			const insert = linksApi.insert;
			const text = readLinkPayloadText(payload, normalizedHref);
			if (typeof insert !== "function" || text.trim() === "") return false;
			const target = collapsedTextAddressFromTarget(payloadTarget) ?? collapsedTextAddressFromSelection(state.selection);
			if (!target) return false;
			try {
				return callEditorMutation("hyperlinks.insert", insert, {
					target,
					text,
					link: { destination: { href: normalizedHref } }
				});
			} catch {
				return false;
			}
		}
		return false;
	};
	/** Route a create command (`create.table` / `create.image` / `create.tableOfContents`). */
	const executeCreateCommand = (descriptor, op, payload) => {
		const kind = descriptor.create.kind;
		const record = payload && typeof payload === "object" ? payload : {};
		if (kind === "table") {
			const rows = Number(record.rows ?? record.rowCount);
			const columns = Number(record.columns ?? record.cols ?? record.colCount);
			if (!Number.isInteger(rows) || rows < 1 || !Number.isInteger(columns) || columns < 1) return false;
			const caret = collapsedTextAddressFromSelection(state.selection);
			const at = caret && typeof caret.blockId === "string" ? {
				kind: "inParagraph",
				target: paragraphTarget(caret.blockId),
				offset: caret.range?.start ?? 0
			} : createLocationAt(state.selection, "nodeId");
			try {
				return callEditorMutation(descriptor.docRoute, op, {
					rows,
					columns,
					at
				});
			} catch {
				return false;
			}
		}
		if (kind === "image") {
			const src = record.src ?? record.value;
			if (typeof src !== "string" || src.trim() === "") return false;
			const caret = collapsedTextAddressFromSelection(state.selection);
			const story = selectionStory(state.selection);
			const nonBodyStory = story.storyType === "body" ? null : story;
			let at;
			if (caret && typeof caret.blockId === "string") at = {
				kind: "inParagraph",
				target: paragraphTarget(caret.blockId, nonBodyStory),
				offset: caret.range?.start ?? 0
			};
			else {
				at = createLocationAt(state.selection, "target");
				if (nonBodyStory && at.kind === "after") at = {
					...at,
					target: {
						...at.target,
						story: nonBodyStory
					}
				};
			}
			const input = {
				src,
				at
			};
			if (nonBodyStory) input.in = at.kind === "inParagraph" ? resolveActiveHeaderFooterSlot(nonBodyStory) ?? nonBodyStory : nonBodyStory;
			if (typeof record.alt === "string") input.alt = record.alt;
			if (typeof record.title === "string") input.title = record.title;
			if (record.size && typeof record.size === "object") input.size = record.size;
			try {
				return callEditorMutation(descriptor.docRoute, op, input);
			} catch {
				return false;
			}
		}
		const input = { at: createLocationAt(state.selection, "target") };
		if (typeof record.instruction === "string") input.instruction = record.instruction;
		if (record.config && typeof record.config === "object") input.config = record.config;
		try {
			return callEditorMutation(descriptor.docRoute, op, input);
		} catch {
			return false;
		}
	};
	/**
	* Route a table cell-context command (`tables.*`) against the live table
	* context resolved from the shared facade. Fails closed (`false`) when the
	* caret is not in a table, the context is incomplete, or the action's
	* required cell is missing — never calling the operation with a malformed
	* locator.
	*/
	const executeTableCommand = (descriptor, op) => {
		const spec = descriptor.table;
		const context = resolveTableContext();
		if (!context) return false;
		if (spec.requiresCell && !context.cellNodeId) return false;
		const input = buildTableCommandInput(spec.action, context);
		if (!input) return false;
		try {
			if (spec.action === "insert-row-before" || spec.action === "insert-row-after") {
				const host = getHost();
				const tableCommands = ((typeof host?.getHandles === "function" ? host.getHandles() : null)?.editing)?.tables;
				if (typeof tableCommands?.insertRow !== "function") return false;
				const options = editorMutationOptionsForRoute(descriptor.docRoute);
				if (options && options.success === false) return options;
				return options ? tableCommands.insertRow(input, options) : tableCommands.insertRow(input);
			}
			if (spec.action === "insert-column-before" || spec.action === "insert-column-after") {
				const host = getHost();
				const tableCommands = ((typeof host?.getHandles === "function" ? host.getHandles() : null)?.editing)?.tables;
				if (typeof tableCommands?.insertColumn !== "function") return false;
				const options = editorMutationOptionsForRoute(descriptor.docRoute);
				if (options && options.success === false) return options;
				return options ? tableCommands.insertColumn(input, context.rowIndex, options) : tableCommands.insertColumn(input, context.rowIndex);
			}
			return callEditorMutation(descriptor.docRoute, op, input);
		} catch {
			return false;
		}
	};
	const descriptorNeedsFreshSelection = (descriptor) => {
		if (!descriptor || descriptor.disposition !== "routed") return false;
		return Boolean(descriptor.inline || descriptor.blockParagraph || descriptor.list || descriptor.link || descriptor.create);
	};
	const linkPayloadHasExplicitTarget = (payload) => {
		const record = readLinkPayloadRecord(payload);
		return Boolean(readLinkPayloadTarget(payload) || isLooseObject(record.hyperlinkTarget) || isLooseObject(record.textTarget));
	};
	const commandSelectionIsReady = (id, descriptor, payload) => {
		if (state.selection.status !== "ready") return false;
		if (trackDecisionCommand(id)?.scope === "id") return true;
		if (!descriptor || descriptor.disposition !== "routed") return true;
		if (descriptor.inline?.kind === "clear") return selectionBlockIds(state.selection).length > 0 || resolveInlineSelectionTarget(state.selection) != null;
		if (descriptor.inline) return resolveInlineSelectionTarget(state.selection) != null || selectionBlockIds(state.selection).length > 0;
		if (descriptor.blockParagraph || descriptor.list) return selectionBlockIds(state.selection).length > 0;
		if (descriptor.link) return linkPayloadHasExplicitTarget(payload) || selectionTextAddresses(state.selection).length > 0 || collapsedTextAddressFromSelection(state.selection) != null || commandActiveState(descriptor, getDoc(), state.selection);
		return true;
	};
	const commandNeedsFreshSelection = (id, payload) => {
		const trackCommand = trackDecisionCommand(id);
		const descriptor = getCommandDescriptor(id);
		if (trackCommand?.scope !== "id" && !descriptorNeedsFreshSelection(descriptor)) return false;
		return !commandSelectionIsReady(id, descriptor, payload);
	};
	const prepareCommandSelectionAsync = (id, payload) => {
		if (!commandNeedsFreshSelection(id, payload)) return null;
		return readSelectionInfoFresh().then(() => void 0);
	};
	const executeCommand = (id, payload, context) => {
		pendingCommandSettlement = null;
		lastCommandSettlement = Promise.resolve(false);
		if (disposed) return false;
		const custom = customCommands.get(id);
		if (custom) try {
			const result = custom.execute(buildCustomCommandContext(payload, context));
			return settleCommandExecution(result);
		} catch {
			return false;
		}
		const listKind = listToggleKind(id);
		if (listKind) {
			if (readDocumentMode() === "viewing") return false;
			if (typeof (getEditCommands()?.lists)?.apply === "function") return executeListToggleCommand(listKind, payload);
		}
		const trackCommand = trackDecisionCommand(id);
		if (trackCommand) return executeTrackDecisionCommand(trackCommand, payload);
		if (id === "copy-format") return settleCommandExecution(executeCopyFormat());
		const descriptor = getCommandDescriptor(id);
		if (!descriptor || descriptor.disposition !== "routed") return false;
		const normalized = descriptor.normalizePayload ? descriptor.normalizePayload(payload) : payload;
		if (descriptor.instanceRoute) {
			if (!getEditor()) return false;
			if (!instanceCommandPayloadIsValid(descriptor, normalized)) return false;
			const method = superdoc?.[descriptor.instanceRoute];
			if (typeof method !== "function") return false;
			try {
				const arg = descriptor.fixedArg !== void 0 ? descriptor.fixedArg : normalized;
				const result = method.call(superdoc, arg);
				return settleCommandExecution(result);
			} catch {
				return false;
			}
		}
		if (descriptor.inline?.kind === "clear") {
			if (descriptor.mutates && readDocumentMode() === "viewing") return false;
			return settleCommandExecution(executeClearFormattingCommand());
		}
		const route = descriptor.docRoute;
		if (!route) return false;
		if (descriptor.mutates && readDocumentMode() === "viewing") return false;
		const doc = getDoc();
		const op = resolveDocOperation(doc, route);
		if (!op) return false;
		if (descriptor.inline) {
			const { lockModesById } = computeActiveContentControlLockModes(doc?.contentControls, state.selection);
			if (contentControlLockReason(lockModesById)) return false;
			const target = resolveInlineSelectionTarget(state.selection);
			if (!target) {
				if (state.selection.empty === false) return settleCommandExecution(false);
				return settleCommandExecution(storePendingInlineFormat(descriptor, normalized));
			}
			const active = commandActiveState(descriptor, doc, state.selection);
			const input = buildInlineFormatInput(descriptor.inline, target, normalized, active);
			if (!input) return false;
			let releaseScheduledMutation = null;
			try {
				const commandEditor = getEditor();
				const commandMode = readDocumentMode();
				const mutate = () => {
					if (getEditor() !== commandEditor || getDoc() !== doc || readDocumentMode() !== commandMode) return false;
					return callInlineFormatMutation(route, op, input);
				};
				const selectionSignature = selectionInlineValueSignature(state.selection) ?? selectionKey(state.selection);
				const scheduledMutation = descriptor.inline.kind === "toggle" ? scheduleInlineToggleMutation(`${descriptor.id}:${selectionSignature}`, mutate) : null;
				releaseScheduledMutation = scheduledMutation?.release ?? null;
				const mutationResult = scheduledMutation ? scheduledMutation.result : mutate();
				const optimisticGeneration = captureOptimisticInlineToggle(descriptor, state.selection, input, mutationResult);
				const result = decorateInlineCommandResult(descriptor, state.selection, input, mutationResult);
				const immediate = settleCommandExecution(result, (settled) => {
					settleOptimisticInlineToggle(descriptor, optimisticGeneration, settled);
					releaseScheduledMutation?.();
					releaseScheduledMutation = null;
				});
				if (descriptor.inline.kind === "toggle") lastInlineToggleCommandSettlement = lastCommandSettlement;
				return immediate;
			} catch {
				releaseScheduledMutation?.();
				return false;
			}
		}
		if (descriptor.blockParagraph) {
			const result = executeBlockParagraph(descriptor, op, normalized);
			const optimisticAlignmentGeneration = descriptor.blockParagraph.kind === "alignment" && commandResultSucceeded(result) ? armOptimisticParagraphAlignment(state.selection, normalized) : null;
			return settleCommandExecution(result, (settled) => {
				settleOptimisticParagraphAlignment(optimisticAlignmentGeneration, settled);
			});
		}
		if (descriptor.list) {
			const result = executeListCommand(descriptor, op);
			return settleCommandExecution(result);
		}
		if (descriptor.link) {
			const result = executeLinkCommand(normalized);
			return settleCommandExecution(result);
		}
		if (descriptor.create) {
			const result = executeCreateCommand(descriptor, op, normalized);
			return settleCommandExecution(result);
		}
		if (descriptor.table) {
			const result = executeTableCommand(descriptor, op);
			return settleCommandExecution(result);
		}
		try {
			return settleCommandExecution(descriptor.mutates ? callEditorMutation(route, op, normalized) : op(normalized));
		} catch {
			return false;
		}
	};
	const exitFormatPainter = () => {
		painterCaptureEpoch += 1;
		painter = {
			mode: "idle",
			snapshot: null,
			sourceSelectionKey: null,
			lastClickAt: painter.lastClickAt,
			pointerSelecting: false,
			keyboardSelecting: false
		};
		for (const cb of painterModeListeners) cb("idle");
		recompute();
	};
	const executeCopyFormat = async () => {
		const visibleActiveMarksAtClick = [
			"bold",
			"italic",
			"underline",
			"strikethrough"
		].filter((id) => state.toolbar.commands[id]?.active === true);
		const inlineToggleSettlement = await lastInlineToggleCommandSettlement;
		await inlineToggleMutationIdle;
		const visibleActiveMarks = commandResultSucceeded(inlineToggleSettlement) ? visibleActiveMarksAtClick : [];
		const DOUBLE_CLICK_MS = 500;
		const now = Date.now();
		if (painter.mode !== "idle") {
			if (painter.mode === "armed" && now - painter.lastClickAt < DOUBLE_CLICK_MS) {
				painter = {
					...painter,
					mode: "persistent",
					lastClickAt: now
				};
				for (const cb of painterModeListeners) cb("persistent");
				recompute();
				return true;
			}
			exitFormatPainter();
			return false;
		}
		const persistent = now - painter.lastClickAt < DOUBLE_CLICK_MS;
		const captureEpoch = ++painterCaptureEpoch;
		painter = {
			...painter,
			lastClickAt: now
		};
		const captureSlice = await readSelectionInfoFresh();
		const sourceKey = `${selectionKey(captureSlice)}:${contentToken()}`;
		const painterSnapshot = await captureFormatPainter(null, captureSlice, sourceKey && sourceKey === frozenProjectedValuesKey ? frozenProjectedValues : void 0, visibleActiveMarks);
		if (captureEpoch !== painterCaptureEpoch) return true;
		painter = {
			...painter,
			mode: persistent ? "persistent" : "armed",
			snapshot: painterSnapshot,
			sourceSelectionKey: selectionKey(captureSlice),
			lastClickAt: now
		};
		for (const cb of painterModeListeners) cb(painter.mode);
		recompute();
		return true;
	};
	const captureFormatPainter = async (selection, captureSlice, captureProjected, visibleActiveMarks = []) => {
		const selTarget = captureSlice?.target ?? selection?.target;
		if (!selTarget || selTarget["kind"] !== "text") return null;
		const segments = Array.isArray(selTarget["segments"]) ? selTarget["segments"] : [];
		if (segments.length === 0) return null;
		const doc = getDoc();
		if (!doc) return null;
		const sourceStory = selTarget["story"];
		let mergedRunProps = null;
		for (const segment of segments) {
			const node = (await readBlockNode(paragraphTarget(segment["blockId"], sourceStory)))?.["node"] ?? null;
			if (!node) continue;
			const para = getParagraphLikeData(node);
			const runs = Array.isArray(para?.["inlines"]) ? para["inlines"] : [];
			const slicedProps = sliceAndIntersectRunProps(runs, segment["range"]);
			if (!mergedRunProps) mergedRunProps = slicedProps;
			else mergedRunProps = intersectRunProps(mergedRunProps, slicedProps);
		}
		const inlinePatch = mergedRunProps ? sdRunPropsToInlineRunPatch(mergedRunProps) : {};
		const MARK_TO_PATCH = {
			bold: "bold",
			italic: "italic",
			underline: "underline",
			strikethrough: "strike"
		};
		const activeMarks = /* @__PURE__ */ new Set([...captureSlice?.activeMarks ?? (Array.isArray(selection?.["activeMarks"]) ? selection["activeMarks"] : []), ...visibleActiveMarks]);
		for (const [markName, patchKey] of Object.entries(MARK_TO_PATCH)) if (activeMarks.has(markName)) inlinePatch[patchKey] = true;
		const projectedInlineValues = captureProjected ?? await readFormatPainterInlineValues(captureSlice ?? selectionSliceFromInfo(selection, "ready"));
		if (projectedInlineValues.fontFamily) inlinePatch["fontFamily"] = projectedInlineValues.fontFamily;
		if (projectedInlineValues.color) inlinePatch["color"] = projectedInlineValues.color;
		if (projectedInlineValues.highlight) inlinePatch["highlight"] = projectedInlineValues.highlight;
		if (projectedInlineValues.fontSize) {
			const fontSize = Number.parseFloat(projectedInlineValues.fontSize);
			if (!Number.isNaN(fontSize)) inlinePatch["fontSize"] = fontSize;
		}
		let paragraphSnapshot = null;
		if (segments.length === 1) {
			const segment = segments[0];
			const node = (await readBlockNode(paragraphTarget(segment["blockId"], sourceStory)))?.["node"] ?? null;
			if (node) {
				if (getParagraphLikeData(node)) paragraphSnapshot = await extractParagraphSnapshot(node, segment["blockId"], doc, sourceStory);
			}
		}
		return {
			story: sourceStory ?? null,
			inline: inlinePatch,
			paragraph: paragraphSnapshot
		};
	};
	const getParagraphLikeData = (node) => {
		if (!node) return null;
		if (node["kind"] === "paragraph") return node["paragraph"] ?? null;
		if (node["kind"] === "heading") return node["heading"] ?? null;
		return null;
	};
	const sliceAndIntersectRunProps = (runs, range) => {
		const getRunText = (r) => {
			const inner = r["run"];
			return typeof inner?.["text"] === "string" ? inner["text"] : "";
		};
		const getRunProps = (r) => {
			return r["run"]?.["props"];
		};
		if (range.start === range.end) {
			let offset = 0;
			for (const run of runs) {
				const text = getRunText(run);
				const runStart = offset;
				const runEnd = offset + text.length;
				offset = runEnd;
				if (range.start >= runStart && range.start <= runEnd) {
					const rPr = getRunProps(run);
					return rPr ? { ...rPr } : {};
				}
			}
			return {};
		}
		let offset = 0;
		const covered = [];
		for (const run of runs) {
			const text = getRunText(run);
			const runStart = offset;
			const runEnd = offset + text.length;
			offset = runEnd;
			if (runEnd <= range.start || runStart >= range.end) continue;
			const rPr = getRunProps(run);
			if (rPr) covered.push(rPr);
		}
		if (covered.length === 0) return {};
		if (covered.length === 1) return { ...covered[0] };
		return intersectRunProps(covered[0], ...covered.slice(1));
	};
	const intersectRunProps = (base, ...rest) => {
		const result = { ...base };
		for (const other of rest) for (const key of Object.keys(result)) {
			if (!(key in other)) {
				delete result[key];
				continue;
			}
			const a = result[key];
			const b = other[key];
			if (typeof a !== typeof b || JSON.stringify(a) !== JSON.stringify(b)) delete result[key];
		}
		return result;
	};
	const extractParagraphSnapshot = async (node, blockId, doc, story) => {
		const para = getParagraphLikeData(node);
		const props = para["props"] ?? {};
		const styleId = para["styleRef"] ?? null;
		const alignment = props["alignment"] ?? null;
		const spacing = props["spacing"] ?? null;
		const indent = props["indent"] ?? null;
		const indentation = indent ? {
			...indent["left"] != null ? { left: indent["left"] } : {},
			...indent["right"] != null ? { right: indent["right"] } : {},
			...indent["firstLine"] != null ? { firstLine: indent["firstLine"] } : {},
			...indent["hanging"] != null ? { hanging: indent["hanging"] } : {}
		} : null;
		const markRunProps = props["markRunProps"] ?? null;
		const rawNumId = props["numbering"]?.["numId"];
		const numId = typeof rawNumId === "string" ? parseInt(rawNumId, 10) : typeof rawNumId === "number" ? rawNumId : NaN;
		const level = props["numbering"]?.["level"];
		const numbering = !isNaN(numId) ? {
			numId,
			...level != null ? { level } : {}
		} : null;
		let listStyle = null;
		if (numbering && typeof doc["lists"]?.["getState"] === "function") try {
			const listState = await doc["lists"]["getState"]({ target: paragraphTarget(blockId, story) });
			if (listState && typeof doc["lists"]?.["getStyle"] === "function") listStyle = await doc["lists"]["getStyle"](listState) ?? null;
		} catch {}
		return {
			styleId,
			alignment,
			spacing,
			indentation,
			markRunProps,
			numbering,
			listStyle
		};
	};
	const maybeApply = async () => {
		if (painter.mode === "idle") return;
		if (painter.pointerSelecting || painter.keyboardSelecting) return;
		const selectionApi = getDoc()?.selection;
		const readSelection = async () => {
			const rawSelection = typeof selectionApi?.["current"] === "function" ? await Promise.resolve(selectionApi["current"]({ includeText: true })) : readSelectionInfoLive().value;
			return normalizeSelectionInfo(rawSelection);
		};
		const waitForSelectionSettle = () => new Promise((resolve) => setTimeout(resolve, 16));
		const MAX_SELECTION_ATTEMPTS = 8;
		let sel = null;
		let key = "";
		for (let attempt = 0; attempt < MAX_SELECTION_ATTEMPTS; attempt += 1) {
			if (attempt > 0) await waitForSelectionSettle();
			if (painter.mode === "idle" || painter.pointerSelecting || painter.keyboardSelecting) return;
			sel = await readSelection();
			if (!sel || sel["empty"]) continue;
			key = selectionKey(sel);
			if (key === painter.sourceSelectionKey) continue;
			break;
		}
		if (sel && !sel["empty"] && key !== painter.sourceSelectionKey) {
			await applyFormatPainter(sel);
			return;
		}
		if (painter.snapshot?.paragraph) {
			const caretSel = await readSelection();
			if (!caretSel) return;
			if (selectionKey(caretSel) === painter.sourceSelectionKey) return;
			await applyFormatPainter(caretSel);
		}
	};
	const applyFormatPainter = async (selection) => {
		const snap = painter.snapshot;
		if (!snap) {
			if (painter.mode === "armed") exitFormatPainter();
			return;
		}
		const doc = getDoc();
		if (!doc) return;
		const targetSelection = selectionSliceFromInfo(selection, "ready");
		const { lockModesById } = computeActiveContentControlLockModes(doc.contentControls, targetSelection);
		if (contentControlLockReason(lockModesById)) {
			recompute();
			return;
		}
		const selTarget = selection["target"];
		const selectionTarget = selection["selectionTarget"];
		if (!(selection["empty"] === true) && Object.keys(snap.inline).length > 0) {
			const inlineOp = resolveDocOperation(doc, "format.apply");
			if (inlineOp && selectionTarget) try {
				if (!commandResultSucceeded(commandResultFromOperationResult(await Promise.resolve(callInlineFormatMutation("format.apply", inlineOp, {
					target: selectionTarget,
					inline: snap.inline
				}, selection))))) {
					recompute();
					return;
				}
			} catch {
				recompute();
				return;
			}
		}
		if (snap.paragraph) {
			const segments = Array.isArray(selTarget?.["segments"]) ? selTarget["segments"] : [];
			const targetStory = selTarget?.["story"];
			for (const segment of segments) {
				const blockAddress = paragraphTarget(segment["blockId"], targetStory);
				const nodeResult = await readBlockNode(blockAddress);
				const node = nodeResult?.["node"] ?? null;
				const nodeAddress = nodeResult?.["address"] ?? null;
				if (!node) continue;
				const target = {
					kind: "block",
					nodeType: nodeAddress?.["nodeType"] ?? node["kind"] ?? "paragraph",
					nodeId: segment["blockId"],
					...targetStory && typeof targetStory === "object" ? { story: targetStory } : {}
				};
				const { styleId, alignment, spacing, indentation, markRunProps, numbering, listStyle } = snap.paragraph;
				if (styleId) await doc.styles?.paragraph?.setStyle?.({
					target,
					styleId
				});
				if (alignment) await doc.format?.paragraph?.setAlignment?.({
					target,
					alignment
				});
				if (spacing) {
					const sp = spacing;
					const rawLr = sp["lineRule"] ?? "auto";
					const lr = (/* @__PURE__ */ new Set([
						"auto",
						"exact",
						"atLeast"
					])).has(rawLr) ? rawLr : "auto";
					const rawSpacing = {
						...sp["before"] != null ? { before: Math.round(sp["before"] * 20) } : {},
						...sp["after"] != null ? { after: Math.round(sp["after"] * 20) } : {},
						...sp["line"] != null ? {
							line: Math.round(lr === "auto" ? sp["line"] * 240 : sp["line"] * 20),
							lineRule: lr
						} : {}
					};
					await doc.format?.paragraph?.setSpacing?.({
						target,
						...rawSpacing
					});
				}
				if (indentation) {
					const rawIndentation = {
						...indentation.left != null ? { left: pointsToTwips(indentation.left) } : {},
						...indentation.right != null ? { right: pointsToTwips(indentation.right) } : {},
						...indentation.firstLine != null ? { firstLine: pointsToTwips(indentation.firstLine) } : {},
						...indentation.hanging != null ? { hanging: pointsToTwips(indentation.hanging) } : {}
					};
					await doc.format?.paragraph?.setIndentation?.({
						target,
						...rawIndentation
					});
				}
				if (markRunProps) await doc.format?.paragraph?.setMarkRunProps?.({
					target,
					markRunProps
				});
				if (numbering) await doc.format?.paragraph?.setNumbering?.({
					target,
					...numbering
				});
				if (listStyle) {
					if (((await readBlockNode(blockAddress))?.["address"])?.["nodeType"] === "listItem") await doc.lists?.applyStyle?.({
						target: listItemTarget(segment["blockId"], targetStory),
						style: listStyle
					});
					else if (numbering) await doc.format?.paragraph?.setNumbering?.({
						target,
						...numbering
					});
				}
			}
		}
		if (painter.mode === "armed") exitFormatPainter();
		recompute();
	};
	const executeCommandAsync = (id, payload, context) => {
		const prepared = prepareCommandSelectionAsync(id, payload);
		const settlement = prepared ? prepared.then(() => {
			executeCommand(id, payload, context);
			return lastCommandSettlement;
		}) : (() => {
			executeCommand(id, payload, context);
			return lastCommandSettlement;
		})();
		if (getCommandDescriptor(id)?.inline?.kind === "toggle") lastInlineToggleCommandSettlement = settlement;
		return settlement;
	};
	const makeCommandHandle = (id) => ({
		id,
		getState: () => state.toolbar.commands[id] ?? computeCommandState(id, getDoc(), state.selection, projectSelectionInlineValues(state.selection)),
		observe: (listener) => {
			return select((s) => s.toolbar.commands[id] ?? {
				enabled: false,
				active: false,
				supported: false,
				source: "unsupported",
				reason: SUPERDOC_UI_REASONS.commandUnsupported
			}).subscribe(listener);
		},
		execute: (payload) => executeCommand(id, payload),
		executeAsync: (payload) => executeCommandAsync(id, payload)
	});
	const registerCommand = (registration) => {
		customCommands.set(registration.id, registration);
		recompute();
		const unregister = () => {
			customCommands.delete(registration.id);
			recompute();
		};
		return Object.assign(unregister, {
			handle: makeCommandHandle(registration.id),
			unregister
		});
	};
	const selectionSub = sliceHandle((s) => s.selection);
	const selectionSnap = snapshotHandle(selectionSub);
	/**
	* Resolve the host-owned selection apply helper (`editing.selectionTargets`)
	* with a truthful failure reason. `host.getHandles()` throws a
	* `V2EditorHostError` with a lifecycle `reason` while the host is booting or
	* disposed — that is a readiness condition, not a missing capability, so it
	* maps to `not-ready` instead of being swallowed into
	* `host-capability-unavailable`.
	*/
	const getSelectionApplyHelper = () => {
		const host = getHost();
		if (typeof host?.getHandles !== "function") return { reason: SUPERDOC_UI_REASONS.hostCapabilityUnavailable };
		let handles = null;
		try {
			handles = host.getHandles();
		} catch (error) {
			const lifecycle = error?.reason;
			return { reason: lifecycle === "host-not-ready" || lifecycle === "host-disposed" || lifecycle === "editing-mount-required" ? SUPERDOC_UI_REASONS.notReady : SUPERDOC_UI_REASONS.hostCapabilityUnavailable };
		}
		const helper = (handles?.editing)?.selectionTargets;
		if (typeof helper?.apply !== "function") return { reason: SUPERDOC_UI_REASONS.hostCapabilityUnavailable };
		return { helper };
	};
	const activateContentControlChrome = (id) => {
		const host = getHost();
		if (typeof host?.getHandles !== "function") return;
		try {
			const contentControls = (host.getHandles()?.editing)?.contentControls;
			if (typeof contentControls?.activate === "function") contentControls.activate({ id });
		} catch {}
	};
	const selection = {
		get: selectionSnap.get,
		getSnapshot: selectionSnap.getSnapshot,
		subscribe: selectionSnap.subscribe,
		observe: selectionSnap.observe,
		current: () => readSelectionInfoLive().value,
		capture: () => {
			const snapshot = selectionSub.get();
			if (snapshot.empty || !snapshot.target && !snapshot.selectionTarget) return null;
			return {
				...snapshot,
				capturedAt: Date.now()
			};
		},
		restore: (capture) => {
			const done = (result) => {
				recompute();
				return {
					...result,
					success: result.ok
				};
			};
			if (!capture || typeof capture !== "object") return done({
				ok: false,
				reason: SUPERDOC_UI_REASONS.targetUnresolved
			});
			if (!getEditor()) return done({
				ok: false,
				reason: SUPERDOC_UI_REASONS.notReady
			});
			const target = selectionTargetForRestore(capture);
			if (!target) return done({
				ok: false,
				reason: SUPERDOC_UI_REASONS.targetUnresolved
			});
			const resolved = getSelectionApplyHelper();
			if (!("helper" in resolved)) return done({
				ok: false,
				reason: resolved.reason
			});
			try {
				return done(normalizeHostSelectionApplyResult(resolved.helper.apply(target)));
			} catch {
				return done({
					ok: false,
					reason: SUPERDOC_UI_REASONS.hostCapabilityUnavailable
				});
			}
		},
		apply: (target) => {
			if (!getEditor()) return {
				ok: false,
				reason: SUPERDOC_UI_REASONS.notReady
			};
			const resolved = getSelectionApplyHelper();
			if (!("helper" in resolved)) return {
				ok: false,
				reason: resolved.reason
			};
			try {
				const result = resolved.helper.apply(target);
				recompute();
				return normalizeHostSelectionApplyResult(result);
			} catch {
				return {
					ok: false,
					reason: SUPERDOC_UI_REASONS.hostCapabilityUnavailable
				};
			}
		},
		getAnchorRect: (input) => {
			const host = getHost();
			if (typeof host?.getSelectionAnchorRect === "function") {
				const fromHost = safeCall(() => host.getSelectionAnchorRect(input), null);
				if (fromHost && typeof fromHost === "object" && (Number(fromHost.width) > 0 || Number(fromHost.height) > 0)) return fromHost;
				return null;
			}
			return null;
		},
		getRects: (input) => {
			const snapshot = selectionSub.get();
			const target = snapshot.selectionTarget ?? snapshot.target;
			if (snapshot.empty || !target) return [];
			const result = viewport.getRect({
				target,
				relativeTo: input?.relativeTo
			});
			return result.found ? result.rects : [];
		}
	};
	const commands = {
		get ids() {
			return allCommandIds();
		},
		has: (id) => getCommandDescriptor(id) != null || customCommands.has(id),
		get: (id) => makeCommandHandle(id),
		execute: executeCommand,
		executeAsync: executeCommandAsync,
		register: registerCommand,
		getContextMenuItems: (context) => {
			const items = [];
			for (const registration of customCommands.values()) {
				const contribution = registration.contextMenu;
				if (!contribution) continue;
				if (!safeCall(contribution.when ? () => contribution.when(context) : void 0, true)) continue;
				items.push({
					id: registration.id,
					label: contribution.label,
					group: contribution.group,
					order: contribution.order,
					invoke: () => executeCommand(registration.id, void 0, context)
				});
			}
			return items.sort((a, b) => (a.order ?? 0) - (b.order ?? 0) || a.label.localeCompare(b.label));
		}
	};
	const toolbarSnap = snapshotHandle(sliceHandle((s) => s.toolbar));
	const toolbar = {
		get: toolbarSnap.get,
		getSnapshot: () => state.toolbar,
		subscribe: toolbarSnap.subscribe,
		observe: toolbarSnap.observe,
		execute: executeCommand,
		executeAsync: executeCommandAsync
	};
	/**
	* Scroll a resolved document target into view through the host navigation
	* surface (`host.scrollTargetIntoView`). Shared by comments / tracked changes /
	* content controls and the generic `viewport.scrollIntoView`. Alignment
	* defaults to `block: 'center'` / `behavior: 'smooth'` (matching the generic
	* method and v1) so every scroll path lands consistently; callers may
	* override. Fails closed with a stable reason rather than a no-op recompute;
	* a resolved target that cannot be made visible is `target-not-visible`, not
	* `target-unresolved`.
	*/
	const scrollTargetIntoView = async (target, options) => {
		if (!getEditor()) return {
			success: false,
			ok: false,
			reason: SUPERDOC_UI_REASONS.notReady
		};
		if (!target) return {
			success: false,
			ok: false,
			reason: SUPERDOC_UI_REASONS.targetUnresolved
		};
		const host = getHost();
		const scroll = host?.scrollTargetIntoView;
		if (typeof scroll !== "function") return {
			success: false,
			ok: false,
			reason: SUPERDOC_UI_REASONS.hostCapabilityUnavailable
		};
		try {
			const input = {
				target,
				block: options?.block ?? "center",
				behavior: options?.behavior ?? "smooth"
			};
			const result = await Promise.resolve(options?.shouldContinue ? scroll.call(host, input, options.shouldContinue) : scroll.call(host, input));
			if (result && typeof result === "object" && result.success === false) return {
				success: false,
				ok: false,
				reason: coerceSuperDocUIReason(result.reason, SUPERDOC_UI_REASONS.targetUnresolved)
			};
			return {
				success: true,
				ok: true
			};
		} catch {
			return {
				success: false,
				ok: false,
				reason: SUPERDOC_UI_REASONS.hostCapabilityUnavailable
			};
		}
	};
	/**
	* Derive the browser-shell's `importedId` carrier-lookup alias from a
	* public list row's `wordRevisionIds` / `sourceIds` provenance fields,
	* mirroring `create-v2-tracked-changes-adapter.js`'s own derivation
	* (`wordRevisionIds.insert ?? .delete ?? .format ?? sourceIds.wordIdInsert
	* ?? .wordIdDelete ?? .wordIdOther[0]`). A carrier imported from a legacy
	* Word revision id is painted with THIS id, not the canonical public id —
	* `focusTrackedChange`'s carrier lookup only tries it when explicitly
	* passed as `importedId` on an object input (see `scrollTrackChangeIntoView`).
	*/
	const deriveTrackedChangeImportedId = (row) => {
		if (!row || typeof row !== "object") return null;
		const record = row;
		const wordRevisionIds = record.wordRevisionIds && typeof record.wordRevisionIds === "object" ? record.wordRevisionIds : null;
		const sourceIds = record.sourceIds && typeof record.sourceIds === "object" ? record.sourceIds : null;
		const wordIdOther = Array.isArray(sourceIds?.wordIdOther) ? sourceIds.wordIdOther : void 0;
		const candidate = wordRevisionIds?.insert ?? wordRevisionIds?.delete ?? wordRevisionIds?.format ?? sourceIds?.wordIdInsert ?? sourceIds?.wordIdDelete ?? wordIdOther?.[0];
		return typeof candidate === "string" && candidate.length > 0 ? candidate : null;
	};
	/**
	* Scroll a tracked-change target into view, falling back to the v2
	* browser-shell's `focusTrackedChange` (the same mechanism the built-in
	* comments/tracked-changes sidebar uses via `CommentDialog.vue`'s
	* `setFocus`) when the shared host geometry path can't resolve the target.
	* The host's `normalizeGeometryTarget` only understands `text`/`replacement`
	* targets (enriched with painted `segments`) and never `structural`/
	* `formatting` targets, so those always fail the primary path and need this
	* fallback.
	*
	* `story`, when present, is threaded into the fallback input as
	* `trackedChangeStory` — a bare id always resolves to the body story in
	* `focusTrackedChange`'s target resolver, which would collapse a non-body
	* (footnote/header/footer) occurrence onto its body counterpart sharing the
	* same raw id. `importedId`, when present, is threaded in too: the carrier
	* lookup (`buildTrackChangeCarrierLookupIds`) tries it as an ADDITIONAL alias
	* alongside the canonical id, for rows whose painted carrier only matches
	* through a legacy-imported Word revision id, not the canonical public id
	* (`create-v2-tracked-changes-adapter.test.js` pins this alias path as
	* necessary for some rows).
	*/
	const scrollTrackChangeIntoView = async (changeId, target, story, importedId, options) => {
		const primary = await scrollTargetIntoView(target, options);
		if (primary.ok) return primary;
		const trackedChanges = getV2TrackedChanges();
		const focusTrackedChange = trackedChanges?.focusTrackedChange;
		if (typeof focusTrackedChange !== "function") return primary;
		const fallbackInput = story || importedId ? {
			commentId: changeId,
			...story ? { trackedChangeStory: story } : {},
			...importedId ? { importedId } : {}
		} : changeId;
		try {
			const fallbackResult = await Promise.resolve(focusTrackedChange.call(trackedChanges, fallbackInput));
			if (fallbackResult && typeof fallbackResult === "object" && fallbackResult.ok === true) return {
				success: true,
				ok: true
			};
		} catch {}
		return primary;
	};
	/**
	* Resolve a document entity (comment / tracked change) to its anchor target.
	* Prefers the already-loaded list row, falling back to a live `get({ id })`
	* read when the list does not carry the row.
	*/
	const resolveEntityTarget = async (namespace, id, loaded, request) => {
		const requestedStory = namespace === "trackChanges" ? request?.story : void 0;
		const withRequestedStory = (target) => {
			if (!requestedStory || !target || typeof target !== "object") return target;
			const record = target;
			const address = record.address && typeof record.address === "object" ? record.address : null;
			if (record.story || address?.story) return target;
			return {
				...record,
				story: requestedStory
			};
		};
		const readTarget = namespace === "trackChanges" ? readTrackedChangeNavigationTarget : readEntityTarget;
		const loadedRow = loaded.find((row) => entityRowMatchesRequest(row, id, requestedStory));
		const loadedRecord = loadedRow && typeof loadedRow === "object" ? loadedRow : null;
		const moveSide = namespace === "trackChanges" && loadedRecord?.type === "move" && (loadedRecord.subtype === "move-to" || loadedRecord.subtype === "move-from") ? loadedRecord.subtype : null;
		const trackedChangeLookupId = moveSide && typeof loadedRecord?.trackedChangeCanonicalId === "string" ? loadedRecord.trackedChangeCanonicalId : id;
		const readResolvedTarget = (row) => {
			if (!moveSide) return namespace === "trackChanges" ? readTrackedChangeNavigationTarget(row, { preferStableBlock: true }) : readTarget(row);
			const moveTarget = readEntityTarget(row);
			if (moveTarget?.kind !== "move") return null;
			const sideTarget = moveSide === "move-to" ? moveTarget.destination : moveTarget.source;
			return isHostGeometryTarget(sideTarget) ? sideTarget : null;
		};
		const fromList = readTarget(loadedRow);
		const listTargetIsAuthoritative = namespace !== "trackChanges" || !moveSide && isHostGeometryTarget(readEntityTarget(loadedRow));
		if (fromList && listTargetIsAuthoritative) return withRequestedStory(fromList);
		const api = getDoc()?.[namespace];
		const input = namespace === "comments" ? { commentId: id } : {
			id: trackedChangeLookupId,
			...requestedStory ? { story: requestedStory } : {}
		};
		const get = api?.get;
		if (typeof get !== "function") return withRequestedStory(fromList);
		try {
			return withRequestedStory(readResolvedTarget(await Promise.resolve(get.call(api, input))) ?? fromList);
		} catch {
			return withRequestedStory(fromList);
		}
	};
	function patchCommentStatus(commentId, status) {
		if (reviewMutationsAreReadOnly()) return failedReceipt("Comments are read-only.", "DOCUMENT_READONLY");
		if (resolveIsForbidden()) return failedReceipt("Resolving comments is disabled.", "DOCUMENT_READONLY");
		const commentsApi = getDoc()?.comments;
		const op = commentsApi?.patch;
		if (typeof op !== "function") return failedReceipt("comments.patch is unavailable.");
		const fallback = failedReceipt("comments.patch failed.");
		return safeCall(() => settleWorkflowReceipt(op.call(commentsApi, {
			commentId,
			status
		}), fallback), fallback);
	}
	/**
	* The refusal every comment write shares, or `null` when the policy permits.
	*
	* `readOnly` is policy rather than presentation, so it cannot be left to the
	* built-in dialog hiding its affordances: a custom comment UI calls
	* `createFromCapture`, `createFromSelection`, `reply`, and `delete` directly,
	* and the Document API underneath carries no policy of its own. Missing one
	* route fails open on exactly the surface the policy exists for.
	*
	* `allowResolve` is deliberately not checked here — it forbids only the
	* resolve/reopen transition, which `patchCommentStatus` owns.
	*/
	const commentWriteRefusal = () => reviewMutationsAreReadOnly() ? failedReceipt("Comments are read-only.", "DOCUMENT_READONLY") : null;
	const filterCommentsSnapshot = (items, query) => {
		const record = query && typeof query === "object" ? query : null;
		let filtered = Array.from(items);
		if (record?.includeResolved === false) filtered = filtered.filter((item) => item.status !== "resolved");
		const rawOffset = Number(record?.offset);
		const offset = Number.isInteger(rawOffset) && rawOffset > 0 ? rawOffset : 0;
		const rawLimit = Number(record?.limit);
		const end = Number.isInteger(rawLimit) && rawLimit >= 0 ? offset + rawLimit : void 0;
		return filtered.slice(offset, end);
	};
	const commentsSub = sliceHandle((s) => s.comments);
	const commentsSnap = directorySnapshotHandle(commentsSub, select((s) => computeCommentsDirectorySnapshot(s.selection, s.comments)), "comments");
	const comments = {
		get: commentsSnap.get,
		getSnapshot: commentsSnap.getSnapshot,
		subscribe: commentsSnap.subscribe,
		observe: commentsSnap.observe,
		list: (query) => {
			ensureCommentsCatalog();
			const directory = readCommentsDirectory();
			return filterCommentsSnapshot(directory.value ?? commentsSub.get().items, query);
		},
		getById: (commentId) => {
			const fromSnapshot = commentsSub.get().items.find((item) => readEntityId(item) === commentId) ?? null;
			if (fromSnapshot) return fromSnapshot;
			const commentsApi = getDoc()?.comments;
			const result = safeCall(commentsApi?.get ? () => commentsApi.get({ commentId }) : void 0, null);
			return isPromiseLike(result) ? null : result;
		},
		createFromCapture: (capture, input) => {
			const refusal = commentWriteRefusal();
			if (refusal) return refusal;
			const commentsApi = getDoc()?.comments;
			const op = commentsApi?.create;
			if (typeof op !== "function") return failedReceipt("comments.create is unavailable.");
			const fallback = failedReceipt("comments.create failed.");
			return safeCall(() => {
				const target = capture && typeof capture === "object" ? capture.target ?? capture.selectionTarget : null;
				if (target == null) return failedReceipt("A range selection is required to comment.", "NO_SELECTION");
				return settleWorkflowReceipt(op.call(commentsApi, {
					target,
					text: input.text
				}), fallback);
			}, fallback);
		},
		createFromSelection: (input) => {
			const refusal = commentWriteRefusal();
			if (refusal) return refusal;
			const commentsApi = getDoc()?.comments;
			const op = commentsApi?.create;
			if (typeof op !== "function") return failedReceipt("comments.create is unavailable.");
			const snapshot = selectionSub.get();
			const target = snapshot.target ?? snapshot.selectionTarget;
			if (snapshot.empty || !target) return failedReceipt("A range selection is required to comment.", "NO_SELECTION");
			const fallback = failedReceipt("comments.create failed.");
			return safeCall(() => settleWorkflowReceipt(op.call(commentsApi, {
				target,
				text: input.text
			}), fallback), fallback);
		},
		reply: (commentId, input) => {
			const refusal = commentWriteRefusal();
			if (refusal) return refusal;
			const commentsApi = getDoc()?.comments;
			const op = commentsApi?.reply ?? commentsApi?.create;
			if (typeof op !== "function") return failedReceipt("comments.reply is unavailable.");
			const fallback = failedReceipt("comments.reply failed.");
			return safeCall(() => settleWorkflowReceipt(op === commentsApi?.reply ? op.call(commentsApi, {
				parentCommentId: commentId,
				text: input.text
			}) : op.call(commentsApi, {
				parentCommentId: commentId,
				text: input.text
			}), fallback), fallback);
		},
		edit: (commentId, input) => {
			const refusal = commentWriteRefusal();
			if (refusal) return refusal;
			const commentsApi = getDoc()?.comments;
			const op = commentsApi?.patch;
			if (typeof op !== "function") return failedReceipt("comments.patch is unavailable.");
			const fallback = failedReceipt("comments.patch failed.");
			return safeCall(() => settleWorkflowReceipt(op.call(commentsApi, {
				commentId,
				text: input.text
			}), fallback), fallback);
		},
		resolve: (commentId) => patchCommentStatus(commentId, "resolved"),
		reopen: (commentId) => patchCommentStatus(commentId, "active"),
		delete: (commentId) => {
			const refusal = commentWriteRefusal();
			if (refusal) return refusal;
			const commentsApi = getDoc()?.comments;
			const op = commentsApi?.delete ?? commentsApi?.remove;
			if (typeof op !== "function") return failedReceipt("comments.delete is unavailable.");
			const fallback = failedReceipt("comments.delete failed.");
			return safeCall(() => settleWorkflowReceipt(op.call(commentsApi, { commentId }), fallback), fallback);
		},
		setActive: (commentId) => {
			if (commentId == null) {
				explicitActiveCommentId = null;
				recompute();
				return true;
			}
			if (!getEditor()) return false;
			const snapshot = commentsSub.get();
			const directory = asyncReads.get("comments");
			const directoryItems = directory?.token === contentToken() && directory.hasSettled && Array.isArray(directory.value) ? directory.value : null;
			const items = directoryItems ?? snapshot.items;
			if (!directoryItems && snapshot.listStatus !== "ready") return false;
			const resolvedId = resolveActiveCommentId(items, commentId);
			if (!resolvedId) return false;
			if (!items.some((entry) => readEntityId(entry) === resolvedId)) return false;
			explicitActiveCommentId = resolvedId;
			recompute();
			return true;
		},
		scrollTo: async (commentId) => {
			if (!getDoc()) return {
				success: false,
				ok: false,
				reason: getEditor() ? SUPERDOC_UI_REASONS.documentApiUnavailable : SUPERDOC_UI_REASONS.notReady
			};
			const target = await resolveEntityTarget("comments", commentId, commentsSub.get().items);
			if (!target) return {
				success: false,
				ok: false,
				reason: SUPERDOC_UI_REASONS.targetUnresolved
			};
			return scrollTargetIntoView(target);
		}
	};
	const trackChangesSub = sliceHandle((s) => s.trackChanges);
	const navigateTrackChange = (step, options) => {
		ensureTrackChangesCatalog();
		const allRows = (readTrackChangesDirectory().value ?? trackChangesSub.get().items).map(projectTrackChangesItem).filter((item) => item != null && readEntityId(item) !== null);
		if (allRows.length === 0) return null;
		const currentId = state.trackChanges.activeId;
		const currentStory = explicitActiveChange?.id === currentId ? explicitActiveChange.story : void 0;
		const bodyRows = allRows.filter((row) => readEntityRequestStory(row) == null);
		const rows = currentStory || bodyRows.length === 0 ? allRows : bodyRows;
		let currentIdx = currentId ? rows.findIndex((row) => entityRowMatchesRequest(row, currentId, currentStory)) : -1;
		if (currentIdx === -1 && currentId && currentStory) currentIdx = rows.findIndex((row) => entityRowMatchesRequest(row, currentId));
		const nextRow = rows[currentIdx === -1 ? step > 0 ? 0 : rows.length - 1 : (currentIdx + step + rows.length) % rows.length];
		const activeId = readEntityId(nextRow);
		const story = readEntityRequestStory(nextRow);
		setExplicitActiveChange(story ? {
			id: activeId,
			story
		} : { id: activeId }, options);
		recompute();
		return activeId;
	};
	const restampVisibleTrackedChangeCarrierAliases = async (publicId) => {
		const v2TrackedChanges = getV2TrackedChanges();
		const listTrackedChanges = v2TrackedChanges?.listTrackedChanges;
		if (typeof listTrackedChanges !== "function") return;
		try {
			await Promise.resolve(listTrackedChanges.call(v2TrackedChanges, {
				mode: "visible-window",
				targetIds: [publicId],
				refreshReason: "ui-track-change-reveal-restamp",
				blocking: true
			}));
		} catch {}
	};
	let trackChangeNavigationTail = Promise.resolve();
	const navigateAndScrollNow = (step) => {
		const requestedAtInvalidation = queuedTrackChangeNavigationInvalidation;
		return trackChangeNavigationTail.catch(() => void 0).then(() => navigateAndScrollCurrentRequest(step, requestedAtInvalidation));
	};
	const navigateAndScrollCurrentRequest = async (step, requestedAtInvalidation) => {
		if (queuedTrackChangeNavigationInvalidation !== requestedAtInvalidation) return { success: false };
		const previousActiveChange = explicitActiveChange;
		const activeId = navigateTrackChange(step, { invalidateQueuedNavigation: false });
		if (activeId == null) return { success: false };
		const optimisticActiveChange = explicitActiveChange;
		const optimisticRevision = explicitActiveChangeRevision;
		const isCurrent = () => queuedTrackChangeNavigationInvalidation === requestedAtInvalidation && explicitActiveChange === optimisticActiveChange && explicitActiveChangeRevision === optimisticRevision;
		const rollback = () => {
			if (!isCurrent()) return;
			setExplicitActiveChange(previousActiveChange, { invalidateQueuedNavigation: false });
			recompute();
		};
		if (optimisticActiveChange) pendingTrackChangeRevealFocuses.add(optimisticActiveChange);
		try {
			const target = await resolveEntityTarget("trackChanges", activeId, trackChangesSub.get().items, optimisticActiveChange?.story ? { story: optimisticActiveChange.story } : void 0);
			if (!isCurrent()) return { success: false };
			if (!target) {
				rollback();
				return { success: false };
			}
			const activeRow = trackChangesSub.get().items.find((item) => entityRowMatchesRequest(item, activeId, optimisticActiveChange?.story)) ?? trackChangesSub.get().items.find((item) => readEntityId(item) === activeId);
			const importedId = deriveTrackedChangeImportedId(activeRow);
			trackedChangeNavigationInFlight += 1;
			try {
				const result = await scrollTrackChangeIntoView(activeId, target, optimisticActiveChange?.story, importedId, {
					behavior: "auto",
					shouldContinue: isCurrent
				});
				if (!isCurrent()) return { success: false };
				if (!result.ok && result.reason !== SUPERDOC_UI_REASONS.targetNotVisible) {
					rollback();
					mirrorTrackedChangeFocusToHost(previousActiveChange);
				} else {
					if (result.ok) await restampVisibleTrackedChangeCarrierAliases(activeId);
					if (!isCurrent()) return { success: false };
					mirrorTrackedChangeFocusToHost(optimisticActiveChange);
				}
				return { success: result.ok };
			} finally {
				trackedChangeNavigationInFlight = Math.max(0, trackedChangeNavigationInFlight - 1);
				if (trackedChangeNavigationInFlight === 0) {
					if (!isCurrent()) mirrorTrackedChangeFocusToHost(explicitActiveChange);
					else if (currentHostReviewSource) syncTrackedChangeFocusFromHostReviewTarget(readHostActiveReviewTarget(currentHostReviewSource));
				}
			}
		} finally {
			if (optimisticActiveChange) pendingTrackChangeRevealFocuses.delete(optimisticActiveChange);
		}
	};
	const navigateAndScroll = (step) => {
		const run = navigateAndScrollNow(step);
		trackChangeNavigationTail = run.then(() => void 0, () => void 0);
		return run;
	};
	const trackChangesSnap = directorySnapshotHandle(trackChangesSub, select((s) => computeTrackChangesDirectorySnapshot(s.selection, s.trackChanges)), "trackChanges");
	const trackChanges = {
		get: trackChangesSnap.get,
		getSnapshot: trackChangesSnap.getSnapshot,
		subscribe: trackChangesSnap.subscribe,
		observe: trackChangesSnap.observe,
		list: () => {
			ensureTrackChangesCatalog();
			const source = readTrackChangesDirectory().value ?? trackChangesSub.get().items;
			const suppressed = postDecisionTrackChangeIdsForToken(contentToken());
			return source.map(projectTrackChangesItem).filter((item) => item != null).filter((item) => {
				const id = readEntityId(item);
				return !id || !suppressed?.has(id);
			});
		},
		accept: (changeId) => executeTrackDecision("accept", changeId),
		reject: (changeId) => executeTrackDecision("reject", changeId),
		acceptAll: () => executeTrackDecisionTarget("accept", { kind: "all" }, null),
		rejectAll: () => executeTrackDecisionTarget("reject", { kind: "all" }, null),
		next: () => navigateTrackChange(1),
		previous: () => navigateTrackChange(-1),
		navigateNext: () => navigateAndScroll(1),
		navigatePrevious: () => navigateAndScroll(-1),
		getAt: (input) => {
			if (!input || typeof input !== "object" || typeof input.x !== "number" || typeof input.y !== "number") return null;
			const hits = entityAt(input);
			if (hits.length === 0) return null;
			const items = trackChangesSub.get().items;
			let allStoryItems;
			for (const hit of hits) {
				if (hit.type !== "trackedChange") continue;
				let candidates;
				if (hit.story) {
					if (allStoryItems === void 0) allStoryItems = readAllStoryTrackChanges();
					if (!allStoryItems) continue;
					candidates = allStoryItems;
				} else candidates = items;
				const item = candidates.find((candidate) => entityRowMatchesRequest(candidate, hit.id, hit.story));
				if (item) return hit.story ? {
					id: item.id,
					item,
					story: hit.story
				} : {
					id: item.id,
					item
				};
			}
			return null;
		},
		setActive: (input) => {
			if (input == null) {
				setExplicitActiveChange(null);
				mirrorTrackedChangeFocusToHost(null);
				recompute();
				return true;
			}
			if (!getEditor()) return false;
			const requested = typeof input === "string" ? { id: input } : {
				id: input.id,
				story: input.story
			};
			if (typeof requested.id !== "string" || requested.id.length === 0) return false;
			const paintedEntityId = requested.id;
			if (requested.story) {
				const allStoryItems = readAllStoryTrackChanges();
				if (!allStoryItems) return false;
				const publicId = buildStoryScopedTrackedChangeIdContext(allStoryItems, requested.story).toPublicId(requested.id) ?? requested.id;
				if (!allStoryItems.some((row) => entityRowMatchesRequest(row, publicId, requested.story))) return false;
				requested.id = publicId;
			} else {
				const items = readAllStoryTrackChanges() ?? trackChangesSub.get().items;
				const publicId = buildTrackedChangeIdContext(items).toPublicId(requested.id) ?? requested.id;
				const item = items.find((candidate) => readEntityId(candidate) === publicId);
				if (!item) return false;
				requested.id = publicId;
				requested.story = readEntityRequestStory(item);
			}
			if (paintedEntityId !== requested.id) requested.paintedEntityId = paintedEntityId;
			setExplicitActiveChange(requested);
			mirrorTrackedChangeFocusToHost(requested);
			recompute();
			return true;
		},
		scrollTo: async (changeId) => {
			if (!getDoc()) return {
				success: false,
				ok: false,
				reason: getEditor() ? SUPERDOC_UI_REASONS.documentApiUnavailable : SUPERDOC_UI_REASONS.notReady
			};
			queuedTrackChangeNavigationInvalidation += 1;
			trackChangeRevealInvalidation += 1;
			const requestedAtInvalidation = trackChangeRevealInvalidation;
			const loadedItems = trackChangesSub.get().items;
			const publicId = buildTrackedChangeIdContext(loadedItems).toPublicId(changeId) ?? changeId;
			const matchingRow = loadedItems.find((item) => readEntityId(item) === publicId);
			const story = readEntityRequestStory(matchingRow);
			const importedId = deriveTrackedChangeImportedId(matchingRow);
			const previousActiveChange = explicitActiveChange;
			const requestedActiveChange = {
				id: publicId,
				...story ? { story } : {},
				...publicId !== changeId ? { paintedEntityId: changeId } : {}
			};
			pendingTrackChangeRevealFocuses.add(requestedActiveChange);
			try {
				const target = await resolveEntityTarget("trackChanges", publicId, loadedItems, story ? { story } : void 0);
				if (trackChangeRevealInvalidation !== requestedAtInvalidation) return {
					success: false,
					ok: false
				};
				if (!target) return {
					success: false,
					ok: false,
					reason: SUPERDOC_UI_REASONS.targetUnresolved
				};
				setExplicitActiveChange(requestedActiveChange);
				const revealInvalidation = trackChangeRevealInvalidation;
				const optimisticActiveChange = explicitActiveChange;
				const optimisticRevision = explicitActiveChangeRevision;
				const isCurrent = () => trackChangeRevealInvalidation === revealInvalidation && explicitActiveChange === optimisticActiveChange && explicitActiveChangeRevision === optimisticRevision;
				const rollback = () => {
					if (!isCurrent()) return;
					setExplicitActiveChange(previousActiveChange, { invalidateQueuedNavigation: false });
					recompute();
				};
				recompute();
				trackedChangeNavigationInFlight += 1;
				try {
					const result = await scrollTrackChangeIntoView(publicId, target, story, importedId, {
						behavior: "auto",
						shouldContinue: isCurrent
					});
					if (!isCurrent()) return {
						success: false,
						ok: false
					};
					if (!result.ok && result.reason !== SUPERDOC_UI_REASONS.targetNotVisible) {
						rollback();
						mirrorTrackedChangeFocusToHost(previousActiveChange);
					} else {
						if (result.ok) await restampVisibleTrackedChangeCarrierAliases(publicId);
						if (!isCurrent()) return {
							success: false,
							ok: false
						};
						mirrorTrackedChangeFocusToHost(requestedActiveChange);
					}
					return result;
				} finally {
					trackedChangeNavigationInFlight = Math.max(0, trackedChangeNavigationInFlight - 1);
					if (trackedChangeNavigationInFlight === 0) {
						if (!isCurrent()) mirrorTrackedChangeFocusToHost(explicitActiveChange);
						else if (currentHostReviewSource) syncTrackedChangeFocusFromHostReviewTarget(readHostActiveReviewTarget(currentHostReviewSource));
					}
				}
			} finally {
				pendingTrackChangeRevealFocuses.delete(requestedActiveChange);
			}
		}
	};
	const executeTrackDecision = (kind, input) => {
		const { id, story } = typeof input === "string" ? {
			id: input,
			story: void 0
		} : input;
		const target = {
			kind: "id",
			id,
			...story ? { story } : {}
		};
		return executeTrackDecisionTarget(kind, target, id, story);
	};
	const executeTrackDecisionTarget = (kind, target, changeId, story) => {
		try {
			return settleCommandExecution(callTrackDecisionTarget(kind, target, changeId, story));
		} catch {
			return false;
		}
	};
	const callTrackDecisionTarget = (kind, target, changeId, story) => {
		if (reviewMutationsAreReadOnly()) return false;
		const tcApi = getDoc()?.trackChanges;
		const isAllTarget = target.kind === "all" || target.scope === "all";
		const isRangeTarget = target.kind === "range";
		const isMultiIdTarget = target.kind === "ids";
		const permissionIds = isAllTarget ? [] : isMultiIdTarget && Array.isArray(target.ids) ? target.ids.filter((id) => typeof id === "string" && id.length > 0) : changeId ? [changeId] : [];
		if (permissionIds.length > 0 && trackedChangeDecisionPermissionReason(kind, permissionIds)) return false;
		if (bulkTrackDecisionBlockedReason({
			kind,
			scope: isAllTarget ? "all" : "id"
		}, tcApi)) return false;
		const legacyName = isAllTarget ? `${kind}All` : kind;
		const op = !isRangeTarget && !isMultiIdTarget && !story && tcApi && typeof tcApi[legacyName] === "function" ? tcApi[legacyName] : null;
		const decide = tcApi && typeof tcApi.decide === "function" ? tcApi.decide : null;
		if (!op && !decide) return false;
		return op ? op.call(tcApi, changeId ?? {}) : decide.call(tcApi, {
			decision: kind,
			target
		});
	};
	const contentControlsSub = sliceHandle((s) => s.contentControls);
	const findContentControl = (id) => {
		return contentControlsSub.get().items.find((item) => item?.id === id) ?? null;
	};
	const contentControlsSnap = snapshotHandle(contentControlsSub);
	const contentControlsGet = ((input) => {
		if (input === void 0) return contentControlsSnap.get();
		const id = readContentControlRequestId(input);
		return id ? findContentControl(id) : null;
	});
	const contentControls = {
		get: ((input) => {
			if (input !== void 0) ensureContentControlsCatalog("api");
			return contentControlsGet(input);
		}),
		getSnapshot: contentControlsSnap.getSnapshot,
		subscribe: contentControlsSnap.subscribe,
		observe: contentControlsSnap.observe,
		list: () => {
			ensureContentControlsCatalog("api");
			return contentControlsSub.get().items;
		},
		getById: (id) => {
			ensureContentControlsCatalog("api");
			return findContentControl(id);
		},
		getRect: (input) => {
			const id = readContentControlRequestId(input);
			if (!id) return rectFailure("unresolved");
			ensureContentControlsCatalog("panel");
			const control = findContentControl(id);
			if (!control) return rectFailure("unresolved");
			const target = readSelectionTarget(control);
			if (!target) return rectFailure("unavailable");
			return viewport.getRect({ target });
		},
		scrollIntoView: async (input) => {
			const id = readContentControlRequestId(input);
			if (!id) return { success: false };
			ensureContentControlsCatalog("panel");
			const control = findContentControl(id);
			if (!control) return { success: false };
			const target = readSelectionTarget(control);
			if (!target) return { success: false };
			return { success: (await scrollTargetIntoView(target, {
				block: input.block,
				behavior: input.behavior
			})).ok };
		},
		focus: async (input) => {
			const id = readContentControlRequestId(input);
			if (!id) return {
				success: false,
				reason: "invalid-id"
			};
			if (!getEditor()) return {
				success: false,
				reason: "not-ready"
			};
			ensureContentControlsCatalog("panel");
			const control = findContentControl(id);
			if (!control) return {
				success: false,
				reason: "not-found"
			};
			const target = readSelectionTarget(control);
			if (!target) return {
				success: false,
				reason: "not-reachable"
			};
			if (!(await scrollTargetIntoView(target, {
				block: input.block,
				behavior: input.behavior
			})).ok) return {
				success: false,
				reason: "not-reachable"
			};
			const caretTarget = collapseSelectionTargetToCaret(target);
			if (!caretTarget) return {
				success: false,
				reason: "not-reachable"
			};
			const applyResult = selection.apply(caretTarget);
			if (!applyResult.ok && applyResult.reason !== SUPERDOC_UI_REASONS.hostCapabilityUnavailable) return {
				success: false,
				reason: "not-reachable"
			};
			activateContentControlChrome(id);
			return { success: true };
		}
	};
	const fontsSnap = snapshotHandle(sliceHandle((s) => s.fonts));
	const fonts = {
		get: fontsSnap.get,
		getSnapshot: fontsSnap.getSnapshot,
		subscribe: fontsSnap.subscribe,
		observe: fontsSnap.observe,
		getFamilyOptions: () => state.fonts.options,
		getSizeOptions: () => state.fonts.sizeOptions
	};
	const zoomSnap = snapshotHandle(sliceHandle((s) => s.zoom));
	const zoom = {
		get: zoomSnap.get,
		getSnapshot: zoomSnap.getSnapshot,
		subscribe: zoomSnap.subscribe,
		observe: zoomSnap.observe,
		set: (value) => {
			if (typeof superdoc?.setZoom === "function") try {
				superdoc.setZoom(value);
				recompute();
			} catch {}
		},
		setMode: (mode) => {
			if (typeof superdoc?.setZoomMode === "function") try {
				superdoc.setZoomMode(mode);
				recompute();
			} catch {}
		}
	};
	const documentSnap = snapshotHandle(sliceHandle((s) => s.document));
	const documentHandle = {
		get: documentSnap.get,
		getSnapshot: documentSnap.getSnapshot,
		subscribe: documentSnap.subscribe,
		observe: documentSnap.observe,
		setMode: (mode) => {
			if (typeof superdoc?.setDocumentMode === "function") try {
				superdoc.setDocumentMode(mode);
				recompute();
			} catch {}
		},
		export: (input) => {
			if (typeof superdoc?.export === "function") try {
				return Promise.resolve(superdoc.export(input));
			} catch {
				return;
			}
		},
		getText: () => {
			const doc = getDoc();
			const result = safeCall(doc?.getText ? () => doc.getText({}) : void 0, null);
			if (typeof result === "string") return result;
			if (result && typeof result === "object" && typeof result.text === "string") return result.text;
			return null;
		},
		replaceFile: (file) => {
			const op = superdoc?.replaceFile ?? superdoc?.loadDocument ?? superdoc?.reload;
			if (typeof op === "function") try {
				return Promise.resolve(op.call(superdoc, file));
			} catch {
				return;
			}
		}
	};
	const resolveVisibleHost = () => {
		if (typeof HTMLElement === "undefined") return null;
		const mountContainer = (getEditor()?.mount)?.container;
		if (mountContainer instanceof HTMLElement) return mountContainer;
		const root = superdoc?.element;
		if (root instanceof HTMLElement) return root;
		return null;
	};
	const pointEntityHits = (x, y) => {
		if (typeof x !== "number" || typeof y !== "number" || !Number.isFinite(x) || !Number.isFinite(y)) return [];
		const dom = globalThis.document;
		if (!dom || typeof dom.elementFromPoint !== "function") return [];
		const container = resolveVisibleHost();
		if (!container) return [];
		const startEl = dom.elementFromPoint(x, y);
		if (!startEl || !container.contains(startEl)) return [];
		const primaryEls = [startEl];
		const addPrimaryEl = (el) => {
			if (el && container.contains(el) && !primaryEls.includes(el)) primaryEls.push(el);
		};
		const elementsFromPoint = dom.elementsFromPoint;
		if (typeof elementsFromPoint === "function") {
			let stacked = [];
			try {
				stacked = elementsFromPoint.call(dom, x, y) ?? [];
			} catch {
				stacked = [];
			}
			for (const el of stacked) addPrimaryEl(el);
		}
		const markerEls = [];
		const addMarkerEl = (el) => {
			if (el && container.contains(el) && !markerEls.includes(el) && !primaryEls.includes(el)) markerEls.push(el);
		};
		const pointInRect = (el) => {
			const getRect = el.getBoundingClientRect;
			if (typeof getRect !== "function") return false;
			let rect;
			try {
				rect = getRect.call(el);
			} catch {
				return false;
			}
			return rect != null && x >= rect.left && x <= rect.right && y >= rect.top && y <= rect.bottom;
		};
		for (const el of primaryEls) {
			const queryAll = el.querySelectorAll;
			if (typeof queryAll !== "function") continue;
			let markers;
			try {
				markers = queryAll.call(el, "[data-track-change-marker]");
			} catch {
				continue;
			}
			for (let i = 0; i < markers.length; i += 1) if (pointInRect(markers[i])) addMarkerEl(markers[i]);
		}
		markerEls.reverse();
		const startEls = [...markerEls, ...primaryEls];
		const rawHits = collectEntityHitsFromChain(startEls[0], container);
		for (let i = 1; i < startEls.length; i += 1) for (const hit of collectEntityHitsFromChain(startEls[i], container)) rawHits.push(hit);
		if (rawHits.length === 0) return rawHits;
		const items = trackChangesSub.get().items;
		const idContext = buildTrackedChangeIdContext(items);
		let allStoryItems;
		const seen = /* @__PURE__ */ new Set();
		const hits = [];
		for (const hit of rawHits) {
			if (hit.type !== "trackedChange") {
				const key = `${hit.type}:${hit.id}`;
				if (seen.has(key)) continue;
				seen.add(key);
				hits.push(hit);
				continue;
			}
			const story = storyKeyToStoryLocator(hit.storyKey) ?? layoutStoryDatasetToStoryLocator(hit.story);
			let publicId;
			if (story) {
				if (allStoryItems === void 0) allStoryItems = readAllStoryTrackChanges();
				if (!allStoryItems) continue;
				publicId = buildStoryScopedTrackedChangeIdContext(allStoryItems, story).toPublicId(hit.id);
				if (!publicId || !allStoryItems.some((item) => entityRowMatchesRequest(item, publicId, story))) continue;
			} else {
				publicId = idContext.toPublicId(hit.id);
				if (!publicId) continue;
			}
			const key = `trackedChange:${publicId}`;
			if (seen.has(key)) continue;
			seen.add(key);
			hits.push(story ? {
				type: "trackedChange",
				id: publicId,
				story
			} : {
				type: "trackedChange",
				id: publicId
			});
		}
		return hits;
	};
	function entityAt(xOrInput, _y) {
		if (typeof xOrInput === "object") return pointEntityHits(xOrInput?.x, xOrInput?.y);
		return null;
	}
	const geometryObservers = /* @__PURE__ */ new Set();
	let geometryReleaseScheduled = false;
	const bindGeometryObserver = (entry) => {
		const host = getHost();
		if (typeof host?.observeGeometry !== "function") return;
		let subscribed = false;
		const off = safeCall(() => {
			const result = host.observeGeometry(() => entry.schedule());
			subscribed = true;
			return result;
		}, null);
		entry.detach = typeof off === "function" ? off : null;
		entry.boundHost = subscribed ? host : null;
	};
	const detachGeometryObserver = (entry) => {
		if (entry.detach) {
			try {
				entry.detach();
			} catch {}
			entry.detach = null;
		}
		entry.boundHost = null;
	};
	/**
	* Move every live geometry subscription to the editor that is now active.
	* Without this, scroll and repaint on the replacement editor never reach a
	* listener that was registered against the previous one, so overlays stop
	* tracking the document while still responding to selection and zoom.
	*/
	/**
	* Release every geometry subscription once a hostless moment turns out to be
	* permanent. Deferred rather than immediate because a null host is ambiguous
	* at the instant it arrives: `registerV2Runtime` unregisters the outgoing
	* runtime and installs the replacement in ONE synchronous block, so a refresh
	* shows up here as a null followed by the new host with nothing in between.
	* By the time a microtask runs, a refresh has already installed its host and a
	* true clear (`removeDocument()`, a fail-closed projection) still has none.
	*/
	const releaseGeometryObserversIfStillHostless = () => {
		geometryReleaseScheduled = false;
		if (disposed || getHost()) return;
		for (const entry of geometryObservers) detachGeometryObserver(entry);
	};
	const scheduleGeometryRelease = () => {
		if (geometryReleaseScheduled) return;
		geometryReleaseScheduled = true;
		if (typeof queueMicrotask === "function") {
			queueMicrotask(releaseGeometryObserversIfStillHostless);
			return;
		}
		Promise.resolve().then(releaseGeometryObserversIfStillHostless);
	};
	const rebindGeometryObservers = () => {
		const host = getHost();
		if (!host) {
			scheduleGeometryRelease();
			return;
		}
		for (const entry of geometryObservers) {
			if (entry.boundHost && entry.boundHost === host) continue;
			detachGeometryObserver(entry);
			bindGeometryObserver(entry);
			entry.schedule();
		}
	};
	activeEditorResetHooks.push(rebindGeometryObservers);
	const viewport = {
		getRect: (input) => {
			const host = getHost();
			const getTargetRects = host?.getTargetRects;
			if (typeof getTargetRects === "function") {
				const res = safeCall(() => getTargetRects.call(host, { target: input.target }), null);
				if (res && typeof res === "object") {
					if (res.success === true && Array.isArray(res.rects)) return relativizeRects(rectResult(res.rects.filter((r) => r != null && typeof r === "object")), input.relativeTo);
					return rectFailure(typeof res.reason === "string" ? res.reason : "unresolved");
				}
				return rectFailure("unresolved");
			}
			return rectFailure("unavailable");
		},
		observe: (listener) => {
			const unsubs = [];
			let frame = 0;
			const hasRaf = typeof requestAnimationFrame === "function";
			const schedule = () => {
				if (!hasRaf) {
					listener();
					return;
				}
				if (frame) return;
				frame = requestAnimationFrame(() => {
					frame = 0;
					listener();
				});
			};
			const sub = select((s) => ({
				ready: s.ready,
				selection: s.selection,
				zoom: s.zoom
			}));
			unsubs.push(sub.subscribe(() => schedule()));
			const entry = {
				schedule,
				detach: null,
				boundHost: null
			};
			bindGeometryObserver(entry);
			geometryObservers.add(entry);
			return () => {
				geometryObservers.delete(entry);
				detachGeometryObserver(entry);
				if (frame && typeof cancelAnimationFrame === "function") cancelAnimationFrame(frame);
				for (const unsub of unsubs.splice(0)) try {
					unsub();
				} catch {}
			};
		},
		getHost: () => resolveVisibleHost(),
		entityAt,
		contextAt: (input) => {
			const validInput = !!input && typeof input.x === "number" && typeof input.y === "number";
			const x = validInput ? input.x : 0;
			const y = validInput ? input.y : 0;
			return {
				point: {
					x,
					y
				},
				entities: validInput ? entityAt({
					x,
					y
				}) : [],
				selection: state.selection,
				position: null,
				insideSelection: false
			};
		},
		scrollIntoView: async (input) => {
			const rawTarget = input?.target;
			if (!rawTarget) return { success: false };
			let target = null;
			if (rawTarget.kind === "entity") {
				const namespace = rawTarget.entityType === "comment" ? "comments" : "trackChanges";
				const items = namespace === "comments" ? commentsSub.get().items : trackChangesSub.get().items;
				const request = rawTarget.entityType === "trackedChange" && rawTarget.story ? { story: rawTarget.story } : void 0;
				target = await resolveEntityTarget(namespace, rawTarget.entityId, items, request);
			} else {
				const asTarget = rawTarget;
				const asAddress = rawTarget;
				const segments = Array.isArray(asTarget.segments) && asTarget.segments.length > 0 ? asTarget.segments : asAddress.blockId && asAddress.range ? [{
					blockId: asAddress.blockId,
					range: asAddress.range
				}] : null;
				if (segments) {
					const story = rawTarget.story;
					target = {
						kind: "text",
						segments,
						...story ? { story } : {}
					};
				}
			}
			if (!target) return { success: false };
			return { success: (await scrollTargetIntoView(target, {
				block: input.block ?? "center",
				behavior: input.behavior ?? "smooth"
			})).ok };
		}
	};
	const readMetadataResolvedTarget = (resolved) => {
		const target = (resolved && typeof resolved === "object" ? resolved : null)?.target;
		return target && typeof target === "object" ? target : null;
	};
	const metadataResolveKey = (id) => `metadata:resolve:${id}`;
	/** Resolve a metadata id to its SelectionTarget, or null when unresolved. */
	const resolveMetadataTarget = (id) => {
		const metaApi = getDoc()?.metadata;
		if (!metaApi || typeof metaApi.resolve !== "function") return null;
		const { value } = readAsync(metadataResolveKey(id), contentToken(), () => metaApi.resolve({ id }), readMetadataResolvedTarget);
		return value;
	};
	const resolveMetadataTargetAsync = async (id) => {
		const metaApi = getDoc()?.metadata;
		if (!metaApi || typeof metaApi.resolve !== "function") return null;
		try {
			const token = contentToken();
			const resolved = await Promise.resolve(metaApi.resolve({ id }));
			if (token !== contentToken()) return null;
			const target = readMetadataResolvedTarget(resolved);
			asyncReads.set(metadataResolveKey(id), {
				token,
				value: target,
				hasSettled: true,
				inflightToken: null
			});
			return target;
		} catch {
			return null;
		}
	};
	const metadata = {
		getRect: (input) => {
			const metaApi = getDoc()?.metadata;
			if (!metaApi || typeof metaApi.resolve !== "function") return rectFailure("unavailable");
			const target = resolveMetadataTarget(input.id);
			if (!target) return rectFailure("unresolved");
			return viewport.getRect({ target });
		},
		scrollIntoView: async (input) => {
			const target = await resolveMetadataTargetAsync(input.id);
			if (!target) return { success: false };
			return { success: (await scrollTargetIntoView(target, {
				block: input.block,
				behavior: input.behavior
			})).ok };
		}
	};
	const EMPTY_TABLE_CONTEXT = {
		inTable: false,
		tableNodeId: null,
		rowIndex: null,
		columnIndex: null,
		cellNodeId: null,
		rows: null,
		columns: null
	};
	const tables = {
		getContext: () => {
			const context = resolveTableContext();
			if (!context) return { ...EMPTY_TABLE_CONTEXT };
			const table = readHostTableContext()?.table;
			return {
				inTable: true,
				tableNodeId: context.tableNodeId,
				rowIndex: context.rowIndex,
				columnIndex: context.columnIndex,
				cellNodeId: context.cellNodeId,
				rows: typeof table?.rows === "number" ? table.rows : null,
				columns: typeof table?.columns === "number" ? table.columns : null
			};
		},
		isInTable: () => resolveTableContext() != null
	};
	const SEARCH_UNAVAILABLE_SLICE = {
		query: "",
		total: 0,
		activeIndex: -1,
		open: false,
		available: false,
		caseSensitive: false,
		includeDeletedText: false,
		regex: false,
		canReplace: false,
		reason: SUPERDOC_UI_REASONS.searchUnavailable
	};
	let searchState = { ...SEARCH_UNAVAILABLE_SLICE };
	const searchListeners = /* @__PURE__ */ new Set();
	const getHostSearch = () => {
		const search = getHost()?.search;
		return search && typeof search === "object" ? search : null;
	};
	const getEditCommandSearch = () => {
		const search = getEditCommands()?.search;
		return search && typeof search === "object" ? search : null;
	};
	const searchIsAvailable = () => {
		const search = getHostSearch();
		if (search && typeof search.setSession === "function") return true;
		const editSearch = getEditCommandSearch();
		return Boolean(editSearch) && typeof editSearch.query === "function" && typeof editSearch.getState === "function";
	};
	const emitSearch = () => {
		for (const listener of [...searchListeners]) try {
			listener(searchState);
		} catch {}
	};
	const setSearchState = (patch) => {
		searchState = {
			...searchState,
			...patch
		};
		emitSearch();
		return searchState;
	};
	let searchRequestGeneration = 0;
	/**
	* How to tear down the session that is currently open, captured when it was
	* opened.
	*
	* A closure rather than a reference to the facade, because the two search
	* paths are released differently: a host session ends with `host.clear()`,
	* while the worker-backed fallback ends by querying the empty string through
	* `editCommands.search`. Both bind to the editor that owned them, and by the
	* time an active-editor change reaches us `activeEditor` already points at the
	* replacement, so neither is reachable by looking it up again. Capturing the
	* teardown keeps the two paths from drifting apart: whichever one opens a
	* session is the one that says how to close it.
	*/
	let releaseActiveSearchSession = null;
	/** Release whatever session is open, then forget it. */
	const releaseSearchSession = () => {
		const release = releaseActiveSearchSession;
		releaseActiveSearchSession = null;
		if (!release) return;
		safeCall(() => {
			release();
			return null;
		}, null);
	};
	/**
	* Drop everything the previous active editor owned.
	*
	* Three separate hazards. An in-flight async query still holds a generation
	* that is current, so without bumping the token it would resolve and publish
	* the old document's matches into the new one. The slice itself describes a
	* document that is gone: leaving it in place reports a total and an active
	* match for content nobody is looking at any more. And the previous host still
	* holds the session it painted, so without clearing it the old document keeps
	* its highlights and switching back shows a closed slice over a host that
	* still has matches.
	*
	* This closes the session rather than re-running the query against the
	* replacement document. Re-running is a plausible product choice and arguably
	* the nicer one, but it is a feature decision, not the correctness fix, so it
	* is deliberately not made here.
	*/
	const resetSearchForActiveEditorChange = () => {
		searchRequestGeneration += 1;
		releaseSearchSession();
		const available = searchIsAvailable();
		searchState = {
			...SEARCH_UNAVAILABLE_SLICE,
			available,
			reason: available ? void 0 : SUPERDOC_UI_REASONS.searchUnavailable
		};
		emitSearch();
	};
	documentResetHooks.push(resetSearchForActiveEditorChange);
	const readSearchQueryError = (record) => {
		if (!record) return false;
		const queryError = record.queryError;
		if (queryError && typeof queryError === "object" && queryError.code === "invalid-pattern") return true;
		const rejection = record.rejection;
		return record.status === "rejected" && Boolean(rejection) && typeof rejection === "object" && rejection.code === "invalid-pattern";
	};
	const normalizeHostSearchResult = (result, fallbackCanReplace = false) => {
		const record = result && typeof result === "object" ? result : null;
		if (!record) return null;
		const matches = Array.isArray(record.matches) ? record.matches : [];
		const total = typeof record.total === "number" && Number.isFinite(record.total) ? record.total : matches.length;
		const activeIndex = typeof record.activeMatchIndex === "number" ? record.activeMatchIndex : typeof record.activeIndex === "number" ? record.activeIndex : -1;
		return {
			...typeof record.query === "string" ? { query: record.query } : {},
			total,
			activeIndex,
			canReplace: record.canReplace === true || fallbackCanReplace,
			...record.includeDeletedText === true ? { includeDeletedText: true } : {},
			...record.regex === true ? { regex: true } : {},
			...readSearchQueryError(record) ? { invalidPattern: true } : {}
		};
	};
	const readEditCommandCanReplace = () => {
		const replaceEntry = readEditCommandStateEntry("find.replace");
		const replaceAllEntry = readEditCommandStateEntry("find.replaceAll");
		return replaceEntry?.enabled === true || replaceAllEntry?.enabled === true;
	};
	const applyHostSearchResult = (result, fallbackCanReplace = false) => {
		const snapshot = normalizeHostSearchResult(result, fallbackCanReplace);
		if (!snapshot) {
			setSearchState({
				total: 0,
				activeIndex: -1,
				canReplace: false,
				reason: void 0
			});
			return;
		}
		setSearchState({
			...snapshot.query !== void 0 ? { query: snapshot.query } : {},
			total: snapshot.total,
			activeIndex: snapshot.activeIndex,
			canReplace: snapshot.canReplace,
			...snapshot.includeDeletedText !== void 0 ? { includeDeletedText: snapshot.includeDeletedText } : {},
			...snapshot.regex !== void 0 ? { regex: snapshot.regex } : {},
			reason: snapshot.invalidPattern ? SUPERDOC_UI_REASONS.searchInvalidPattern : void 0
		});
	};
	const syncSearchStateFromHost = () => {
		const host = getHostSearch();
		if (host && typeof host.getState !== "function") {
			searchState = {
				...searchState,
				available: searchIsAvailable(),
				reason: searchIsAvailable() ? void 0 : SUPERDOC_UI_REASONS.searchUnavailable
			};
			return searchState;
		}
		if (!host) {
			const editSearch = getEditCommandSearch();
			if (editSearch && typeof editSearch.getState === "function") {
				const editSnapshot = normalizeHostSearchResult(safeCall(() => editSearch.getState(), null), readEditCommandCanReplace());
				if (editSnapshot) {
					searchState = {
						...searchState,
						...editSnapshot.query !== void 0 ? { query: editSnapshot.query } : {},
						total: editSnapshot.total,
						activeIndex: editSnapshot.activeIndex,
						canReplace: editSnapshot.canReplace,
						available: true,
						reason: editSnapshot.invalidPattern ? SUPERDOC_UI_REASONS.searchInvalidPattern : void 0,
						open: searchState.open || Boolean(editSnapshot.query)
					};
					return searchState;
				}
			}
			searchState = {
				...SEARCH_UNAVAILABLE_SLICE,
				query: searchState.query,
				caseSensitive: searchState.caseSensitive,
				includeDeletedText: searchState.includeDeletedText
			};
			return searchState;
		}
		const snapshot = normalizeHostSearchResult(safeCall(() => host.getState(), null));
		if (!snapshot) return searchState;
		searchState = {
			...searchState,
			...snapshot.query !== void 0 ? { query: snapshot.query } : {},
			total: snapshot.total,
			activeIndex: snapshot.activeIndex,
			canReplace: snapshot.canReplace,
			...snapshot.includeDeletedText !== void 0 ? { includeDeletedText: snapshot.includeDeletedText } : {},
			...snapshot.regex !== void 0 ? { regex: snapshot.regex } : {},
			available: true,
			reason: snapshot.invalidPattern ? SUPERDOC_UI_REASONS.searchInvalidPattern : void 0,
			open: searchState.open || Boolean(snapshot.query)
		};
		return searchState;
	};
	const mapHostReplaceResult = (result) => {
		const record = result && typeof result === "object" ? result : null;
		if (record?.status === "committed") return { ok: true };
		if (record?.status === "rejected" && record.reason === "read-only") return {
			ok: false,
			reason: SUPERDOC_UI_REASONS.documentReadonly
		};
		const rejection = record?.rejection;
		if (record?.status === "rejected" && rejection && typeof rejection === "object" && rejection.code === "read-only-document") return {
			ok: false,
			reason: SUPERDOC_UI_REASONS.documentReadonly
		};
		return {
			ok: false,
			reason: SUPERDOC_UI_REASONS.operationUnavailable
		};
	};
	const searchSnap = snapshotHandle({
		get: () => syncSearchStateFromHost(),
		subscribe: (listener) => {
			searchListeners.add(listener);
			return () => searchListeners.delete(listener);
		}
	});
	const search = {
		get: searchSnap.get,
		getSnapshot: searchSnap.getSnapshot,
		subscribe: searchSnap.subscribe,
		observe: searchSnap.observe,
		open: () => {
			if (!searchIsAvailable()) {
				setSearchState({
					available: false,
					open: false,
					reason: SUPERDOC_UI_REASONS.searchUnavailable
				});
				return {
					ok: false,
					reason: SUPERDOC_UI_REASONS.searchUnavailable
				};
			}
			setSearchState({
				available: true,
				open: true,
				reason: void 0
			});
			return { ok: true };
		},
		close: () => {
			searchRequestGeneration += 1;
			if (releaseActiveSearchSession) releaseSearchSession();
			else {
				const host = getHostSearch();
				if (host && typeof host.clear === "function") safeCall(() => host.clear(), null);
				else {
					const editSearch = getEditCommandSearch();
					if (editSearch && typeof editSearch.query === "function") safeCall(() => editSearch.query({ query: "" }), null);
				}
			}
			searchState = {
				...SEARCH_UNAVAILABLE_SLICE,
				available: searchIsAvailable(),
				reason: void 0
			};
			if (!searchState.available) searchState.reason = SUPERDOC_UI_REASONS.searchUnavailable;
			emitSearch();
		},
		search: (query, options) => {
			const host = getHostSearch();
			const caseSensitive = Boolean(options?.caseSensitive);
			const includeDeletedText = options?.includeDeletedText === true;
			const regex = options?.regex === true;
			const generation = ++searchRequestGeneration;
			if (!host || typeof host.setSession !== "function") {
				const editSearch = getEditCommandSearch();
				if (editSearch && typeof editSearch.query === "function" && typeof editSearch.getState === "function") {
					setSearchState({
						query,
						caseSensitive,
						includeDeletedText,
						regex,
						available: true,
						open: true,
						reason: void 0
					});
					releaseActiveSearchSession = () => {
						editSearch.query({ query: "" });
					};
					const result = safeCall(() => editSearch.query({
						query,
						caseSensitive,
						includeDeletedText,
						regex
					}), null);
					if (isPromiseLike(result)) Promise.resolve(result).then((resolved) => {
						if (generation !== searchRequestGeneration) return;
						applyHostSearchResult(resolved, readEditCommandCanReplace());
					}, () => {
						if (generation !== searchRequestGeneration) return;
						setSearchState({
							available: false,
							reason: SUPERDOC_UI_REASONS.searchUnavailable
						});
					});
					else applyHostSearchResult(result, readEditCommandCanReplace());
					applyHostSearchResult(safeCall(() => editSearch.getState(), null), readEditCommandCanReplace());
					return searchState;
				}
				return setSearchState({
					query,
					total: 0,
					activeIndex: -1,
					available: false,
					caseSensitive,
					includeDeletedText,
					regex,
					reason: SUPERDOC_UI_REASONS.searchUnavailable
				});
			}
			setSearchState({
				query,
				caseSensitive,
				includeDeletedText,
				regex,
				available: true,
				open: true,
				reason: void 0
			});
			releaseActiveSearchSession = () => {
				if (typeof host.clear === "function") host.clear();
			};
			const result = safeCall(() => host.setSession(query, {
				caseSensitive,
				includeDeletedText,
				...regex ? { regex: true } : {},
				highlight: true
			}), null);
			applyHostSearchResult(result);
			if (query.length > 0 && searchState.total === 0 && searchState.reason !== SUPERDOC_UI_REASONS.searchInvalidPattern) {
				const editSearch = getEditCommandSearch();
				if (editSearch && typeof editSearch.query === "function" && typeof editSearch.getState === "function") {
					const releaseHostSession = releaseActiveSearchSession;
					releaseActiveSearchSession = () => {
						releaseHostSession?.();
						editSearch.query({ query: "" });
					};
					const commandResult = safeCall(() => editSearch.query({
						query,
						caseSensitive,
						includeDeletedText,
						regex
					}), null);
					if (isPromiseLike(commandResult)) Promise.resolve(commandResult).then((resolved) => {
						if (generation !== searchRequestGeneration) return;
						applyHostSearchResult(resolved, readEditCommandCanReplace());
					}, () => {
						if (generation !== searchRequestGeneration) return;
						setSearchState({
							available: false,
							reason: SUPERDOC_UI_REASONS.searchUnavailable
						});
					});
					else applyHostSearchResult(commandResult, readEditCommandCanReplace());
					applyHostSearchResult(safeCall(() => editSearch.getState(), null), readEditCommandCanReplace());
				}
			}
			return searchState;
		},
		next: () => {
			const host = getHostSearch();
			if (!host || typeof host.next !== "function") {
				const editSearch = getEditCommandSearch();
				if (!editSearch || typeof editSearch.next !== "function" || typeof editSearch.getState !== "function") return {
					ok: false,
					reason: SUPERDOC_UI_REASONS.searchUnavailable
				};
				if (searchState.total === 0) return {
					ok: false,
					reason: SUPERDOC_UI_REASONS.operationUnavailable
				};
				const result = safeCall(() => editSearch.next(), null);
				if (isPromiseLike(result)) {
					const generation = searchRequestGeneration;
					Promise.resolve(result).then((resolved) => {
						if (generation !== searchRequestGeneration) return;
						applyHostSearchResult(resolved, readEditCommandCanReplace());
					}).catch(() => {
						if (generation !== searchRequestGeneration) return;
						setSearchState({
							available: false,
							reason: SUPERDOC_UI_REASONS.searchUnavailable
						});
					});
				} else applyHostSearchResult(result, readEditCommandCanReplace());
				applyHostSearchResult(safeCall(() => editSearch.getState(), null), readEditCommandCanReplace());
				return { ok: true };
			}
			if (searchState.total === 0) return {
				ok: false,
				reason: SUPERDOC_UI_REASONS.operationUnavailable
			};
			applyHostSearchResult(safeCall(() => host.next(), null));
			return { ok: true };
		},
		previous: () => {
			const host = getHostSearch();
			if (!host || typeof host.previous !== "function") {
				const editSearch = getEditCommandSearch();
				if (!editSearch || typeof editSearch.previous !== "function" || typeof editSearch.getState !== "function") return {
					ok: false,
					reason: SUPERDOC_UI_REASONS.searchUnavailable
				};
				if (searchState.total === 0) return {
					ok: false,
					reason: SUPERDOC_UI_REASONS.operationUnavailable
				};
				const result = safeCall(() => editSearch.previous(), null);
				if (isPromiseLike(result)) {
					const generation = searchRequestGeneration;
					Promise.resolve(result).then((resolved) => {
						if (generation !== searchRequestGeneration) return;
						applyHostSearchResult(resolved, readEditCommandCanReplace());
					}).catch(() => {
						if (generation !== searchRequestGeneration) return;
						setSearchState({
							available: false,
							reason: SUPERDOC_UI_REASONS.searchUnavailable
						});
					});
				} else applyHostSearchResult(result, readEditCommandCanReplace());
				applyHostSearchResult(safeCall(() => editSearch.getState(), null), readEditCommandCanReplace());
				return { ok: true };
			}
			if (searchState.total === 0) return {
				ok: false,
				reason: SUPERDOC_UI_REASONS.operationUnavailable
			};
			applyHostSearchResult(safeCall(() => host.previous(), null));
			return { ok: true };
		},
		clear: () => {
			searchRequestGeneration += 1;
			const host = getHostSearch();
			if (host && typeof host.clear === "function") safeCall(() => host.clear(), null);
			if (!host || typeof host.clear !== "function") {
				const editSearch = getEditCommandSearch();
				if (editSearch && typeof editSearch.query === "function") safeCall(() => editSearch.query({ query: "" }), null);
			}
			setSearchState({
				query: "",
				total: 0,
				activeIndex: -1,
				canReplace: false
			});
		},
		replace: (replacement) => {
			const host = getHostSearch();
			if (!host) {
				const editSearch = getEditCommandSearch();
				if (!editSearch || typeof editSearch.replace !== "function" || typeof editSearch.getState !== "function") return {
					ok: false,
					reason: SUPERDOC_UI_REASONS.searchUnavailable
				};
				if (!readEditCommandCanReplace()) return {
					ok: false,
					reason: SUPERDOC_UI_REASONS.operationUnavailable
				};
				const result = safeCall(() => editSearch.replace({ replacement: typeof replacement === "string" ? replacement : "" }), null);
				if (isPromiseLike(result)) {
					const generation = searchRequestGeneration;
					syncSearchStateFromHost();
					emitSearch();
					const isCurrent = () => generation === searchRequestGeneration;
					return Promise.resolve(result).then((resolved) => {
						if (isCurrent()) {
							applyHostSearchResult(resolved, readEditCommandCanReplace());
							syncSearchStateFromHost();
							emitSearch();
						}
						return mapHostReplaceResult(resolved);
					}, () => {
						if (isCurrent()) setSearchState({
							available: false,
							reason: SUPERDOC_UI_REASONS.searchUnavailable
						});
						return {
							ok: false,
							reason: SUPERDOC_UI_REASONS.searchUnavailable
						};
					});
				}
				syncSearchStateFromHost();
				emitSearch();
				return mapHostReplaceResult(result);
			}
			if (typeof host.replaceCurrent !== "function") return {
				ok: false,
				reason: SUPERDOC_UI_REASONS.operationUnavailable
			};
			const result = safeCall(() => host.replaceCurrent(typeof replacement === "string" ? replacement : ""), null);
			syncSearchStateFromHost();
			emitSearch();
			return mapHostReplaceResult(result);
		},
		replaceAll: (replacement) => {
			const host = getHostSearch();
			if (!host) {
				const editSearch = getEditCommandSearch();
				if (!editSearch || typeof editSearch.replaceAll !== "function" || typeof editSearch.getState !== "function") return {
					ok: false,
					reason: SUPERDOC_UI_REASONS.searchUnavailable
				};
				if (!readEditCommandCanReplace()) return {
					ok: false,
					reason: SUPERDOC_UI_REASONS.operationUnavailable
				};
				const result = safeCall(() => editSearch.replaceAll({ replacement: typeof replacement === "string" ? replacement : "" }), null);
				if (isPromiseLike(result)) {
					const generation = searchRequestGeneration;
					syncSearchStateFromHost();
					emitSearch();
					const isCurrent = () => generation === searchRequestGeneration;
					return Promise.resolve(result).then((resolved) => {
						if (isCurrent()) {
							applyHostSearchResult(resolved, readEditCommandCanReplace());
							syncSearchStateFromHost();
							emitSearch();
						}
						return mapHostReplaceResult(resolved);
					}, () => {
						if (isCurrent()) setSearchState({
							available: false,
							reason: SUPERDOC_UI_REASONS.searchUnavailable
						});
						return {
							ok: false,
							reason: SUPERDOC_UI_REASONS.searchUnavailable
						};
					});
				}
				syncSearchStateFromHost();
				emitSearch();
				return mapHostReplaceResult(result);
			}
			if (typeof host.replaceAll !== "function") return {
				ok: false,
				reason: SUPERDOC_UI_REASONS.operationUnavailable
			};
			const result = safeCall(() => host.replaceAll(typeof replacement === "string" ? replacement : ""), null);
			syncSearchStateFromHost();
			emitSearch();
			return mapHostReplaceResult(result);
		}
	};
	const stylesSub = sliceHandle((s) => s.styles);
	const stylesSnap = snapshotHandle(stylesSub);
	const styles = {
		get: stylesSnap.get,
		getSnapshot: stylesSnap.getSnapshot,
		subscribe: stylesSnap.subscribe,
		observe: stylesSnap.observe,
		getCatalog: (options) => readStyleCatalogLive(options).value,
		getQuickGallery: () => stylesSub.get().quickGallery,
		getActiveParagraphStyle: () => computeActiveParagraphStyle(state.selection, getStyleCatalog().cache).style
	};
	const createScope = () => {
		const scopeUnsubs = [];
		return {
			select: (selector, equality) => {
				const sub = select(selector, equality);
				return {
					get: sub.get,
					subscribe: (cb) => {
						const unsub = sub.subscribe(cb);
						scopeUnsubs.push(unsub);
						return unsub;
					}
				};
			},
			dispose: () => {
				for (const unsub of scopeUnsubs.splice(0)) unsub();
			}
		};
	};
	const destroy = () => {
		if (disposed) return;
		disposed = true;
		releaseSharedUiTrackedChangesCatalog(uiTrackedChangesCatalogHost, uiTrackedChangesCatalogState);
		if (foregroundAsyncRetryTimer) {
			clearTimeout(foregroundAsyncRetryTimer);
			foregroundAsyncRetryTimer = null;
		}
		if (asyncReadFailureRetryTimer) {
			clearTimeout(asyncReadFailureRetryTimer);
			asyncReadFailureRetryTimer = null;
			asyncReadFailureRetryAtMs = 0;
		}
		if (pendingEffectiveInlineRead?.timer) {
			clearTimeout(pendingEffectiveInlineRead.timer);
			pendingEffectiveInlineRead.timer = null;
		}
		pendingEffectiveInlineRead = null;
		if (typingContentInvalidationTimer) {
			clearTimeout(typingContentInvalidationTimer);
			typingContentInvalidationTimer = null;
		}
		if (heavyReadCompletionRecomputeTimer) {
			clearTimeout(heavyReadCompletionRecomputeTimer);
			heavyReadCompletionRecomputeTimer = null;
		}
		if (detachSourceLoading) detachSourceLoading();
		detachSourceLoading = null;
		sourceLoadingSubscriptionHost = null;
		commentsDirectoryLeaseCount = 0;
		trackChangesDirectoryLeaseCount = 0;
		demandedHeavyReads.clear();
		incompleteTrackChangesDirectoryReadTokens.clear();
		postSourceCompletionRefreshTokens.clear();
		sourceCompletionObservedToken = null;
		coldAsyncReadDeferrals.clear();
		for (const detach of detachers.splice(0)) detach();
		if (detachHostSelection) detachHostSelection();
		detachHostSelection = null;
		currentHostSelectionSource = null;
		if (detachEditCommands) detachEditCommands();
		detachEditCommands = null;
		currentEditCommandsSource = null;
		if (detachV2ReviewWindow) detachV2ReviewWindow();
		detachV2ReviewWindow = null;
		currentV2ReviewWindowSource = null;
		if (detachHostReview) detachHostReview();
		detachHostReview = null;
		currentHostReviewSource = null;
		if (detachHostEvents) detachHostEvents();
		detachHostEvents = null;
		currentHostEventsSource = null;
		if (detachDocumentSelection) detachDocumentSelection();
		detachDocumentSelection = null;
		currentDocumentSelectionSource = null;
		for (const entry of geometryObservers) detachGeometryObserver(entry);
		geometryObservers.clear();
		listeners.clear();
		searchListeners.clear();
		painterCaptureEpoch += 1;
		painterModeListeners.clear();
		searchRequestGeneration += 1;
		customCommands.clear();
	};
	const controller = {
		select,
		get state() {
			return state;
		},
		selection,
		commands,
		toolbar,
		comments,
		trackChanges,
		contentControls,
		fonts,
		zoom,
		document: documentHandle,
		viewport,
		metadata,
		tables,
		search,
		styles,
		formatPainter: {
			setPointerSelecting(flag) {
				if (disposed) return;
				painter = {
					...painter,
					pointerSelecting: flag
				};
			},
			notifyPointerUp() {
				if (disposed) return;
				painter = {
					...painter,
					pointerSelecting: false
				};
				maybeApply();
			},
			setKeyboardSelecting(flag) {
				if (disposed) return;
				painter = {
					...painter,
					keyboardSelecting: flag
				};
			},
			notifyKeyUp() {
				if (disposed) return;
				painter = {
					...painter,
					keyboardSelecting: false
				};
				maybeApply();
			},
			cancel() {
				if (disposed) return;
				exitFormatPainter();
			},
			onModeChange(cb) {
				if (disposed) return () => {};
				painterModeListeners.add(cb);
				return () => painterModeListeners.delete(cb);
			}
		},
		createScope,
		destroy
	};
	controllerRef = controller;
	return controller;
}
/**
* Default font-family offerings, used to backfill the picker when the active document resolves few
* (or no) fonts and the runtime picker list is unavailable. Values are logical Word family names —
* the formatting command writes them verbatim as logical `w:rFonts` intent; the runtime resolves
* substitutes only at measure/paint time.
*/
var DEFAULT_FONT_FAMILY_OPTIONS = [
	{
		value: "Arial",
		label: "Arial",
		previewFamily: "Arial, sans-serif"
	},
	{
		value: "Calibri",
		label: "Calibri",
		previewFamily: "Calibri, sans-serif"
	},
	{
		value: "Courier New",
		label: "Courier New",
		previewFamily: "\"Courier New\", monospace"
	},
	{
		value: "Georgia",
		label: "Georgia",
		previewFamily: "Georgia, serif"
	},
	{
		value: "Times New Roman",
		label: "Times New Roman",
		previewFamily: "\"Times New Roman\", serif"
	},
	{
		value: "Verdana",
		label: "Verdana",
		previewFamily: "Verdana, sans-serif"
	}
];
/**
* The Word-facing logical family: first family of a CSS stack, quotes stripped.
* Document / command values sometimes carry `"Cambria, serif"`; the picker must
* advertise `Cambria` so it dedupes against picker/default rows.
*/
function canonicalFontFamilyName(family) {
	const trimmed = family.trim();
	const quote = trimmed[0];
	if (quote === "\"" || quote === "'") {
		const close = trimmed.indexOf(quote, 1);
		if (close > 0) return trimmed.slice(1, close).trim();
	}
	const comma = trimmed.indexOf(",");
	return (comma === -1 ? trimmed : trimmed.slice(0, comma)).trim().replace(/^["']|["']$/g, "");
}
/**
* Normalize document-only rows (`DocumentFontOption` with `logicalFamily`) into the custom-UI
* picker shape. Raw document families may be CSS stacks, so canonicalize to the first family.
*/
function normalizeDocumentFontOptions(raw) {
	if (!Array.isArray(raw)) return [];
	const out = [];
	for (const option of raw) {
		if (!option || typeof option !== "object") continue;
		const rec = option;
		const logical = typeof rec.logicalFamily === "string" ? canonicalFontFamilyName(rec.logicalFamily) : "";
		if (!logical) continue;
		const previewFamily = typeof rec.previewFamily === "string" && rec.previewFamily.trim() ? rec.previewFamily.trim() : logical;
		out.push({
			value: logical,
			label: logical,
			previewFamily
		});
	}
	return out;
}
/**
* Normalize picker rows (`FontFamilyOption`) without treating their value as a CSS stack. The font
* runtime has already converted quoted document stacks such as `"Acme, Inc Sans", serif` into the
* exact apply value (`Acme, Inc Sans`), so preserving `value` avoids truncating internal commas.
*/
function normalizePickerFontOptions(raw) {
	if (!Array.isArray(raw)) return [];
	const out = [];
	for (const option of raw) {
		if (!option || typeof option !== "object") continue;
		const rec = option;
		const value = typeof rec.value === "string" ? rec.value.trim() : "";
		if (!value) continue;
		const label = typeof rec.label === "string" && rec.label.trim() ? rec.label.trim() : value;
		const previewFamily = typeof rec.previewFamily === "string" && rec.previewFamily.trim() ? rec.previewFamily.trim() : value;
		out.push({
			value,
			label,
			previewFamily
		});
	}
	return out;
}
/**
* Compose document font options on top of the picker/default rows: document rows lead and win on
* value collisions (case-insensitive), defaults backfill the rest. Order within each group is
* preserved so document-used families stay at the front of the custom-UI picker (SD-3887).
*/
function composeFontFamilyOptions(documentOptions, pickerOptions = []) {
	const out = [];
	const seen = /* @__PURE__ */ new Set();
	const push = (option) => {
		const key = String(option.value).trim().toLowerCase();
		if (!key || seen.has(key)) return;
		seen.add(key);
		out.push(option);
	};
	for (const option of documentOptions) push(option);
	const defaults = pickerOptions.length ? pickerOptions : DEFAULT_FONT_FAMILY_OPTIONS;
	for (const option of defaults) push(option);
	return out;
}
var DEFAULT_FONT_SIZE_OPTIONS = [
	{
		value: "8",
		label: "8"
	},
	{
		value: "9",
		label: "9"
	},
	{
		value: "10",
		label: "10"
	},
	{
		value: "11",
		label: "11"
	},
	{
		value: "12",
		label: "12"
	},
	{
		value: "14",
		label: "14"
	},
	{
		value: "16",
		label: "16"
	},
	{
		value: "18",
		label: "18"
	},
	{
		value: "24",
		label: "24"
	},
	{
		value: "36",
		label: "36"
	}
];
/** Active state for a routed command: true when its mark is live at the selection. */
function commandIsActive(descriptor, selection) {
	return descriptor.activeMark ? selection.activeMarks.includes(descriptor.activeMark) : false;
}
//#endregion
Object.defineProperty(exports, "BUILT_IN_COMMAND_IDS", {
	enumerable: true,
	get: function() {
		return BUILT_IN_COMMAND_IDS;
	}
});
Object.defineProperty(exports, "DOM_CLASS_NAMES", {
	enumerable: true,
	get: function() {
		return DOM_CLASS_NAMES;
	}
});
Object.defineProperty(exports, "createSuperDocUI", {
	enumerable: true,
	get: function() {
		return createSuperDocUI;
	}
});
Object.defineProperty(exports, "getV2TrackedChangeMutationImpact", {
	enumerable: true,
	get: function() {
		return getV2TrackedChangeMutationImpact;
	}
});
Object.defineProperty(exports, "shallowEqual", {
	enumerable: true,
	get: function() {
		return shallowEqual;
	}
});
