const require__plugin_vue_export_helper = require("./_plugin-vue_export-helper-SDR04tiH.cjs");
let vue = require("vue");
//#region src/components/surfaces/PasswordPromptSurface.vue
var _hoisted_1 = ["onKeydown"];
var _hoisted_2 = ["id"];
var _hoisted_3 = { class: "sd-password-prompt__description" };
var _hoisted_4 = { class: "sd-password-prompt__field" };
var _hoisted_5 = [
	"placeholder",
	"disabled",
	"aria-label"
];
var _hoisted_6 = {
	key: 0,
	class: "sd-password-prompt__error",
	role: "alert"
};
var _hoisted_7 = { class: "sd-password-prompt__actions" };
var _hoisted_8 = ["disabled"];
var _hoisted_9 = ["disabled"];
var _sfc_main = {
	__name: "PasswordPromptSurface",
	props: {
		surfaceId: {
			type: String,
			default: ""
		},
		mode: {
			type: String,
			default: "dialog"
		},
		request: {
			type: Object,
			default: () => ({})
		},
		resolve: {
			type: Function,
			default: () => {}
		},
		close: {
			type: Function,
			default: () => {}
		},
		passwordPrompt: {
			type: Object,
			required: true
		}
	},
	setup(__props) {
		const props = __props;
		const password = (0, vue.ref)("");
		const isBusy = (0, vue.ref)(false);
		const isInvalid = (0, vue.ref)(props.passwordPrompt.errorCode === "DOCX_PASSWORD_INVALID");
		const errorMessage = (0, vue.ref)(isInvalid.value ? props.passwordPrompt.texts.invalidMessage : "");
		const heading = (0, vue.computed)(() => isInvalid.value ? props.passwordPrompt.texts.invalidTitle : props.passwordPrompt.texts.title);
		const canSubmit = (0, vue.computed)(() => password.value.length > 0 && !isBusy.value);
		async function handleSubmit() {
			if (!canSubmit.value) return;
			isBusy.value = true;
			errorMessage.value = "";
			const result = await props.passwordPrompt.attemptPassword(password.value);
			if (result.success) {
				props.resolve({ password: password.value });
				return;
			}
			isBusy.value = false;
			password.value = "";
			if (result.errorCode === "DOCX_PASSWORD_INVALID") {
				isInvalid.value = true;
				errorMessage.value = props.passwordPrompt.texts.invalidMessage;
			} else if (result.errorCode === "timeout") errorMessage.value = props.passwordPrompt.texts.timeoutMessage;
			else errorMessage.value = props.passwordPrompt.texts.genericErrorMessage;
		}
		function handleCancel() {
			props.close("user-cancelled");
		}
		return (_ctx, _cache) => {
			return (0, vue.openBlock)(), (0, vue.createElementBlock)("div", {
				class: "sd-password-prompt",
				onKeydown: (0, vue.withKeys)((0, vue.withModifiers)(handleSubmit, ["prevent"]), ["enter"])
			}, [
				(0, vue.createElementVNode)("h3", {
					id: `sd-password-prompt-heading-${__props.surfaceId}`,
					class: "sd-password-prompt__heading"
				}, (0, vue.toDisplayString)(heading.value), 9, _hoisted_2),
				(0, vue.createElementVNode)("p", _hoisted_3, (0, vue.toDisplayString)(__props.passwordPrompt.texts.description), 1),
				(0, vue.createElementVNode)("div", _hoisted_4, [(0, vue.withDirectives)((0, vue.createElementVNode)("input", {
					"onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => password.value = $event),
					type: "password",
					class: "sd-password-prompt__input",
					placeholder: __props.passwordPrompt.texts.placeholder,
					disabled: isBusy.value,
					autocomplete: "current-password",
					"aria-label": __props.passwordPrompt.texts.inputAriaLabel
				}, null, 8, _hoisted_5), [[vue.vModelText, password.value]])]),
				errorMessage.value ? ((0, vue.openBlock)(), (0, vue.createElementBlock)("p", _hoisted_6, (0, vue.toDisplayString)(errorMessage.value), 1)) : (0, vue.createCommentVNode)("", true),
				(0, vue.createElementVNode)("div", _hoisted_7, [(0, vue.createElementVNode)("button", {
					type: "button",
					class: "sd-password-prompt__btn sd-password-prompt__btn--cancel",
					disabled: isBusy.value,
					onClick: handleCancel
				}, (0, vue.toDisplayString)(__props.passwordPrompt.texts.cancelLabel), 9, _hoisted_8), (0, vue.createElementVNode)("button", {
					type: "button",
					class: "sd-password-prompt__btn sd-password-prompt__btn--submit",
					disabled: !canSubmit.value,
					onClick: handleSubmit
				}, (0, vue.toDisplayString)(isBusy.value ? __props.passwordPrompt.texts.busyLabel : __props.passwordPrompt.texts.submitLabel), 9, _hoisted_9)])
			], 40, _hoisted_1);
		};
	}
};
var PasswordPromptSurface_default = /*#__PURE__*/ require__plugin_vue_export_helper._plugin_vue_export_helper_default(_sfc_main, [["__scopeId", "data-v-ecf7f6fb"]]);
//#endregion
exports.default = PasswordPromptSurface_default;
