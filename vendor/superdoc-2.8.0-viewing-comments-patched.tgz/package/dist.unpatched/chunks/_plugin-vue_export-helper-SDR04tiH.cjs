//#region \0plugin-vue:export-helper
var _plugin_vue_export_helper_default = (sfc, props) => {
	const target = sfc.__vccOpts || sfc;
	for (const [key, val] of props) target[key] = val;
	return target;
};
//#endregion
Object.defineProperty(exports, "_plugin_vue_export_helper_default", {
	enumerable: true,
	get: function() {
		return _plugin_vue_export_helper_default;
	}
});
