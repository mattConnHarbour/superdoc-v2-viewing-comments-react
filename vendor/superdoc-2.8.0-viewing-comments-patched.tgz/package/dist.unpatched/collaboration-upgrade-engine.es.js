import { buildV2CollaborationUpgradeArtifactFromBundle as buildV2CollaborationUpgradeArtifactFromBundle$1, getCollaborationUpgradeEngineInfo as getCollaborationUpgradeEngineInfo$1, validateV2CollaborationUpgradeTarget as validateV2CollaborationUpgradeTarget$1 } from "@superdoc/docx-engine/collaboration-upgrade-engine";
//#region src/public/collaboration-upgrade-engine.ts
/**
* SuperDoc public facade: `superdoc/collaboration-upgrade-engine`.
*
* This is a Node-only bridge used by the public v2 collaboration upgrade package.
* It deliberately exposes data-only inputs and outputs: no live Y.Doc, editor,
* provider, browser, UI, or private workspace type crosses this boundary.
*/
/** Compatibility protocol between the upgrade package and installed SuperDoc. */
var COLLABORATION_UPGRADE_ENGINE_PROTOCOL_VERSION = 1;
/** Recovery-bundle versions accepted by this engine. */
var SUPPORTED_COLLABORATION_UPGRADE_BUNDLE_VERSIONS = Object.freeze([1]);
/** Frozen final-v1 reader contracts accepted by this engine. */
var SUPPORTED_V1_READER_CONTRACT_VERSIONS = Object.freeze([1]);
/** Minimum supported Node.js major version. */
var COLLABORATION_UPGRADE_ENGINE_MINIMUM_NODE_MAJOR = 20;
var PRIVATE_ENGINE_INFO = getCollaborationUpgradeEngineInfo$1();
var ENGINE_INFO = Object.freeze({
	...PRIVATE_ENGINE_INFO,
	superdocVersion: "2.8.0",
	roomSchemaVersion: Object.freeze({ ...PRIVATE_ENGINE_INFO.roomSchemaVersion }),
	supportedBundleVersions: SUPPORTED_COLLABORATION_UPGRADE_BUNDLE_VERSIONS,
	supportedV1ReaderContractVersions: SUPPORTED_V1_READER_CONTRACT_VERSIONS
});
/** Return immutable metadata used to reject incompatible engines preflight. */
function getCollaborationUpgradeEngineInfo() {
	return ENGINE_INFO;
}
/**
* Build and offline-validate one self-contained v2 collaboration update.
*
* This function performs no provider I/O and never mutates the v1 source room.
*/
async function buildV2CollaborationUpgradeArtifactFromBundle(input) {
	assertSupportedNodeRuntime();
	return buildV2CollaborationUpgradeArtifactFromBundle$1(input);
}
/**
* Validate target bytes after a provider reads them through a fresh client.
*
* Provenance and carrier bytes are derived from the authenticated recovery
* bundle rather than accepted as independent caller assertions.
*/
async function validateV2CollaborationUpgradeTarget(input) {
	assertSupportedNodeRuntime();
	return validateV2CollaborationUpgradeTarget$1(input);
}
function assertSupportedNodeRuntime() {
	const nodeVersion = globalThis.process?.versions?.node;
	const nodeMajor = nodeVersion ? Number.parseInt(nodeVersion.split(".")[0] ?? "", 10) : NaN;
	if (!Number.isInteger(nodeMajor) || nodeMajor < 20) throw new Error(`superdoc/collaboration-upgrade-engine requires Node.js 20 or newer`);
}
//#endregion
export { COLLABORATION_UPGRADE_ENGINE_MINIMUM_NODE_MAJOR, COLLABORATION_UPGRADE_ENGINE_PROTOCOL_VERSION, SUPPORTED_COLLABORATION_UPGRADE_BUNDLE_VERSIONS, SUPPORTED_V1_READER_CONTRACT_VERSIONS, buildV2CollaborationUpgradeArtifactFromBundle, getCollaborationUpgradeEngineInfo, validateV2CollaborationUpgradeTarget };
